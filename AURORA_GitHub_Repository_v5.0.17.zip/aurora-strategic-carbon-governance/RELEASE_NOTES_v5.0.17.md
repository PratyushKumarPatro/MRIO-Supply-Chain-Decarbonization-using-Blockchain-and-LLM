## AURORA v5.0.17

Validated research deployment of the AURORA Strategic Carbon Intelligence & Governance Framework.

### Included capabilities

- EE-MRIO focal-company carbon accounting and producer-origin hotspots
- Dynamically bounded SPA reporting and four-factor company/node/path SDA
- Network leverage, Carbon Footprint Dependency, pooled Pearson-CRITIC DLI, and robustness analysis
- Regional opportunity assessment and complete decision-trace exports
- Evidence-bound intervention development, abatement assessment, and human governance
- Four-contract Solidity governance layer, content-addressed evidence, and audit trail
- Local governed LLM decision support using Ollama
- Publication-readable plot typography

### Validation

- Deployment archive SHA-256 verified
- 255 Python regression tests passed
- Python source compilation passed
- Source-matched Solidity artifacts and contract validation records included

### Data boundary

Operational MRIO and focal-company workbooks are not included. Users must supply workbooks conforming to the schemas and unit conventions documented in the repository.

### Deployment boundary

This is a local research prototype based on Windows PowerShell, Ganache, Streamlit, and Ollama. It is not a production identity, credential-management, or blockchain deployment.
