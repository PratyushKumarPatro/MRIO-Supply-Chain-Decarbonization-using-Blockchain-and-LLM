# AURORA: Strategic Carbon Intelligence & Governance Framework

AURORA is a research-grade decision-support framework for governed low-carbon supply-chain analysis. It combines environmentally extended multi-regional input-output (EE-MRIO) accounting, structural path analysis (SPA), structural decomposition analysis (SDA), network leverage and CRITIC-weighted DLI, regional opportunity assessment, evidence-bound intervention development, blockchain governance, and a locally hosted LLM assistant.

The repository contains the complete validated source package for version **5.0.17**. Operational MRIO and focal-company workbooks are deliberately excluded.

> **Research prototype:** this release is designed for reproducible local research and evaluation. It is not a production blockchain, identity, or credential-management system.

## Framework flow

```mermaid
flowchart TD
    A["Governed MRIO and demand inputs"] --> B["Carbon footprint and producer hotspots"]
    B --> C["SPA and SDA"]
    C --> D["Network leverage, CFD and DLI"]
    D --> E["Regional opportunity assessment"]
    E --> F["Evidence-bound interventions"]
    F --> G["Blockchain governance and audit"]
    G --> H["Governed LLM decision support"]
```

## What is included

- Deterministic EE-MRIO carbon-footprint accounting for 2014 and 2017.
- Producer-origin hotspot analysis and dynamically bounded SPA reporting to at least 87% of the complete focal-company footprint.
- Company-, node-, and union-path-level four-factor SDA.
- Network measures, Carbon Footprint Dependency (CFD), pooled Pearson-CRITIC weighting, DLI, and robustness diagnostics.
- Regional opportunity assessment using similarity, carbon, linkage, Pareto, and temporal-evidence gates.
- Deterministic intervention mapping, actionability and feasibility recording, evidence-bound abatement scenarios, and formal human approval or rejection.
- Four role-aware Solidity contracts, a local Ganache chain, content-addressed evidence, and an auditable transaction/event trail.
- A local Ollama-based LLM assistant that retrieves and explains governed evidence without replacing the deterministic analytical modules.
- 255 Python regression tests, Solidity compilation and contract-workflow validation scripts, and source-file SHA-256 manifests.

## Terminology used in the paper and code

| Paper/public term | Backward-compatible source identifier | Interpretation |
| --- | --- | --- |
| AURORA | `AURORA` | AURORA names the complete framework. Some retained internal identifiers use `aurora` for the regional-opportunity component; those identifiers remain unchanged to preserve validated source and artifact compatibility. |
| Carbon Footprint Dependency (CFD) | `CDR` in legacy fields, modules, tests, and stored artifacts | Dimensionless complete-node-removal dependency measure used as one DLI criterion. Public reporting should use CFD. |
| Dependency Leverage Index (DLI) | `DLI` | CRITIC-weighted composite of normalized network and dependency criteria; it is not an emissions or abatement quantity. |

## Quick start

The validated end-to-end launcher targets **Windows 10/11 with PowerShell**. Install these prerequisites first:

- Python 3.10 or newer
- Node.js 18–24 and npm
- [Ollama](https://ollama.com/) available on `127.0.0.1:11434`
- Git, when cloning the repository

Clone and enter the platform directory:

```powershell
git clone <REPOSITORY_URL>
Set-Location .\aurora-strategic-carbon-governance\platform
```

Create the isolated Python environment, install dependencies, compile the contracts, and run the complete offline regression battery:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt -r .\streamlit_app\requirements.txt
.\.venv\Scripts\python.exe -m pip check

npm ci
npm run compile
npm run validate:contract

.\.venv\Scripts\python.exe -m unittest discover -v
.\.venv\Scripts\python.exe -m compileall -q .
```

Pull the default local language model and start a clean Ganache chain in the same PowerShell window:

```powershell
ollama pull qwen3:4b
npx ganache -p 8545 --wallet.totalAccounts 10
```

Leave Ganache running. In a **second PowerShell window**, start a fresh application lifecycle:

```powershell
Set-Location .\aurora-strategic-carbon-governance\platform
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\start_dapp_lifecycle.ps1 -Reset
```

The interface opens at <http://127.0.0.1:8501>. The local Data Orchestrator uses port `8765`; Ganache uses `8545`; Ollama uses `11434`.

For the complete clone, release-archive, validation, deployment, input, workflow, and troubleshooting commands, see [Testing and deployment](docs/TESTING_AND_DEPLOYMENT.md).

If you received the repository as an upload kit rather than through GitHub, follow [Publishing to GitHub](docs/GITHUB_PUBLICATION.md) to create the public repository and immutable release.

## Required research inputs

No operational data are committed. A full analytical run requires:

1. An `.xlsx` EE-MRIO workbook with sheets `2014`, `2017`, and `Metadata`, 455 unique and consistently ordered nodes, aligned matrices, and the unit convention documented in `platform/UPLOAD_INPUTS_GUIDE.txt`.
2. An `.xlsx` focal-company workbook with sheet `Converted_Demand` and columns `Node_Code`, `Company_2014_USD`, and `Company_2017_USD`, containing exactly the same 455 nodes and order.

The MRIO workbook is interpreted in million USD and Mt CO2. The focal-demand workbook is interpreted in ordinary USD; focal-company carbon results are reported in t CO2. The platform performs no hidden rescaling.

## Reproducibility boundaries

- Hotspot values are producer-origin emissions; SPA path values attribute emissions to the path's producing endpoint and should not be added indiscriminately across overlapping paths.
- CFD and producer-linkage results are structural counterfactual diagnostics, not predicted abatement.
- DLI indicates governance leverage, not emissions magnitude.
- SDA explains historical change drivers; it does not forecast intervention performance.
- Regional-opportunity evidence does not by itself justify supplier substitution or assert functional equivalence.
- Scenario reductions are assumption-bound comparative estimates. Observed reductions require separately submitted like-for-like monitoring evidence.
- Blockchain records authorization, sequence, provenance, and integrity; it does not establish the external truth of an uploaded document.
- The LLM retrieves and explains governed results. It cannot alter analytical values, invent feasibility, approve an intervention, or change lifecycle state.

## Repository layout

```text
.
├── README.md
├── docs/
│   └── TESTING_AND_DEPLOYMENT.md
├── platform/
│   ├── contracts/
│   ├── streamlit_app/
│   ├── tests/
│   ├── assurance_history/
│   ├── BUILD_MANIFEST_SHA256.txt
│   ├── U23_WINDOWS_DEPLOYMENT_COMMANDS.txt
│   └── start_dapp_lifecycle.ps1
└── .github/workflows/validate.yml
```

The `platform/BUILD_MANIFEST_SHA256.txt` file covers the validated deployment package. Repository-level documentation and automation files are intentionally outside that manifest.

## Security and deployment scope

The supplied Ganache accounts, role bootstrap, local content store, and localhost services are for controlled research evaluation. Do not expose ports `8501`, `8545`, `8765`, or `11434` to untrusted networks. Before any production use, replace local test accounts with governed credentials, implement secrets management and access control, secure off-chain storage, use an approved blockchain network, and complete independent security and privacy review.

## Validation status

The final source archive passed SHA-256 verification. In the preparation environment, all **255 Python regression tests** and Python bytecode compilation passed. JavaScript/Solidity dependency installation could not be repeated in that restricted environment because access to the npm package registry was blocked; the repository therefore retains the source-matched artifacts and contract validation records from the validated release, and the documented `npm ci`, `npm run compile`, and `npm run validate:contract` commands remain mandatory on the deployment computer.

## Citation

When referring to the software in the paper, use the public GitHub repository URL and the immutable `v5.0.17` release URL. A DOI can be added later by archiving that tagged release through Zenodo without changing the repository link.
