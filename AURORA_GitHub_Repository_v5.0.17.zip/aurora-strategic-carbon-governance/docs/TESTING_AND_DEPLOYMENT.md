# Testing and deployment

This guide provides copy-ready commands for verifying, testing, and deploying AURORA v5.0.17. The validated end-to-end runtime is Windows/PowerShell based. Linux runners can execute the static Python and contract test battery, but the supplied lifecycle launcher is PowerShell/Windows specific.

## 1. Prerequisites

Install and verify:

```powershell
python --version
node --version
npm --version
git --version
ollama --version
```

Required ranges and services:

| Component | Requirement | Purpose |
| --- | --- | --- |
| Windows | Windows 10/11 | Validated runtime target |
| PowerShell | Windows PowerShell 5.1 or newer | Lifecycle launcher |
| Python | 3.10 or newer | Analytics, orchestration, UI, and tests |
| Node.js | 18–24 | Solidity compilation and Ganache |
| Ollama | Current local installation | LLM planner and answer synthesis |
| Browser | Current Chromium, Firefox, or Edge | Streamlit interface |

The first setup downloads Python and npm dependencies and the `qwen3:4b` model, so internet access is required. Later local runs can be offline once dependencies and the model are present.

## 2. Obtain the code

### Option A — clone the source repository

```powershell
Set-Location "$env:USERPROFILE\Documents"
git clone <REPOSITORY_URL>
Set-Location .\aurora-strategic-carbon-governance\platform
```

### Option B — use the immutable release archive

Download these two assets from the `v5.0.17` GitHub release:

- `AURORA_v5.0.17_windows_deployable.zip`
- `AURORA_v5.0.17_windows_deployable.zip.sha256`

Verify and extract them:

```powershell
$ReleaseZip = "$env:USERPROFILE\Downloads\AURORA_v5.0.17_windows_deployable.zip"
$ChecksumFile = "$ReleaseZip.sha256"
$InstallRoot = "$env:USERPROFILE\Documents\aurora-v5.0.17"

if (-not (Test-Path -LiteralPath $ReleaseZip)) { throw "Release ZIP not found: $ReleaseZip" }
if (-not (Test-Path -LiteralPath $ChecksumFile)) { throw "Checksum file not found: $ChecksumFile" }

$Expected = ((Get-Content -LiteralPath $ChecksumFile -Raw).Trim() -split '\s+')[0].ToLower()
$Actual = (Get-FileHash -Algorithm SHA256 -LiteralPath $ReleaseZip).Hash.ToLower()
if ($Actual -ne $Expected) { throw "SHA-256 verification failed." }

New-Item -ItemType Directory -Path $InstallRoot -Force | Out-Null
Expand-Archive -LiteralPath $ReleaseZip -DestinationPath $InstallRoot -Force
Set-Location "$InstallRoot\DEPLOY_FINAL"
```

The release archive preserves the original validated `DEPLOY_FINAL` directory. The cloned repository stores the same files under `platform`.

## 3. Clean installation and static validation

Run these commands from `platform` for a clone, or `DEPLOY_FINAL` for an extracted release:

```powershell
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt -r .\streamlit_app\requirements.txt
.\.venv\Scripts\python.exe -m pip check

npm ci
npm run compile
npm run validate:contract

.\.venv\Scripts\python.exe -m unittest discover -v
.\.venv\Scripts\python.exe -m compileall -q .
```

Expected gates:

- `pip check` reports no broken requirements.
- Solidity compilation uses `solc 0.8.19`, optimizer runs `200`, and the Paris EVM target.
- `npm run validate:contract` exits with status 0.
- The Python suite reports `Ran 255 tests` and `OK` for this release.
- `compileall` exits silently with status 0.

Do not continue to the live deployment if compilation, contract validation, or the Python regression battery fails.

### Optional manifest verification

From the platform directory, verify every file listed in the curated source manifest:

```powershell
$Failures = @()
Get-Content .\BUILD_MANIFEST_SHA256.txt | ForEach-Object {
    if ($_ -match '^([0-9a-f]{64})\s{2}(.+)$') {
        $ExpectedHash = $Matches[1]
        $RelativePath = $Matches[2].Replace('/', '\')
        if (-not (Test-Path -LiteralPath $RelativePath -PathType Leaf)) {
            $Failures += "Missing: $RelativePath"
        } elseif ((Get-FileHash -Algorithm SHA256 -LiteralPath $RelativePath).Hash.ToLower() -ne $ExpectedHash) {
            $Failures += "Hash mismatch: $RelativePath"
        }
    }
}
if ($Failures.Count -gt 0) { $Failures | ForEach-Object { Write-Error $_ }; throw "Manifest verification failed." }
Write-Host "Manifest verification passed." -ForegroundColor Green
```

Run this check before `npm run compile` if you want to compare a release extraction byte-for-byte with the distributed source package.

## 4. Start local services

Pull the default model once:

```powershell
ollama pull qwen3:4b
```

Confirm that Ollama is reachable:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:11434/api/tags -Method Get
```

Start a clean Ganache chain and leave the window open:

```powershell
npx ganache -p 8545 --wallet.totalAccounts 10
```

In a second PowerShell window, return to the platform directory and run:

```powershell
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\start_dapp_lifecycle.ps1 -Reset
```

The `-Reset` switch is mandatory for a new validation deployment. It prevents stale contract addresses, runtime evidence, and prior input bindings from being reused.

Service endpoints:

| Service | Address |
| --- | --- |
| Streamlit interface | <http://127.0.0.1:8501> |
| Data Orchestrator health | <http://127.0.0.1:8765/health> |
| Ganache JSON-RPC | <http://127.0.0.1:8545> |
| Ollama | <http://127.0.0.1:11434> |

Check the Data Orchestrator independently:

```powershell
Invoke-RestMethod -Uri http://127.0.0.1:8765/health -Method Get | ConvertTo-Json -Depth 8
```

## 5. Prepare and upload input workbooks

The repository intentionally contains no operational MRIO or focal-company data.

### MRIO workbook

The workbook must:

- contain `2014`, `2017`, and `Metadata` sheets;
- describe exactly 455 unique nodes in a consistent order;
- contain aligned transaction, output, final-demand, and emissions information required by the validator;
- reconstruct the Leontief system and emissions identity within the implemented validation tolerances; and
- follow the fixed unit convention: MRIO monetary values in million USD and direct emissions in Mt CO2.

### Focal-company demand workbook

The workbook must contain a `Converted_Demand` sheet with:

```text
Node_Code
Company_2014_USD
Company_2017_USD
```

It must contain exactly 455 rows in the same `Node_Code` order as the active MRIO metadata. Demand is entered in ordinary USD. See `UPLOAD_INPUTS_GUIDE.txt` and `UNIT_CONSISTENCY_NO_RESCALING_GUIDE.txt` for the authoritative package-level validation rules.

## 6. Guided end-to-end workflow

Use the **Governance & Audit Control** page and complete the lifecycle in order:

1. Register the regulatory authority, focal company, MRIO data provider, and four oracle roles.
2. Deploy the Registration contract from the authorized account.
3. Upload, validate, request, fulfil, and promote the MRIO workbook.
4. Upload, validate, request, fulfil, and promote the focal-company demand workbook.
5. Run footprint accounting and producer-origin hotspot analysis.
6. Run bounded SPA for 2014 and 2017.
7. Run company-, node-, and path-level SDA.
8. Run Network/DLI for 2014 first, then 2017. The 2017 fulfilment creates the authoritative pooled two-year Pearson-CRITIC evidence.
9. Run the regional opportunity assessment for 2017.
10. On the Blockchain and LLM-based System page, compute intervention evidence and candidate mappings.
11. Select a producer hotspot and a linked leverage node; inspect the deterministic driver-to-mechanism mapping.
12. Record node-level actionability and pair-specific technical feasibility.
13. Either quantify a conservative/expected/ambitious scenario with evidence, coverage, adoption, and limitations, or explicitly document why quantification is not defensible.
14. Generate governance-ready options, select one, complete Oracle verification, and separately approve or reject it using an authorized human decision account.
15. Open final LLM decision support only after the intervention-governance branch is resolved.
16. For an implemented approved intervention, append a like-for-like monitored footprint and evidence reference without overwriting the original scenario.

The Intervention Governance sidebar is a read-only result, comparison, provenance, and download surface. State-changing actions remain on the Blockchain and LLM-based System page.

## 7. Live runtime methodology audit

After Query Management is deployed and all services are running, execute:

```powershell
.\.venv\Scripts\python.exe .\validate_runtime_methodology.py --output .\runtime_methodology_validation.json
```

Do not report the deployed method as verified if this live audit fails. The audit checks current inputs, contract identities, ordered Network/DLI evidence, regional-opportunity binding, intervention-governance resolution, content hashes, and final-query readiness.

## 8. LLM validation prompts

Use these only after the governed analytical and intervention lifecycle is complete. Replace bracketed identifiers with values visible in the interface.

```text
What is the focal-company carbon footprint in 2017, and what governed evidence supports the value?
```

```text
Explain why [node_code] can have high DLI even if it is not a major producer-origin emissions hotspot.
```

```text
For [node_code], distinguish the primary adverse node-SDA driver from the supporting path-SDA evidence.
```

```text
Summarize the evidence chain for intervention [intervention_id], including actionability, feasibility, scenario status, Oracle verification, and human decision.
```

```text
Distinguish the baseline hotspot footprint, structurally associated footprint, scenario abatement range, and observed reduction for [intervention_id].
```

Acceptance checks:

- Exact numerical answers identify the governed year and evidence source.
- Hotspot emissions are not confused with demand/transmission participation.
- DLI is not described as t CO2 or predicted abatement.
- Regional opportunity evidence is not presented as proof of functional supplier equivalence.
- Scenario estimates are not described as observed outcomes.
- The assistant does not invent actionability, feasibility, approval, or monitoring evidence.

## 9. Clean restart

Stop the Streamlit process with `Ctrl+C`, close the Ganache window, and run a fresh local chain before the next clean experiment:

```powershell
npx ganache -p 8545 --wallet.totalAccounts 10
```

Then restart with:

```powershell
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\start_dapp_lifecycle.ps1 -Reset
```

Do not copy `deployment.json`, `runtime`, `content_store`, `.venv`, `node_modules`, old contract addresses, or operational workbooks between clean release extractions.

## 10. Troubleshooting

### Python environment is missing or incomplete

```powershell
Remove-Item -LiteralPath .\.venv -Recurse -Force -ErrorAction SilentlyContinue
python -m venv .venv
.\.venv\Scripts\python.exe -m pip install --upgrade pip
.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt -r .\streamlit_app\requirements.txt
.\.venv\Scripts\python.exe -m pip check
```

### Solidity compiler or artifacts do not match

```powershell
Remove-Item -LiteralPath .\node_modules -Recurse -Force -ErrorAction SilentlyContinue
npm ci
npm run compile
npm run validate:contract
```

### A port is already in use

Inspect listeners:

```powershell
Get-NetTCPConnection -State Listen | Where-Object LocalPort -In 8501,8545,8765,11434 |
    Select-Object LocalAddress,LocalPort,OwningProcess
```

Stop only the confirmed stale process:

```powershell
Stop-Process -Id <PROCESS_ID>
```

### Data Orchestrator does not start

Inspect the current package-local logs:

```powershell
Get-Content .\runtime\orchestrator_stdout.log -Tail 100 -ErrorAction SilentlyContinue
Get-Content .\runtime\orchestrator_stderr.log -Tail 100 -ErrorAction SilentlyContinue
```

Confirm Ganache is running and then rerun the launcher with `-Reset`.

### Ollama model is unavailable

```powershell
ollama list
ollama pull qwen3:4b
Invoke-RestMethod -Uri http://127.0.0.1:11434/api/tags -Method Get
```

The deterministic analytical modules remain authoritative even when the local model is unavailable; however, live LLM validation and model-generated explanations require a reachable configured model.

## 11. Production boundary

This local deployment uses Ganache-managed test accounts and localhost services. It is suitable for research demonstration and reproducibility testing, not production operations. Production use requires governed identities and keys, secrets management, network and storage security, privacy controls, an approved blockchain environment, monitoring, backup and recovery, and independent security review.
