# Publishing AURORA to GitHub

This guide publishes the prepared source repository and its immutable deployable release. It assumes the recommended public repository name `aurora-strategic-carbon-governance`. Replace `<USERNAME>` with your GitHub username or organization.

No software license has been added automatically. Before publishing, choose one deliberately: MIT permits broad reuse with attribution; Apache-2.0 adds an explicit patent grant; publishing without a license reserves reuse rights by default.

## Option A — Git command line

### 1. Create the empty GitHub repository

In GitHub, select **New repository** and use:

- Repository name: `aurora-strategic-carbon-governance`
- Description: `AURORA framework for MRIO-based supply-chain carbon intelligence, intervention governance, blockchain auditability, and governed LLM decision support.`
- Visibility: **Public** when the link must be accessible to journal reviewers and readers
- Do not initialize it with a README, `.gitignore`, or license; those choices are handled in the prepared source

### 2. Extract the repository upload kit

Extract `AURORA_GitHub_Repository_v5.0.17.zip`, open PowerShell, and enter the extracted directory:

```powershell
Set-Location "$env:USERPROFILE\Downloads\aurora-strategic-carbon-governance"
```

### 3. Add a license if required

If you selected a license when creating the GitHub repository, download the generated `LICENSE` file and place it in this directory before committing. If the GitHub repository was created empty, add the chosen license text as `LICENSE` here.

### 4. Initialize and push the source

```powershell
git init -b main
git add .
git status
git commit -m "Publish AURORA v5.0.17"
git remote add origin https://github.com/<USERNAME>/aurora-strategic-carbon-governance.git
git push -u origin main
```

If GitHub requests authentication, use Git Credential Manager, the GitHub CLI, or a personal access token as instructed by GitHub. Do not place credentials in the repository, command history, README, or configuration files committed to source control.

### 5. Replace repository URL placeholders

After the first push, replace `<REPOSITORY_URL>` in `README.md` and `docs/TESTING_AND_DEPLOYMENT.md` with:

```text
https://github.com/<USERNAME>/aurora-strategic-carbon-governance.git
```

Commit and push the change:

```powershell
git add README.md docs/TESTING_AND_DEPLOYMENT.md
git commit -m "Add public repository URLs"
git push
```

## Option B — GitHub CLI

After extracting the upload kit and entering its directory:

```powershell
gh auth login
git init -b main
git add .
git commit -m "Publish AURORA v5.0.17"
gh repo create aurora-strategic-carbon-governance --public --source . --remote origin --push --description "AURORA framework for MRIO-based supply-chain carbon intelligence, intervention governance, blockchain auditability, and governed LLM decision support."
```

Then replace the URL placeholders and push as described above.

## Create the immutable v5.0.17 release

Keep these two files together:

- `AURORA_v5.0.17_windows_deployable.zip`
- `AURORA_v5.0.17_windows_deployable.zip.sha256`

### GitHub website

1. Open the repository and select **Releases** → **Draft a new release**.
2. Create tag `v5.0.17` from `main`.
3. Set the release title to `AURORA v5.0.17 — validated research deployment`.
4. Paste the release notes below.
5. Attach the ZIP and SHA-256 files.
6. Publish the release.

### GitHub CLI

Run from the directory containing the two release assets:

```powershell
gh release create v5.0.17 `
  .\AURORA_v5.0.17_windows_deployable.zip `
  .\AURORA_v5.0.17_windows_deployable.zip.sha256 `
  --repo <USERNAME>/aurora-strategic-carbon-governance `
  --target main `
  --title "AURORA v5.0.17 — validated research deployment" `
  --notes-file .\RELEASE_NOTES_v5.0.17.md
```

## Release notes

Use the following text as `RELEASE_NOTES_v5.0.17.md` or paste it into the GitHub release form:

```markdown
## AURORA v5.0.17

Validated research deployment of the AURORA Strategic Carbon Intelligence & Governance Framework.

### Included capabilities

- EE-MRIO focal-company carbon accounting and producer-origin hotspots
- Dynamically bounded SPA reporting and four-factor company/node/path SDA
- Network leverage, Carbon Footprint Dependency, pooled Pearson-CRITIC DLI, and robustness analysis
- Regional opportunity assessment and complete decision-trace exports
- Evidence-bound intervention development, abatement assessment, and human governance
- Four-contract Solidity governance layer, content-addressed evidence, and audit trail
- Local governed LLM decision support using Ollama
- Publication-readable plot typography

### Validation

- Deployment archive SHA-256 verified
- 255 Python regression tests passed
- Python source compilation passed
- Source-matched Solidity artifacts and contract validation records included

### Data boundary

Operational MRIO and focal-company workbooks are not included. Users must supply workbooks conforming to the schemas and unit conventions documented in the repository.

### Deployment boundary

This is a local research prototype based on Windows PowerShell, Ganache, Streamlit, and Ollama. It is not a production identity, credential-management, or blockchain deployment.
```

## Verify the published release

Download both release assets to a clean directory and run:

```powershell
$ReleaseZip = ".\AURORA_v5.0.17_windows_deployable.zip"
$Expected = ((Get-Content "$ReleaseZip.sha256" -Raw).Trim() -split '\s+')[0].ToLower()
$Actual = (Get-FileHash -Algorithm SHA256 $ReleaseZip).Hash.ToLower()
if ($Actual -ne $Expected) { throw "Published release checksum failed." }
Write-Host "Published release checksum passed." -ForegroundColor Green
```

Expected SHA-256:

```text
5447624f4eadd0b9734dd851c9f7cc085da1ef33bcf70f0bcfb3d2d35648f947
```

## Links for the paper

Use the repository link for the general software-availability statement:

```text
https://github.com/<USERNAME>/aurora-strategic-carbon-governance
```

Use the immutable release link when identifying the exact evaluated version:

```text
https://github.com/<USERNAME>/aurora-strategic-carbon-governance/releases/tag/v5.0.17
```

Suggested paper wording:

> The AURORA framework source code, deployment instructions, validation tests, and the immutable v5.0.17 research release are available at: https://github.com/<USERNAME>/aurora-strategic-carbon-governance.

Check both links in a signed-out/private browser window before submitting the paper. A private repository URL will not be accessible to reviewers unless access is granted separately.
