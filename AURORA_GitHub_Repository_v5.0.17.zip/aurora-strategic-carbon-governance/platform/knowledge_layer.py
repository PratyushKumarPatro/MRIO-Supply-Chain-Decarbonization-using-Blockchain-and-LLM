"""Curated conceptual and methodological knowledge for the Strategic Carbon Intelligence & Governance assistant.

This module separates three evidence classes that must not be conflated:

1. conceptual knowledge - definitions and distinctions;
2. methodology knowledge - how the deployed study implements a concept;
3. analytical evidence - numerical results produced by deterministic engines.

The matcher is deterministic. Exact aliases are preferred and TF-IDF is used
only as a fallback within the requested evidence class. The local LLM may
rephrase returned records, but it is not the source of research-specific facts.
"""
from __future__ import annotations

import json
import re
from functools import lru_cache
from pathlib import Path
from typing import Any, Iterable

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

import query_intelligence as qi

BASE_DIR = Path(__file__).resolve().parent


def _knowledge_path() -> Path:
    candidates = [
        BASE_DIR / "data" / "domain_knowledge.json",
        BASE_DIR / "domain_knowledge.json",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError(
        "domain_knowledge.json was not found beside knowledge_layer.py or in its data folder"
    )


@lru_cache(maxsize=1)
def load_knowledge() -> dict[str, Any]:
    with _knowledge_path().open(encoding="utf-8") as handle:
        payload = json.load(handle)
    if not isinstance(payload, dict):
        raise ValueError("domain_knowledge.json must contain a JSON object")
    payload.setdefault("concepts", [])
    payload.setdefault("methodologies", [])
    return payload


def _normalise(text: Any) -> str:
    value = str(text or "").casefold().replace("-", " ").replace("_", " ")
    value = re.sub(r"[^a-z0-9%]+", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def _entry_text(entry: dict[str, Any], kind: str) -> str:
    aliases = " ".join(str(x) for x in entry.get("aliases", []))
    if kind == "concepts":
        return " ".join(
            [
                str(entry.get("term", "")),
                aliases,
                str(entry.get("definition", "")),
                str(entry.get("framework_application", "")),
                " ".join(str(x) for x in entry.get("related_terms", [])),
            ]
        )
    return " ".join(
        [
            str(entry.get("title", "")),
            aliases,
            str(entry.get("purpose", "")),
            " ".join(str(x) for x in entry.get("procedure", [])),
            str(entry.get("boundary", "")),
            " ".join(str(x) for x in entry.get("modules", [])),
        ]
    )


def _alias_hits(query: str, entry: dict[str, Any]) -> list[tuple[str, float]]:
    q = _normalise(query)
    hits: list[tuple[str, float]] = []
    labels = [entry.get("term"), entry.get("title"), *entry.get("aliases", [])]
    for label in labels:
        alias = _normalise(label)
        if not alias:
            continue
        if q == alias:
            hits.append((str(label), 1.0))
            continue
        pattern = r"(?<![a-z0-9])" + re.escape(alias) + r"(?![a-z0-9])"
        if re.search(pattern, q):
            # Longer, more specific aliases receive a modest deterministic boost.
            specificity = min(0.12, len(alias.split()) * 0.02)
            hits.append((str(label), 0.84 + specificity))
    return hits


@lru_cache(maxsize=4)
def _tfidf_index(kind: str):
    entries = load_knowledge().get(kind, [])
    if not entries:
        return [], None, None
    corpus = [_entry_text(entry, kind) for entry in entries]
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(corpus)
    return entries, vectorizer, matrix


def match_entries(
    query: str,
    kind: str,
    top_n: int = 3,
    minimum_score: float = 0.10,
) -> list[dict[str, Any]]:
    """Return deterministic matches from one evidence class.

    Exact alias matches are returned first and normally suppress weak semantic
    neighbours. TF-IDF is a fallback for paraphrases, not a mechanism for mixing
    conceptual definitions with analytical summaries.
    """

    if kind not in {"concepts", "methodologies"}:
        raise ValueError("kind must be 'concepts' or 'methodologies'")
    entries, vectorizer, matrix = _tfidf_index(kind)
    if not entries:
        return []

    exact: list[tuple[int, str, float]] = []
    for index, entry in enumerate(entries):
        hits = _alias_hits(query, entry)
        if hits:
            label, score = max(hits, key=lambda item: item[1])
            exact.append((index, label, score))

    if exact:
        # Prefer the most specific exact match. Keep multiple records only when
        # the question explicitly names multiple distinct concepts/methods.
        exact.sort(key=lambda item: (-item[2], -len(_normalise(item[1]))))
        selected: list[dict[str, Any]] = []
        seen_ids: set[str] = set()
        for index, label, score in exact:
            entry = dict(entries[index])
            entry_id = str(entry.get("id", index))
            if entry_id in seen_ids:
                continue
            seen_ids.add(entry_id)
            entry["match_score"] = float(score)
            entry["match_reason"] = f"exact alias: {label}"
            selected.append(entry)
            if len(selected) >= top_n:
                break
        return selected

    if vectorizer is None or matrix is None:
        return []
    similarities = cosine_similarity(vectorizer.transform([query]), matrix).flatten()
    order = similarities.argsort()[::-1]
    selected = []
    for index in order:
        score = float(similarities[index])
        if score < minimum_score:
            continue
        entry = dict(entries[index])
        entry["match_score"] = score
        entry["match_reason"] = "TF-IDF similarity within curated evidence class"
        selected.append(entry)
        if len(selected) >= top_n:
            break
    return selected


def match_concepts(query: str, top_n: int = 3) -> list[dict[str, Any]]:
    return match_entries(query, "concepts", top_n=top_n)


def match_methodologies(query: str, top_n: int = 3) -> list[dict[str, Any]]:
    return match_entries(query, "methodologies", top_n=top_n)


def _contains_any(text: str, patterns: Iterable[str]) -> bool:
    return any(re.search(pattern, text) for pattern in patterns)


def analyse_knowledge_intent(
    question: str,
    *,
    named_node: str = "",
) -> dict[str, Any]:
    """Classify definition and study-method needs without using the LLM.

    The result is intentionally multi-label. A question can ask for a concept,
    the study's implementation, and numerical evidence in the same sentence.
    """

    q = question.casefold().strip()
    meta_hint = qi.deterministic_understanding(question)
    if meta_hint.get("route_hint") == "system_meta":
        return {
            "conceptual": False,
            "methodological": False,
            "definition_cue": False,
            "methodology_cue": False,
            "empirical_cue": False,
            "concept_matches": [],
            "methodology_matches": [],
            "system_meta": True,
            "routing_note": (
                "Deployment and architecture questions are handled by the curated system-knowledge route, not by conceptual similarity retrieval."
            ),
        }
    concept_matches = match_concepts(question, top_n=4)
    methodology_matches = match_methodologies(question, top_n=4)

    definition_patterns = [
        r"^\s*what\s+(?:is|are)\b",
        r"\bdefine\b",
        r"\bdefinition\b",
        r"\bmeaning\b",
        r"\bwhat\s+does\b.*\bmean\b",
        r"\bin simple terms\b",
        r"\bexplain\b",
        r"\btell me about\b",
        r"\bdifference between\b",
        r"\bhow does\b.*\bdiffer\b",
    ]
    methodology_patterns = [
        r"\bmethod(?:ology)?\b",
        r"\bcalculated\b",
        r"\bcomputed\b",
        r"\bformula\b",
        r"\bequation\b",
        r"\bimplemented\b",
        r"\boperationali[sz]ed\b",
        r"\bprocedure\b",
        r"\bsteps?\b",
        r"\bdata source\b",
        r"\bassumptions?\b",
        r"\blimitations?\b",
        r"\bvalidation\b",
        r"\bwhy (?:use|did .* use|is .* used)\b",
        # A generic "how does X differ" is conceptual rather than
        # methodological.  Treat a how-question as methodology only when it
        # asks about calculation, implementation, use, or validation in the
        # study/deployment.
        r"\bhow\s+(?:is|are|was|were)\b.{0,90}\b(?:calculat|comput|implement|operationali[sz]|construct|deriv|estimat|measur|validat)\w*\b",
        r"\bhow\s+(?:do|does|did)\s+(?:this study|the study|the model|the framework|the deployment|we)\b.{0,90}\b(?:calculat|comput|implement|use|apply|deriv|estimat|validat|work)\w*\b",
        r"\bhow\s+(?:is|are|was|were)\b.{0,90}\bused\b.{0,60}\b(?:study|framework|deployment)\b",
        r"\bhow\s+does\b.{0,90}\bwork\b.{0,60}\b(?:study|framework|deployment)\b",
    ]
    empirical_patterns = [
        r"\b20(?:14|17)\b",
        r"\bour\b",
        r"\bfocal[- ]company\b",
        r"\bcompany'?s\b",
        r"\brank(?:ed|ing)?\b",
        r"\bscore\b",
        r"\bvalue\b",
        r"\bresult\b",
        r"\bwhich\b",
        r"\btop\b",
        r"\bhighest\b",
        r"\bchange(?:d)?\b",
        r"\bincrease(?:d)?\b",
        r"\bdecrease(?:d)?\b",
        r"\bscenario\b",
        r"\bwhat would\b",
        r"\bhow much\b",
        r"\bhow many\b",
        r"\bpercent\b|%",
    ]

    definition_cue = _contains_any(q, definition_patterns)
    methodology_cue = _contains_any(q, methodology_patterns)
    empirical_cue = bool(named_node) or _contains_any(q, empirical_patterns)

    # Curated concepts can explicitly point to the study-method record that
    # operationalises them.  This resolves concise questions such as "How is
    # SDA calculated in this study?" without relying on a loose semantic
    # similarity threshold.  The link is activated only by a methodology cue,
    # so a conceptual comparison such as "How does DLI differ from a hotspot?"
    # remains conceptual.
    if methodology_cue and concept_matches:
        methods_by_id = {
            str(item.get("id")): item
            for item in load_knowledge().get("methodologies", [])
        }
        linked: list[dict[str, Any]] = []
        linked_ids: set[str] = set()
        for concept in concept_matches:
            for method_id in concept.get("methodology_ids", []) or []:
                method_id = str(method_id)
                if method_id in linked_ids or method_id not in methods_by_id:
                    continue
                item = dict(methods_by_id[method_id])
                item["match_score"] = 0.99
                item["match_reason"] = (
                    f"curated concept-to-method link from {concept.get('id')}"
                )
                linked.append(item)
                linked_ids.add(method_id)

        methodology_matches = linked + [
            item
            for item in methodology_matches
            if str(item.get("id")) not in linked_ids
        ]
        # Remove any accidental duplicate while preserving curated-link order.
        deduplicated: list[dict[str, Any]] = []
        seen: set[str] = set()
        for item in methodology_matches:
            key = str(item.get("id", ""))
            if key and key in seen:
                continue
            if key:
                seen.add(key)
            deduplicated.append(item)
        methodology_matches = deduplicated[:4]

    explicit_definition = _contains_any(
        q,
        [
            r"\bdefine\b",
            r"\bdefinition\b",
            r"\bmeaning\b",
            r"\bwhat\s+does\b.*\bmean\b",
            r"\bin simple terms\b",
            r"\bconcept\b",
            r"^\s*explain\s+(?!why\b|how\b)",
            r"^\s*tell me about\b",
            r"^\s*what\s+(?:is|are)\b.*\band\b",
        ],
    )

    # "What is DLI of ARE-nmm?" requests a node value, whereas "What does DLI
    # mean for ARE-nmm?" genuinely contains both conceptual and empirical intent.
    metric_of_node = bool(
        named_node
        and re.search(r"^\s*what\s+(?:is|are)\b.*\b(?:of|for)\b", q)
        and not re.search(r"\bmean(?:ing)?\b|\bdefine\b|\bconcept\b", q)
    )

    conceptual = bool(concept_matches) and definition_cue and (
        not empirical_cue or explicit_definition
    )
    if metric_of_node:
        conceptual = False

    methodological = bool(methodology_matches) and methodology_cue

    return {
        "conceptual": conceptual,
        "methodological": methodological,
        "definition_cue": definition_cue,
        "methodology_cue": methodology_cue,
        "empirical_cue": empirical_cue,
        "concept_matches": concept_matches,
        "methodology_matches": methodology_matches,
    }
