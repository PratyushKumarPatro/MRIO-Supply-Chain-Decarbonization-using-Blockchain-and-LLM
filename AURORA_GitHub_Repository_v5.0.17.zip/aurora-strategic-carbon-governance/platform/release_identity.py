"""Read package release identity from VERSION.txt.

This module contains deployment metadata only. It does not participate in any
MRIO, SPA, SDA, CRITIC-DLI, intervention, AURORA, blockchain, or LLM algorithm.
"""
from __future__ import annotations

from pathlib import Path
from types import MappingProxyType
from typing import Mapping

BASE_DIR = Path(__file__).resolve().parent
VERSION_PATH = BASE_DIR / "VERSION.txt"


def load_release_identity(path: str | Path = VERSION_PATH) -> Mapping[str, str]:
    source = Path(path)
    lines = source.read_text(encoding="utf-8-sig").splitlines()
    nonempty = [line.strip() for line in lines if line.strip()]
    if len(nonempty) < 2:
        raise RuntimeError(f"Release identity is incomplete: {source}")

    values: dict[str, str] = {
        "version": nonempty[0],
        "package_name": nonempty[1],
    }
    for line in nonempty[2:]:
        if "=" not in line or line.startswith("#"):
            continue
        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()
        if key:
            values[key] = value

    required = (
        "version",
        "package_name",
        "architecture_version",
        "release_patch",
        "integrated_methodology_extension_id",
        "spa_pathway_relevance_extension_id",
        "spa_reporting_extension_id",
        "dli_objective_weighting_extension_id",
        "aurora_similarity_threshold_extension_id",
        "dli_in_app_execution_extension_id",
        "deployment_runtime_extension_id",
        "cdr_producer_linkage_extension_id",
        "path_alignment_extension_id",
        "path_driver_extension_id",
        "node_wise_sda_extension_id",
        "hotspot_leverage_extension_id",
        "intervention_governance_extension_id",
        "aurora_lifecycle_extension_id",
        "methodology_lifecycle_extension_id",
        "governance_interface_extension_id",
        "abatement_scenario_extension_id",
        "performance_monitoring_extension_id",
        "final_decision_support_gate_extension_id",
        "blockchain_control_plane_extension_id",
    )
    missing = [key for key in required if not values.get(key)]
    if missing:
        raise RuntimeError(
            "Release identity is missing required values: " + ", ".join(missing)
        )
    return MappingProxyType(values)


RELEASE_IDENTITY = load_release_identity()
RELEASE_PATCH = RELEASE_IDENTITY["release_patch"]
PACKAGE_NAME = RELEASE_IDENTITY["package_name"]
PACKAGE_VERSION = RELEASE_IDENTITY["version"]
