"""CRITIC-only DLI construction for the integrated U11 methodology.

Theory selects BC, PR, CDR and IC as the four governance-leverage criteria.
CRITIC derives their relative weights from one pooled 2014-2017 evaluation
matrix.  No fixed or researcher-assigned DLI weights are used by this module.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Mapping, Sequence
import hashlib
import json
import math

import numpy as np
import pandas as pd

CRITERIA: tuple[str, ...] = ("BC", "PR", "CDR", "IC")
YEARS: tuple[int, ...] = (2014, 2017)


@dataclass(frozen=True)
class CriticResult:
    weights: dict[str, float]
    standard_deviation: dict[str, float]
    conflict: dict[str, float]
    information: dict[str, float]
    correlation: pd.DataFrame
    normalized: pd.DataFrame
    scope: str
    correlation_method: str
    minima: dict[str, float]
    maxima: dict[str, float]


def _finite_frame(frame: pd.DataFrame, columns: Sequence[str]) -> pd.DataFrame:
    missing = sorted(set(columns).difference(frame.columns))
    if missing:
        raise ValueError(f"CRITIC evaluation matrix is missing columns: {missing}")
    out = frame.loc[:, list(columns)].apply(pd.to_numeric, errors="coerce")
    values = out.to_numpy(dtype=float)
    if out.isna().any().any() or not np.isfinite(values).all():
        raise ValueError("CRITIC evaluation matrix contains missing or non-finite values")
    return out.astype(float)


def pooled_minmax(
    frame: pd.DataFrame,
    columns: Sequence[str] = CRITERIA,
) -> pd.DataFrame:
    """Normalize all observations over one common evaluation universe."""
    x = _finite_frame(frame, columns)
    minima = x.min(axis=0)
    spans = x.max(axis=0) - minima
    safe_spans = spans.where(spans.abs() > np.finfo(float).eps, 1.0)
    z = (x - minima) / safe_spans
    for criterion in columns:
        if abs(float(spans[criterion])) <= np.finfo(float).eps:
            z[criterion] = 0.0
    return z


def critic_weights(
    frame: pd.DataFrame,
    columns: Sequence[str] = CRITERIA,
    correlation_method: str = "pearson",
    already_normalized: bool = False,
    scope: str = "pooled-2014-2017",
) -> CriticResult:
    """Calculate CRITIC contrast-conflict weights.

    A criterion receives weight when it differentiates the node observations
    (standard deviation) and contributes information that is not redundant
    with the remaining criteria (one minus inter-criterion correlation).
    """
    method = str(correlation_method).strip().lower()
    if method != "pearson":
        raise ValueError(
            "The governed DLI method is fixed to pooled Pearson-CRITIC; alternative correlation methods are not accepted"
        )

    raw = _finite_frame(frame, columns)
    z = raw.copy() if already_normalized else pooled_minmax(raw, columns)
    ddof = 1 if len(z) > 1 else 0
    sigma = z.std(axis=0, ddof=ddof).fillna(0.0)
    corr = z.corr(method=method).fillna(0.0)
    for criterion in columns:
        corr.loc[criterion, criterion] = 1.0
    conflict = (1.0 - corr).sum(axis=1)
    information = sigma * conflict
    total = float(information.sum())
    if not math.isfinite(total) or total <= np.finfo(float).eps:
        raise ValueError("CRITIC information content is zero; criteria cannot be weighted")
    weights = information / total

    return CriticResult(
        weights={criterion: float(weights[criterion]) for criterion in columns},
        standard_deviation={criterion: float(sigma[criterion]) for criterion in columns},
        conflict={criterion: float(conflict[criterion]) for criterion in columns},
        information={criterion: float(information[criterion]) for criterion in columns},
        correlation=corr.loc[list(columns), list(columns)].copy(),
        normalized=z.loc[:, list(columns)].copy(),
        scope=str(scope),
        correlation_method=method,
        minima={criterion: float(raw[criterion].min()) for criterion in columns},
        maxima={criterion: float(raw[criterion].max()) for criterion in columns},
    )


def score_and_rank(
    frame: pd.DataFrame,
    result: CriticResult,
    node_col: str = "node_code",
    year_col: str = "year",
) -> pd.DataFrame:
    """Apply one CRITIC result to the observations used to estimate it."""
    out = frame.reset_index(drop=True).copy()
    if len(out) != len(result.normalized):
        raise ValueError("CRITIC normalized matrix and scoring frame have different row counts")
    if node_col not in out.columns:
        raise ValueError(f"Scoring frame is missing {node_col!r}")

    score = np.zeros(len(out), dtype=float)
    contribution_columns: list[str] = []
    for criterion in CRITERIA:
        normalized_column = f"{criterion}_norm_critic"
        contribution_column = f"{criterion}_critic_weight_contribution"
        out[normalized_column] = result.normalized[criterion].to_numpy(dtype=float)
        out[contribution_column] = (
            result.weights[criterion] * out[normalized_column].to_numpy(dtype=float)
        )
        score += out[contribution_column].to_numpy(dtype=float)
        contribution_columns.append(contribution_column)
        out[f"weight_{criterion}"] = result.weights[criterion]

    out["DLI"] = score
    if year_col in out.columns:
        out["dli_rank"] = (
            out.groupby(year_col, dropna=False)["DLI"]
            .rank(method="min", ascending=False)
            .astype(int)
        )
    else:
        out["dli_rank"] = out["DLI"].rank(method="min", ascending=False).astype(int)

    out["dominant_dli_component"] = (
        out[contribution_columns]
        .idxmax(axis=1)
        .str.replace("_critic_weight_contribution", "", regex=False)
    )
    out["dli_weighting_method"] = "CRITIC"
    out["dli_weighting_scope"] = result.scope
    out["critic_correlation_method"] = result.correlation_method
    return out


def build_pooled_critic(
    annual_frames: Mapping[int, pd.DataFrame],
    correlation_method: str = "pearson",
) -> tuple[pd.DataFrame, CriticResult]:
    """Build the authoritative common-weight DLI for 2014 and 2017."""
    missing_years = sorted(set(YEARS).difference(int(y) for y in annual_frames))
    if missing_years:
        raise ValueError(f"Both annual raw metric frames are required; missing {missing_years}")
    frames: list[pd.DataFrame] = []
    reference_nodes: list[str] | None = None
    for year in YEARS:
        frame = annual_frames[int(year)].copy()
        frame["year"] = int(year)
        required = {"node_code", "region", "sector", *CRITERIA}
        missing = sorted(required.difference(frame.columns))
        if missing:
            raise ValueError(f"Raw network metrics for {year} are missing: {missing}")
        frame = frame.sort_values("node_code", kind="mergesort").reset_index(drop=True)
        nodes = frame["node_code"].astype(str).tolist()
        if reference_nodes is None:
            reference_nodes = nodes
        elif nodes != reference_nodes:
            raise ValueError("Annual raw metric frames do not contain the same node universe")
        frames.append(frame)
    pooled = pd.concat(frames, ignore_index=True)
    result = critic_weights(
        pooled,
        columns=CRITERIA,
        correlation_method=correlation_method,
        already_normalized=False,
        scope="pooled-2014-2017",
    )
    scored = score_and_rank(pooled, result)
    scored = scored.sort_values(["year", "dli_rank", "node_code"], kind="mergesort").reset_index(drop=True)
    return scored, result


def criterion_statistics(result: CriticResult) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "criterion": list(CRITERIA),
            "minimum_raw": [result.minima[c] for c in CRITERIA],
            "maximum_raw": [result.maxima[c] for c in CRITERIA],
            "standard_deviation": [result.standard_deviation[c] for c in CRITERIA],
            "conflict": [result.conflict[c] for c in CRITERIA],
            "information": [result.information[c] for c in CRITERIA],
            "critic_weight": [result.weights[c] for c in CRITERIA],
        }
    )


def canonical_critic_evidence(
    scored: pd.DataFrame,
    result: CriticResult,
    input_hashes: Mapping[str, str],
) -> dict:
    ranking_columns = [
        column
        for column in [
            "year", "node_code", "region", "sector", *CRITERIA,
            *[f"{c}_norm_critic" for c in CRITERIA],
            *[f"{c}_critic_weight_contribution" for c in CRITERIA],
            "DLI", "dli_rank", "dominant_dli_component",
        ]
        if column in scored.columns
    ]
    return {
        "method": "pooled Pearson-CRITIC DLI",
        "scope": result.scope,
        "correlation_method": result.correlation_method,
        "input_hashes": dict(input_hashes),
        "weights": result.weights,
        "standard_deviation": result.standard_deviation,
        "conflict": result.conflict,
        "information": result.information,
        "correlation_matrix": result.correlation.to_dict(),
        "ranking": scored[ranking_columns].to_dict(orient="records"),
        "legacy_fixed_weights_used": False,
    }


def sha256_json(payload: Mapping) -> str:
    body = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
    return hashlib.sha256(body).hexdigest()


def write_authoritative_artifacts(
    output_dir: str | Path,
    scored: pd.DataFrame,
    result: CriticResult,
    input_hashes: Mapping[str, str],
    evidence_cid: str,
) -> dict[str, str]:
    """Write the CSV/Excel convenience mirrors committed by the evidence CID."""
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    ranking_path = output / "critic_authoritative_dli_ranking.csv"
    weights_path = output / "critic_authoritative_weights.csv"
    correlation_path = output / "critic_authoritative_correlation.csv"
    json_path = output / "critic_authoritative_dli.json"
    workbook_path = output / "CRITIC_DLI_Authoritative_Results.xlsx"

    scored.to_csv(ranking_path, index=False)
    stats = criterion_statistics(result)
    stats.to_csv(weights_path, index=False)
    result.correlation.to_csv(correlation_path, index=True)
    metadata = {
        "critic_evidence_cid": evidence_cid,
        "input_hashes": dict(input_hashes),
        "scope": result.scope,
        "correlation_method": result.correlation_method,
        "weights": result.weights,
        "legacy_fixed_weights_used": False,
        "ranking_sha256": hashlib.sha256(ranking_path.read_bytes()).hexdigest(),
    }
    json_path.write_text(json.dumps(metadata, indent=2, sort_keys=True), encoding="utf-8")

    with pd.ExcelWriter(workbook_path, engine="openpyxl") as writer:
        pd.DataFrame([metadata | {"weights": json.dumps(result.weights, sort_keys=True)}]).to_excel(
            writer, sheet_name="Summary", index=False
        )
        stats.to_excel(writer, sheet_name="CRITIC_Weights", index=False)
        result.correlation.to_excel(writer, sheet_name="Correlation_Matrix", index=True)
        scored.loc[scored["year"] == 2014].sort_values("dli_rank").to_excel(
            writer, sheet_name="DLI_2014", index=False
        )
        scored.loc[scored["year"] == 2017].sort_values("dli_rank").to_excel(
            writer, sheet_name="DLI_2017", index=False
        )

    files = [ranking_path, weights_path, correlation_path, json_path, workbook_path]
    return {path.name: hashlib.sha256(path.read_bytes()).hexdigest() for path in files}
