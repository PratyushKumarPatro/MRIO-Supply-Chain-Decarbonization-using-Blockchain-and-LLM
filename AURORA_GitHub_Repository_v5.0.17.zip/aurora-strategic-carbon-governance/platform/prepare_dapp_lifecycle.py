"""Prepare a clean Streamlit-guided blockchain deployment state.

This script does NOT deploy any smart contract. It only verifies that the current
Solidity sources are compiled, connects to Ganache, allocates the deterministic
reference-deployment accounts, and writes a partial deployment.json that the Streamlit platform interface
can extend one business transaction at a time.
"""
from __future__ import annotations

import argparse
import json
import os
import shutil
from pathlib import Path

from web3 import Web3

from deploy_contracts import ARTIFACT_DIR, BASE_DIR, ROLE_CODES, ensure_artifacts

RPC_URL = os.environ.get("RPC_URL", "http://127.0.0.1:8545")
RUNTIME_DIR = BASE_DIR / "runtime"
ARCHITECTURE_VERSION = "5.0.17-u23-evidence-bound-abatement-decision"


def clear_runtime_state() -> None:
    """Remove the current guided runtime, promoted inputs and local result store."""
    if RUNTIME_DIR.exists():
        shutil.rmtree(RUNTIME_DIR)
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    content_store = BASE_DIR / "content_store"
    if content_store.exists():
        shutil.rmtree(content_store)
    for filename in (
        "input_mrio_completed.xlsx",
        "Focal_Company_Demand_Converted.xlsx",
    ):
        (BASE_DIR / filename).unlink(missing_ok=True)
        (BASE_DIR / "streamlit_app" / filename).unlink(missing_ok=True)


def build_bootstrap_state(w3: Web3) -> dict:
    accounts = w3.eth.accounts
    if len(accounts) < 8:
        raise RuntimeError("This deployment requires at least 8 Ganache accounts.")

    (
        bootstrap_account,
        registration_oracle,
        upstream_oracle,
        governance_oracle,
        query_oracle,
        regulator,
        mrio_provider,
        focal_company,
    ) = accounts[:8]

    contract_build = json.loads(
        (ARTIFACT_DIR / "contract_build.json").read_text(encoding="utf-8")
    )
    return {
        "architecture_version": ARCHITECTURE_VERSION,
        "base_architecture_version": "5.0.0-four-oracle-regional-opportunity-analytics",
        "deployment_mode": "streamlit-guided-platform",
        "contract_build": contract_build,
        "rpc_url": RPC_URL,
        "chain_id": int(w3.eth.chain_id),
        "bootstrap_block": int(w3.eth.block_number),
        "deployment_block": None,
        "accounts": {
            "deployer": regulator,
            "bootstrap_account": bootstrap_account,
            "registration_oracle": registration_oracle,
            "upstream_oracle": upstream_oracle,
            "governance_oracle": governance_oracle,
            "query_oracle": query_oracle,
            "regulator": regulator,
            "mrio_provider": mrio_provider,
            "focal_company": focal_company,
        },
        "oracle_roles": {
            "registration": {
                "address": registration_oracle,
                "role_code": ROLE_CODES["RegistrationOracle"],
                "role_name": "RegistrationOracle",
            },
            "upstream": {
                "address": upstream_oracle,
                "role_code": ROLE_CODES["UpstreamAnalyticsOracle"],
                "role_name": "UpstreamAnalyticsOracle",
            },
            "governance": {
                "address": governance_oracle,
                "role_code": ROLE_CODES["GovernanceOracle"],
                "role_name": "GovernanceOracle",
            },
            "query": {
                "address": query_oracle,
                "role_code": ROLE_CODES["QueryOracle"],
                "role_name": "QueryOracle",
            },
        },
        "stakeholder_registration_requests": {},
        "contract_deployers": {
            "Registration": {
                "address": regulator,
                "role_name": "RegulatoryAuthority",
            },
            "UpstreamCarbonEmissionsAnalysis": {
                "address": mrio_provider,
                "role_name": "MRIODataProvider",
            },
            "HotspotsManagementAndGovernance": {
                "address": focal_company,
                "role_name": "FocalCompany",
            },
            "QueryManagement": {
                "address": focal_company,
                "role_name": "FocalCompany",
            },
        },
        "contracts": {},
        "deployment_receipts": {},
        "lifecycle": {
            "registration_deployed": False,
            "regulatory_authority_bootstrapped": False,
            "oracle_roles_assigned": False,
            "stakeholders_registered": False,
            "upstream_deployed": False,
            "mrio_data_validated": False,
            "focal_demand_validated": False,
            "mrio_2014_complete": False,
            "mrio_2017_complete": False,
            "spa_2014_complete": False,
            "spa_2017_complete": False,
            "sda_complete": False,
            "upstream_baseline_complete": False,
            "governance_deployed": False,
            "network_2014_complete": False,
            "network_2017_complete": False,
            "temporal_dli_complete": False,
            "network_complete": False,
            "intervention_portfolio_ready": False,
            "intervention_selected": False,
            "selected_intervention_count": 0,
            "proposed_intervention_count": 0,
            "decided_intervention_count": 0,
            "hotspot_registered": False,
            "intervention_proposed": False,
            "intervention_decided": False,
            "all_selected_interventions_decided": False,
            "intervention_governance_evidence_verified": False,
            "intervention_governance_evidence_error": "",
            "intervention_governance_evidence_extension_id": "",
            "intervention_governance_source_network_cid": "",
            "intervention_governance_source_aurora_cid": "",
            "intervention_actionability_review_complete": False,
            "required_actionability_pair_count": 0,
            "terminal_actionability_pair_count": 0,
            "governance_ready_option_count": 0,
            "verified_no_governance_ready_intervention": False,
            "verified_no_governance_ready_options": False,
            "no_governance_ready_intervention": False,
            "intervention_governance_resolved": False,
            "intervention_governance_outcome_complete": False,
            "outcome_complete": False,
            "intervention_governance_resolution_basis": (
                "Current intervention-governance evidence has not yet been verified."
            ),
            "aurora_request_ready": False,
            "aurora_2017_complete": False,
            "aurora_complete": False,
            "aurora_bound_to_active_2017_network": False,
            "intervention_workspace_ready": False,
            "query_management_ready": False,
            "query_deployed": False,
            "system_operational": False,
        },
        "active_results": {
            "mrio": {}, "spa": {}, "sda": {}, "network": {},
            "hotspots": {}, "interventions": {}, "intervention_requests": {},
            "intervention_portfolio_status": {}, "aurora": {}
        },
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--reset", action="store_true")
    args = parser.parse_args()

    ensure_artifacts()
    w3 = Web3(Web3.HTTPProvider(RPC_URL, request_kwargs={"timeout": 20}))
    if not w3.is_connected():
        raise SystemExit(f"Cannot reach Ganache at {RPC_URL}. Start Ganache first.")

    deployment_path = BASE_DIR / "deployment.json"
    if args.reset:
        clear_runtime_state()
        deployment_path.unlink(missing_ok=True)
    elif deployment_path.exists():
        try:
            current = json.loads(deployment_path.read_text(encoding="utf-8"))
            if (
                current.get("deployment_mode") == "streamlit-guided-platform"
                and current.get("architecture_version")
                == ARCHITECTURE_VERSION
                and int(current.get("chain_id", -1)) == int(w3.eth.chain_id)
            ):
                contracts = current.get("contracts", {}) if isinstance(current.get("contracts"), dict) else {}
                stale = False
                for spec in contracts.values():
                    address = spec.get("address") if isinstance(spec, dict) else None
                    if address and len(bytes(w3.eth.get_code(address))) == 0:
                        stale = True
                        break
                if not stale:
                    print(f"Using existing guided deployment state: {deployment_path}")
                    return
                print("Existing guided state is stale for the current Ganache chain; rebuilding bootstrap state.")
                clear_runtime_state()
                deployment_path.unlink(missing_ok=True)
            else:
                print(
                    "Existing guided state is incompatible with the current architecture, "
                    "deployment mode, or Ganache chain; rebuilding bootstrap state."
                )
                clear_runtime_state()
                deployment_path.unlink(missing_ok=True)
        except Exception:
            clear_runtime_state()
            deployment_path.unlink(missing_ok=True)

    state = build_bootstrap_state(w3)
    deployment_path.write_text(json.dumps(state, indent=2), encoding="utf-8")
    print(f"Prepared Streamlit-guided deployment state: {deployment_path}")
    print(f"Chain ID: {w3.eth.chain_id}; current block: {w3.eth.block_number}")
    print("No smart contract has been deployed yet. Open Streamlit -> Governance & Audit Control.")


if __name__ == "__main__":
    main()
