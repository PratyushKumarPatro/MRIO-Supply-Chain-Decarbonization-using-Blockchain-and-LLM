"""Analogue-based Upstream Regional Opportunity and Resilience Assessment (AURORA).

This module screens regional variants of sectors already present in the focal
company's MRIO demand vector.  It does not identify individual suppliers and
it does not claim product-level substitutability.  Its purpose is narrower and
methodologically defensible:

* hold the demanded GTAP sector fixed;
* compare regional variants using observed MRIO production recipes and
  intermediate-sales patterns;
* verify whether the candidate has an observed linkage to the focal region and
  focal consuming sector in the intermediate transaction matrix;
* compare total embodied-emissions multipliers from the unchanged MRIO
  identity F(y) = f^T L y;
* attach DLI evidence as a governance lens, not as a substitutability test;
* return a Pareto-efficient shortlist for supplier-level investigation.

The output is an evidence-based region-sector screening result.  A candidate
becomes an implementable sourcing option only after product specification,
supplier identity, capacity, cost, logistics, qualification and supplier-
specific emissions are verified outside the MRIO table.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass, replace
from pathlib import Path
import hashlib
import json
from typing import Any, Iterable

import numpy as np
import pandas as pd

from analytics_engine import MRIOYear

EPS = 1e-12
AURORA_THRESHOLD_RELEASE_ID = "v5.0.17-U11"
DEFAULT_THRESHOLD_CALIBRATION_YEAR = 2014


@dataclass(frozen=True)
class AURORAConfig:
    """Transparent screening parameters.

    Thresholds do not prove substitutability.  They only determine which
    region-sector analogues are prominent enough to appear on the shortlist.
    Every candidate and its continuous metrics remain available in the full
    output for sensitivity review.
    """

    focal_region: str = "ARE"
    focal_consuming_sector: str = "cns"
    # U11 has no fixed structural-similarity cut-offs.  The deployed workflow
    # derives both values from the complete 2014 same-sector candidate universe
    # through exact bin-free Otsu calibration and passes them explicitly.
    production_similarity_threshold: float = float("nan")
    market_similarity_threshold: float = float("nan")
    similarity_threshold_method: str = "exact_bin_free_otsu_required"
    similarity_threshold_calibration_year: int | None = None
    minimum_carbon_improvement: float = 0.0
    top_candidates_per_sector: int = 3
    trade_epsilon: float = EPS


@dataclass
class ProfileSet:
    sector_labels: list[str]
    region_labels: list[str]
    production_by_sector: np.ndarray
    production_by_region: np.ndarray
    market_by_sector: np.ndarray
    market_by_region: np.ndarray


def _stable_unique(values: Iterable[str]) -> list[str]:
    return list(dict.fromkeys(str(v) for v in values))


def _row_normalize(matrix: np.ndarray) -> np.ndarray:
    totals = matrix.sum(axis=1, keepdims=True)
    return np.divide(
        matrix,
        totals,
        out=np.zeros_like(matrix, dtype=float),
        where=np.abs(totals) > EPS,
    )


def _cosine(a: np.ndarray, b: np.ndarray) -> float:
    norm_a = float(np.linalg.norm(a))
    norm_b = float(np.linalg.norm(b))
    if norm_a <= EPS and norm_b <= EPS:
        return 1.0
    if norm_a <= EPS or norm_b <= EPS:
        return 0.0
    value = float(np.dot(a, b) / (norm_a * norm_b))
    return float(np.clip(value, -1.0, 1.0))


def exact_bin_free_otsu(values: Iterable[float], *, label: str = "similarity") -> dict[str, Any]:
    """Return an exact empirical Otsu split without histogram binning.

    The observations are sorted and every split between consecutive distinct
    values is evaluated.  The selected threshold is the midpoint between the
    adjacent observations surrounding the split that maximises between-class
    variance.  This preserves Otsu's discrimination principle while avoiding
    the arbitrary 256-bin convention inherited from image processing.
    """

    array = np.asarray(list(values), dtype=float).reshape(-1)
    if array.size < 2:
        raise ValueError(f"At least two {label} observations are required for exact Otsu calibration")
    if not np.all(np.isfinite(array)):
        raise ValueError(f"All {label} observations must be finite for exact Otsu calibration")

    ordered = np.sort(array)
    split_points = np.flatnonzero(ordered[:-1] < ordered[1:]) + 1
    if split_points.size == 0:
        constant = float(ordered[0])
        return {
            "method": "exact_bin_free_otsu",
            "label": str(label),
            "threshold": constant,
            "sample_count": int(ordered.size),
            "distinct_value_count": 1,
            "split_index": None,
            "lower_class_count": 0,
            "upper_class_count": int(ordered.size),
            "lower_class_mean": None,
            "upper_class_mean": constant,
            "lower_boundary_value": None,
            "upper_boundary_value": constant,
            "between_class_variance": 0.0,
            "constant_distribution": True,
        }

    cumulative = np.cumsum(ordered, dtype=float)
    total = float(cumulative[-1])
    n = float(ordered.size)
    lower_counts = split_points.astype(float)
    upper_counts = n - lower_counts
    lower_means = cumulative[split_points - 1] / lower_counts
    upper_means = (total - cumulative[split_points - 1]) / upper_counts
    lower_weights = lower_counts / n
    upper_weights = upper_counts / n
    scores = lower_weights * upper_weights * np.square(lower_means - upper_means)
    best_position = int(np.argmax(scores))
    split_index = int(split_points[best_position])
    lower_boundary = float(ordered[split_index - 1])
    upper_boundary = float(ordered[split_index])
    threshold = float((lower_boundary + upper_boundary) / 2.0)

    return {
        "method": "exact_bin_free_otsu",
        "label": str(label),
        "threshold": threshold,
        "sample_count": int(ordered.size),
        "distinct_value_count": int(np.unique(ordered).size),
        "split_index": split_index,
        "lower_class_count": split_index,
        "upper_class_count": int(ordered.size - split_index),
        "lower_class_mean": float(lower_means[best_position]),
        "upper_class_mean": float(upper_means[best_position]),
        "lower_boundary_value": lower_boundary,
        "upper_boundary_value": upper_boundary,
        "between_class_variance": float(scores[best_position]),
        "constant_distribution": False,
    }


def build_profiles(my: MRIOYear) -> ProfileSet:
    """Build normalized production and market profiles for every node.

    Production behaviour is derived from columns of A = Z x_hat^-1.
    Market/output-distribution behaviour is derived from rows of Z and then
    normalized by each node's total intermediate sales.
    """

    A = np.divide(
        my.Z,
        my.X[np.newaxis, :],
        out=np.zeros_like(my.Z, dtype=float),
        where=np.abs(my.X[np.newaxis, :]) > EPS,
    )
    sector_labels = _stable_unique(my.sectors)
    region_labels = _stable_unique(my.regions)

    production_by_sector = np.column_stack(
        [A[my.sectors == sector, :].sum(axis=0) for sector in sector_labels]
    )
    production_by_region = np.column_stack(
        [A[my.regions == region, :].sum(axis=0) for region in region_labels]
    )

    market_by_sector_raw = np.column_stack(
        [my.Z[:, my.sectors == sector].sum(axis=1) for sector in sector_labels]
    )
    market_by_region_raw = np.column_stack(
        [my.Z[:, my.regions == region].sum(axis=1) for region in region_labels]
    )

    return ProfileSet(
        sector_labels=sector_labels,
        region_labels=region_labels,
        production_by_sector=production_by_sector,
        production_by_region=production_by_region,
        market_by_sector=_row_normalize(market_by_sector_raw),
        market_by_region=_row_normalize(market_by_region_raw),
    )


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _active_input_hashes(root: Path) -> dict[str, str]:
    """Return hashes of the currently promoted runtime workbooks.

    The same module is imported from both the package root and ``streamlit_app``.
    The candidate roots therefore include the current folder and its parent.
    """
    candidates = [root, root.parent]
    for base in candidates:
        mrio = base / "input_mrio_completed.xlsx"
        demand = base / "Focal_Company_Demand_Converted.xlsx"
        if mrio.is_file() and demand.is_file():
            return {
                "mrio": _sha256_file(mrio),
                "focal_demand": _sha256_file(demand),
            }
    raise RuntimeError(
        "Operational MRIO and focal-company demand workbooks are not active. "
        "Upload and validate them through the Governance & Audit Control workspace first."
    )


def load_runtime_dli(base_dir: str | Path, year: int) -> pd.DataFrame:
    """Load DLI evidence produced for the active uploaded input hashes.

    No packaged analytical result is accepted. The CSV and its metadata are
    written by the current Network/DLI request under ``runtime/active_analytics``.
    """
    root = Path(base_dir).resolve()
    expected = _active_input_hashes(root)
    runtime_dirs = [
        root / "runtime" / "active_analytics",
        root.parent / "runtime" / "active_analytics",
    ]
    checked: list[str] = []
    for runtime in runtime_dirs:
        csv_path = runtime / f"dli_{int(year)}.csv"
        meta_path = runtime / f"dli_{int(year)}.json"
        checked.extend([str(csv_path), str(meta_path)])
        if not csv_path.is_file() or not meta_path.is_file():
            continue
        try:
            metadata = json.loads(meta_path.read_text(encoding="utf-8"))
        except Exception as exc:
            raise RuntimeError(f"Invalid runtime DLI metadata: {meta_path}: {exc}") from exc
        if metadata.get("input_hashes") != expected:
            continue
        frame = pd.read_csv(csv_path)
        required = {"node_code", "DLI"}
        missing = sorted(required - set(frame.columns))
        if missing:
            raise RuntimeError(
                f"Runtime DLI file {csv_path} is missing columns: {', '.join(missing)}"
            )
        return frame
    raise RuntimeError(
        f"No Network/DLI result matching the active uploaded workbooks is available for {year}. "
        "Run the on-chain Network/DLI lifecycle first. Checked: " + ", ".join(checked)
    )


def load_packaged_dli(base_dir: str | Path, year: int) -> pd.DataFrame:
    """Compatibility alias; packaged analytical DLI files are no longer used."""
    return load_runtime_dli(base_dir, year)


def _dli_lookup(dli_df: pd.DataFrame | None) -> tuple[dict[str, dict[str, Any]], float, float]:
    if dli_df is None or dli_df.empty:
        return {}, 0.0, 0.0
    frame = dli_df.copy().reset_index(drop=True)
    if "dli_rank" not in frame.columns:
        frame["dli_rank"] = np.arange(1, len(frame) + 1)
    q80 = float(frame["DLI"].quantile(0.80)) if "DLI" in frame else 0.0
    q50 = float(frame["DLI"].quantile(0.50)) if "DLI" in frame else 0.0
    lookup = {
        str(row["node_code"]): row.to_dict()
        for _, row in frame.iterrows()
        if str(row.get("node_code", ""))
    }
    return lookup, q80, q50


def _dominant_dli_component(row: dict[str, Any]) -> str:
    components = {
        "betweenness / network position": float(row.get("BC_norm", 0.0)) * 0.25,
        "PageRank / structural importance": float(row.get("PR_norm", 0.0)) * 0.20,
        "carbon dependency risk": float(row.get("CDR_norm", 0.0)) * 0.30,
        "intervention criticality": float(row.get("IC_norm", 0.0)) * 0.25,
    }
    return max(components, key=components.get) if components else "not available"


def _governance_lens(row: dict[str, Any], q80: float, q50: float) -> str:
    if not row:
        return "DLI evidence was not available for this candidate."
    dli = float(row.get("DLI", 0.0))
    dominant = _dominant_dli_component(row)
    if dli >= q80:
        level = "high governance leverage"
    elif dli >= q50:
        level = "moderate governance leverage"
    else:
        level = "lower governance leverage"
    return (
        f"The node has {level} in the deployed DLI distribution; its strongest "
        f"weighted signal is {dominant}. DLI informs engagement and risk handling, "
        "not product substitutability."
    )


def _pareto_flags(records: list[dict[str, Any]]) -> dict[str, bool]:
    """Mark non-dominated candidates on four transparent dimensions.

    All dimensions are maximized: sector-production similarity, downstream-
    market similarity, observed focal-region sales share and carbon-multiplier
    improvement.  DLI is deliberately excluded because a larger DLI is not
    unambiguously better for sourcing.
    """

    flags = {str(row["node_code"]): True for row in records}
    fields = (
        "production_sector_similarity",
        "market_sector_similarity",
        "focal_region_intermediate_sales_share",
        "relative_multiplier_reduction",
    )
    for left in records:
        left_values = np.array([float(left.get(field, 0.0)) for field in fields])
        for right in records:
            if left is right:
                continue
            right_values = np.array([float(right.get(field, 0.0)) for field in fields])
            if np.all(right_values >= left_values - 1e-12) and np.any(
                right_values > left_values + 1e-12
            ):
                flags[str(left["node_code"])] = False
                break
    return flags


def _weighted_profile(matrix: np.ndarray, indices: np.ndarray, weights: np.ndarray) -> np.ndarray:
    if len(indices) == 1:
        return matrix[int(indices[0])].copy()
    return np.average(matrix[indices], axis=0, weights=weights)


def analyse(
    my: MRIOYear,
    company_y: np.ndarray,
    dli_df: pd.DataFrame | None = None,
    config: AURORAConfig | None = None,
) -> dict[str, Any]:
    """Run AURORA for one MRIO reference year."""

    cfg = config or AURORAConfig()
    if not np.isfinite(float(cfg.production_similarity_threshold)) or not np.isfinite(float(cfg.market_similarity_threshold)):
        raise ValueError(
            "AURORA requires production and market thresholds calibrated through exact bin-free Otsu. "
            "Call calibrate_exact_otsu_config() before analyse()."
        )
    if len(company_y) != len(my.node_codes):
        raise ValueError("company_y length does not match the MRIO node count")

    profiles = build_profiles(my)
    multiplier = my.fE @ my.L
    total_footprint = float(my.footprint(company_y))
    dli_lookup, dli_q80, dli_q50 = _dli_lookup(dli_df)

    try:
        focal_consumer_index = my.node_index(
            cfg.focal_region,
            cfg.focal_consuming_sector,
        )
    except KeyError:
        focal_consumer_index = -1

    focal_region_mask = my.regions == cfg.focal_region
    gcc_regions = {"ARE", "BHR", "KWT", "OMN", "QAT", "SAU"}
    gcc_mask = np.array([str(region) in gcc_regions for region in my.regions])

    current_mix: list[dict[str, Any]] = []
    all_candidates: list[dict[str, Any]] = []
    sector_summaries: list[dict[str, Any]] = []

    demanded_sectors = sorted(set(str(s) for s in my.sectors[company_y > EPS]))
    for sector in demanded_sectors:
        current_indices = np.where((my.sectors == sector) & (company_y > EPS))[0]
        if len(current_indices) == 0:
            continue
        sector_demand = float(company_y[current_indices].sum())
        weights = company_y[current_indices] / sector_demand

        reference_prod_sector = _weighted_profile(
            profiles.production_by_sector,
            current_indices,
            weights,
        )
        reference_prod_region = _weighted_profile(
            profiles.production_by_region,
            current_indices,
            weights,
        )
        reference_market_sector = _weighted_profile(
            profiles.market_by_sector,
            current_indices,
            weights,
        )
        reference_market_region = _weighted_profile(
            profiles.market_by_region,
            current_indices,
            weights,
        )
        baseline_multiplier = float(np.dot(weights, multiplier[current_indices]))

        current_nodes = []
        for index, weight in zip(current_indices, weights):
            node = str(my.node_codes[index])
            dli_row = dli_lookup.get(node, {})
            record = {
                "sector": sector,
                "node_code": node,
                "region": str(my.regions[index]),
                "share_of_sector_demand": float(weight),
                "company_demand": float(company_y[index]),
                "embodied_multiplier": float(multiplier[index]),
                "DLI": float(dli_row.get("DLI", 0.0)) if dli_row else None,
                "dli_rank": int(dli_row.get("dli_rank", 0)) if dli_row else None,
                "dli_governance_lens": _governance_lens(dli_row, dli_q80, dli_q50),
            }
            current_nodes.append(record)
            current_mix.append(record)

        sector_candidates: list[dict[str, Any]] = []
        candidate_indices = np.where((my.sectors == sector) & (my.X > EPS))[0]
        for index in candidate_indices:
            if int(index) in set(int(i) for i in current_indices):
                continue

            total_intermediate_sales = float(my.Z[index, :].sum())
            direct_focal_flow = (
                float(my.Z[index, focal_consumer_index])
                if focal_consumer_index >= 0
                else 0.0
            )
            focal_region_sales = float(my.Z[index, focal_region_mask].sum())
            gcc_sales = float(my.Z[index, gcc_mask].sum())
            focal_region_share = (
                focal_region_sales / total_intermediate_sales
                if total_intermediate_sales > EPS
                else 0.0
            )
            focal_consumer_share = (
                direct_focal_flow / total_intermediate_sales
                if total_intermediate_sales > EPS
                else 0.0
            )
            gcc_share = (
                gcc_sales / total_intermediate_sales
                if total_intermediate_sales > EPS
                else 0.0
            )

            production_sector_similarity = _cosine(
                reference_prod_sector,
                profiles.production_by_sector[index],
            )
            production_region_similarity = _cosine(
                reference_prod_region,
                profiles.production_by_region[index],
            )
            market_sector_similarity = _cosine(
                reference_market_sector,
                profiles.market_by_sector[index],
            )
            market_region_similarity = _cosine(
                reference_market_region,
                profiles.market_by_region[index],
            )

            candidate_multiplier = float(multiplier[index])
            relative_reduction = (
                (baseline_multiplier - candidate_multiplier) / baseline_multiplier
                if abs(baseline_multiplier) > EPS
                else 0.0
            )
            full_reallocation_opportunity = sector_demand * max(
                0.0,
                baseline_multiplier - candidate_multiplier,
            )

            if direct_focal_flow > cfg.trade_epsilon:
                linkage_tier = "observed direct flow to focal-region construction"
                linkage_code = 1
            elif focal_region_sales > cfg.trade_epsilon:
                linkage_tier = "observed flow to other focal-region industries"
                linkage_code = 2
            elif gcc_sales > cfg.trade_epsilon:
                linkage_tier = "observed GCC intermediate-market flow"
                linkage_code = 3
            else:
                linkage_tier = "positive sector output but no observed relevant intermediate flow"
                linkage_code = 4

            structural_analogue = bool(
                production_sector_similarity >= cfg.production_similarity_threshold
                and market_sector_similarity >= cfg.market_similarity_threshold
            )
            lower_carbon = bool(
                relative_reduction > cfg.minimum_carbon_improvement + EPS
            )
            dli_row = dli_lookup.get(str(my.node_codes[index]), {})

            candidate = {
                "sector": sector,
                "current_nodes": [row["node_code"] for row in current_nodes],
                "node_code": str(my.node_codes[index]),
                "region": str(my.regions[index]),
                "sector_demand": sector_demand,
                "baseline_embodied_multiplier": baseline_multiplier,
                "candidate_embodied_multiplier": candidate_multiplier,
                "relative_multiplier_reduction": float(relative_reduction),
                "modelled_full_reallocation_opportunity": float(full_reallocation_opportunity),
                "opportunity_share_of_company_footprint": (
                    float(full_reallocation_opportunity / total_footprint)
                    if total_footprint > EPS
                    else 0.0
                ),
                "production_sector_similarity": production_sector_similarity,
                "production_similarity_threshold_used": float(cfg.production_similarity_threshold),
                "production_region_similarity": production_region_similarity,
                "market_sector_similarity": market_sector_similarity,
                "market_similarity_threshold_used": float(cfg.market_similarity_threshold),
                "market_region_similarity": market_region_similarity,
                "similarity_threshold_method": str(cfg.similarity_threshold_method),
                "similarity_threshold_calibration_year": cfg.similarity_threshold_calibration_year,
                "direct_flow_to_focal_region_construction": direct_focal_flow,
                "focal_consumer_intermediate_sales_share": focal_consumer_share,
                "intermediate_sales_to_focal_region": focal_region_sales,
                "focal_region_intermediate_sales_share": focal_region_share,
                "gcc_intermediate_sales_share": gcc_share,
                "observed_linkage_tier": linkage_tier,
                "observed_linkage_code": linkage_code,
                "structural_analogue": structural_analogue,
                "lower_carbon_multiplier": lower_carbon,
                "DLI": float(dli_row.get("DLI", 0.0)) if dli_row else None,
                "dli_rank": int(dli_row.get("dli_rank", 0)) if dli_row else None,
                "BC_norm": float(dli_row.get("BC_norm", 0.0)) if dli_row else None,
                "PR_norm": float(dli_row.get("PR_norm", 0.0)) if dli_row else None,
                "CDR_norm": float(dli_row.get("CDR_norm", 0.0)) if dli_row else None,
                "IC_norm": float(dli_row.get("IC_norm", 0.0)) if dli_row else None,
                "dominant_dli_component": _dominant_dli_component(dli_row) if dli_row else None,
                "dli_governance_lens": _governance_lens(dli_row, dli_q80, dli_q50),
            }
            sector_candidates.append(candidate)

        eligible_for_pareto = [
            row
            for row in sector_candidates
            if row["structural_analogue"]
            and row["lower_carbon_multiplier"]
            and int(row["observed_linkage_code"]) <= 3
        ]
        pareto = _pareto_flags(eligible_for_pareto)
        for candidate in sector_candidates:
            candidate["pareto_efficient"] = bool(
                pareto.get(str(candidate["node_code"]), False)
            )
            candidate["eligible_for_regional_investigation"] = bool(
                candidate["structural_analogue"]
                and candidate["lower_carbon_multiplier"]
                and candidate["observed_linkage_code"] <= 3
            )

        # Rank first, then retain at most the disclosed number of Pareto candidates
        # per demanded sector. The full candidate table remains in the result.
        sector_candidates.sort(
            key=lambda row: (
                not bool(row["eligible_for_regional_investigation"]),
                not bool(row["pareto_efficient"]),
                int(row["observed_linkage_code"]),
                -float(row["modelled_full_reallocation_opportunity"]),
                -float(row["production_sector_similarity"]),
                -float(row["market_sector_similarity"]),
            )
        )
        recommended_codes = {
            str(row["node_code"])
            for row in sector_candidates
            if row["eligible_for_regional_investigation"] and row["pareto_efficient"]
        }
        if cfg.top_candidates_per_sector > 0:
            recommended_codes = set(
                list(
                    row["node_code"]
                    for row in sector_candidates
                    if row["eligible_for_regional_investigation"]
                    and row["pareto_efficient"]
                )[: cfg.top_candidates_per_sector]
            )

        for candidate in sector_candidates:
            candidate["recommended_for_investigation"] = (
                str(candidate["node_code"]) in recommended_codes
            )
            if candidate["recommended_for_investigation"]:
                if candidate["observed_linkage_code"] == 1:
                    recommendation = "Priority regional procurement investigation"
                elif candidate["observed_linkage_code"] == 2:
                    recommendation = "Regional investigation with focal-market validation"
                else:
                    recommendation = "Secondary regional investigation; verify UAE market access"
            elif candidate["eligible_for_regional_investigation"] and candidate["pareto_efficient"]:
                recommendation = "Additional Pareto candidate; review if a broader shortlist is required"
            elif candidate["eligible_for_regional_investigation"]:
                recommendation = "Reserve candidate; dominated by another screened alternative"
            elif candidate["structural_analogue"] and not candidate["lower_carbon_multiplier"]:
                recommendation = "Do not shift on carbon grounds; consider decarbonization engagement with the current regional source"
            else:
                recommendation = "Not shortlisted without product-level and structural validation"
            candidate["recommendation"] = recommendation
        all_candidates.extend(sector_candidates)

        recommended = [
            row for row in sector_candidates if row["recommended_for_investigation"]
        ]
        top = recommended[0] if recommended else None
        sector_summaries.append(
            {
                "sector": sector,
                "sector_demand": sector_demand,
                "current_nodes": [row["node_code"] for row in current_nodes],
                "baseline_embodied_multiplier": baseline_multiplier,
                "candidate_count": len(sector_candidates),
                "structural_analogue_count": sum(
                    bool(row["structural_analogue"]) for row in sector_candidates
                ),
                "lower_carbon_analogue_count": sum(
                    bool(row["eligible_for_regional_investigation"])
                    for row in sector_candidates
                ),
                "recommended_count": len(recommended),
                "top_candidate": top,
            }
        )

    recommended_opportunities = [
        row for row in all_candidates if row["recommended_for_investigation"]
    ]
    recommended_opportunities.sort(
        key=lambda row: -float(row["modelled_full_reallocation_opportunity"])
    )

    return {
        "method": "AURORA",
        "method_name": "Analogue-based Upstream Regional Opportunity and Resilience Assessment",
        "year": int(my.year),
        "configuration": asdict(cfg),
        "company_footprint": total_footprint,
        "demanded_sector_count": len(demanded_sectors),
        "current_mix": current_mix,
        "sector_summaries": sector_summaries,
        "recommended_opportunities": recommended_opportunities,
        "all_candidates": all_candidates,
        "claim_boundary": (
            "The shortlist identifies same-sector regional analogues for procurement due "
            "diligence. It does not identify an individual supplier, prove product "
            "equivalence, capacity, cost, logistics, qualification or a realized emissions reduction."
        ),
        "dli_rule": (
            "DLI is used only to interpret governance leverage, dependency and engagement needs. "
            "It is not used as proof that a candidate is substitutable or lower carbon."
        ),
    }


def calibrate_exact_otsu_config(
    calibration_my: MRIOYear,
    calibration_company_y: np.ndarray,
    *,
    base_config: AURORAConfig | None = None,
) -> tuple[AURORAConfig, dict[str, Any]]:
    """Calibrate production and market thresholds from one reference year.

    The complete positive-output, same-sector candidate universe is generated
    before carbon, linkage, Pareto, or recommendation screening.  Exact
    bin-free Otsu is then applied separately to the two cosine-similarity
    distributions.  The returned config can be applied unchanged to both the
    calibration year and the primary assessment year.
    """

    base = base_config or AURORAConfig()
    calibration_year = int(calibration_my.year)
    probe_config = replace(
        base,
        production_similarity_threshold=-1.0,
        market_similarity_threshold=-1.0,
        similarity_threshold_method="exact_bin_free_otsu_calibration_probe",
        similarity_threshold_calibration_year=calibration_year,
    )
    probe = analyse(
        calibration_my,
        calibration_company_y,
        dli_df=None,
        config=probe_config,
    )
    candidates = [row for row in probe.get("all_candidates", []) if isinstance(row, dict)]
    if not candidates:
        raise ValueError("Exact Otsu calibration produced no same-sector candidate observations")

    production = exact_bin_free_otsu(
        (float(row["production_sector_similarity"]) for row in candidates),
        label="production_sector_similarity",
    )
    market = exact_bin_free_otsu(
        (float(row["market_sector_similarity"]) for row in candidates),
        label="market_sector_similarity",
    )
    calibrated = replace(
        base,
        production_similarity_threshold=float(production["threshold"]),
        market_similarity_threshold=float(market["threshold"]),
        similarity_threshold_method="exact_bin_free_otsu",
        similarity_threshold_calibration_year=calibration_year,
    )
    evidence = {
        "release_id": AURORA_THRESHOLD_RELEASE_ID,
        "method": "exact_bin_free_otsu",
        "calibration_year": calibration_year,
        "candidate_universe_count": len(candidates),
        "candidate_universe_definition": (
            "All positive-output regional variants of sectors with positive focal-company demand, "
            "excluding nodes already represented in the current regional mix."
        ),
        "calibration_order": (
            "Similarity thresholds are calibrated before carbon improvement, observed linkage, "
            "Pareto dominance, DLI interpretation, and shortlist selection."
        ),
        "production": production,
        "market": market,
        "reporting_rule": (
            "The computation retains full-precision thresholds; rounded values are for display only. "
            "The midpoint is a transparent representative of the empty interval between the two "
            "observations surrounding the optimal empirical split."
        ),
        "claim_boundary": (
            "The thresholds separate empirically lower- and higher-similarity regimes in the "
            "calibration-year candidate distribution. They do not prove supplier or product equivalence."
        ),
    }
    return calibrated, evidence


def attach_threshold_calibration(
    result: dict[str, Any],
    calibration_evidence: dict[str, Any],
) -> dict[str, Any]:
    """Attach immutable calibration metadata to an AURORA result package."""

    result["threshold_calibration"] = dict(calibration_evidence)
    configuration = dict(result.get("configuration", {}) or {})
    configuration["production_similarity_threshold"] = float(
        calibration_evidence["production"]["threshold"]
    )
    configuration["market_similarity_threshold"] = float(
        calibration_evidence["market"]["threshold"]
    )
    configuration["similarity_threshold_method"] = str(calibration_evidence["method"])
    configuration["similarity_threshold_calibration_year"] = int(
        calibration_evidence["calibration_year"]
    )
    result["configuration"] = configuration
    return result


def add_cross_year_stability(
    primary: dict[str, Any],
    comparison: dict[str, Any],
) -> dict[str, Any]:
    """Annotate primary-year candidates with stability in another reference year."""

    comparison_map = {
        (str(row.get("sector")), str(row.get("node_code"))): row
        for row in comparison.get("all_candidates", [])
    }
    for row in primary.get("all_candidates", []):
        other = comparison_map.get((str(row.get("sector")), str(row.get("node_code"))))
        row["comparison_year"] = comparison.get("year")
        row["comparison_year_available"] = bool(other)
        row["lower_carbon_in_both_reference_years"] = bool(
            other
            and row.get("lower_carbon_multiplier")
            and other.get("lower_carbon_multiplier")
        )
        row["structural_analogue_in_both_reference_years"] = bool(
            other
            and row.get("structural_analogue")
            and other.get("structural_analogue")
        )
        row["stable_reference_year_signal"] = bool(
            other
            and row.get("recommended_for_investigation")
            and other.get("eligible_for_regional_investigation")
        )
        if other:
            row["comparison_relative_multiplier_reduction"] = other.get(
                "relative_multiplier_reduction"
            )
    primary["recommended_opportunities"] = [
        row for row in primary.get("all_candidates", []) if row.get("recommended_for_investigation")
    ]
    primary["recommended_opportunities"].sort(
        key=lambda row: (
            not bool(row.get("stable_reference_year_signal")),
            -float(row.get("modelled_full_reallocation_opportunity", 0.0)),
        )
    )
    primary["cross_year_comparison"] = {
        "primary_year": primary.get("year"),
        "comparison_year": comparison.get("year"),
        "interpretation": (
            "A stable signal means the same candidate remains a lower-carbon structural analogue "
            "in both available reference years. It is stronger screening evidence, not supplier verification."
        ),
    }
    return primary



