// SPDX-License-Identifier: MIT
pragma solidity ^0.8.19;

/// @notice Unified source file for the Strategic Carbon Intelligence & Governance deployment. Compilation still
/// produces four independently deployed contracts with separate addresses,
/// storage, events, access controls and transaction histories.

interface IRegistration {
    enum Role {
        None,
        RegulatoryAuthority,
        MRIODataProvider,
        FocalCompany,
        RegistrationOracle,
        UpstreamAnalyticsOracle,
        GovernanceOracle,
        QueryOracle
    }

    function roleOf(address entity) external view returns (Role);
    function oracleForRole(Role role) external view returns (address);
}

/// @title Shared Registration reference and authorization helpers
/// @notice The three operational contracts inherit this reference layer. It does
/// not duplicate stakeholder state: every authorization check is made against
/// the one separately deployed Registration contract supplied to the constructor.
abstract contract RegistrationAware {
    IRegistration public immutable registration;
    address public immutable deployedBy;

    constructor(
        address registrationAddress,
        IRegistration.Role requiredDeployerRole,
        string memory deployerError
    ) {
        require(registrationAddress != address(0), "registration cannot be zero");
        IRegistration registry = IRegistration(registrationAddress);
        require(registry.roleOf(msg.sender) == requiredDeployerRole, deployerError);
        registration = registry;
        deployedBy = msg.sender;
    }

    modifier onlyRole(IRegistration.Role role) {
        require(registration.roleOf(msg.sender) == role, "wrong role for this action");
        _;
    }

    function _requireActiveOracle(
        IRegistration.Role oracleRole,
        string memory errorMessage
    ) internal view {
        require(
            registration.roleOf(msg.sender) == oracleRole &&
                registration.oracleForRole(oracleRole) == msg.sender,
            errorMessage
        );
    }
}

/// @title Role-aware stakeholder and oracle registration
/// @notice The contract separates three stakeholder roles from four dedicated
/// oracle roles. Stakeholders request registration on-chain; the Registration
/// Oracle verifies the request off-chain through the Data Orchestrator and then
/// records the decision on-chain. The Regulatory Authority account deploys this
/// contract in the reference implementation; deployedBy records that constructor caller. Oracle
/// identities are assigned by the admin at deployment and are visible through
/// oracleForRole().
contract Registration {
    enum Role {
        None,
        RegulatoryAuthority,
        MRIODataProvider,
        FocalCompany,
        RegistrationOracle,
        UpstreamAnalyticsOracle,
        GovernanceOracle,
        QueryOracle
    }

    enum RequestStatus { Pending, Approved, Rejected }

    struct RegistrationRequest {
        address requester;
        Role requestedRole;
        string evidenceCID;
        RequestStatus status;
        string verificationCID;
        address verifiedBy;
        uint256 requestedAt;
        uint256 verifiedAt;
    }

    address public admin;
    address public immutable deployedBy;
    Role public constant deploymentRole = Role.RegulatoryAuthority;
    uint256 public nextRequestId;

    mapping(address => Role) private roleOf_;
    mapping(Role => address) public oracleForRole;
    mapping(uint256 => RegistrationRequest) private requests;
    mapping(address => uint256) private pendingRequestPlusOne;

    event OracleRoleAssigned(
        address indexed oracle,
        Role indexed role,
        address indexed assignedBy
    );
    event RegistrationRequested(
        uint256 indexed requestId,
        address indexed requester,
        Role indexed requestedRole,
        string evidenceCID
    );
    event RegistrationVerified(
        uint256 indexed requestId,
        address indexed requester,
        Role indexed assignedRole,
        bool approved,
        string verificationCID,
        address verifiedBy
    );
    event EntityRegistered(address indexed entity, Role indexed role, address indexed registeredBy);
    event EntityRevoked(address indexed entity, Role indexed previousRole, address indexed revokedBy);

    modifier onlyAdmin() {
        require(msg.sender == admin, "caller is not the admin");
        _;
    }

    modifier onlyRegistrationOracle() {
        require(
            roleOf_[msg.sender] == Role.RegistrationOracle &&
                oracleForRole[Role.RegistrationOracle] == msg.sender,
            "caller is not the registration oracle"
        );
        _;
    }

    modifier onlyAdminOrRegulator() {
        require(
            msg.sender == admin || roleOf_[msg.sender] == Role.RegulatoryAuthority,
            "caller cannot revoke stakeholders"
        );
        _;
    }

    constructor(address registrationOracle) {
        require(registrationOracle != address(0), "registration oracle cannot be zero");
        admin = msg.sender;
        deployedBy = msg.sender;

        // The constructor caller is the governance root. This avoids a circular
        // dependency in which the Regulatory Authority would need to be verified
        // before the registration system itself exists.
        roleOf_[msg.sender] = Role.RegulatoryAuthority;
        emit EntityRegistered(msg.sender, Role.RegulatoryAuthority, msg.sender);

        // The Regulatory Authority appoints the first Registration Oracle at
        // bootstrap. The remaining specialized Oracle identities are assigned
        // through assignOracleRole after deployment.
        _assignOracleRole(registrationOracle, Role.RegistrationOracle);
    }

    function _isStakeholderRole(Role role) internal pure returns (bool) {
        return
            role == Role.RegulatoryAuthority ||
            role == Role.MRIODataProvider ||
            role == Role.FocalCompany;
    }

    function _isOracleRole(Role role) internal pure returns (bool) {
        return
            role == Role.RegistrationOracle ||
            role == Role.UpstreamAnalyticsOracle ||
            role == Role.GovernanceOracle ||
            role == Role.QueryOracle;
    }

    function _assignOracleRole(address oracle, Role role) internal {
        require(oracle != address(0), "oracle cannot be zero");
        require(_isOracleRole(role), "role is not an oracle role");

        address previous = oracleForRole[role];
        if (previous != address(0) && previous != oracle) {
            roleOf_[previous] = Role.None;
        }

        Role current = roleOf_[oracle];
        require(current == Role.None || current == role, "address already has a different role");
        roleOf_[oracle] = role;
        oracleForRole[role] = oracle;
        emit OracleRoleAssigned(oracle, role, msg.sender);
        emit EntityRegistered(oracle, role, msg.sender);
    }

    /// @notice Assign or rotate one of the four oracle identities.
    function assignOracleRole(address oracle, Role role) external onlyAdmin {
        _assignOracleRole(oracle, role);
    }

    /// @notice A stakeholder starts the on-chain request. No role is granted
    /// until the Registration Oracle has verified the evidence off-chain.
    function requestRegistration(Role requestedRole, string calldata evidenceCID)
        external
        returns (uint256 requestId)
    {
        require(
            requestedRole == Role.MRIODataProvider || requestedRole == Role.FocalCompany,
            "only MRIO provider or focal company registration may be requested"
        );
        require(roleOf_[msg.sender] == Role.None, "address is already registered");
        require(pendingRequestPlusOne[msg.sender] == 0, "registration request already pending");
        require(bytes(evidenceCID).length > 0, "evidence CID required");

        requestId = nextRequestId++;
        requests[requestId] = RegistrationRequest({
            requester: msg.sender,
            requestedRole: requestedRole,
            evidenceCID: evidenceCID,
            status: RequestStatus.Pending,
            verificationCID: "",
            verifiedBy: address(0),
            requestedAt: block.timestamp,
            verifiedAt: 0
        });
        pendingRequestPlusOne[msg.sender] = requestId + 1;
        emit RegistrationRequested(requestId, msg.sender, requestedRole, evidenceCID);
    }

    /// @notice The Registration Oracle records the Data Orchestrator's
    /// verification decision. The oracle cannot change the requested role.
    function fulfillRegistration(
        uint256 requestId,
        bool approved,
        string calldata verificationCID
    ) external onlyRegistrationOracle {
        RegistrationRequest storage r = requests[requestId];
        require(r.requester != address(0), "request does not exist");
        require(r.status == RequestStatus.Pending, "request already decided");
        require(bytes(verificationCID).length > 0, "verification CID required");

        r.status = approved ? RequestStatus.Approved : RequestStatus.Rejected;
        r.verificationCID = verificationCID;
        r.verifiedBy = msg.sender;
        r.verifiedAt = block.timestamp;
        pendingRequestPlusOne[r.requester] = 0;

        if (approved) {
            roleOf_[r.requester] = r.requestedRole;
            emit EntityRegistered(r.requester, r.requestedRole, msg.sender);
        }

        emit RegistrationVerified(
            requestId,
            r.requester,
            r.requestedRole,
            approved,
            verificationCID,
            msg.sender
        );
    }

    function revokeStakeholder(address entity) external onlyAdminOrRegulator {
        Role previous = roleOf_[entity];
        require(_isStakeholderRole(previous), "entity is not a stakeholder");
        roleOf_[entity] = Role.None;
        emit EntityRevoked(entity, previous, msg.sender);
    }

    function isRegistered(address entity) external view returns (bool) {
        return roleOf_[entity] != Role.None;
    }

    function isStakeholder(address entity) external view returns (bool) {
        return _isStakeholderRole(roleOf_[entity]);
    }

    function roleOf(address entity) external view returns (Role) {
        return roleOf_[entity];
    }

    function getRegistrationRequest(uint256 requestId)
        external
        view
        returns (RegistrationRequest memory)
    {
        require(requests[requestId].requester != address(0), "request does not exist");
        return requests[requestId];
    }
}


/// @title Upstream Carbon Emissions Analysis
/// @notice Every off-chain data validation or analytical calculation follows a
/// request-event -> Upstream Analytics Oracle -> Data Orchestrator -> oracle
/// fulfillment transaction sequence. The contract records which oracle fulfilled
/// each request and snapshots the input data hashes used for computation.
contract UpstreamCarbonEmissionsAnalysis is RegistrationAware {
    enum DataKind { MRIOData, FocalDemandData }
    enum ComputeKind { MRIOAccounting, StructuralPathAnalysis, StructuralDecompositionAnalysis }
    enum RequestStatus { Pending, Fulfilled, Rejected, Failed }

    struct DataUpdateRequest {
        address requester;
        DataKind kind;
        string dataHash;
        string validationHash;
        RequestStatus status;
        uint256 requestedAt;
        uint256 fulfilledAt;
        address fulfilledBy;
    }

    struct ComputeRequest {
        address requester;
        ComputeKind kind;
        uint16 baseYear;
        uint16 comparisonYear;
        string mrioDataHash;
        string focalDemandDataHash;
        string resultHash;
        RequestStatus status;
        uint256 requestedAt;
        uint256 fulfilledAt;
        address fulfilledBy;
    }

    IRegistration.Role public constant deploymentRole = IRegistration.Role.MRIODataProvider;

    string public latestMRIODataHash;
    string public latestFocalDemandDataHash;

    uint256 public nextDataRequestId;
    uint256 public nextComputeRequestId;
    mapping(uint256 => DataUpdateRequest) private dataRequests;
    mapping(uint256 => ComputeRequest) private computeRequests;

    event MRIODataUpdateRequested(
        uint256 indexed requestId,
        address indexed requester,
        string dataHash
    );
    event FocalCompanyDemandDataUpdateRequested(
        uint256 indexed requestId,
        address indexed requester,
        string dataHash
    );
    event DataUpdateValidated(
        uint256 indexed requestId,
        DataKind indexed kind,
        bool accepted,
        string validationHash,
        address indexed oracle
    );
    event FocalDemandInvalidated(
        string previousHash,
        address indexed oracle
    );

    event MRIOCarbonAccountingRequested(
        uint256 indexed requestId,
        address indexed requester,
        uint16 indexed year,
        string mrioDataHash,
        string focalDemandDataHash
    );
    event MRIOCarbonAccountingComputed(
        uint256 indexed requestId,
        uint16 indexed year,
        string resultHash,
        address indexed oracle
    );

    event StructuralPathAnalysisRequested(
        uint256 indexed requestId,
        address indexed requester,
        uint16 indexed year,
        string mrioDataHash,
        string focalDemandDataHash
    );
    event StructuralPathAnalysisCompleted(
        uint256 indexed requestId,
        uint16 indexed year,
        string resultHash,
        address indexed oracle
    );

    event StructuralDecompositionAnalysisRequested(
        uint256 indexed requestId,
        address indexed requester,
        uint16 indexed baseYear,
        uint16 comparisonYear,
        string mrioDataHash,
        string focalDemandDataHash
    );
    event StructuralDecompositionAnalysisPerformed(
        uint256 indexed requestId,
        uint16 indexed baseYear,
        uint16 indexed comparisonYear,
        string resultHash,
        address oracle
    );
    event ComputeFailed(
        uint256 indexed requestId,
        ComputeKind indexed kind,
        string errorHash,
        address indexed oracle
    );

    modifier onlyUpstreamOracle() {
        _requireActiveOracle(
            IRegistration.Role.UpstreamAnalyticsOracle,
            "caller is not the active upstream analytics oracle"
        );
        _;
    }

    constructor(address registrationAddress)
        RegistrationAware(
            registrationAddress,
            IRegistration.Role.MRIODataProvider,
            "deployer is not the registered MRIO data provider"
        )
    {}

    function _requestDataUpdate(DataKind kind, string calldata dataHash)
        internal
        returns (uint256 requestId)
    {
        require(bytes(dataHash).length > 0, "data hash required");
        requestId = nextDataRequestId++;
        dataRequests[requestId] = DataUpdateRequest({
            requester: msg.sender,
            kind: kind,
            dataHash: dataHash,
            validationHash: "",
            status: RequestStatus.Pending,
            requestedAt: block.timestamp,
            fulfilledAt: 0,
            fulfilledBy: address(0)
        });
    }

    function requestMRIODataUpdate(string calldata dataHash)
        external
        onlyRole(IRegistration.Role.MRIODataProvider)
        returns (uint256 requestId)
    {
        requestId = _requestDataUpdate(DataKind.MRIOData, dataHash);
        emit MRIODataUpdateRequested(requestId, msg.sender, dataHash);
    }

    function requestFocalCompanyDemandDataUpdate(string calldata dataHash)
        external
        onlyRole(IRegistration.Role.FocalCompany)
        returns (uint256 requestId)
    {
        requestId = _requestDataUpdate(DataKind.FocalDemandData, dataHash);
        emit FocalCompanyDemandDataUpdateRequested(requestId, msg.sender, dataHash);
    }

    function fulfillDataUpdate(
        uint256 requestId,
        bool accepted,
        string calldata validationHash
    ) external onlyUpstreamOracle {
        DataUpdateRequest storage r = dataRequests[requestId];
        require(r.requester != address(0), "request does not exist");
        require(r.status == RequestStatus.Pending, "request already decided");
        require(bytes(validationHash).length > 0, "validation hash required");

        r.validationHash = validationHash;
        r.status = accepted ? RequestStatus.Fulfilled : RequestStatus.Rejected;
        r.fulfilledAt = block.timestamp;
        r.fulfilledBy = msg.sender;

        if (accepted && r.kind == DataKind.MRIOData) {
            bool changed = keccak256(bytes(latestMRIODataHash)) != keccak256(bytes(r.dataHash));
            latestMRIODataHash = r.dataHash;
            if (changed && bytes(latestFocalDemandDataHash).length > 0) {
                string memory previousDemandHash = latestFocalDemandDataHash;
                latestFocalDemandDataHash = "";
                emit FocalDemandInvalidated(previousDemandHash, msg.sender);
            }
        } else if (accepted) {
            latestFocalDemandDataHash = r.dataHash;
        }

        emit DataUpdateValidated(requestId, r.kind, accepted, validationHash, msg.sender);
    }

    function _requestCompute(
        ComputeKind kind,
        uint16 baseYear,
        uint16 comparisonYear
    ) internal returns (uint256 requestId) {
        require(bytes(latestMRIODataHash).length > 0, "MRIO data has not been validated");
        require(bytes(latestFocalDemandDataHash).length > 0, "focal demand data has not been validated");
        require(baseYear > 0, "base year required");
        if (kind == ComputeKind.StructuralDecompositionAnalysis) {
            require(comparisonYear > baseYear, "comparison year must be later than base year");
        } else {
            require(comparisonYear == 0, "comparison year is only used for SDA");
        }

        requestId = nextComputeRequestId++;
        computeRequests[requestId] = ComputeRequest({
            requester: msg.sender,
            kind: kind,
            baseYear: baseYear,
            comparisonYear: comparisonYear,
            mrioDataHash: latestMRIODataHash,
            focalDemandDataHash: latestFocalDemandDataHash,
            resultHash: "",
            status: RequestStatus.Pending,
            requestedAt: block.timestamp,
            fulfilledAt: 0,
            fulfilledBy: address(0)
        });
    }

    function computeMRIOCarbonAccounting(uint16 year)
        external
        onlyRole(IRegistration.Role.FocalCompany)
        returns (uint256 requestId)
    {
        requestId = _requestCompute(ComputeKind.MRIOAccounting, year, 0);
        ComputeRequest storage r = computeRequests[requestId];
        emit MRIOCarbonAccountingRequested(
            requestId,
            msg.sender,
            year,
            r.mrioDataHash,
            r.focalDemandDataHash
        );
    }

    function performStructuralPathAnalysis(uint16 year)
        external
        onlyRole(IRegistration.Role.FocalCompany)
        returns (uint256 requestId)
    {
        requestId = _requestCompute(ComputeKind.StructuralPathAnalysis, year, 0);
        ComputeRequest storage r = computeRequests[requestId];
        emit StructuralPathAnalysisRequested(
            requestId,
            msg.sender,
            year,
            r.mrioDataHash,
            r.focalDemandDataHash
        );
    }

    function performStructuralDecompositionAnalysis(uint16 baseYear, uint16 comparisonYear)
        external
        onlyRole(IRegistration.Role.FocalCompany)
        returns (uint256 requestId)
    {
        requestId = _requestCompute(
            ComputeKind.StructuralDecompositionAnalysis,
            baseYear,
            comparisonYear
        );
        ComputeRequest storage r = computeRequests[requestId];
        emit StructuralDecompositionAnalysisRequested(
            requestId,
            msg.sender,
            baseYear,
            comparisonYear,
            r.mrioDataHash,
            r.focalDemandDataHash
        );
    }

    function fulfillCompute(uint256 requestId, string calldata resultHash)
        external
        onlyUpstreamOracle
    {
        ComputeRequest storage r = computeRequests[requestId];
        require(r.requester != address(0), "request does not exist");
        require(r.status == RequestStatus.Pending, "request already decided");
        require(bytes(resultHash).length > 0, "result hash required");

        r.resultHash = resultHash;
        r.status = RequestStatus.Fulfilled;
        r.fulfilledAt = block.timestamp;
        r.fulfilledBy = msg.sender;

        if (r.kind == ComputeKind.MRIOAccounting) {
            emit MRIOCarbonAccountingComputed(requestId, r.baseYear, resultHash, msg.sender);
        } else if (r.kind == ComputeKind.StructuralPathAnalysis) {
            emit StructuralPathAnalysisCompleted(requestId, r.baseYear, resultHash, msg.sender);
        } else {
            emit StructuralDecompositionAnalysisPerformed(
                requestId,
                r.baseYear,
                r.comparisonYear,
                resultHash,
                msg.sender
            );
        }
    }

    function failCompute(uint256 requestId, string calldata errorHash)
        external
        onlyUpstreamOracle
    {
        ComputeRequest storage r = computeRequests[requestId];
        require(r.requester != address(0), "request does not exist");
        require(r.status == RequestStatus.Pending, "request already decided");
        require(bytes(errorHash).length > 0, "error hash required");
        r.resultHash = errorHash;
        r.status = RequestStatus.Failed;
        r.fulfilledAt = block.timestamp;
        r.fulfilledBy = msg.sender;
        emit ComputeFailed(requestId, r.kind, errorHash, msg.sender);
    }

    function getDataUpdateRequest(uint256 requestId)
        external
        view
        returns (DataUpdateRequest memory)
    {
        require(dataRequests[requestId].requester != address(0), "request does not exist");
        return dataRequests[requestId];
    }

    function getComputeRequest(uint256 requestId)
        external
        view
        returns (ComputeRequest memory)
    {
        require(computeRequests[requestId].requester != address(0), "request does not exist");
        return computeRequests[requestId];
    }
}


/// @title Hotspots Management and Governance
/// @notice Governs the temporal Network/DLI evidence sequence, Analogue-based Upstream
/// Regional Opportunity and Resilience Assessment (AURORA), and subsequent
/// stakeholder-selected intervention governance.
/// The deterministic network result may contain a portfolio of intervention options.
/// A regulator or focal company chooses which options enter formal on-chain governance;
/// the Governance Oracle verifies each selection against the exact fulfilled Network/DLI
/// evidence before creating the associated hotspot and intervention records.
contract HotspotsManagementAndGovernance is RegistrationAware {
    enum RequestStatus { Pending, Fulfilled, Failed }
    enum InterventionStatus { Proposed, Approved, Rejected }

    struct NetworkAnalysisRequest {
        address requester;
        uint16 year;
        string resultHash;
        RequestStatus status;
        uint256 requestedAt;
        uint256 fulfilledAt;
        address fulfilledBy;
    }

    struct SourcingOpportunityRequest {
        address requester;
        uint16 year;
        uint256 networkRequestId;
        string networkResultHash;
        string resultHash;
        RequestStatus status;
        uint256 requestedAt;
        uint256 fulfilledAt;
        address fulfilledBy;
    }

    struct InterventionProposalRequest {
        address requester;
        uint256 networkRequestId;
        string networkResultHash;
        string nodeCode;
        string optionCID;
        string verificationCID;
        uint256 hotspotId;
        uint256 interventionId;
        RequestStatus status;
        uint256 requestedAt;
        uint256 fulfilledAt;
        address fulfilledBy;
    }

    struct Hotspot {
        uint256 sourceRequestId;
        string nodeCode;
        uint256 dliScoreBps;
        string evidenceCID;
        uint256 registeredAt;
        address registeredBy;
    }

    struct Intervention {
        uint256 hotspotId;
        string category;
        string actionCID;
        InterventionStatus status;
        address proposedBy;
        address decidedBy;
        uint256 proposedAt;
        uint256 decidedAt;
    }

    IRegistration.Role public constant deploymentRole = IRegistration.Role.FocalCompany;

    uint256 public nextRequestId;
    mapping(uint256 => NetworkAnalysisRequest) private networkRequests;
    mapping(uint16 => uint256) private latestFulfilledNetworkRequestPlusOne;
    mapping(uint256 => uint256) private temporalBaselineForDecisionRequestPlusOne;

    uint256 public nextSourcingRequestId;
    mapping(uint256 => SourcingOpportunityRequest) private sourcingRequests;
    mapping(uint256 => uint256) private sourcingForNetworkRequestPlusOne;

    uint256 public nextInterventionProposalRequestId;
    mapping(uint256 => InterventionProposalRequest) private interventionProposalRequests;
    mapping(uint256 => uint256[]) private interventionProposalRequestIdsForNetworkRequest;
    mapping(uint256 => mapping(bytes32 => bool)) private interventionOptionRequestedForNetworkRequest;

    uint256 public nextHotspotId;
    uint256 public nextInterventionId;
    mapping(uint256 => Hotspot) private hotspots;
    mapping(uint256 => Intervention) private interventions;
    mapping(uint256 => string[]) private interventionPerformanceEvidenceCIDs;
    mapping(uint256 => uint256[]) private hotspotIdsForRequest;
    mapping(uint256 => mapping(bytes32 => uint256)) private hotspotForRequestAndNodePlusOne;
    mapping(uint256 => uint256) private interventionForHotspotPlusOne;

    event NetworkAnalysisRequested(
        uint256 indexed requestId,
        address indexed requester,
        uint16 indexed year
    );
    event NetworkAnalysisCompleted(
        uint256 indexed requestId,
        uint16 indexed year,
        string resultHash,
        address indexed oracle
    );
    event NetworkAnalysisFailed(
        uint256 indexed requestId,
        uint16 indexed year,
        string errorHash,
        address indexed oracle
    );

    event InterventionProposalRequested(
        uint256 indexed requestId,
        address indexed requester,
        uint256 indexed networkRequestId,
        string networkResultHash,
        string nodeCode,
        string optionCID
    );
    event InterventionProposalFulfilled(
        uint256 indexed requestId,
        uint256 indexed hotspotId,
        uint256 indexed interventionId,
        string nodeCode,
        string verificationCID,
        address oracle
    );
    event InterventionProposalFailed(
        uint256 indexed requestId,
        uint256 indexed networkRequestId,
        string nodeCode,
        string errorCID,
        address indexed oracle
    );

    event RegionalSourcingOpportunityAnalysisRequested(
        uint256 indexed requestId,
        address indexed requester,
        uint16 indexed year,
        uint256 networkRequestId,
        string networkResultHash
    );
    event RegionalSourcingOpportunityAnalysisCompleted(
        uint256 indexed requestId,
        uint16 year,
        uint256 indexed networkRequestId,
        string resultHash,
        address indexed oracle
    );
    event RegionalSourcingOpportunityAnalysisFailed(
        uint256 indexed requestId,
        uint16 year,
        uint256 indexed networkRequestId,
        string errorHash,
        address indexed oracle
    );

    event HotspotRegistered(
        uint256 indexed hotspotId,
        uint256 indexed sourceRequestId,
        string nodeCode,
        uint256 dliScoreBps,
        string evidenceCID,
        address indexed oracle
    );
    event InterventionProposed(
        uint256 indexed interventionId,
        uint256 indexed hotspotId,
        string category,
        string actionCID,
        address indexed oracle
    );
    event InterventionDecided(
        uint256 indexed interventionId,
        InterventionStatus status,
        address indexed decidedBy
    );
    event InterventionPerformanceRecorded(
        uint256 indexed interventionId,
        uint256 indexed observationIndex,
        string evidenceCID,
        address indexed recordedBy
    );

    modifier onlyGovernanceOracle() {
        _requireActiveOracle(
            IRegistration.Role.GovernanceOracle,
            "caller is not the active governance oracle"
        );
        _;
    }

    modifier onlyGovernor() {
        IRegistration.Role role = registration.roleOf(msg.sender);
        require(
            role == IRegistration.Role.RegulatoryAuthority ||
                role == IRegistration.Role.FocalCompany,
            "caller is not authorized to govern interventions"
        );
        _;
    }

    constructor(address registrationAddress)
        RegistrationAware(
            registrationAddress,
            IRegistration.Role.FocalCompany,
            "deployer is not the registered focal company"
        )
    {}

    function performNetworkAnalysis(uint16 year)
        external
        onlyRole(IRegistration.Role.FocalCompany)
        returns (uint256 requestId)
    {
        require(year == 2014 || year == 2017, "supported Network/DLI year required");
        requestId = nextRequestId++;
        if (year == 2017) {
            uint256 baselinePlusOne = latestFulfilledNetworkRequestPlusOne[2014];
            require(baselinePlusOne != 0, "complete 2014 Network/DLI before 2017");
            temporalBaselineForDecisionRequestPlusOne[requestId] = baselinePlusOne;
        }
        networkRequests[requestId] = NetworkAnalysisRequest({
            requester: msg.sender,
            year: year,
            resultHash: "",
            status: RequestStatus.Pending,
            requestedAt: block.timestamp,
            fulfilledAt: 0,
            fulfilledBy: address(0)
        });
        emit NetworkAnalysisRequested(requestId, msg.sender, year);
    }

    function fulfillNetworkAnalysis(uint256 requestId, string calldata resultHash)
        external
        onlyGovernanceOracle
    {
        NetworkAnalysisRequest storage r = networkRequests[requestId];
        require(r.requester != address(0), "request does not exist");
        require(r.status == RequestStatus.Pending, "request already decided");
        require(bytes(resultHash).length > 0, "result hash required");
        r.resultHash = resultHash;
        r.status = RequestStatus.Fulfilled;
        r.fulfilledAt = block.timestamp;
        r.fulfilledBy = msg.sender;
        latestFulfilledNetworkRequestPlusOne[r.year] = requestId + 1;
        emit NetworkAnalysisCompleted(requestId, r.year, resultHash, msg.sender);
    }

    function failNetworkAnalysis(uint256 requestId, string calldata errorHash)
        external
        onlyGovernanceOracle
    {
        NetworkAnalysisRequest storage r = networkRequests[requestId];
        require(r.requester != address(0), "request does not exist");
        require(r.status == RequestStatus.Pending, "request already decided");
        require(bytes(errorHash).length > 0, "error hash required");
        r.resultHash = errorHash;
        r.status = RequestStatus.Failed;
        r.fulfilledAt = block.timestamp;
        r.fulfilledBy = msg.sender;
        emit NetworkAnalysisFailed(requestId, r.year, errorHash, msg.sender);
    }

    function requestInterventionProposal(
        uint256 networkRequestId,
        string calldata nodeCode,
        string calldata optionCID
    ) external onlyGovernor returns (uint256 requestId) {
        NetworkAnalysisRequest storage source = networkRequests[networkRequestId];
        require(source.requester != address(0), "network request does not exist");
        require(source.status == RequestStatus.Fulfilled, "network request is not fulfilled");
        require(source.year == 2017, "formal interventions require 2017 network evidence");
        require(bytes(source.resultHash).length > 0, "network result hash required");
        require(bytes(nodeCode).length > 0, "node code required");
        require(bytes(optionCID).length > 0, "intervention option CID required");
        uint256 sourcingPlusOne = sourcingForNetworkRequestPlusOne[networkRequestId];
        require(sourcingPlusOne != 0, "complete AURORA before intervention governance");
        require(
            sourcingRequests[sourcingPlusOne - 1].status == RequestStatus.Fulfilled,
            "AURORA request is not fulfilled"
        );

        bytes32 optionKey = keccak256(abi.encode(nodeCode, optionCID));
        require(
            !interventionOptionRequestedForNetworkRequest[networkRequestId][optionKey],
            "intervention option already requested"
        );

        requestId = nextInterventionProposalRequestId++;
        interventionProposalRequests[requestId] = InterventionProposalRequest({
            requester: msg.sender,
            networkRequestId: networkRequestId,
            networkResultHash: source.resultHash,
            nodeCode: nodeCode,
            optionCID: optionCID,
            verificationCID: "",
            hotspotId: 0,
            interventionId: 0,
            status: RequestStatus.Pending,
            requestedAt: block.timestamp,
            fulfilledAt: 0,
            fulfilledBy: address(0)
        });
        interventionProposalRequestIdsForNetworkRequest[networkRequestId].push(requestId);
        interventionOptionRequestedForNetworkRequest[networkRequestId][optionKey] = true;
        emit InterventionProposalRequested(
            requestId,
            msg.sender,
            networkRequestId,
            source.resultHash,
            nodeCode,
            optionCID
        );
    }

    function fulfillInterventionProposal(
        uint256 requestId,
        uint256 dliScoreBps,
        string calldata evidenceCID,
        string calldata category,
        string calldata actionCID,
        string calldata verificationCID
    ) external onlyGovernanceOracle returns (uint256 hotspotId, uint256 interventionId) {
        InterventionProposalRequest storage r = interventionProposalRequests[requestId];
        require(r.requester != address(0), "proposal request does not exist");
        require(r.status == RequestStatus.Pending, "proposal request already decided");
        require(networkRequests[r.networkRequestId].status == RequestStatus.Fulfilled, "network request is not fulfilled");
        require(dliScoreBps <= 10000, "DLI score out of range");
        require(bytes(evidenceCID).length > 0, "evidence CID required");
        require(bytes(category).length > 0, "category required");
        require(bytes(actionCID).length > 0, "action CID required");
        require(bytes(verificationCID).length > 0, "verification CID required");
        require(
            keccak256(bytes(actionCID)) == keccak256(bytes(r.optionCID)),
            "action CID does not match selected option"
        );

        hotspotId = _registerSelectedHotspot(r, dliScoreBps, evidenceCID);
        interventionId = _createSelectedIntervention(hotspotId, category, actionCID);

        r.verificationCID = verificationCID;
        r.hotspotId = hotspotId;
        r.interventionId = interventionId;
        r.status = RequestStatus.Fulfilled;
        r.fulfilledAt = block.timestamp;
        r.fulfilledBy = msg.sender;

        emit InterventionProposalFulfilled(
            requestId,
            hotspotId,
            interventionId,
            r.nodeCode,
            verificationCID,
            msg.sender
        );
    }

    function failInterventionProposal(uint256 requestId, string calldata errorCID)
        external
        onlyGovernanceOracle
    {
        InterventionProposalRequest storage r = interventionProposalRequests[requestId];
        require(r.requester != address(0), "proposal request does not exist");
        require(r.status == RequestStatus.Pending, "proposal request already decided");
        require(bytes(errorCID).length > 0, "error CID required");
        r.verificationCID = errorCID;
        r.status = RequestStatus.Failed;
        r.fulfilledAt = block.timestamp;
        r.fulfilledBy = msg.sender;
        interventionOptionRequestedForNetworkRequest[r.networkRequestId][
            keccak256(abi.encode(r.nodeCode, r.optionCID))
        ] = false;
        emit InterventionProposalFailed(
            requestId,
            r.networkRequestId,
            r.nodeCode,
            errorCID,
            msg.sender
        );
    }

    function decideIntervention(uint256 interventionId, bool approve) external onlyGovernor {
        Intervention storage intervention = interventions[interventionId];
        require(intervention.proposedBy != address(0), "intervention does not exist");
        require(intervention.status == InterventionStatus.Proposed, "intervention already decided");
        intervention.status = approve ? InterventionStatus.Approved : InterventionStatus.Rejected;
        intervention.decidedBy = msg.sender;
        intervention.decidedAt = block.timestamp;
        emit InterventionDecided(interventionId, intervention.status, msg.sender);
    }

    /// @notice Anchor a post-deployment monitoring package for an approved intervention.
    /// The content-addressed package contains baseline, observed footprint,
    /// monitoring period, assessor and evidence reference. The contract records
    /// provenance and authorization; it does not attest to external measurement truth.
    function recordInterventionPerformance(
        uint256 interventionId,
        string calldata evidenceCID
    ) external onlyGovernor returns (uint256 observationIndex) {
        Intervention storage intervention = interventions[interventionId];
        require(intervention.proposedBy != address(0), "intervention does not exist");
        require(intervention.status == InterventionStatus.Approved, "intervention is not approved");
        require(bytes(evidenceCID).length > 0, "performance evidence CID required");
        observationIndex = interventionPerformanceEvidenceCIDs[interventionId].length;
        interventionPerformanceEvidenceCIDs[interventionId].push(evidenceCID);
        emit InterventionPerformanceRecorded(
            interventionId,
            observationIndex,
            evidenceCID,
            msg.sender
        );
    }

    function performRegionalSourcingOpportunityAnalysis(
        uint16 year,
        uint256 networkRequestId
    )
        external
        onlyRole(IRegistration.Role.FocalCompany)
        returns (uint256 requestId)
    {
        NetworkAnalysisRequest storage networkRequest = networkRequests[networkRequestId];
        require(networkRequest.requester != address(0), "network request does not exist");
        require(networkRequest.status == RequestStatus.Fulfilled, "network request is not fulfilled");
        require(year == 2017, "AURORA requires the 2017 decision year");
        require(networkRequest.year == year, "year does not match network evidence");
        require(bytes(networkRequest.resultHash).length > 0, "network result hash required");
        uint256 baselinePlusOne = temporalBaselineForDecisionRequestPlusOne[networkRequestId];
        require(baselinePlusOne != 0, "2017 evidence is not bound to fulfilled 2014 Network/DLI");
        NetworkAnalysisRequest storage baselineRequest = networkRequests[baselinePlusOne - 1];
        require(
            baselineRequest.status == RequestStatus.Fulfilled && baselineRequest.year == 2014,
            "bound 2014 Network/DLI evidence is not fulfilled"
        );
        uint256 previousPlusOne = sourcingForNetworkRequestPlusOne[networkRequestId];
        if (previousPlusOne != 0) {
            require(
                sourcingRequests[previousPlusOne - 1].status == RequestStatus.Failed,
                "sourcing analysis already pending or fulfilled for network evidence"
            );
        }

        requestId = nextSourcingRequestId++;
        sourcingRequests[requestId] = SourcingOpportunityRequest({
            requester: msg.sender,
            year: year,
            networkRequestId: networkRequestId,
            networkResultHash: networkRequest.resultHash,
            resultHash: "",
            status: RequestStatus.Pending,
            requestedAt: block.timestamp,
            fulfilledAt: 0,
            fulfilledBy: address(0)
        });
        sourcingForNetworkRequestPlusOne[networkRequestId] = requestId + 1;
        emit RegionalSourcingOpportunityAnalysisRequested(
            requestId,
            msg.sender,
            year,
            networkRequestId,
            networkRequest.resultHash
        );
    }

    function fulfillRegionalSourcingOpportunityAnalysis(
        uint256 requestId,
        string calldata resultHash
    ) external onlyGovernanceOracle {
        SourcingOpportunityRequest storage r = sourcingRequests[requestId];
        require(r.requester != address(0), "request does not exist");
        require(r.status == RequestStatus.Pending, "request already decided");
        require(bytes(resultHash).length > 0, "result hash required");
        r.resultHash = resultHash;
        r.status = RequestStatus.Fulfilled;
        r.fulfilledAt = block.timestamp;
        r.fulfilledBy = msg.sender;
        emit RegionalSourcingOpportunityAnalysisCompleted(
            requestId,
            r.year,
            r.networkRequestId,
            resultHash,
            msg.sender
        );
    }

    function failRegionalSourcingOpportunityAnalysis(
        uint256 requestId,
        string calldata errorHash
    ) external onlyGovernanceOracle {
        SourcingOpportunityRequest storage r = sourcingRequests[requestId];
        require(r.requester != address(0), "request does not exist");
        require(r.status == RequestStatus.Pending, "request already decided");
        require(bytes(errorHash).length > 0, "error hash required");
        r.resultHash = errorHash;
        r.status = RequestStatus.Failed;
        r.fulfilledAt = block.timestamp;
        r.fulfilledBy = msg.sender;
        emit RegionalSourcingOpportunityAnalysisFailed(
            requestId,
            r.year,
            r.networkRequestId,
            errorHash,
            msg.sender
        );
    }

    function getNetworkRequest(uint256 requestId)
        external
        view
        returns (NetworkAnalysisRequest memory)
    {
        require(networkRequests[requestId].requester != address(0), "request does not exist");
        return networkRequests[requestId];
    }

    /// @notice Exposes the exact fulfilled 2014 Network/DLI request bound when
    /// a 2017 decision-year request was created. This makes the temporal pair
    /// independently reconstructable by lifecycle and audit clients.
    function getTemporalBaselineNetworkRequest(uint256 decisionRequestId)
        external
        view
        returns (uint256 baselineRequestId)
    {
        NetworkAnalysisRequest storage decision = networkRequests[decisionRequestId];
        require(decision.requester != address(0), "network request does not exist");
        require(decision.year == 2017, "decision-year Network/DLI request required");
        uint256 baselinePlusOne = temporalBaselineForDecisionRequestPlusOne[
            decisionRequestId
        ];
        require(baselinePlusOne != 0, "temporal baseline is unavailable");
        return baselinePlusOne - 1;
    }

    function getInterventionProposalRequest(uint256 requestId)
        external
        view
        returns (InterventionProposalRequest memory)
    {
        require(
            interventionProposalRequests[requestId].requester != address(0),
            "proposal request does not exist"
        );
        return interventionProposalRequests[requestId];
    }

    function getInterventionProposalRequestIdsForNetworkRequest(uint256 networkRequestId)
        external
        view
        returns (uint256[] memory)
    {
        return interventionProposalRequestIdsForNetworkRequest[networkRequestId];
    }

    function getInterventionPortfolioStatus(uint256 networkRequestId)
        external
        view
        returns (
            uint256 selected,
            uint256 fulfilled,
            uint256 decided,
            bool allDecided
        )
    {
        return _portfolioStatus(networkRequestId);
    }

    function getSourcingOpportunityRequest(uint256 requestId)
        external
        view
        returns (SourcingOpportunityRequest memory)
    {
        require(sourcingRequests[requestId].requester != address(0), "request does not exist");
        return sourcingRequests[requestId];
    }

    function getSourcingRequestIdForNetworkRequest(uint256 networkRequestId)
        external
        view
        returns (bool exists, uint256 requestId)
    {
        uint256 value = sourcingForNetworkRequestPlusOne[networkRequestId];
        return (value != 0, value == 0 ? 0 : value - 1);
    }

    function getHotspot(uint256 hotspotId) external view returns (Hotspot memory) {
        require(bytes(hotspots[hotspotId].nodeCode).length != 0, "hotspot does not exist");
        return hotspots[hotspotId];
    }

    function getHotspotIdsForRequest(uint256 requestId)
        external
        view
        returns (uint256[] memory)
    {
        return hotspotIdsForRequest[requestId];
    }

    /// @notice Backward-compatible helper returning the first registered hotspot.
    function getHotspotIdForRequest(uint256 requestId)
        external
        view
        returns (bool exists, uint256 hotspotId)
    {
        uint256[] storage ids = hotspotIdsForRequest[requestId];
        return (ids.length > 0, ids.length == 0 ? 0 : ids[0]);
    }

    function getIntervention(uint256 interventionId)
        external
        view
        returns (Intervention memory)
    {
        require(interventions[interventionId].proposedBy != address(0), "intervention does not exist");
        return interventions[interventionId];
    }

    function getInterventionPerformanceEvidenceCIDs(uint256 interventionId)
        external
        view
        returns (string[] memory)
    {
        require(interventions[interventionId].proposedBy != address(0), "intervention does not exist");
        return interventionPerformanceEvidenceCIDs[interventionId];
    }

    function getInterventionIdForHotspot(uint256 hotspotId)
        external
        view
        returns (bool exists, uint256 interventionId)
    {
        uint256 value = interventionForHotspotPlusOne[hotspotId];
        return (value != 0, value == 0 ? 0 : value - 1);
    }

    function _registerSelectedHotspot(
        InterventionProposalRequest storage proposal,
        uint256 dliScoreBps,
        string calldata evidenceCID
    ) internal returns (uint256 hotspotId) {
        bytes32 nodeKey = keccak256(bytes(proposal.nodeCode));
        uint256 existingPlusOne = hotspotForRequestAndNodePlusOne[
            proposal.networkRequestId
        ][nodeKey];
        if (existingPlusOne != 0) {
            return existingPlusOne - 1;
        }
        hotspotId = nextHotspotId++;
        hotspots[hotspotId] = Hotspot({
            sourceRequestId: proposal.networkRequestId,
            nodeCode: proposal.nodeCode,
            dliScoreBps: dliScoreBps,
            evidenceCID: evidenceCID,
            registeredAt: block.timestamp,
            registeredBy: msg.sender
        });
        hotspotIdsForRequest[proposal.networkRequestId].push(hotspotId);
        hotspotForRequestAndNodePlusOne[proposal.networkRequestId][nodeKey] = hotspotId + 1;
        emit HotspotRegistered(
            hotspotId,
            proposal.networkRequestId,
            proposal.nodeCode,
            dliScoreBps,
            evidenceCID,
            msg.sender
        );
    }

    function _createSelectedIntervention(
        uint256 hotspotId,
        string calldata category,
        string calldata actionCID
    ) internal returns (uint256 interventionId) {
        interventionId = nextInterventionId++;
        interventions[interventionId] = Intervention({
            hotspotId: hotspotId,
            category: category,
            actionCID: actionCID,
            status: InterventionStatus.Proposed,
            proposedBy: msg.sender,
            decidedBy: address(0),
            proposedAt: block.timestamp,
            decidedAt: 0
        });
        if (interventionForHotspotPlusOne[hotspotId] == 0) {
            interventionForHotspotPlusOne[hotspotId] = interventionId + 1;
        }
        emit InterventionProposed(interventionId, hotspotId, category, actionCID, msg.sender);
    }

    function _portfolioStatus(uint256 networkRequestId)
        internal
        view
        returns (
            uint256 selected,
            uint256 fulfilled,
            uint256 decided,
            bool allDecided
        )
    {
        uint256[] storage ids = interventionProposalRequestIdsForNetworkRequest[networkRequestId];
        for (uint256 i = 0; i < ids.length; i++) {
            InterventionProposalRequest storage proposal = interventionProposalRequests[ids[i]];
            if (proposal.status == RequestStatus.Failed) {
                continue;
            }
            selected += 1;
            if (proposal.status == RequestStatus.Fulfilled) {
                fulfilled += 1;
                Intervention storage intervention = interventions[proposal.interventionId];
                if (
                    intervention.status == InterventionStatus.Approved ||
                    intervention.status == InterventionStatus.Rejected
                ) {
                    decided += 1;
                }
            }
        }
        allDecided = selected > 0 && fulfilled == selected && decided == selected;
    }
}


/// @title Query Management
/// @notice Natural-language requests are submitted by registered stakeholders,
/// emitted to the dedicated Query Oracle, processed by the off-chain Data
/// Orchestrator, and fulfilled by the Query Oracle with a content-addressed
/// result. The requested assistant mode and the fulfilling oracle are recorded
/// explicitly for auditability.
contract QueryManagement is RegistrationAware {
    enum AssistantMode { Auto, ResearchOnly, GeneralChat }
    enum RouteType { Unclassified, Direct, Compute, Retrieval, Composite }
    enum QueryStatus { Pending, Fulfilled, Failed }

    struct Query {
        address requester;
        string queryText;
        string dataReferenceCID;
        AssistantMode assistantMode;
        RouteType route;
        QueryStatus status;
        string resultCID;
        string errorCID;
        uint256 requestedAt;
        uint256 fulfilledAt;
        address fulfilledBy;
    }

    IRegistration.Role public constant deploymentRole = IRegistration.Role.FocalCompany;
    uint256 public nextRequestId;
    mapping(uint256 => Query) private queries;

    event QueryRequested(
        uint256 indexed requestId,
        address indexed requester,
        AssistantMode indexed assistantMode,
        string queryText,
        string dataReferenceCID
    );
    event QueryFulfilled(
        uint256 indexed requestId,
        RouteType indexed route,
        string resultCID,
        address indexed oracle
    );
    event QueryFailed(
        uint256 indexed requestId,
        string errorCID,
        address indexed oracle
    );

    modifier onlyStakeholder() {
        IRegistration.Role role = registration.roleOf(msg.sender);
        require(
            role == IRegistration.Role.RegulatoryAuthority ||
                role == IRegistration.Role.MRIODataProvider ||
                role == IRegistration.Role.FocalCompany,
            "caller is not a registered stakeholder"
        );
        _;
    }

    modifier onlyQueryOracle() {
        _requireActiveOracle(
            IRegistration.Role.QueryOracle,
            "caller is not the active query oracle"
        );
        _;
    }

    constructor(address registrationAddress)
        RegistrationAware(
            registrationAddress,
            IRegistration.Role.FocalCompany,
            "deployer is not the registered focal company"
        )
    {}

    function _submitQuery(
        string calldata queryText,
        string calldata dataReferenceCID,
        AssistantMode assistantMode
    ) internal returns (uint256 requestId) {
        require(bytes(queryText).length > 0, "query text required");
        requestId = nextRequestId++;
        queries[requestId] = Query({
            requester: msg.sender,
            queryText: queryText,
            dataReferenceCID: dataReferenceCID,
            assistantMode: assistantMode,
            route: RouteType.Unclassified,
            status: QueryStatus.Pending,
            resultCID: "",
            errorCID: "",
            requestedAt: block.timestamp,
            fulfilledAt: 0,
            fulfilledBy: address(0)
        });
        emit QueryRequested(
            requestId,
            msg.sender,
            assistantMode,
            queryText,
            dataReferenceCID
        );
    }

    /// @notice Explicit assistant-mode entry point used by the dashboard.
    function submitQuery(
        string calldata queryText,
        string calldata dataReferenceCID,
        AssistantMode assistantMode
    ) external onlyStakeholder returns (uint256 requestId) {
        return _submitQuery(queryText, dataReferenceCID, assistantMode);
    }

    /// @notice Backward-compatible entry point; defaults to Auto mode.
    function submitQuery(string calldata queryText, string calldata dataReferenceCID)
        external
        onlyStakeholder
        returns (uint256 requestId)
    {
        return _submitQuery(queryText, dataReferenceCID, AssistantMode.Auto);
    }

    function fulfillQuery(
        uint256 requestId,
        RouteType route,
        string calldata resultCID
    ) external onlyQueryOracle {
        Query storage q = queries[requestId];
        require(q.requester != address(0), "query does not exist");
        require(q.status == QueryStatus.Pending, "query already decided");
        require(route != RouteType.Unclassified, "classified route required");
        require(bytes(resultCID).length > 0, "result CID required");

        q.route = route;
        q.status = QueryStatus.Fulfilled;
        q.resultCID = resultCID;
        q.fulfilledAt = block.timestamp;
        q.fulfilledBy = msg.sender;
        emit QueryFulfilled(requestId, route, resultCID, msg.sender);
    }

    function failQuery(uint256 requestId, string calldata errorCID)
        external
        onlyQueryOracle
    {
        Query storage q = queries[requestId];
        require(q.requester != address(0), "query does not exist");
        require(q.status == QueryStatus.Pending, "query already decided");
        require(bytes(errorCID).length > 0, "error CID required");
        q.status = QueryStatus.Failed;
        q.errorCID = errorCID;
        q.fulfilledAt = block.timestamp;
        q.fulfilledBy = msg.sender;
        emit QueryFailed(requestId, errorCID, msg.sender);
    }

    function getQuery(uint256 requestId) external view returns (Query memory) {
        require(queries[requestId].requester != address(0), "query does not exist");
        return queries[requestId];
    }
}
