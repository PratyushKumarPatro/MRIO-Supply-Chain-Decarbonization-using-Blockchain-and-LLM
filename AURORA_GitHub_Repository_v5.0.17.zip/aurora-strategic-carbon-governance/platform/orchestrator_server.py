"""HTTP boundary for the off-chain Data Orchestrator.

The four oracle processes call this service; they do not import or execute the
analytical modules themselves. This makes the runtime sequence explicit:

    smart-contract event -> dedicated oracle -> HTTP Data Orchestrator
    -> dedicated oracle -> smart-contract fulfillment
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import traceback
import threading
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any

from data_orchestrator import DataOrchestrator, _jsonable, utc_now
from release_identity import PACKAGE_VERSION, RELEASE_IDENTITY, RELEASE_PATCH

BASE_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = BASE_DIR / "runtime"


class OrchestratorApplication:
    def __init__(self, deployment_path: str):
        self.deployment_path = Path(deployment_path).resolve()
        self.package_root = BASE_DIR.resolve()
        self.orchestrator = DataOrchestrator(deployment_path=self.deployment_path)
        self.deployment_fingerprint = ""
        self._refresh_deployment()

    def _refresh_deployment(self) -> None:
        """Reload the evolving guided platform deployment state without restarting the service."""
        if self.deployment_path.is_file():
            raw = self.deployment_path.read_bytes()
            self.deployment_fingerprint = hashlib.sha256(raw).hexdigest()
            try:
                deployment = json.loads(raw.decode("utf-8"))
            except (UnicodeDecodeError, json.JSONDecodeError):
                return
            if isinstance(deployment, dict):
                self.orchestrator.deployment = deployment
        else:
            self.deployment_fingerprint = ""

    def health_payload(self) -> dict[str, Any]:
        self._refresh_deployment()
        deployment = self.orchestrator.deployment
        return {
            "ok": True,
            "service": "off-chain-data-orchestrator",
            "version": PACKAGE_VERSION,
            "release_patch": RELEASE_PATCH,
            "integrated_methodology_extension": RELEASE_IDENTITY["integrated_methodology_extension_id"],
            "spa_pathway_relevance_extension": RELEASE_IDENTITY["spa_pathway_relevance_extension_id"],
            "spa_reporting_extension": RELEASE_IDENTITY["spa_reporting_extension_id"],
            "dli_objective_weighting_extension": RELEASE_IDENTITY["dli_objective_weighting_extension_id"],
            "aurora_similarity_threshold_extension": RELEASE_IDENTITY["aurora_similarity_threshold_extension_id"],
            "dli_in_app_execution_extension": RELEASE_IDENTITY["dli_in_app_execution_extension_id"],
            "cdr_producer_linkage_extension": RELEASE_IDENTITY["cdr_producer_linkage_extension_id"],
            "path_alignment_extension": RELEASE_IDENTITY["path_alignment_extension_id"],
            "path_driver_extension": RELEASE_IDENTITY["path_driver_extension_id"],
            "node_wise_sda_extension": RELEASE_IDENTITY["node_wise_sda_extension_id"],
            "hotspot_leverage_extension": RELEASE_IDENTITY["hotspot_leverage_extension_id"],
            "intervention_governance_extension": RELEASE_IDENTITY["intervention_governance_extension_id"],
            "aurora_lifecycle_extension": RELEASE_IDENTITY["aurora_lifecycle_extension_id"],
            "methodology_lifecycle_extension": RELEASE_IDENTITY["methodology_lifecycle_extension_id"],
            "governance_interface_extension": RELEASE_IDENTITY["governance_interface_extension_id"],
            "abatement_scenario_extension": RELEASE_IDENTITY["abatement_scenario_extension_id"],
            "performance_monitoring_extension": RELEASE_IDENTITY["performance_monitoring_extension_id"],
            "final_decision_support_gate_extension": RELEASE_IDENTITY["final_decision_support_gate_extension_id"],
            "blockchain_control_plane_extension": RELEASE_IDENTITY["blockchain_control_plane_extension_id"],
            "time_utc": utc_now(),
            "pid": os.getpid(),
            "package_root": str(self.package_root),
            "deployment_path": str(self.deployment_path),
            "deployment_fingerprint": self.deployment_fingerprint,
            "chain_id": deployment.get("chain_id"),
            "architecture_version": deployment.get("architecture_version"),
            "content_store": str((self.package_root / "content_store").resolve()),
        }

    def dispatch(self, path: str, body: dict[str, Any]) -> dict[str, Any]:
        self._refresh_deployment()
        request_context = (
            body.get("request_context")
            if isinstance(body.get("request_context"), dict)
            else {}
        )
        if path == "/v1/registration/verify":
            result = self.orchestrator.verify_registration(
                requester=str(body["requester"]),
                requested_role=int(body["requested_role"]),
                evidence_cid=str(body.get("evidence_cid", "")),
                request_context=request_context,
            )
        elif path == "/v1/upstream/data-validate":
            result = self.orchestrator.validate_data_update(
                kind=str(body["kind"]),
                data_hash=str(body["data_hash"]),
                requester=str(body["requester"]),
                request_context=request_context,
            )
        elif path == "/v1/upstream/data-promote":
            result = self.orchestrator.promote_data_update(
                kind=str(body["kind"]),
                data_hash=str(body["data_hash"]),
                requester=str(body["requester"]),
                request_context=request_context,
            )
        elif path == "/v1/upstream/mrio":
            result = self.orchestrator.compute_mrio(
                int(body["year"]), request_context=request_context
            )
        elif path == "/v1/upstream/spa":
            result = self.orchestrator.compute_spa(
                int(body["year"]), request_context=request_context
            )
        elif path == "/v1/upstream/sda":
            result = self.orchestrator.compute_sda(
                int(body["base_year"]),
                int(body["comparison_year"]),
                request_context=request_context,
            )
        elif path == "/v1/governance/network":
            result = self.orchestrator.compute_network(
                int(body["year"]), request_context=request_context
            )
        elif path == "/v1/governance/intervention-materialize":
            result = self.orchestrator.materialize_post_aurora_intervention_governance(
                str(body["network_result_hash"]),
                str(body["aurora_result_hash"]),
                request_context=request_context,
            )
        elif path == "/v1/governance/intervention-actionability":
            result = self.orchestrator.record_intervention_actionability(
                str(body["network_result_hash"]),
                str(body["candidate_id"]),
                body.get("assessment") if isinstance(body.get("assessment"), dict) else {},
                request_context=request_context,
            )
        elif path == "/v1/governance/intervention-proposal":
            result = self.orchestrator.prepare_intervention_proposal(
                str(body["network_result_hash"]),
                str(body["node_code"]),
                str(body["option_cid"]),
                request_context=request_context,
            )
        elif path == "/v1/governance/intervention-performance":
            result = self.orchestrator.record_intervention_performance_evidence(
                str(body["network_result_hash"]),
                str(body["option_cid"]),
                int(body["intervention_id"]),
                body.get("observation") if isinstance(body.get("observation"), dict) else {},
                request_context=request_context,
            )
        elif path == "/v1/governance/sourcing-opportunities":
            result = self.orchestrator.compute_sourcing_opportunities(
                int(body["year"]),
                str(body["network_result_hash"]),
                request_context=request_context,
            )
        elif path == "/v1/governance/final-methodology":
            result = self.orchestrator.compute_integrated_methodology(
                request_context=request_context,
            )
        elif path == "/v1/governance/dli-robustness":
            result = self.orchestrator.compute_dli_weight_robustness(
                int(body["year"]),
                top_k=int(body.get("top_k", 15)),
                monte_carlo_samples=int(body.get("samples", 5000)),
                dirichlet_concentration=float(body.get("concentration", 80.0)),
                random_seed=int(body.get("seed", 20260831)),
                critic_correlation_method=str(body.get("critic_correlation", "pearson")),
                request_context=request_context,
            )
        elif path == "/v1/query":
            result = self.orchestrator.process_query(
                requester=str(body["requester"]),
                query_text=str(body["query_text"]),
                data_reference_cid=str(body.get("data_reference_cid", "")),
                mode=str(body.get("mode", "auto")),
                request_context=request_context,
            )
        elif path == "/v1/content/get":
            from data_orchestrator import load_content
            content_hash = str(body["content_hash"]).strip().lower()
            content = load_content(content_hash)
            return {
                "ok": True,
                "result": {"content_hash": content_hash, "content": content},
            }
        elif path == "/v1/error":
            result = self.orchestrator.record_error(
                operation=str(body.get("operation", "unknown")),
                error=str(body.get("error", "unknown error")),
                context=body.get("context") if isinstance(body.get("context"), dict) else {},
                request_context=request_context,
            )
        else:
            raise KeyError(f"Unknown orchestrator endpoint: {path}")
        return {"ok": True, "result": result.to_dict()}


class Handler(BaseHTTPRequestHandler):
    server_version = f"StrategicCarbonOrchestrator/{PACKAGE_VERSION}-{RELEASE_PATCH}"

    def _send(self, status: int, payload: dict[str, Any]) -> None:
        body = json.dumps(
            _jsonable(payload),
            ensure_ascii=False,
            allow_nan=False,
            default=str,
        ).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt: str, *args: Any) -> None:
        print(f"[orchestrator-http] {self.address_string()} - {fmt % args}")

    def do_GET(self) -> None:  # noqa: N802
        if self.path == "/health":
            self._send(HTTPStatus.OK, self.server.application.health_payload())  # type: ignore[attr-defined]
            return
        self._send(HTTPStatus.NOT_FOUND, {"ok": False, "error": "not found"})

    def do_POST(self) -> None:  # noqa: N802
        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length)
            body = json.loads(raw.decode("utf-8") or "{}")
            if not isinstance(body, dict):
                raise ValueError("JSON request body must be an object")
            response = self.server.application.dispatch(self.path, body)  # type: ignore[attr-defined]
            self._send(HTTPStatus.OK, response)
        except KeyError as exc:
            self._send(HTTPStatus.NOT_FOUND, {"ok": False, "error": str(exc)})
        except FileNotFoundError as exc:
            self._send(HTTPStatus.NOT_FOUND, {"ok": False, "error": str(exc)})
        except (ValueError, TypeError) as exc:
            self._send(HTTPStatus.BAD_REQUEST, {"ok": False, "error": str(exc)})
        except Exception as exc:  # keep the oracle-facing API explicit about failure
            traceback.print_exc()
            self._send(
                HTTPStatus.INTERNAL_SERVER_ERROR,
                {"ok": False, "error": str(exc), "type": type(exc).__name__},
            )


def write_status(
    host: str,
    port: int,
    application: OrchestratorApplication,
    *,
    status: str = "running",
    started_at_utc: str | None = None,
    error: str = "",
) -> None:
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    payload = {
        **application.health_payload(),
        "status": status,
        "host": host,
        "port": port,
        "url": f"http://{host}:{port}",
        "started_at_utc": started_at_utc or utc_now(),
        "updated_at_utc": utc_now(),
        "error": error,
    }
    (RUNTIME_DIR / "orchestrator_status.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )


def status_heartbeat(
    host: str,
    port: int,
    application: OrchestratorApplication,
    started_at_utc: str,
    stop_event: threading.Event,
) -> None:
    while not stop_event.wait(5.0):
        write_status(host, port, application, started_at_utc=started_at_utc)


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the off-chain Data Orchestrator HTTP service")
    parser.add_argument("--host", default=os.getenv("ORCHESTRATOR_HOST", "127.0.0.1"))
    parser.add_argument("--port", type=int, default=int(os.getenv("ORCHESTRATOR_PORT", "8765")))
    parser.add_argument("--deployment", default=str(BASE_DIR / "deployment.json"))
    args = parser.parse_args()

    application = OrchestratorApplication(args.deployment)
    server = ThreadingHTTPServer((args.host, args.port), Handler)
    server.application = application  # type: ignore[attr-defined]
    started_at_utc = utc_now()
    stop_event = threading.Event()
    heartbeat_thread = threading.Thread(
        target=status_heartbeat,
        args=(args.host, args.port, application, started_at_utc, stop_event),
        daemon=True,
    )
    write_status(args.host, args.port, application, started_at_utc=started_at_utc)
    heartbeat_thread.start()
    print(
        f"[orchestrator] listening at http://{args.host}:{args.port}; "
        "four oracle roles must call this service before fulfilling contracts"
    )
    try:
        server.serve_forever(poll_interval=0.5)
    except KeyboardInterrupt:
        print("[orchestrator] stopping")
    finally:
        stop_event.set()
        heartbeat_thread.join(timeout=2)
        server.server_close()
        write_status(
            args.host,
            args.port,
            application,
            status="stopped",
            started_at_utc=started_at_utc,
        )


if __name__ == "__main__":
    main()
