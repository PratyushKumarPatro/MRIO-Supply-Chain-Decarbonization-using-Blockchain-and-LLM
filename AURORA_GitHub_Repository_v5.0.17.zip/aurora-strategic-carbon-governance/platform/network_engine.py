"""Network metrics and CRITIC-weighted Decarbonization Leverage Index.

The raw network/carbon criteria are BC, PR, CDR and IC.  The authoritative
DLI used by the integrated methodology is produced by ``critic_dli_core``
from a pooled 2014-2017 evaluation matrix.  This module contains no fixed
criterion weights. U13 additionally exposes a producer-specific decomposition
of the unchanged CDR counterfactual; that diagnostic never enters DLI.
"""
from __future__ import annotations

import time
import networkx as nx
import numpy as np
import pandas as pd

import cdr_producer_linkage as cdr_link
from analytics_engine import MRIOYear, load_company_Y, load_year
from critic_dli_core import CRITERIA, build_pooled_critic, critic_weights, score_and_rank

# Retained only as an explicit compatibility marker.  It is not a weighting
# vector and must never be used in arithmetic.
DLI_WEIGHTS: dict[str, float] = {}
DLI_WEIGHTING_METHOD = "CRITIC"


def build_graph(my: MRIOYear, min_weight: float = 1e-6) -> nx.DiGraph:
    n = len(my.node_codes)
    graph = nx.DiGraph()
    graph.add_nodes_from(range(n))
    rows, cols = np.where(np.asarray(my.Z, dtype=float) > float(min_weight))
    for i, j in zip(rows, cols):
        weight = float(my.Z[i, j])
        graph.add_edge(int(i), int(j), weight=weight, distance=1.0 / weight)
    return graph


def betweenness(graph: nx.DiGraph) -> np.ndarray:
    values = nx.betweenness_centrality(graph, weight="distance", normalized=True)
    return np.array([values[index] for index in range(graph.number_of_nodes())], dtype=float)


def pagerank(graph: nx.DiGraph) -> np.ndarray:
    values = nx.pagerank(graph, weight="weight")
    return np.array([values[index] for index in range(graph.number_of_nodes())], dtype=float)


def carbon_dependency_risk(my: MRIOYear, demand: np.ndarray) -> np.ndarray:
    """Return the established node-removal CDR vector.

    U13 delegates the unchanged counterfactual to the producer-linkage module,
    which additionally retains the producer-by-producer footprint difference.
    Only the CDR vector returned here enters CRITIC-DLI.
    """
    return cdr_link.compute_cdr_producer_linkage(my, demand).cdr.copy()


def intervention_criticality(my: MRIOYear, demand: np.ndarray) -> np.ndarray:
    """Marginal footprint sensitivity to the node's direct carbon intensity."""
    return my.L @ np.asarray(demand, dtype=float)


def compute_raw_metrics_with_cdr_linkage(
    my: MRIOYear, demand: np.ndarray
) -> tuple[pd.DataFrame, cdr_link.CDRProducerLinkageResult]:
    """Compute raw DLI criteria and the supplementary CDR producer linkage.

    The linkage calculation is produced in the same node-removal loop that
    supplies the unchanged CDR vector. It is explanatory evidence only and is
    not included as a fifth DLI criterion.
    """
    graph = build_graph(my)

    start = time.time()
    bc = betweenness(graph)
    print(f"  betweenness centrality: {time.time() - start:.1f}s")

    start = time.time()
    pr = pagerank(graph)
    print(f"  pagerank: {time.time() - start:.1f}s")

    start = time.time()
    linkage = cdr_link.compute_cdr_producer_linkage(my, demand)
    cdr = linkage.cdr.copy()
    print(
        f"  carbon dependency risk and producer linkage "
        f"({len(demand)} inversions): {time.time() - start:.1f}s"
    )

    start = time.time()
    ic = intervention_criticality(my, demand)
    print(f"  intervention criticality: {time.time() - start:.1f}s")

    frame = pd.DataFrame(
        {
            "year": int(my.year),
            "node_code": np.asarray(my.node_codes).astype(str),
            "region": np.asarray(my.regions).astype(str),
            "sector": np.asarray(my.sectors).astype(str),
            "BC": bc,
            "PR": pr,
            "CDR": cdr,
            "IC": ic,
            "company_demand": np.asarray(demand, dtype=float),
        }
    )
    values = frame[list(CRITERIA)].to_numpy(dtype=float)
    if not np.isfinite(values).all():
        raise RuntimeError("Network metrics contain non-finite values")
    sorted_frame = frame.sort_values("node_code", kind="mergesort").reset_index(drop=True)
    return sorted_frame, linkage


def compute_raw_metrics(my: MRIOYear, demand: np.ndarray) -> pd.DataFrame:
    """Compute the unweighted 455-node network/governance criteria."""
    frame, _linkage = compute_raw_metrics_with_cdr_linkage(my, demand)
    return frame


def compute_dli(
    my: MRIOYear,
    demand: np.ndarray,
    *,
    weights: dict[str, float] | None = None,
) -> pd.DataFrame:
    """Compatibility entry point using provisional annual Pearson-CRITIC.

    The Data Orchestrator does not use this function for the final decision-year
    ranking; it pools both annual raw frames through ``build_pooled_critic``.
    This annual result is explicitly labelled provisional.
    """
    if weights is not None:
        raise ValueError(
            "Researcher-assigned DLI weights are retired; use the governed pooled Pearson-CRITIC workflow"
        )
    raw = compute_raw_metrics(my, demand)
    result = critic_weights(raw, scope=f"annual-provisional-{int(my.year)}")
    scored = score_and_rank(raw, result)
    return scored.sort_values(["dli_rank", "node_code"], kind="mergesort").reset_index(drop=True)


def compute_pooled_dli(
    base_raw: pd.DataFrame,
    comparison_raw: pd.DataFrame,
    *,
    correlation_method: str = "pearson",
) -> tuple[pd.DataFrame, object]:
    return build_pooled_critic(
        {2014: base_raw, 2017: comparison_raw},
        correlation_method=correlation_method,
    )


def compute_temporal_dli(
    base_df: pd.DataFrame,
    comparison_df: pd.DataFrame,
    *,
    base_year: int = 2014,
    comparison_year: int = 2017,
) -> pd.DataFrame:
    """Compare two annual slices scored on the same pooled CRITIC scale."""
    required = {
        "node_code", "region", "sector", "DLI", "dli_rank",
        *CRITERIA,
        *[f"{criterion}_critic_weight_contribution" for criterion in CRITERIA],
    }
    frames = []
    for label, frame in ((base_year, base_df), (comparison_year, comparison_df)):
        missing = sorted(required.difference(frame.columns))
        if missing:
            raise ValueError(f"CRITIC-DLI {label} frame is missing columns: {missing}")
        copy = frame.copy()
        copy["year"] = int(label)
        frames.append(copy)

    base = frames[0]
    comparison = frames[1]
    columns = [
        "node_code", "region", "sector", "DLI", "dli_rank", *CRITERIA,
        *[f"{criterion}_critic_weight_contribution" for criterion in CRITERIA],
    ]
    merged = base[columns].merge(
        comparison[columns],
        on="node_code",
        suffixes=(f"_{base_year}", f"_{comparison_year}"),
        how="inner",
    )
    if len(merged) != len(base) or len(merged) != len(comparison):
        raise ValueError("Annual CRITIC-DLI frames do not contain the same node universe")
    merged["region"] = merged[f"region_{comparison_year}"]
    merged["sector"] = merged[f"sector_{comparison_year}"]
    merged["delta_DLI"] = merged[f"DLI_{comparison_year}"] - merged[f"DLI_{base_year}"]
    merged["rank_change"] = merged[f"dli_rank_{base_year}"] - merged[f"dli_rank_{comparison_year}"]
    for criterion in CRITERIA:
        merged[f"delta_{criterion}_contribution"] = (
            merged[f"{criterion}_critic_weight_contribution_{comparison_year}"]
            - merged[f"{criterion}_critic_weight_contribution_{base_year}"]
        )

    tolerance = max(1e-12, float(merged["delta_DLI"].abs().median()) * 0.05)
    merged["two_period_status"] = np.select(
        [merged["delta_DLI"] > tolerance, merged["delta_DLI"] < -tolerance],
        ["higher in 2017", "lower in 2017"],
        default="approximately stable",
    )
    return merged.sort_values(
        [f"dli_rank_{comparison_year}", "node_code"], kind="mergesort"
    ).reset_index(drop=True)


if __name__ == "__main__":
    annual = {}
    for reference_year in (2014, 2017):
        model = load_year("input_mrio_completed.xlsx", reference_year)
        company_demand = load_company_Y("Focal_Company_Demand_Converted.xlsx", reference_year)
        annual[reference_year] = compute_raw_metrics(model, company_demand)
    ranking, critic = build_pooled_critic(annual)
    print("Pooled CRITIC weights:", critic.weights)
    print(ranking.loc[ranking["year"] == 2017, ["dli_rank", "node_code", "DLI"]].head(15).to_string(index=False))
