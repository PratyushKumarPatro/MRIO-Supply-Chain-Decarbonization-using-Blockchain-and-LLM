# Centralized Python runtime management for the Windows deployment.
# All package scripts use the project-local virtual environment at .venv.
# The machine-wide Python installation and machine-wide pip are never modified.

$script:RqPackageRoot = $PSScriptRoot
$script:RqVenvDirectory = Join-Path $script:RqPackageRoot ".venv"
$script:RqVenvPython = Join-Path $script:RqVenvDirectory "Scripts\python.exe"
$env:PIP_DISABLE_PIP_VERSION_CHECK = "1"
$env:PYTHONNOUSERSITE = "1"

function Get-RqBootstrapPython {
    $pythonCommand = Get-Command "python.exe" -ErrorAction SilentlyContinue
    if ($null -ne $pythonCommand) {
        return [string]$pythonCommand.Source
    }

    $pythonCommand = Get-Command "python" -ErrorAction SilentlyContinue
    if ($null -ne $pythonCommand) {
        return [string]$pythonCommand.Source
    }

    throw "Python was not found on PATH. Install Python 3.10 or newer, then reopen PowerShell."
}

function Test-RqVirtualEnvironment {
    if (-not (Test-Path $script:RqVenvPython -PathType Leaf)) {
        return $false
    }

    & $script:RqVenvPython -c "import sys; raise SystemExit(0 if sys.prefix != sys.base_prefix else 1)" *> $null
    return ($LASTEXITCODE -eq 0)
}

function Initialize-RqPythonEnvironment {
    [CmdletBinding()]
    param(
        [switch]$InstallRequirements,
        [switch]$Recreate
    )

    if ($Recreate -and (Test-Path $script:RqVenvDirectory)) {
        Write-Host "Removing the previous project-local Python environment." -ForegroundColor Yellow
        Remove-Item $script:RqVenvDirectory -Recurse -Force -ErrorAction Stop
    }

    if (-not (Test-RqVirtualEnvironment)) {
        if (Test-Path $script:RqVenvDirectory) {
            Write-Host "Removing an incomplete project-local Python environment." -ForegroundColor Yellow
            Remove-Item $script:RqVenvDirectory -Recurse -Force -ErrorAction Stop
        }

        $bootstrapPython = Get-RqBootstrapPython
        & $bootstrapPython -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 10) else 1)" *> $null
        if ($LASTEXITCODE -ne 0) {
            throw "Python 3.10 or newer is required to create the project-local environment."
        }
        Write-Host "Creating a project-local Python environment at $script:RqVenvDirectory" -ForegroundColor Cyan
        & $bootstrapPython -m venv $script:RqVenvDirectory | Out-Host
        if ($LASTEXITCODE -ne 0 -or -not (Test-RqVirtualEnvironment)) {
            throw "Python could not create the project-local virtual environment. Verify that the Python venv component is installed."
        }
    }

    $env:SCIG_PLATFORM_PYTHON = $script:RqVenvPython
    $env:VIRTUAL_ENV = $script:RqVenvDirectory

    $runtimeDirectory = Join-Path $script:RqPackageRoot "runtime"
    New-Item -ItemType Directory -Force -Path $runtimeDirectory | Out-Null
    $pythonVersion = (& $script:RqVenvPython -c "import platform; print(platform.python_version())" 2>$null | Select-Object -First 1)
    $environmentRecord = [ordered]@{
        package_root = [IO.Path]::GetFullPath($script:RqPackageRoot)
        virtual_environment = [IO.Path]::GetFullPath($script:RqVenvDirectory)
        python_executable = [IO.Path]::GetFullPath($script:RqVenvPython)
        python_version = [string]$pythonVersion
        machine_wide_python_modified = $false
        updated_at_utc = [DateTimeOffset]::UtcNow.ToString("o")
    }
    $environmentRecord | ConvertTo-Json -Depth 3 | Set-Content -Encoding UTF8 (Join-Path $runtimeDirectory "python_environment.json")

    if ($InstallRequirements) {
        Write-Host "Using isolated Python: $script:RqVenvPython" -ForegroundColor Green
        & $script:RqVenvPython --version | Out-Host
        if ($LASTEXITCODE -ne 0) {
            throw "The project-local Python interpreter could not be started."
        }

        & $script:RqVenvPython -m pip --version | Out-Host
        if ($LASTEXITCODE -ne 0) {
            Write-Host "Bootstrapping pip inside the project-local environment." -ForegroundColor Yellow
            & $script:RqVenvPython -m ensurepip --upgrade | Out-Host
            if ($LASTEXITCODE -ne 0) {
                throw "pip could not be bootstrapped inside the project-local environment."
            }
        }

        # Do not upgrade the machine-wide pip. Dependencies are installed only
        # inside .venv, which avoids administrator and corporate-PC permissions.
        Write-Host "Installing all Python dependencies inside .venv." -ForegroundColor Cyan
        & $script:RqVenvPython -m pip install `
            --disable-pip-version-check `
            --prefer-binary `
            --upgrade-strategy only-if-needed `
            -r (Join-Path $script:RqPackageRoot "requirements.txt") `
            -r (Join-Path $script:RqPackageRoot "streamlit_app\requirements.txt") | Out-Host
        if ($LASTEXITCODE -ne 0) {
            throw "Python dependency installation inside .venv failed with exit code $LASTEXITCODE."
        }

        & $script:RqVenvPython -m pip check | Out-Host
        if ($LASTEXITCODE -ne 0) {
            throw "The project-local Python environment contains incompatible packages."
        }
    }
}

function Get-RqPythonPath {
    if (Test-RqVirtualEnvironment) {
        $env:SCIG_PLATFORM_PYTHON = $script:RqVenvPython
        $env:VIRTUAL_ENV = $script:RqVenvDirectory
        return [string](Resolve-Path $script:RqVenvPython).Path
    }

    throw "The project-local Python environment is missing. Re-run the unchanged python -m venv .venv and pip installation commands from DEPLOY_FINAL."
}

function Ensure-RqApplicationPython {
    [CmdletBinding()]
    param([switch]$InstallIfMissing)

    if (-not (Test-RqVirtualEnvironment)) {
        if (-not $InstallIfMissing) {
            throw "The project-local Python environment is missing. Re-run the unchanged python -m venv .venv and pip installation commands from DEPLOY_FINAL."
        }
        Initialize-RqPythonEnvironment -InstallRequirements
    }

    $python = Get-RqPythonPath
    $probeCode = "import web3, streamlit, pandas, numpy, networkx, sklearn, plotly, openpyxl, matplotlib, requests"

    # Windows PowerShell 5 can promote native-process stderr to a terminating
    # NativeCommandError when the caller uses $ErrorActionPreference = "Stop".
    # Dependency probing must therefore inspect the Python exit code without
    # allowing stderr handling itself to abort the launcher.
    $savedErrorActionPreference = $ErrorActionPreference
    try {
        $ErrorActionPreference = "Continue"
        & $python -c $probeCode *> $null
        $probeExitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $savedErrorActionPreference
    }

    if ($probeExitCode -ne 0) {
        if (-not $InstallIfMissing) {
            throw "The project-local Python environment is incomplete. Re-run the unchanged pip install command for requirements.txt and streamlit_app\requirements.txt from DEPLOY_FINAL."
        }
        Write-Host "Completing missing packages inside the project-local .venv." -ForegroundColor Yellow
        Initialize-RqPythonEnvironment -InstallRequirements
        $python = Get-RqPythonPath

        $savedErrorActionPreference = $ErrorActionPreference
        try {
            $ErrorActionPreference = "Continue"
            & $python -c $probeCode *> $null
            $probeExitCode = $LASTEXITCODE
        }
        finally {
            $ErrorActionPreference = $savedErrorActionPreference
        }

        if ($probeExitCode -ne 0) {
            throw "The project-local Python environment remains incomplete after dependency installation."
        }
    }
}
