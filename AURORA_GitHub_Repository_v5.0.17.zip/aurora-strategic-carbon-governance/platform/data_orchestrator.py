"""Off-chain Data Orchestrator for the four-oracle deployment.

The module contains no blockchain polling or transaction signing. Dedicated
oracle processes receive smart-contract events, call this orchestrator through
``orchestrator_server.py``, and then submit the returned content hash to the
originating smart contract.

Authoritative quantitative results remain deterministic:

* MRIO accounting and hotspots -> analytics_engine.py
* Structural Path Analysis -> spa_engine.py
* Structural Decomposition Analysis -> sda_engine.py
* network/DLI -> network_engine.py
* regional sourcing opportunities -> sourcing_opportunity_engine.py
* integrated interventions -> intervention_governance.py
* all natural-language questions -> dual_capability_assistant.py and llm_first_orchestrator.py.
  The local LLM is the primary task interpreter and prose reasoner; curated and deterministic
  modules remain closed evidence services for system claims and project-specific values.
"""
from __future__ import annotations

import hashlib
import json
import math
import os
import threading
from dataclasses import asdict, dataclass, is_dataclass
from datetime import datetime, timezone
from functools import wraps
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd

import analytics_engine as ae
import dual_capability_assistant as ca
import network_engine as net
import sda_engine as sda
import spa_engine as spa
import sourcing_opportunity_engine as aurora
import aurora_reporting as aurora_report
import critic_dli_core as critic_core
import critic_robustness as critic_robustness
import cdr_producer_linkage as cdr_link
import node_sda_engine as node_sda
import hotspot_leverage as hotspot_link
import intervention_governance as intervention_gov
import final_methodology_service as final_methodology
import strategic_assistant as sa
import input_onboarding as onboarding

BASE_DIR = Path(__file__).resolve().parent
MRIO_PATH = BASE_DIR / "input_mrio_completed.xlsx"
COMPANY_PATH = BASE_DIR / "Focal_Company_Demand_Converted.xlsx"
RESULT_INDEX_PATH = BASE_DIR / "runtime" / "result_index.json"
CONTENT_STORE = BASE_DIR / "content_store"
RESULTS_DIR = BASE_DIR / "results"
DEPLOYMENT_PATH = BASE_DIR / "deployment.json"
ACTIVE_ANALYTICS_DIR = BASE_DIR / "runtime" / "active_analytics"
_RESULT_INDEX_LOCK = threading.RLock()


def _with_result_index_lock(function):
    """Hold the active-result generation stable for one verification operation."""

    @wraps(function)
    def guarded(*args, **kwargs):
        with _RESULT_INDEX_LOCK:
            return function(*args, **kwargs)

    return guarded

ROLE_NAMES = {
    1: "RegulatoryAuthority",
    2: "MRIODataProvider",
    3: "FocalCompany",
    4: "RegistrationOracle",
    5: "UpstreamAnalyticsOracle",
    6: "GovernanceOracle",
    7: "QueryOracle",
}

ROUTE_ENUM = {
    "general": 1,
    "direct": 1,
    "compute": 2,
    "retrieval": 3,
    "composite": 4,
    "hybrid": 4,
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _jsonable(value: Any) -> Any:
    """Convert numpy/pandas/dataclass values into strict JSON values."""
    if is_dataclass(value):
        return _jsonable(asdict(value))
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    if isinstance(value, pd.DataFrame):
        return _jsonable(value.to_dict(orient="records"))
    if isinstance(value, pd.Series):
        return _jsonable(value.to_dict())
    if isinstance(value, np.ndarray):
        return _jsonable(value.tolist())
    if isinstance(value, np.generic):
        return _jsonable(value.item())
    if value is None:
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    if isinstance(value, Path):
        return str(value)
    if isinstance(value, float):
        if math.isnan(value) or math.isinf(value):
            return None
        return value
    return value


def canonical_json(payload: Any) -> str:
    return json.dumps(
        _jsonable(payload),
        indent=2,
        sort_keys=True,
        ensure_ascii=False,
        allow_nan=False,
        default=str,
    )


def sha256_bytes(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def active_input_hashes() -> dict[str, str]:
    hashes = onboarding.active_input_hashes(require_both=True)
    # The active manifest and actual bytes must agree.  This prevents an
    # out-of-band file replacement from being treated as a validated input.
    actual = {
        "mrio": sha256_file(MRIO_PATH),
        "focal_demand": sha256_file(COMPANY_PATH),
    }
    if hashes != actual:
        raise RuntimeError(
            "The active input manifest does not match the analytical workbook bytes. Re-onboard the inputs through the Governance & Audit Control workspace."
        )
    return hashes


def record_active_result(
    operation: str,
    key: str,
    response: "OrchestratorResponse",
    *,
    input_hashes: dict[str, str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Atomically publish one active-result generation within this service."""

    with _RESULT_INDEX_LOCK:
        _record_active_result_unlocked(
            operation,
            key,
            response,
            input_hashes=input_hashes,
            metadata=metadata,
        )


def _record_active_result_unlocked(
    operation: str,
    key: str,
    response: "OrchestratorResponse",
    *,
    input_hashes: dict[str, str] | None = None,
    metadata: dict[str, Any] | None = None,
) -> None:
    """Record the newest off-chain result for progressive UI discovery.

    The blockchain remains authoritative for completion.  The Streamlit UI
    cross-checks these CIDs against fulfilled contract requests before a page is
    unlocked; this index only provides a compact local lookup.
    """
    RESULT_INDEX_PATH.parent.mkdir(parents=True, exist_ok=True)
    try:
        index = json.loads(RESULT_INDEX_PATH.read_text(encoding="utf-8"))
    except Exception:
        index = {"results": {}}
    results = index.setdefault("results", {})
    results[f"{operation}:{key}"] = {
        "operation": operation,
        "key": str(key),
        "content_hash": response.content_hash,
        "input_hashes": input_hashes or {},
        "metadata": metadata or {},
        "generated_at_utc": response.generated_at_utc,
    }
    index["updated_at_utc"] = utc_now()
    temporary = RESULT_INDEX_PATH.with_name(f".{RESULT_INDEX_PATH.name}.tmp")
    temporary.write_text(json.dumps(index, indent=2, default=str), encoding="utf-8")
    temporary.replace(RESULT_INDEX_PATH)


def store_active_analytics_frame(
    kind: str,
    year: int,
    frame: pd.DataFrame,
    *,
    input_hashes: dict[str, str] | None = None,
    source_result_cid: str | None = None,
) -> None:
    """Persist an active analytical convenience mirror with source provenance.

    The CSV is not an authority by itself: for Network/DLI it is a local
    convenience copy of the immutable, content-addressed response.  Record
    both its byte hash and the response CID so downstream readers can reject a
    stale or out-of-band replacement instead of merely trusting a mutable side
    file.
    """
    expected_hashes = dict(input_hashes or active_input_hashes())
    if active_input_hashes() != expected_hashes:
        raise RuntimeError(
            "Active analytical inputs changed while writing an active result; recompute the governed request."
        )
    ACTIVE_ANALYTICS_DIR.mkdir(parents=True, exist_ok=True)
    frame_path = ACTIVE_ANALYTICS_DIR / f"{kind}_{int(year)}.csv"
    frame.to_csv(frame_path, index=False)
    meta = {
        "kind": kind,
        "year": int(year),
        "input_hashes": expected_hashes,
        "frame_sha256": sha256_file(frame_path),
        "generated_at_utc": utc_now(),
    }
    if source_result_cid:
        meta["source_result_cid"] = str(source_result_cid)
    metadata_path = frame_path.with_suffix(".json")
    temporary = metadata_path.with_name(f".{metadata_path.name}.tmp")
    temporary.write_text(json.dumps(meta, indent=2), encoding="utf-8")
    temporary.replace(metadata_path)


def _atomic_write_bytes(path: Path, body: bytes) -> None:
    """Write a content file atomically so readers never observe partial JSON."""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(
        f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp"
    )
    temporary.write_bytes(body)
    temporary.replace(path)



def write_active_frame_artifact(
    filename_stem: str,
    frame: pd.DataFrame,
    *,
    input_hashes: dict[str, str],
    source_result_cid: str = "",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Write a provenance-bound active CSV used by deterministic downstream stages."""
    if active_input_hashes() != dict(input_hashes):
        raise RuntimeError("Active inputs changed while writing an analytical artifact")
    ACTIVE_ANALYTICS_DIR.mkdir(parents=True, exist_ok=True)
    csv_path = ACTIVE_ANALYTICS_DIR / f"{filename_stem}.csv"
    json_path = ACTIVE_ANALYTICS_DIR / f"{filename_stem}.json"
    frame.to_csv(csv_path, index=False)
    record = {
        "filename_stem": filename_stem,
        "input_hashes": dict(input_hashes),
        "frame_sha256": sha256_file(csv_path),
        "row_count": int(len(frame)),
        "source_result_cid": str(source_result_cid),
        "generated_at_utc": utc_now(),
        **(metadata or {}),
    }
    temporary = json_path.with_name(f".{json_path.name}.tmp")
    temporary.write_text(json.dumps(record, indent=2, default=str), encoding="utf-8")
    temporary.replace(json_path)
    return record


def load_verified_active_frame(
    filename_stem: str,
    *,
    expected_input_hashes: dict[str, str],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    csv_path = ACTIVE_ANALYTICS_DIR / f"{filename_stem}.csv"
    json_path = ACTIVE_ANALYTICS_DIR / f"{filename_stem}.json"
    if not csv_path.is_file() or not json_path.is_file():
        raise FileNotFoundError(f"Active analytical artifact is unavailable: {filename_stem}")
    metadata = json.loads(json_path.read_text(encoding="utf-8"))
    if metadata.get("input_hashes") != dict(expected_input_hashes):
        raise RuntimeError(f"Active artifact {filename_stem} is stale for the current inputs")
    if sha256_file(csv_path) != str(metadata.get("frame_sha256", "")):
        raise RuntimeError(f"Active artifact {filename_stem} failed its SHA-256 check")
    frame = pd.read_csv(csv_path)
    if len(frame) != int(metadata.get("row_count", len(frame))):
        raise RuntimeError(f"Active artifact {filename_stem} failed its row-count check")
    return frame, metadata


def store_content(payload: Any, namespace: str = "orchestrator") -> str:
    """Store a provenance-bearing JSON envelope and return its SHA-256 CID."""
    CONTENT_STORE.mkdir(parents=True, exist_ok=True)
    envelope = {
        "namespace": namespace,
        "stored_at_utc": utc_now(),
        "payload": _jsonable(payload),
    }
    body = canonical_json(envelope).encode("utf-8")
    content_hash = sha256_bytes(body)
    _atomic_write_bytes(CONTENT_STORE / f"{content_hash}.json", body)
    # Keep the extensionless form for compatibility with earlier package tools.
    _atomic_write_bytes(CONTENT_STORE / content_hash, body)
    return content_hash


def load_content(content_hash: str) -> dict[str, Any]:
    normalized = str(content_hash or "").strip().lower()
    if len(normalized) != 64 or any(ch not in "0123456789abcdef" for ch in normalized):
        raise ValueError("content_hash must be a 64-character SHA-256 hexadecimal value")
    for candidate in (
        CONTENT_STORE / f"{normalized}.json",
        CONTENT_STORE / normalized,
        RESULTS_DIR / f"{normalized}.json",
    ):
        if candidate.exists():
            body = candidate.read_bytes()
            if sha256_bytes(body) != normalized:
                raise RuntimeError(
                    f"Stored content failed its SHA-256 CID check: {normalized}"
                )
            return json.loads(body.decode("utf-8"))
    raise FileNotFoundError(f"No locally stored content found for hash {normalized}")


def _verified_active_network_payload(
    source_network_result_cid: str,
    expected_input_hashes: dict[str, str],
    year: int,
) -> dict[str, Any]:
    """Verify one active content-addressed annual Network/DLI payload."""

    network_cid = str(source_network_result_cid).strip().lower()
    expected_year = int(year)
    try:
        active_index = json.loads(RESULT_INDEX_PATH.read_text(encoding="utf-8"))
        record = active_index["results"][f"network:{expected_year}"]
    except Exception as exc:
        raise RuntimeError(
            f"The active {expected_year} Network/DLI result index is unavailable"
        ) from exc
    if str(record.get("content_hash", "")).strip().lower() != network_cid:
        raise RuntimeError(
            f"The requested Network/DLI CID is not the active {expected_year} result"
        )
    if record.get("input_hashes") != expected_input_hashes:
        raise RuntimeError(
            f"The active {expected_year} Network/DLI result is stale for the validated inputs"
        )

    envelope = load_content(network_cid)
    if str(envelope.get("namespace", "")) != "network_and_critic_dli_analysis":
        raise RuntimeError("The active Network/DLI CID does not identify governed Network/DLI evidence")
    material = envelope.get("payload", {})
    if not isinstance(material, dict) or str(material.get("operation", "")) != (
        "network_and_critic_dli_analysis"
    ):
        raise RuntimeError("The active Network/DLI evidence envelope is malformed")
    payload = material.get("payload", {})
    if not isinstance(payload, dict):
        raise RuntimeError("The active Network/DLI payload is malformed")
    if int(payload.get("year", -1)) != expected_year:
        raise RuntimeError(
            f"The active Network/DLI result is not the {expected_year} annual result"
        )
    if payload.get("input_hashes") != expected_input_hashes:
        raise RuntimeError("The active Network/DLI payload is stale for the validated inputs")
    return payload


def _verified_active_network_2017_payload(
    source_network_result_cid: str,
    expected_input_hashes: dict[str, str],
) -> dict[str, Any]:
    """Verify the active 2017 result and its authoritative pooled-CRITIC basis."""

    payload = _verified_active_network_payload(
        source_network_result_cid,
        expected_input_hashes,
        2017,
    )
    if not bool(payload.get("pooled_critic_ready", False)):
        raise RuntimeError("The active 2017 Network/DLI result lacks the temporal pooled CRITIC baseline")
    slices = payload.get("authoritative_dli_slices", {})
    if not isinstance(slices, dict) or not all(
        isinstance(slices.get(str(year)), list) and bool(slices.get(str(year)))
        for year in (2014, 2017)
    ):
        raise RuntimeError(
            "The active 2017 Network/DLI result does not contain both authoritative pooled DLI slices"
        )
    authority = payload.get("temporal_dli_authority", {})
    weighting = payload.get("dli_weighting", {})
    weights = weighting.get("weights", {}) if isinstance(weighting, dict) else {}
    if (
        not isinstance(authority, dict)
        or authority.get("method") != "one pooled two-year Pearson-CRITIC calculation"
        or authority.get("years") != [2014, 2017]
        or weighting.get("method") != "pooled Pearson-CRITIC"
        or set(weights) != set(critic_core.CRITERIA)
        or not all(
            math.isfinite(float(weights[criterion]))
            and float(weights[criterion]) >= 0.0
            for criterion in critic_core.CRITERIA
        )
        or not math.isclose(
            math.fsum(float(weights[criterion]) for criterion in critic_core.CRITERIA),
            1.0,
            rel_tol=1e-10,
            abs_tol=1e-12,
        )
    ):
        raise RuntimeError("The active 2017 Network/DLI temporal authority declaration is invalid")
    try:
        active_index = json.loads(RESULT_INDEX_PATH.read_text(encoding="utf-8"))
        baseline_record = active_index["results"]["network:2014"]
    except Exception as exc:
        raise RuntimeError(
            "The active fulfilled 2014 Network baseline index is unavailable"
        ) from exc
    baseline_cid = str(baseline_record.get("content_hash", "")).strip().lower()
    if (
        baseline_record.get("input_hashes") != expected_input_hashes
        or len(baseline_cid) != 64
        or str(
            authority.get("baseline_evidence_network_result_cid", "")
        ).strip().lower()
        != baseline_cid
    ):
        raise RuntimeError(
            "The active 2017 Network/DLI result is not bound to the active 2014 baseline"
        )
    _verified_active_network_payload(baseline_cid, expected_input_hashes, 2014)
    return payload


def _verified_active_aurora_cid(
    source_network_result_cid: str,
    expected_input_hashes: dict[str, str],
) -> str:
    """Return the current completed AURORA CID bound to one Network/DLI CID.

    The result index is only a locator.  This verifier reloads the immutable
    content-addressed envelope and checks the analytical operation, year,
    active inputs and source Network/DLI CID before intervention evidence may
    be assessed or proposed.  The Solidity contract separately enforces that
    the corresponding AURORA request is fulfilled before formal selection.
    """

    network_cid = str(source_network_result_cid).strip().lower()
    try:
        active_index = json.loads(RESULT_INDEX_PATH.read_text(encoding="utf-8"))
        record = active_index["results"]["aurora:2017"]
    except Exception as exc:
        raise RuntimeError(
            "A completed active 2017 AURORA result is required before intervention governance"
        ) from exc

    aurora_cid = str(record.get("content_hash", "")).strip().lower()
    if len(aurora_cid) != 64 or any(ch not in "0123456789abcdef" for ch in aurora_cid):
        raise RuntimeError("The active AURORA result CID is invalid")
    if record.get("input_hashes") != expected_input_hashes:
        raise RuntimeError("The active AURORA result is stale for the validated inputs")
    record_metadata = record.get("metadata", {})
    if str(record_metadata.get("network_result_hash", "")).strip().lower() != network_cid:
        raise RuntimeError("The active AURORA result is bound to a different 2017 Network/DLI result")

    envelope = load_content(aurora_cid)
    if str(envelope.get("namespace", "")) != "regional_sourcing_opportunity_analysis":
        raise RuntimeError("The active AURORA CID does not identify an AURORA result")
    material = envelope.get("payload", {})
    if not isinstance(material, dict) or str(material.get("operation", "")) != (
        "regional_sourcing_opportunity_analysis"
    ):
        raise RuntimeError("The active AURORA evidence envelope is malformed")
    payload = material.get("payload", {})
    if not isinstance(payload, dict):
        raise RuntimeError("The active AURORA result payload is malformed")
    if int(payload.get("year", -1)) != 2017:
        raise RuntimeError("The active AURORA result is not the 2017 decision assessment")
    if payload.get("input_hashes") != expected_input_hashes:
        raise RuntimeError("The active AURORA result payload is stale for the validated inputs")
    if str(payload.get("network_result_hash", "")).strip().lower() != network_cid:
        raise RuntimeError("The active AURORA payload is bound to a different Network/DLI result")
    return aurora_cid


def make_client(base_url: str | None = None, model: str | None = None):
    return sa.make_client(base_url=base_url, model=model)


def process_question(
    client,
    query_text: str,
    mode: str = "auto",
    history: list[dict] | None = None,
    state: dict | None = None,
) -> ca.ConversationResult:
    return ca.answer_turn(
        client,
        query_text,
        mode=mode,
        history=history,
        state=state,
    )


def store_result(request_id: int, result) -> str:
    """Backward-compatible query-result storage helper."""
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    payload = {"request_id": request_id, **asdict(result)}
    body = canonical_json(payload)
    content_hash = sha256_bytes(body.encode("utf-8"))
    (RESULTS_DIR / f"{content_hash}.json").write_text(body, encoding="utf-8")
    return content_hash


@dataclass
class OrchestratorResponse:
    operation: str
    content_hash: str
    payload: dict[str, Any]
    auxiliary: dict[str, Any]
    request_context: dict[str, Any]
    generated_at_utc: str

    def to_dict(self) -> dict[str, Any]:
        return _jsonable(asdict(self))


class DataOrchestrator:
    """Pure off-chain service called by the four specialized oracle adapters."""

    def __init__(
        self,
        deployment_path: str | Path = DEPLOYMENT_PATH,
        client: Any | None = None,
    ):
        self.deployment_path = Path(deployment_path)
        self.deployment: dict[str, Any] = {}
        if self.deployment_path.exists():
            self.deployment = json.loads(self.deployment_path.read_text(encoding="utf-8"))
        self.client = client or make_client()
        self._query_lock = threading.Lock()
        self._intervention_governance_lock = threading.Lock()
        self._conversation_history: dict[str, list[dict[str, str]]] = {}
        self._conversation_state: dict[str, dict[str, Any]] = {}

    def _response(
        self,
        operation: str,
        payload: dict[str, Any],
        auxiliary: dict[str, Any] | None = None,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        material = {
            "operation": operation,
            "generated_at_utc": utc_now(),
            "payload": _jsonable(payload),
            "auxiliary": _jsonable(auxiliary or {}),
            "request_context": _jsonable(request_context or {}),
            "provenance": {
                "orchestrator": "DataOrchestrator",
                "analytics_authority": "deterministic modules for research-specific values",
                "system_knowledge_authority": "curated system_knowledge.json for deployment and architecture claims",
                "narrative_policy": "validated connected prose with answer-question alignment checks",
            },
        }
        content_hash = store_content(material, namespace=operation)
        return OrchestratorResponse(
            operation=operation,
            content_hash=content_hash,
            payload=_jsonable(payload),
            auxiliary=_jsonable(auxiliary or {}),
            request_context=_jsonable(request_context or {}),
            generated_at_utc=material["generated_at_utc"],
        )

    def verify_registration(
        self,
        requester: str,
        requested_role: int,
        evidence_cid: str,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        """Verify reference-deployment stakeholder identities against the deployed allow-list.

        This is deliberately explicit about its scope: it proves the oracle
        workflow and role separation on a local chain. It is not a substitute
        for production KYC, certification, or regulator-managed identity.
        """
        account_key_by_role = {
            1: "regulator",
            2: "mrio_provider",
            3: "focal_company",
        }
        expected_key = account_key_by_role.get(int(requested_role))
        expected_address = (
            self.deployment.get("accounts", {}).get(expected_key, "")
            if expected_key
            else ""
        )
        address_matches = bool(expected_address) and requester.lower() == expected_address.lower()
        evidence_present = bool(str(evidence_cid).strip())
        approved = bool(expected_key and address_matches and evidence_present)
        reason = (
            "approved by the local deployment allow-list"
            if approved
            else "requester, requested role, or evidence did not match the local deployment allow-list"
        )
        payload = {
            "requester": requester,
            "requested_role": int(requested_role),
            "requested_role_name": ROLE_NAMES.get(int(requested_role), "Unknown"),
            "evidence_cid": evidence_cid,
            "approved": approved,
            "verification_policy": "reference-deployment-address-and-role-allow-list",
            "reason": reason,
            "production_boundary": (
                "Replace this policy with governed credential verification for a production deployment."
            ),
        }
        return self._response("registration_verification", payload, request_context=request_context)

    def validate_data_update(
        self,
        kind: str,
        data_hash: str,
        requester: str,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        validation = onboarding.validate_staged_for_oracle(
            kind,
            data_hash,
            requester,
            self.deployment,
        )
        return self._response(
            "data_update_validation",
            validation,
            request_context=request_context,
        )

    def promote_data_update(
        self,
        kind: str,
        data_hash: str,
        requester: str,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        promoted = onboarding.promote_staged_after_onchain_acceptance(
            kind,
            data_hash,
            requester,
            self.deployment,
        )
        return self._response(
            "data_update_promotion",
            {
                "kind": onboarding.normalise_kind(kind),
                "data_hash": str(data_hash).lower(),
                "requester": requester,
                "active": True,
                "active_record": promoted,
            },
            request_context=request_context,
        )

    def compute_mrio(
        self, year: int, request_context: dict[str, Any] | None = None
    ) -> OrchestratorResponse:
        year = int(year)
        hashes = active_input_hashes()
        my = ae.load_year(str(MRIO_PATH), year)
        company_y = ae.load_company_Y(str(COMPANY_PATH), year)
        validation = ae.validate(my)
        if not validation.get("L_at_Y_economy_matches_X") or not validation.get(
            "emissions_identity_holds"
        ):
            raise RuntimeError(f"MRIO internal validation failed for {year}: {validation}")
        required_output = my.L @ company_y
        contributions = my.fE * required_output
        total = float(contributions.sum())
        all_hotspots = pd.DataFrame(
            {
                "node_code": my.node_codes,
                "region": my.regions,
                "sector": my.sectors,
                "footprint_contribution": contributions,
            }
        ).sort_values("footprint_contribution", ascending=False)
        all_hotspots["share_of_total"] = (
            all_hotspots["footprint_contribution"] / total if total else 0.0
        )
        domestic = float(all_hotspots.loc[all_hotspots["region"] == "ARE", "footprint_contribution"].sum())
        imported = float(total - domestic)
        economy = float(my.footprint(my.Y_economy))
        payload = {
            "year": year,
            "company_footprint": total,
            "economy_wide_footprint": economy,
            "company_demand_total": float(company_y.sum()),
            "units": {
                "mrio_monetary_values": "million USD",
                "economy_wide_footprint": "Mt CO2",
                "focal_company_demand": "USD",
                "focal_company_footprint": "t CO2",
                "carbon_intensity": "t CO2/USD",
            },
            "hotspots": all_hotspots.head(15).to_dict(orient="records"),
            "all_hotspots": all_hotspots.to_dict(orient="records"),
            "domestic_vs_imported": {
                "ARE_domestic": domestic,
                "ROW_imported": imported,
                "ARE_share": domestic / total if total else 0.0,
                "ROW_share": imported / total if total else 0.0,
            },
            "validation": validation,
            "input_hashes": hashes,
        }
        response = self._response("mrio_carbon_accounting", payload, request_context=request_context)
        record_active_result("mrio", str(year), response, input_hashes=hashes, metadata={"year": year})
        return response

    def compute_spa(
        self, year: int, request_context: dict[str, Any] | None = None
    ) -> OrchestratorResponse:
        """Compute an 87%-complete SPA prefix or fail without committing a result."""
        year = int(year)
        hashes = active_input_hashes()
        my = ae.load_year(str(MRIO_PATH), year)
        company_y = ae.load_company_Y(str(COMPANY_PATH), year)
        initial_config = spa.SPAConfig()

        (
            screened_paths,
            reported_paths,
            total_footprint,
            config,
            adaptive_attempts,
        ) = spa.trace_paths_to_threshold_adaptive(
            my, company_y, initial_config
        )
        screened_share = (
            float(screened_paths["cumulative_share"].iloc[-1])
            if not screened_paths.empty
            else 0.0
        )
        reported_share = (
            float(reported_paths["cumulative_share"].iloc[-1])
            if not reported_paths.empty
            else 0.0
        )
        threshold_reached = bool(
            adaptive_attempts
            and adaptive_attempts[-1].get("threshold_reached", False)
            and reported_share + spa.SPA_COVERAGE_TOLERANCE
            >= float(config.cumulative_target)
        )
        if not threshold_reached:
            raise RuntimeError(
                "SPA coverage validation failed closed: the bounded adaptive "
                f"screen reached {reported_share:.12%}, below the required "
                f"{float(config.cumulative_target):.12%}, after "
                f"{len(adaptive_attempts)} deterministic attempt(s). No SPA "
                "content package or active result was committed."
            )
        reported_footprint = float(
            pd.to_numeric(reported_paths.get("contribution", pd.Series(dtype=float)), errors="coerce")
            .fillna(0.0)
            .sum()
        )
        target_footprint = float(config.cumulative_target * total_footprint)
        target_shortfall = max(0.0, target_footprint - reported_footprint)
        target_overshoot = max(0.0, reported_footprint - target_footprint)
        unrepresented_footprint = max(0.0, float(total_footprint) - reported_footprint)

        hotspot_node_count = min(15, len(my.node_codes))
        top_hotspots = my.hotspots(company_y, top=hotspot_node_count)
        top_hotspot_footprint = float(top_hotspots["footprint_contribution"].sum())
        top_hotspot_share = (
            top_hotspot_footprint / float(total_footprint) if total_footprint else 0.0
        )

        tier_vector = np.asarray(company_y, dtype=float).copy()
        exact_cumulative = 0.0
        convergence: list[dict[str, float | int]] = []
        A = np.zeros_like(my.Z, dtype=float)
        positive = np.asarray(my.X, dtype=float) > 0
        A[:, positive] = my.Z[:, positive] / my.X[positive][np.newaxis, :]
        for depth in range(config.exact_max_tier + 1):
            if depth > 0:
                tier_vector = A @ tier_vector
            tier_footprint = float(my.fE @ tier_vector)
            exact_cumulative += tier_footprint
            convergence.append(
                {
                    "depth": depth,
                    "tier_footprint": tier_footprint,
                    "cumulative_footprint": exact_cumulative,
                    "share": exact_cumulative / float(total_footprint) if total_footprint else 0.0,
                }
            )

        screened_footprint = float(
            pd.to_numeric(screened_paths.get("contribution", pd.Series(dtype=float)), errors="coerce")
            .fillna(0.0)
            .sum()
        )
        exact_through_path_depth = float(
            convergence[min(config.max_depth, len(convergence) - 1)]["cumulative_footprint"]
        )
        screened_but_unreported = max(0.0, screened_footprint - reported_footprint)
        screening_pruning_residual = max(0.0, exact_through_path_depth - screened_footprint)
        depth_tail_residual = max(0.0, float(total_footprint) - exact_through_path_depth)
        footprint_reconciliation_residual = float(total_footprint) - (
            reported_footprint
            + screened_but_unreported
            + screening_pruning_residual
            + depth_tail_residual
        )

        artifact_bytes = screened_paths.to_csv(index=False).encode("utf-8")
        artifact_sha256 = sha256_bytes(artifact_bytes)
        payload = {
            "year": year,
            "total_footprint": float(total_footprint),
            "units": {
                "total_footprint": "t CO2",
                "path_contribution": "t CO2",
                "tier_footprint": "t CO2",
                "cumulative_share": "fraction",
            },
            "paths_to_threshold": int(len(reported_paths)),
            "cumulative_share": reported_share,
            "reported_path_count": int(len(reported_paths)),
            "screened_path_count": int(len(screened_paths)),
            "threshold_reached": bool(threshold_reached),
            "coverage_enforcement": (
                "fail closed: no governed SPA result is committed or eligible for "
                "oracle fulfilment unless the complete-path prefix reaches at least "
                "87% of the complete focal-company footprint"
            ),
            "adaptive_expansion_attempts": adaptive_attempts,
            "adaptive_expansion_used": len(adaptive_attempts) > 1,
            "screened_cumulative_share": screened_share,
            "reported_cumulative_share": reported_share,
            "cumulative_target": float(config.cumulative_target),
            "coverage_target_basis": (
                "fixed 87% share of the complete focal-company footprint, motivated by the "
                "study's approximately 87% top-15 producer-hotspot benchmark; the active-year "
                "top-15 share is reported separately"
            ),
            "target_footprint": target_footprint,
            "reported_path_footprint": reported_footprint,
            "target_shortfall": target_shortfall,
            "target_overshoot": target_overshoot,
            "unrepresented_footprint": unrepresented_footprint,
            "selection_rule": (
                "minimum number of complete contribution-ranked paths required to reach at least "
                "the configured share of the complete focal-company footprint"
            ),
            "final_path_policy": "retain the complete final path; never fractionally adjust a path to force exact coverage",
            "screening_priority": "remaining complete Leontief embodied-carbon potential of each partial path",
            "zero_intensity_intermediaries_expandable": True,
            "repeated_node_walks_included_within_depth_bound": True,
            "hotspot_alignment": {
                "leading_node_count": int(hotspot_node_count),
                "leading_node_codes": top_hotspots["node_code"].astype(str).tolist(),
                "leading_node_footprint": top_hotspot_footprint,
                "leading_node_share_of_total": top_hotspot_share,
                "relationship": (
                    "coverage-target alignment only; SPA paths are ranked globally and are not filtered by terminal-emitter membership"
                ),
            },
            "coverage_reconciliation": {
                "complete_focal_company_footprint": float(total_footprint),
                "reported_selected_paths": reported_footprint,
                "screened_but_unreported_paths": screened_but_unreported,
                "screening_and_pruning_residual_through_max_path_depth": screening_pruning_residual,
                "exact_depth_tail_beyond_max_path_depth": depth_tail_residual,
                "exact_cumulative_footprint_through_max_path_depth": exact_through_path_depth,
                "screened_path_footprint": screened_footprint,
                "reconciliation_residual": footprint_reconciliation_residual,
                "target_identity_residual": (
                    reported_footprint - target_overshoot + target_shortfall - target_footprint
                ),
            },
            "max_depth": int(config.max_depth),
            "exact_max_tier": int(config.exact_max_tier),
            "top_k_per_hop": int(config.top_k_per_hop),
            "beam_width": int(config.beam_width),
            "max_reported_paths": (
                int(config.max_reported_paths)
                if config.max_reported_paths is not None
                else None
            ),
            "fixed_reported_path_cap_applied": config.max_reported_paths is not None,
            "screened_paths_artifact": {
                "filename": f"spa_screened_paths_{year}.csv",
                "sha256": artifact_sha256,
                "row_count": int(len(screened_paths)),
                "authority": "complete bounded beam output used by the integrated SPA-SDA analysis",
            },
            "paths": reported_paths.to_dict(orient="records"),
            "convergence": convergence,
            "input_hashes": hashes,
        }
        response = self._response(
            "structural_path_analysis", payload, request_context=request_context
        )
        write_active_frame_artifact(
            f"spa_screened_paths_{year}",
            screened_paths,
            input_hashes=hashes,
            source_result_cid=response.content_hash,
            metadata={
                "screened_path_count": int(len(screened_paths)),
                "committed_artifact_sha256": artifact_sha256,
                "year": year,
            },
        )
        store_active_analytics_frame(
            "spa", year, reported_paths,
            input_hashes=hashes,
            source_result_cid=response.content_hash,
        )
        record_active_result(
            "spa", str(year), response, input_hashes=hashes, metadata={"year": year}
        )
        return response

    @staticmethod
    def _sda_block(my1, y1, my2, y2) -> dict[str, Any]:
        inputs1 = sda.SDAInputs.from_year(my1, y1)
        inputs2 = sda.SDAInputs.from_year(my2, y2)
        effects = sda.sda_decompose(inputs1, inputs2)
        footprint1 = float(inputs1.footprint())
        footprint2 = float(inputs2.footprint())
        true_change = footprint2 - footprint1
        residual = sum(float(v) for v in effects.values()) - true_change
        if abs(residual) > 1e-6:
            raise RuntimeError(f"SDA effects do not reconcile; residual={residual}")
        return {
            "footprint_base": footprint1,
            "footprint_comparison": footprint2,
            "net_change": true_change,
            "effects": {k: float(v) for k, v in effects.items()},
            "reconciliation_residual": residual,
        }

    def compute_sda(
        self,
        base_year: int,
        comparison_year: int,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        base_year = int(base_year)
        comparison_year = int(comparison_year)
        my1 = ae.load_year(str(MRIO_PATH), base_year)
        my2 = ae.load_year(str(MRIO_PATH), comparison_year)
        company_y1 = ae.load_company_Y(str(COMPANY_PATH), base_year)
        company_y2 = ae.load_company_Y(str(COMPANY_PATH), comparison_year)
        hashes = active_input_hashes()

        company_block = self._sda_block(my1, company_y1, my2, company_y2)
        economy_block = self._sda_block(my1, my1.Y_economy, my2, my2.Y_economy)
        node_result = node_sda.compute_node_wise_sda(
            my1,
            company_y1,
            my2,
            company_y2,
            hotspot_threshold=0.80,
            authoritative_company_effects=company_block["effects"],
        )
        node_metadata = node_sda.write_node_sda_artifacts(
            ACTIVE_ANALYTICS_DIR,
            node_result,
            input_hashes=hashes,
        )
        node_evidence_basis = {
            key: value
            for key, value in node_metadata.items()
            if key not in {"generated_at_utc", "source_sda_result_cid", "node_sda_evidence_cid"}
        }
        node_sda_evidence_cid = store_content(
            node_evidence_basis, namespace="node_wise_sda_authoritative"
        )
        payload = {
            "base_year": base_year,
            "comparison_year": comparison_year,
            "company_primary": company_block,
            "economy_wide_context": economy_block,
            "node_wise_sda": {
                "available": True,
                "extension_id": node_sda.NODE_SDA_EXTENSION_ID,
                "method": "same four-factor full 24-permutation average as company SDA",
                "node_count": node_result.node_count,
                "comparison_hotspot_count": node_result.comparison_hotspot_count,
                "comparison_hotspot_coverage": node_result.comparison_hotspot_coverage,
                "maximum_row_reconciliation_residual_tco2": node_result.maximum_row_residual,
                "maximum_column_reconciliation_residual_tco2": node_result.maximum_column_residual,
                "node_sda_evidence_cid": node_sda_evidence_cid,
                "artifacts": node_metadata.get("artifacts", {}),
                "top80_hotspot_node_drivers": node_result.hotspot_frame.to_dict(orient="records"),
                "authority_boundary": (
                    "Node-wise SDA is the primary producer-level temporal attribution. "
                    "Path-level SDA remains a secondary bounded-path mechanism drill-down."
                ),
                "dli_boundary": (
                    "The node-wise SDA effects do not enter BC, PR, CDR, IC, pooled Pearson-CRITIC, DLI scores or ranks."
                ),
            },
            "input_hashes": hashes,
        }
        response = self._response(
            "structural_decomposition_analysis",
            payload,
            request_context=request_context,
        )
        node_sda.bind_node_sda_metadata(
            ACTIVE_ANALYTICS_DIR,
            response.content_hash,
            node_sda_evidence_cid,
        )
        record_active_result(
            "sda",
            f"{base_year}-{comparison_year}",
            response,
            input_hashes=hashes,
            metadata={
                "base_year": base_year,
                "comparison_year": comparison_year,
                "node_sda_evidence_cid": node_sda_evidence_cid,
                "comparison_hotspot_count": node_result.comparison_hotspot_count,
            },
        )
        return response

    def compute_network(
        self, year: int, request_context: dict[str, Any] | None = None
    ) -> OrchestratorResponse:
        """Compute raw network metrics and the authoritative pooled CRITIC-DLI."""
        year = int(year)
        if year not in {2014, 2017}:
            raise ValueError("The current empirical implementation requires 2014 or 2017")
        hashes = active_input_hashes()
        my = ae.load_year(str(MRIO_PATH), year)
        company_y = ae.load_company_Y(str(COMPANY_PATH), year)
        raw_current, cdr_linkage = net.compute_raw_metrics_with_cdr_linkage(my, company_y)

        cdr_linkage_metadata = cdr_link.write_cdr_producer_linkage_artifacts(
            ACTIVE_ANALYTICS_DIR,
            cdr_linkage,
            input_hashes=hashes,
            preferred_pair=("ARE-cns", "ARE-ely"),
        )
        cdr_linkage_evidence_basis = {
            "extension_id": cdr_linkage_metadata.get("extension_id"),
            "year": year,
            "node_count": cdr_linkage_metadata.get("node_count"),
            "pair_count": cdr_linkage_metadata.get("pair_count"),
            "footprint_unit": cdr_linkage_metadata.get("footprint_unit"),
            "baseline_company_footprint_tco2": cdr_linkage_metadata.get(
                "baseline_company_footprint_tco2"
            ),
            "maximum_absolute_reconciliation_residual_tco2": cdr_linkage_metadata.get(
                "maximum_absolute_reconciliation_residual_tco2"
            ),
            "formula": cdr_linkage_metadata.get("formula"),
            "row_identity": cdr_linkage_metadata.get("row_identity"),
            "counterfactual_definition": cdr_linkage_metadata.get(
                "counterfactual_definition"
            ),
            "dli_authority_boundary": cdr_linkage_metadata.get(
                "dli_authority_boundary"
            ),
            "interpretation_boundary": cdr_linkage_metadata.get(
                "interpretation_boundary"
            ),
            "input_hashes": hashes,
            "artifacts": cdr_linkage_metadata.get("artifacts", {}),
            "pairwise_fields": cdr_linkage_metadata.get("pairwise_fields", []),
            "preferred_pair": cdr_linkage_metadata.get("preferred_pair"),
        }
        cdr_linkage_evidence_cid = store_content(
            cdr_linkage_evidence_basis, namespace="cdr_producer_linkage"
        )

        raw_bytes = raw_current.to_csv(index=False).encode("utf-8")
        raw_hash = sha256_bytes(raw_bytes)
        annual_frames: dict[int, pd.DataFrame] = {year: raw_current}
        other_year = 2017 if year == 2014 else 2014
        try:
            other_frame, _other_meta = load_verified_active_frame(
                f"critic_raw_network_metrics_{other_year}",
                expected_input_hashes=hashes,
            )
            annual_frames[other_year] = other_frame
        except FileNotFoundError:
            pass

        pooled_ready = set(annual_frames) == {2014, 2017}
        pooled_authority_ready = bool(pooled_ready and year == 2017)
        authoritative_dli_slices: dict[str, list[dict[str, Any]]] = {}
        temporal_dli_records: list[dict[str, Any]] = []
        baseline_network_result_cid = ""
        if pooled_authority_ready:
            scored_all, critic_result = critic_core.build_pooled_critic(
                annual_frames, correlation_method="pearson"
            )
            critic_basis = critic_core.canonical_critic_evidence(
                scored_all, critic_result, hashes
            )
            critic_evidence_cid = store_content(
                critic_basis, namespace="critic_dli_authoritative"
            )
            critic_stats = critic_core.criterion_statistics(critic_result)
            critic_artifact_hashes = critic_core.write_authoritative_artifacts(
                ACTIVE_ANALYTICS_DIR,
                scored_all,
                critic_result,
                hashes,
                critic_evidence_cid,
            )
            ranking = scored_all.loc[
                pd.to_numeric(scored_all["year"], errors="coerce") == year
            ].sort_values(["dli_rank", "node_code"], kind="mergesort").reset_index(drop=True)
            pooled_frames: dict[int, pd.DataFrame] = {}
            for reference_year in (2014, 2017):
                annual_slice = scored_all.loc[
                    pd.to_numeric(scored_all["year"], errors="coerce")
                    == reference_year
                ].sort_values(
                    ["dli_rank", "node_code"], kind="mergesort"
                ).reset_index(drop=True)
                pooled_frames[reference_year] = annual_slice
                authoritative_dli_slices[str(reference_year)] = (
                    annual_slice.to_dict(orient="records")
                )
            temporal_dli_records = net.compute_temporal_dli(
                pooled_frames[2014],
                pooled_frames[2017],
                base_year=2014,
                comparison_year=2017,
            ).to_dict(orient="records")
            try:
                active_index = json.loads(
                    RESULT_INDEX_PATH.read_text(encoding="utf-8")
                )
                baseline_record = active_index["results"]["network:2014"]
                if baseline_record.get("input_hashes") == hashes:
                    baseline_network_result_cid = str(
                        baseline_record.get("content_hash", "")
                    ).strip().lower()
            except Exception:
                baseline_network_result_cid = ""
            if (
                len(baseline_network_result_cid) != 64
                or any(
                    character not in "0123456789abcdef"
                    for character in baseline_network_result_cid
                )
            ):
                raise RuntimeError(
                    "The authoritative 2017 temporal DLI package requires the active fulfilled 2014 Network result CID"
                )
            dli_weighting = {
                "method": "pooled Pearson-CRITIC",
                "scope": "2014-2017 pooled evaluation matrix",
                "weights": critic_result.weights,
                "standard_deviation": critic_result.standard_deviation,
                "conflict": critic_result.conflict,
                "information": critic_result.information,
                "correlation_matrix": critic_result.correlation.to_dict(),
                "critic_evidence_cid": critic_evidence_cid,
                "legacy_fixed_weights_used": False,
                "artifact_sha256": critic_artifact_hashes,
            }
        else:
            provisional = critic_core.critic_weights(
                raw_current,
                correlation_method="pearson",
                scope=f"annual-provisional-{year}",
            )
            ranking = critic_core.score_and_rank(raw_current, provisional).sort_values(
                ["dli_rank", "node_code"], kind="mergesort"
            ).reset_index(drop=True)
            critic_result = provisional
            critic_stats = critic_core.criterion_statistics(provisional)
            critic_evidence_cid = ""
            dli_weighting = {
                "method": "annual provisional CRITIC",
                "scope": provisional.scope,
                "weights": provisional.weights,
                "legacy_fixed_weights_used": False,
                "pooled_years_available": sorted(annual_frames),
                "decision_boundary": (
                    "Formal 2017 intervention governance requires both annual raw metric sets and the pooled CRITIC result."
                ),
            }

        hotspot_leverage_result: hotspot_link.HotspotLeverageResult | None = None
        hotspot_leverage_metadata: dict[str, Any] = {}
        hotspot_leverage_evidence_cid = ""
        node_sda_metadata: dict[str, Any] = {}
        if pooled_authority_ready:
            node_sda_metadata = node_sda.verify_node_sda_artifacts(
                ACTIVE_ANALYTICS_DIR,
                expected_input_hashes=hashes,
            )
            node_sda_frame = pd.read_csv(
                ACTIVE_ANALYTICS_DIR / node_sda.ALL_NODES_FILENAME
            )
            hotspot_leverage_result = hotspot_link.compute_hotspot_leverage(
                my,
                company_y,
                cdr_linkage,
                node_sda_frame,
                scored_all,
                hotspot_threshold=0.80,
                high_dli_quantile=0.75,
                target_coverage=0.80,
            )
            hotspot_leverage_metadata = hotspot_link.write_hotspot_leverage_artifacts(
                ACTIVE_ANALYTICS_DIR,
                hotspot_leverage_result,
                input_hashes=hashes,
                critic_evidence_cid=critic_evidence_cid,
                cdr_linkage_evidence_cid=cdr_linkage_evidence_cid,
                node_sda_evidence_cid=str(node_sda_metadata.get("node_sda_evidence_cid", "")),
            )
            hotspot_evidence_basis = {
                key: value
                for key, value in hotspot_leverage_metadata.items()
                if key not in {
                    "generated_at_utc",
                    "source_network_result_cid",
                    "hotspot_leverage_evidence_cid",
                }
            }
            hotspot_leverage_evidence_cid = store_content(
                hotspot_evidence_basis,
                namespace="hotspot_leverage_structural_coverage",
            )
            # The structural evidence needed by U16 is assembled here, but the
            # formal intervention register is deliberately deferred until the
            # governed AURORA result has its immutable CID.

        integrated_result: dict[str, Any] | None = None
        intervention_records: list[dict[str, Any]] = []
        auxiliary: dict[str, Any]
        if pooled_authority_ready:
            integrated_result = final_methodology.run_integrated_methodology(
                runtime_dir=BASE_DIR / "runtime",
                mrio_path=MRIO_PATH,
                company_path=COMPANY_PATH,
                critic_ranking=scored_all,
                critic_weights=critic_stats,
                input_hashes=hashes,
                critic_evidence_cid=critic_evidence_cid,
                store_content_fn=lambda payload, namespace: store_content(payload, namespace=namespace),
            )
            auxiliary = {
                "decision_year": True,
                "intervention_count": 0,
                "formal_governance_option_count": 0,
                "formal_governance_source": (
                    "single hotspot-driver-path-leverage-actionability funnel, generated only after AURORA"
                ),
                "stakeholder_selection_required": True,
                "intervention_evidence_status": "deferred-until-fulfilled-aurora",
                "integrated_evidence_cid": integrated_result.get("integrated_evidence_cid"),
                "critic_evidence_cid": critic_evidence_cid,
                "hotspot_leverage_evidence_cid": hotspot_leverage_evidence_cid,
                "legacy_top15_intervention_authority": False,
            }
        elif year == 2017:
            auxiliary = {
                "decision_year": True,
                "intervention_count": 0,
                "stakeholder_selection_required": False,
                "note": (
                    "The 2017 raw network metrics were computed, but the 2014 metrics are not yet available. Complete Network 2014 and rerun Network 2017 to generate the pooled CRITIC ranking and integrated intervention portfolio."
                ),
            }
        else:
            auxiliary = {
                "decision_year": False,
                "historical_reference_year": year,
                "pooled_critic_ready": pooled_authority_ready,
                "note": (
                    "Historical raw network evidence retained for the pooled CRITIC weighting system. No formal historical intervention portfolio is generated."
                ),
            }

        payload = {
            "year": year,
            "decision_year": year == 2017,
            "pooled_critic_ready": pooled_authority_ready,
            "dli_weighting": dli_weighting,
            "dli_ranking": ranking.to_dict(orient="records"),
            "authoritative_dli_slices": authoritative_dli_slices,
            "temporal_dli_comparison": temporal_dli_records,
            "temporal_dli_authority": (
                {
                    "method": "one pooled two-year Pearson-CRITIC calculation",
                    "years": [2014, 2017],
                    "decision_result_year": 2017,
                    "baseline_evidence_network_result_cid": baseline_network_result_cid,
                    "baseline_role": (
                        "The fulfilled 2014 Network request supplies required raw baseline evidence; "
                        "after 2017 fulfillment, both displayed annual DLI slices are the jointly "
                        "normalized and jointly weighted slices embedded in this 2017 result."
                    ),
                }
                if pooled_authority_ready
                else {
                    "method": "provisional annual evidence only",
                    "years": [year],
                    "decision_result_year": None,
                }
            ),
            "interventions": intervention_records,
            "integrated_methodology": (
                {
                    "available": True,
                    "integrated_evidence_cid": integrated_result.get("integrated_evidence_cid"),
                    "summary": integrated_result.get("summary", {}),
                }
                if integrated_result
                else {"available": False}
            ),
            "raw_network_artifact": {
                "filename": f"critic_raw_network_metrics_{year}.csv",
                "sha256": raw_hash,
                "row_count": int(len(raw_current)),
            },
            "cdr_producer_linkage": {
                **cdr_linkage_evidence_basis,
                "available": True,
                "evidence_cid": cdr_linkage_evidence_cid,
                "source_network_result_binding": (
                    "The runtime metadata artifact is bound to this response content hash "
                    "immediately after the immutable response hash is created."
                ),
            },
            "hotspot_leverage": (
                {
                    "available": True,
                    "extension_id": hotspot_link.HOTSPOT_LEVERAGE_EXTENSION_ID,
                    "evidence_cid": hotspot_leverage_evidence_cid,
                    "hotspot_count": hotspot_leverage_result.hotspot_count,
                    "hotspot_total_footprint_tco2": hotspot_leverage_result.hotspot_total_footprint,
                    "hotspot_share_of_company_footprint": (
                        hotspot_leverage_result.hotspot_total_footprint
                        / hotspot_leverage_result.company_total_footprint
                        if hotspot_leverage_result.company_total_footprint
                        else 0.0
                    ),
                    "high_dli_threshold": hotspot_leverage_result.high_dli_threshold,
                    "portfolio_summaries": hotspot_leverage_metadata.get("portfolio_summaries", []),
                    "artifacts": hotspot_leverage_metadata.get("artifacts", {}),
                    "method_boundary": hotspot_leverage_metadata.get("abatement_boundary"),
                }
                if hotspot_leverage_result is not None
                else {
                    "available": False,
                    "reason": "Authoritative pooled 2014-2017 CRITIC-DLI and node-wise SDA are required.",
                }
            ),
            "intervention_governance": {
                "available": False,
                "extension_id": intervention_gov.INTERVENTION_GOVERNANCE_EXTENSION_ID,
                "status": "deferred-until-fulfilled-aurora",
                "reason": (
                    "The deterministic intervention register is generated after the 2017 AURORA result "
                    "receives its immutable CID, so every formal option is bound to both evidence stages."
                ),
                "governance_boundary": (
                    "No legacy top-15 DLI intervention authority is generated. After AURORA, formal governance "
                    "accepts only current options with positive producer linkage, an adverse-driver mechanism, and verified actionability."
                ),
                "dli_boundary": (
                    "Node-wise SDA, deterministic mechanism mapping, actionability, and AURORA do not enter BC, "
                    "PR, CDR, IC, pooled Pearson-CRITIC, DLI scores, or DLI ranks."
                ),
            },
            "input_hashes": hashes,
        }
        response = self._response(
            "network_and_critic_dli_analysis",
            payload,
            auxiliary,
            request_context=request_context,
        )
        cdr_link.bind_cdr_linkage_metadata_to_network_result(
            ACTIVE_ANALYTICS_DIR,
            year,
            response.content_hash,
            cdr_linkage_evidence_cid,
        )
        if hotspot_leverage_result is not None:
            hotspot_link.bind_hotspot_leverage_metadata(
                ACTIVE_ANALYTICS_DIR,
                response.content_hash,
                hotspot_leverage_evidence_cid,
            )
        write_active_frame_artifact(
            f"critic_raw_network_metrics_{year}",
            raw_current,
            input_hashes=hashes,
            source_result_cid=response.content_hash,
            metadata={"year": year, "committed_artifact_sha256": raw_hash},
        )
        if pooled_authority_ready:
            # Both convenience mirrors are derived from, and bound to, the same
            # immutable 2017 response.  The earlier 2014 response remains the
            # required baseline request but its provisional annual score must
            # never be merged with the authoritative pooled 2017 slice.
            for reference_year in (2014, 2017):
                store_active_analytics_frame(
                    "dli",
                    reference_year,
                    pd.DataFrame(authoritative_dli_slices[str(reference_year)]),
                    input_hashes=hashes,
                    source_result_cid=response.content_hash,
                )
        else:
            store_active_analytics_frame(
                "dli_provisional", year, ranking,
                input_hashes=hashes,
                source_result_cid=response.content_hash,
            )
        record_active_result(
            "network", str(year), response, input_hashes=hashes,
            metadata={
                "year": year,
                "pooled_critic_ready": pooled_authority_ready,
                "critic_evidence_cid": critic_evidence_cid,
                "integrated_evidence_cid": integrated_result.get("integrated_evidence_cid") if integrated_result else None,
                "cdr_producer_linkage_evidence_cid": cdr_linkage_evidence_cid,
                "hotspot_leverage_evidence_cid": hotspot_leverage_evidence_cid,
                "intervention_governance_evidence_cid": None,
                "intervention_governance_status": "deferred-until-fulfilled-aurora",
            },
        )
        if pooled_authority_ready:
            try:
                self.compute_dli_weight_robustness(
                    year,
                    monte_carlo_samples=5000,
                    dirichlet_concentration=80.0,
                    random_seed=20260903,
                    request_context={
                        "trigger": "automatic_after_authoritative_critic_dli",
                        "source_network_result_cid": response.content_hash,
                    },
                )
            except Exception as exc:
                (ACTIVE_ANALYTICS_DIR / "critic_robustness_auto_error.json").write_text(
                    json.dumps({"error": str(exc), "generated_at_utc": utc_now()}, indent=2),
                    encoding="utf-8",
                )
        return response

    def compute_dli_weight_robustness(
        self,
        year: int,
        *,
        top_k: int = 15,
        monte_carlo_samples: int = 5000,
        dirichlet_concentration: float = 80.0,
        random_seed: int = 20260903,
        critic_correlation_method: str = "pearson",
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        """Generate one-way and Monte Carlo evidence centred on pooled CRITIC."""
        if int(year) != 2017:
            raise ValueError("The final CRITIC-centred robustness analysis is reported for the 2017 decision year")
        if str(critic_correlation_method).lower() != "pearson":
            raise ValueError("The authoritative U11 DLI uses Pearson-CRITIC; use Pearson for the in-app robustness run")
        summary = critic_robustness.run_critic_robustness(
            BASE_DIR / "runtime",
            samples=int(monte_carlo_samples),
            concentration=float(dirichlet_concentration),
            seed=int(random_seed),
            top_k=int(top_k),
        )
        hashes = active_input_hashes()
        payload = {
            "year": 2017,
            "status": "completed",
            "summary": summary,
            "input_hashes": hashes,
            "authority_boundary": (
                "Only positive CRITIC-centred criterion weights are randomized. The MRIO-derived BC, PR, CDR and IC values remain fixed."
            ),
        }
        response = self._response(
            "critic_dli_weight_robustness", payload,
            {"automatic_or_in_app": True},
            request_context=request_context,
        )
        record_active_result(
            "dli_sensitivity", "2017", response, input_hashes=hashes,
            metadata={"year": 2017, "method": "CRITIC-centred"},
        )
        return response


    def compute_integrated_methodology(
        self,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        """Regenerate the integrated reporting layer from active governed evidence."""
        hashes = active_input_hashes()
        ranking_path = ACTIVE_ANALYTICS_DIR / "critic_authoritative_dli_ranking.csv"
        weights_path = ACTIVE_ANALYTICS_DIR / "critic_authoritative_weights.csv"
        critic_meta_path = ACTIVE_ANALYTICS_DIR / "critic_authoritative_dli.json"
        if not ranking_path.is_file() or not weights_path.is_file() or not critic_meta_path.is_file():
            raise FileNotFoundError(
                "The pooled CRITIC-DLI evidence is unavailable. Complete Network analysis for 2014 and then 2017."
            )
        critic_meta = json.loads(critic_meta_path.read_text(encoding="utf-8"))
        if critic_meta.get("input_hashes") != hashes:
            raise RuntimeError("The pooled CRITIC-DLI evidence is stale for the active inputs")
        result = final_methodology.run_integrated_methodology(
            runtime_dir=BASE_DIR / "runtime",
            mrio_path=MRIO_PATH,
            company_path=COMPANY_PATH,
            critic_ranking=pd.read_csv(ranking_path),
            critic_weights=pd.read_csv(weights_path),
            input_hashes=hashes,
            critic_evidence_cid=str(critic_meta.get("critic_evidence_cid", "")),
            store_content_fn=lambda payload, namespace: store_content(payload, namespace=namespace),
        )
        payload = {
            "status": "completed",
            "summary": result.get("summary", {}),
            "integrated_evidence_cid": result.get("integrated_evidence_cid"),
            "artifact_cids": result.get("artifact_cids", {}),
            "input_hashes": hashes,
            "authority_boundary": (
                "This refresh updates off-chain explanatory evidence. Formal intervention options are published only after the governed 2017 AURORA result and are bound to both the active Network/DLI and AURORA CIDs."
            ),
        }
        response = self._response(
            "spa_sda_critic_dli_integrated_methodology",
            payload,
            request_context=request_context,
        )
        record_active_result(
            "integrated", "2014-2017", response, input_hashes=hashes,
            metadata={"integrated_evidence_cid": result.get("integrated_evidence_cid")},
        )
        return response

    def _materialize_post_aurora_intervention_artifacts(
        self,
        network_result_hash: str,
        aurora_result_hash: str,
        expected_input_hashes: dict[str, str],
    ) -> dict[str, Any]:
        """Build only the downstream U16 evidence for a verified AURORA chain."""

        network_cid = str(network_result_hash).strip().lower()
        aurora_cid = str(aurora_result_hash).strip().lower()
        hashes = active_input_hashes()
        if hashes != dict(expected_input_hashes):
            raise RuntimeError("Active inputs changed before intervention materialization")
        _verified_active_network_2017_payload(network_cid, hashes)
        if _verified_active_aurora_cid(network_cid, hashes) != aurora_cid:
            raise RuntimeError("The requested AURORA CID is not the active 2017 result")

        pair_path_file = (
            ACTIVE_ANALYTICS_DIR / final_methodology.PATH_PAIR_EVIDENCE_FILENAME
        )
        if not pair_path_file.is_file():
            raise FileNotFoundError(
                "Integrated path/linkage evidence is unavailable for post-AURORA intervention governance"
            )
        hotspot_metadata = hotspot_link.verify_hotspot_leverage_artifacts(
            ACTIVE_ANALYTICS_DIR,
            expected_input_hashes=hashes,
        )
        if str(hotspot_metadata.get("source_network_result_cid", "")).lower() != network_cid:
            raise RuntimeError(
                "Hotspot-leverage evidence is bound to a different 2017 Network/DLI result"
            )

        prior_assessments: pd.DataFrame | None = None
        prior_options: pd.DataFrame | None = None
        try:
            intervention_gov.verify_intervention_governance_artifacts(
                ACTIVE_ANALYTICS_DIR,
                expected_input_hashes=hashes,
                expected_source_network_result_cid=network_cid,
                expected_source_aurora_result_cid=aurora_cid,
            )
            prior_frames = intervention_gov.load_intervention_governance_frames(
                ACTIVE_ANALYTICS_DIR
            )
            prior_assessments = prior_frames.get("assessments")
            prior_options = prior_frames.get("governance_options")
        except Exception:
            # A different or incomplete evidence chain cannot contribute named
            # assertions or immutable option CIDs to this AURORA binding.
            prior_assessments = None
            prior_options = None

        integrated_meta_path = (
            ACTIVE_ANALYTICS_DIR / "spa_sda_critic_dli_integrated_result.json"
        )
        integrated_meta = (
            json.loads(integrated_meta_path.read_text(encoding="utf-8"))
            if integrated_meta_path.is_file()
            else {}
        )
        model = ae.load_year(str(MRIO_PATH), 2017)
        company_y = ae.load_company_Y(str(COMPANY_PATH), 2017)
        governance_result = intervention_gov.compute_intervention_governance(
            model,
            company_y,
            pd.read_csv(pair_path_file),
            assessments=prior_assessments,
            target_coverage=0.80,
            source_network_result_cid=network_cid,
            source_aurora_result_cid=aurora_cid,
            input_hashes=hashes,
            store_content_fn=store_content,
            existing_options=prior_options,
        )
        if active_input_hashes() != hashes:
            raise RuntimeError("Active inputs changed during intervention materialization")
        metadata = intervention_gov.write_intervention_governance_artifacts(
            ACTIVE_ANALYTICS_DIR,
            governance_result,
            input_hashes=hashes,
            source_network_result_cid=network_cid,
            source_aurora_result_cid=aurora_cid,
            hotspot_leverage_evidence_cid=str(
                hotspot_metadata.get("hotspot_leverage_evidence_cid", "")
            ),
            node_sda_evidence_cid=str(hotspot_metadata.get("node_sda_evidence_cid", "")),
            critic_evidence_cid=str(hotspot_metadata.get("critic_evidence_cid", "")),
            integrated_evidence_cid=str(integrated_meta.get("integrated_evidence_cid", "")),
            store_content_fn=store_content,
        )
        if active_input_hashes() != hashes:
            raise RuntimeError("Active inputs changed while intervention artifacts were written")
        return metadata

    def _fulfilled_deployment_result_cid(self, kind: str, year: int) -> str:
        """Read a CID admitted by lifecycle reconstruction from fulfilled chain state."""

        groups = self.deployment.get("active_results", {})
        group = groups.get(str(kind), {}) if isinstance(groups, dict) else {}
        record = group.get(str(int(year)), {}) if isinstance(group, dict) else {}
        cid = str(record.get("content_hash", "")).strip().lower() if isinstance(record, dict) else ""
        if len(cid) != 64 or any(ch not in "0123456789abcdef" for ch in cid):
            raise RuntimeError(
                f"No fulfilled, lifecycle-verified {kind} result is active for {int(year)}"
            )
        return cid

    def _require_current_query_methodology_gate(self) -> dict[str, Any]:
        """Verify the full analytical and intervention gate before any query.

        The Streamlit interface exposes the same rule, but an Oracle-facing
        service must enforce it independently.  This prevents a direct contract
        call from obtaining a new governed answer after input replacement or
        against stale Network/DLI or AURORA evidence, or before the intervention
        branch has reached an accountable decision/no-option outcome.
        """

        if getattr(self, "deployment_path", None) and self.deployment_path.is_file():
            self.deployment = json.loads(self.deployment_path.read_text(encoding="utf-8"))
        if str(self.deployment.get("architecture_version", "")) != (
            "5.0.17-u23-evidence-bound-abatement-decision"
        ):
            raise RuntimeError("The active deployment does not use the current governed methodology lifecycle")
        contracts = self.deployment.get("contracts", {})
        if not isinstance(contracts, dict) or "QueryManagement" not in contracts:
            raise RuntimeError("QueryManagement is not deployed for the active governed lifecycle")

        lifecycle = self.deployment.get("lifecycle", {})
        if not isinstance(lifecycle, dict) or not lifecycle.get("intervention_governance_resolved"):
            raise RuntimeError(
                "Final decision support is paused until intervention governance has an on-chain decision or a verified no-option outcome"
            )

        hashes = active_input_hashes()
        if self.deployment.get("active_input_hashes") != hashes:
            raise RuntimeError(
                "Query execution is paused because deployment evidence is stale for the active inputs"
            )

        network_2014_cid = self._fulfilled_deployment_result_cid("network", 2014)
        network_2017_cid = self._fulfilled_deployment_result_cid("network", 2017)
        aurora_2017_cid = self._fulfilled_deployment_result_cid("aurora", 2017)

        _verified_active_network_payload(network_2014_cid, hashes, 2014)
        network_2017 = _verified_active_network_2017_payload(network_2017_cid, hashes)
        temporal_authority = network_2017.get("temporal_dli_authority", {})
        if (
            not isinstance(temporal_authority, dict)
            or str(
                temporal_authority.get(
                    "baseline_evidence_network_result_cid", ""
                )
            ).strip().lower()
            != network_2014_cid
        ):
            raise RuntimeError(
                "Query execution is paused because the 2017 temporal DLI result is not bound to the active 2014 baseline CID"
            )
        active_aurora_cid = _verified_active_aurora_cid(network_2017_cid, hashes)
        if active_aurora_cid != aurora_2017_cid:
            raise RuntimeError(
                "Query execution is paused because AURORA is not the fulfilled active 2017 result"
            )

        return {
            "input_hashes": hashes,
            "network_2014_cid": network_2014_cid,
            "network_2017_cid": network_2017_cid,
            "aurora_2017_cid": aurora_2017_cid,
            "pooled_critic_ready": bool(network_2017.get("pooled_critic_ready", False)),
            "intervention_governance_dependency": "resolved",
        }

    def materialize_post_aurora_intervention_governance(
        self,
        network_result_hash: str,
        aurora_result_hash: str,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        """Safely retry governed intervention artifacts after matching AURORA.

        This operation reads the existing governed analytical evidence.  It
        never runs AURORA, Network metrics, CRITIC, DLI, MRIO, SPA or SDA.
        Invalid prerequisites and downstream file-generation errors fail this
        explicit retry visibly. It does not invalidate valid AURORA evidence,
        but final QueryManagement support remains locked until governance is
        resolved by an accountable decision or verified no-option outcome.
        """

        network_cid = str(network_result_hash).strip().lower()
        requested_aurora_cid = str(aurora_result_hash).strip().lower()
        hashes = active_input_hashes()
        _verified_active_network_2017_payload(network_cid, hashes)
        active_aurora_cid = _verified_active_aurora_cid(network_cid, hashes)
        if requested_aurora_cid != active_aurora_cid:
            raise RuntimeError("The requested AURORA CID is not the active indexed 2017 result")

        fulfilled_network_cid = self._fulfilled_deployment_result_cid("network", 2017)
        fulfilled_aurora_cid = self._fulfilled_deployment_result_cid("aurora", 2017)
        if fulfilled_network_cid != network_cid:
            raise RuntimeError("The active indexed Network/DLI CID is not the fulfilled on-chain result")
        if fulfilled_aurora_cid != active_aurora_cid:
            raise RuntimeError("The active indexed AURORA CID is not the fulfilled on-chain result")
        deployment_hashes = self.deployment.get("active_input_hashes", {})
        if deployment_hashes != hashes:
            raise RuntimeError("The fulfilled lifecycle state is stale for the active input workbooks")

        with self._intervention_governance_lock, _RESULT_INDEX_LOCK:
            try:
                metadata = intervention_gov.verify_intervention_governance_artifacts(
                    ACTIVE_ANALYTICS_DIR,
                    expected_input_hashes=hashes,
                    expected_source_network_result_cid=network_cid,
                    expected_source_aurora_result_cid=active_aurora_cid,
                )
                status = "already-materialized"
            except Exception:
                metadata = self._materialize_post_aurora_intervention_artifacts(
                    network_cid,
                    active_aurora_cid,
                    hashes,
                )
                metadata = intervention_gov.verify_intervention_governance_artifacts(
                    ACTIVE_ANALYTICS_DIR,
                    expected_input_hashes=hashes,
                    expected_source_network_result_cid=network_cid,
                    expected_source_aurora_result_cid=active_aurora_cid,
                )
                status = "materialized-on-demand"

        governance_evidence_cid = str(
            metadata.get("intervention_governance_evidence_cid", "")
        )
        payload = {
            "year": 2017,
            "status": status,
            "network_result_hash": network_cid,
            "aurora_result_hash": active_aurora_cid,
            "input_hashes": hashes,
            "intervention_governance_evidence_cid": governance_evidence_cid,
            "candidate_pair_count": int(metadata.get("candidate_pair_count", 0)),
            "governance_ready_option_count": int(
                metadata.get("governance_ready_option_count", 0)
            ),
            "verified_fulfilled_lifecycle_binding": True,
            "analytical_recomputation": False,
            "authority_boundary": (
                "This recovery operation writes only the downstream intervention register. "
                "It does not recompute or alter AURORA, Network/DLI, CRITIC weights or any upstream result."
            ),
        }
        response = self._response(
            "intervention_governance_evidence_materialization",
            payload,
            {
                "available": True,
                "status": status,
                "intervention_governance_evidence_cid": governance_evidence_cid,
            },
            request_context=request_context,
        )
        record_active_result(
            "intervention_materialization",
            "2017",
            response,
            input_hashes=hashes,
            metadata={
                "network_result_hash": network_cid,
                "aurora_result_hash": active_aurora_cid,
                "intervention_governance_evidence_cid": governance_evidence_cid,
                "available": True,
                "status": status,
            },
        )
        return response

    def record_intervention_actionability(
        self,
        network_result_hash: str,
        candidate_id: str,
        assessment: dict[str, Any],
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        """Record one stakeholder actionability assessment and rebuild U16.

        This operation never changes the analytical results. It verifies the
        exact 2017 Network/DLI result, the active completed AURORA CID, and the
        active workbook hashes; records node-level governance evidence plus
        pair/mechanism technical feasibility; then reruns only the single U16
        governance-ready funnel.
        """
        network_result_hash = str(network_result_hash).strip().lower()
        candidate_id = str(candidate_id).strip().lower()
        if not isinstance(assessment, dict):
            raise TypeError("assessment must be a JSON object")

        # Once any current option enters formal on-chain governance, freeze the
        # assessment register for this evidence cycle.  Otherwise a later edit
        # could change the option fingerprint and detach the selected proposal
        # from the detailed register that justified it.
        if getattr(self, "deployment_path", None) and self.deployment_path.is_file():
            self.deployment = json.loads(
                self.deployment_path.read_text(encoding="utf-8")
            )
        deployment_state = getattr(self, "deployment", {})
        selected_requests = (
            deployment_state.get("active_results", {})
            .get("intervention_requests", {})
            .get("2017", [])
        )
        if any(
            isinstance(item, dict) and int(item.get("status", -1)) in {0, 1}
            for item in selected_requests
        ):
            raise RuntimeError(
                "The intervention assessment register is frozen because a current option has already entered formal on-chain governance"
            )

        with self._intervention_governance_lock, _RESULT_INDEX_LOCK:
            hashes = active_input_hashes()
            _verified_active_network_2017_payload(network_result_hash, hashes)
            aurora_result_cid = _verified_active_aurora_cid(
                network_result_hash,
                hashes,
            )

            hotspot_metadata = hotspot_link.verify_hotspot_leverage_artifacts(
                ACTIVE_ANALYTICS_DIR,
                expected_input_hashes=hashes,
            )
            if str(hotspot_metadata.get("source_network_result_cid", "")) != network_result_hash:
                raise RuntimeError("Hotspot-leverage evidence is bound to a different Network/DLI result")
            current_u16_metadata = intervention_gov.verify_intervention_governance_artifacts(
                ACTIVE_ANALYTICS_DIR,
                expected_input_hashes=hashes,
                expected_source_network_result_cid=network_result_hash,
                expected_source_aurora_result_cid=aurora_result_cid,
            )
            frames = intervention_gov.load_intervention_governance_frames(ACTIVE_ANALYTICS_DIR)
            updated_assessments = intervention_gov.upsert_actionability_assessment(
                frames["candidates"],
                frames["assessments"],
                candidate_id,
                assessment,
            )
            assessment_row = updated_assessments.loc[
                updated_assessments["candidate_id"].astype(str).eq(candidate_id)
            ].iloc[0].to_dict()
            assessment_attestation_cid = store_content(
                {
                    "extension_id": intervention_gov.INTERVENTION_GOVERNANCE_EXTENSION_ID,
                    "source_network_result_cid": network_result_hash,
                    "source_aurora_result_cid": aurora_result_cid,
                    "input_hashes": hashes,
                    "candidate_id": candidate_id,
                    "assessment": assessment_row,
                    "attestation_boundary": (
                        "This is a named stakeholder attestation and evidence reference. The Data Orchestrator verifies completeness and provenance, not the external truth of the supporting document."
                    ),
                },
                namespace="u16_actionability_attestation",
            )

            model = ae.load_year(str(MRIO_PATH), 2017)
            company_y = ae.load_company_Y(str(COMPANY_PATH), 2017)
            pair_path_file = ACTIVE_ANALYTICS_DIR / final_methodology.PATH_PAIR_EVIDENCE_FILENAME
            pair_evidence = pd.read_csv(
                pair_path_file
                if pair_path_file.is_file()
                else ACTIVE_ANALYTICS_DIR / hotspot_link.PAIR_EVIDENCE_FILENAME
            )
            integrated_meta_path = ACTIVE_ANALYTICS_DIR / "spa_sda_critic_dli_integrated_result.json"
            integrated_meta = (
                json.loads(integrated_meta_path.read_text(encoding="utf-8"))
                if integrated_meta_path.is_file()
                else {}
            )
            result = intervention_gov.compute_intervention_governance(
                model,
                company_y,
                pair_evidence,
                assessments=updated_assessments,
                target_coverage=0.80,
                source_network_result_cid=network_result_hash,
                source_aurora_result_cid=aurora_result_cid,
                input_hashes=hashes,
                store_content_fn=store_content,
                existing_options=frames.get("governance_options"),
            )
            metadata = intervention_gov.write_intervention_governance_artifacts(
                ACTIVE_ANALYTICS_DIR,
                result,
                input_hashes=hashes,
                source_network_result_cid=network_result_hash,
                source_aurora_result_cid=aurora_result_cid,
                hotspot_leverage_evidence_cid=str(
                    hotspot_metadata.get("hotspot_leverage_evidence_cid", "")
                ),
                node_sda_evidence_cid=str(hotspot_metadata.get("node_sda_evidence_cid", "")),
                critic_evidence_cid=str(hotspot_metadata.get("critic_evidence_cid", "")),
                integrated_evidence_cid=str(integrated_meta.get("integrated_evidence_cid", "")),
                store_content_fn=store_content,
            )
            selected = result.eligibility.loc[
                result.eligibility["candidate_id"].astype(str).eq(candidate_id)
            ].iloc[0]
            governance_ready = result.portfolio
            payload = {
                "year": 2017,
                "network_result_hash": network_result_hash,
                "aurora_result_hash": aurora_result_cid,
                "candidate_id": candidate_id,
                "assessment_attestation_cid": assessment_attestation_cid,
                "assessment_status": str(selected["assessment_status"]),
                "assessment_status_basis": str(selected["assessment_status_basis"]),
                "scenario_status": str(selected.get("scenario_status", "Not quantified")),
                "scenario_status_basis": str(selected.get("scenario_status_basis", "")),
                "mechanism_mapping_status": str(selected["mechanism_mapping_status"]),
                "primary_adverse_driver": str(selected.get("hotspot_primary_adverse_driver", "")),
                "primary_beneficial_driver_to_preserve": str(
                    selected.get("hotspot_primary_beneficial_driver", "")
                ),
                "governance_eligibility_status": str(selected["governance_eligibility_status"]),
                "intervention_node": str(selected["intervention_node"]),
                "hotspot_producer_node": str(selected["hotspot_producer_node"]),
                "recommended_action": str(selected["recommended_action"]),
                "governance_ready_option_count": int(len(result.governance_options)),
                "governance_ready_portfolio_node_count": int(len(governance_ready.frame)),
                "governance_ready_hotspot_structural_coverage": governance_ready.achieved_hotspot_coverage,
                "governance_ready_company_structural_coverage": governance_ready.achieved_company_coverage,
                "intervention_governance_evidence_cid": metadata.get(
                    "intervention_governance_evidence_cid", ""
                ),
                "input_hashes": hashes,
                "authority_boundary": (
                    "This operation changes only organizational actionability, pair feasibility, eligibility, and the single governance-ready portfolio. It does not recalculate or modify MRIO, SPA, node/path SDA, CRITIC-DLI, CDR linkage, or HSI values."
                ),
            }
            response = self._response(
                "u16_intervention_actionability_assessment",
                payload,
                {
                    "candidate_id": candidate_id,
                    "assessment_attestation_cid": assessment_attestation_cid,
                    "governance_ready_option_count": int(len(result.governance_options)),
                },
                request_context=request_context,
            )
            record_active_result(
                "intervention_governance",
                "2017",
                response,
                input_hashes=hashes,
                metadata={
                    "source_network_result_cid": network_result_hash,
                    "source_aurora_result_cid": aurora_result_cid,
                    "intervention_governance_evidence_cid": metadata.get(
                        "intervention_governance_evidence_cid", ""
                    ),
                    "assessment_attestation_cid": assessment_attestation_cid,
                    "governance_ready_option_count": int(len(result.governance_options)),
                },
            )
            return response

    @_with_result_index_lock
    def prepare_intervention_proposal(
        self,
        network_result_hash: str,
        node_code: str,
        option_cid: str,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        """Verify a stakeholder-selected deterministic intervention option.

        The Oracle supplies the exact fulfilled 2017 Network/DLI result hash,
        node code and option CID emitted by the selection transaction.  The
        orchestrator verifies the active completed AURORA binding, confirms
        that the option occurs in that post-AURORA portfolio, and checks the
        active workbook hashes before returning fields for the Governance
        Oracle to record on-chain.
        """

        network_result_hash = str(network_result_hash).strip().lower()
        node_code = str(node_code).strip()
        option_cid = str(option_cid).strip().lower()
        hashes = active_input_hashes()
        _verified_active_network_2017_payload(network_result_hash, hashes)
        aurora_result_cid = _verified_active_aurora_cid(
            network_result_hash,
            hashes,
        )

        metadata = intervention_gov.verify_intervention_governance_artifacts(
            ACTIVE_ANALYTICS_DIR,
            expected_input_hashes=hashes,
            expected_source_network_result_cid=network_result_hash,
            expected_source_aurora_result_cid=aurora_result_cid,
        )
        options = pd.read_csv(ACTIVE_ANALYTICS_DIR / intervention_gov.GOVERNANCE_OPTIONS_FILENAME)
        selected_rows = options.loc[
            options.get("node_code", pd.Series(dtype=str)).astype(str).eq(node_code)
            & options.get("option_cid", pd.Series(dtype=str)).astype(str).str.lower().eq(option_cid)
        ]
        if selected_rows.empty:
            raise ValueError(
                "The selected node/option CID is not a current governance-ready option. "
                "Legacy top-DLI analytical options and unassessed candidates cannot enter formal governance."
            )
        selected = selected_rows.iloc[0].to_dict()
        if str(selected.get("governance_eligibility_status", "")) != intervention_gov.ELIGIBLE_STATUS:
            raise ValueError("The selected intervention option is not eligible for formal governance")

        option_envelope = load_content(option_cid)
        option_material = option_envelope.get("payload", {})
        option_payload = option_material if isinstance(option_material, dict) else {}
        if option_payload.get("extension_id") != intervention_gov.INTERVENTION_GOVERNANCE_EXTENSION_ID:
            raise ValueError("The option package is not a governance-ready intervention")
        if str(option_payload.get("source_network_result_cid", "")) != network_result_hash:
            raise ValueError("The option is bound to a different Network/DLI result")
        if str(option_payload.get("source_aurora_result_cid", "")) != aurora_result_cid:
            raise ValueError("The option is bound to a different fulfilled AURORA result")
        if option_payload.get("input_hashes", {}) != hashes:
            raise ValueError("The option is stale for the active input workbooks")
        option_record = option_payload.get("intervention", {})
        if not isinstance(option_record, dict):
            raise ValueError("The selected intervention option package is malformed")
        if str(option_record.get("node_code", "")) != node_code:
            raise ValueError("The option package node does not match the selected node")
        if str(option_record.get("governance_eligibility_status", "")) != intervention_gov.ELIGIBLE_STATUS:
            raise ValueError("The immutable option package does not record formal eligibility")
        if str(option_payload.get("option_fingerprint", "")) != str(selected.get("option_fingerprint", "")):
            raise ValueError("The option package fingerprint does not match the verified option register")

        payload = {
            "network_result_hash": network_result_hash,
            "aurora_result_hash": aurora_result_cid,
            "node_code": node_code,
            "option_cid": option_cid,
            "dli_rank": int(selected["dli_rank"]),
            "dli_score": float(selected["dli_score"]),
            "dli_score_bps": int(selected["dli_score_bps"]),
            "category": str(selected["category"]),
            "action": str(selected["action"]),
            "channel": str(selected["channel"]),
            "driven_by": str(selected["driven_by"]),
            "hotspot_targets": str(selected.get("hotspot_targets", "")),
            "intervention_route": str(selected.get("intervention_route", "")),
            "abatement_scenario_status": str(selected.get("abatement_scenario_status", "Not quantified")),
            "scenario_conservative_reduction_tco2": selected.get("scenario_conservative_reduction_tco2"),
            "scenario_expected_reduction_tco2": selected.get("scenario_expected_reduction_tco2"),
            "scenario_ambitious_reduction_tco2": selected.get("scenario_ambitious_reduction_tco2"),
            "scenario_assumption_summary": str(selected.get("scenario_assumption_summary", "")),
            "scenario_evidence_references": str(selected.get("scenario_evidence_references", "")),
            "scenario_assessment_ids": str(selected.get("scenario_assessment_ids", "")),
            "scenario_claim_boundary": str(selected.get("scenario_claim_boundary", "")),
            "governance_eligibility_status": str(selected.get("governance_eligibility_status", "")),
            "intervention_governance_evidence_cid": str(
                metadata.get("intervention_governance_evidence_cid", "")
            ),
            "input_hashes": hashes,
            "verified": True,
        }
        auxiliary = {
            "node_code": node_code,
            "dli_score_bps": int(selected["dli_score_bps"]),
            "evidence_cid": str(
                metadata.get("intervention_governance_evidence_cid", network_result_hash)
            ),
            "category": str(selected["category"]),
            "action_cid": option_cid,
        }
        return self._response(
            "governance_intervention_proposal_verification",
            payload,
            auxiliary,
            request_context=request_context,
        )

    @_with_result_index_lock
    def record_intervention_performance_evidence(
        self,
        network_result_hash: str,
        option_cid: str,
        intervention_id: int,
        observation: Mapping[str, Any],
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        """Create a verified post-deployment monitoring package for on-chain anchoring."""

        network_result_hash = str(network_result_hash).strip().lower()
        option_cid = str(option_cid).strip().lower()
        intervention_id = int(intervention_id)
        if intervention_id < 0:
            raise ValueError("intervention_id must be non-negative")
        hashes = active_input_hashes()
        _verified_active_network_2017_payload(network_result_hash, hashes)
        aurora_result_cid = _verified_active_aurora_cid(network_result_hash, hashes)
        metadata = intervention_gov.verify_intervention_governance_artifacts(
            ACTIVE_ANALYTICS_DIR,
            expected_input_hashes=hashes,
            expected_source_network_result_cid=network_result_hash,
            expected_source_aurora_result_cid=aurora_result_cid,
        )
        options = pd.read_csv(
            ACTIVE_ANALYTICS_DIR / intervention_gov.GOVERNANCE_OPTIONS_FILENAME,
            keep_default_na=False,
        )
        rows = options.loc[options["option_cid"].astype(str).str.lower().eq(option_cid)]
        if rows.empty:
            raise ValueError("The monitoring record does not reference a current governed intervention option")
        selected = rows.iloc[0].to_dict()

        # Bind the supplied intervention ID to this exact selected option and
        # require an approved on-chain lifecycle record before creating an
        # observation package.  The contract independently rechecks approval
        # when the resulting CID is anchored.
        if getattr(self, "deployment_path", None) and self.deployment_path.is_file():
            self.deployment = json.loads(
                self.deployment_path.read_text(encoding="utf-8")
            )
        deployment_state = getattr(self, "deployment", {})
        governed_interventions = (
            deployment_state.get("active_results", {})
            .get("interventions", {})
            .get("2017", [])
        )
        exact_intervention = [
            item
            for item in governed_interventions
            if isinstance(item, dict)
            and int(item.get("intervention_id", -1)) == intervention_id
            and str(item.get("option_cid", "")).strip().lower() == option_cid
            and str(item.get("network_result_hash", "")).strip().lower() == network_result_hash
        ]
        if not exact_intervention:
            raise ValueError(
                "The intervention ID is not bound to this governed option CID and active Network/DLI result"
            )
        if int(exact_intervention[0].get("status", 0)) != 1:
            raise ValueError("Post-deployment performance can be recorded only for an approved intervention")

        def required_text(field: str, maximum: int = 4000) -> str:
            value = str(observation.get(field, "") or "").strip()
            if not value or value.lower() in {"nan", "none", "null", "n/a", "unknown", "tbd"}:
                raise ValueError(f"{field} is required for monitored performance evidence")
            if len(value) > maximum:
                raise ValueError(f"{field} exceeds {maximum} characters")
            return value

        observed = float(observation.get("observed_hotspot_footprint_tco2"))
        if not np.isfinite(observed) or observed < 0.0:
            raise ValueError("observed_hotspot_footprint_tco2 must be a finite non-negative number")
        baseline = float(selected.get("target_baseline_hotspot_footprint_tco2", 0.0))
        if not np.isfinite(baseline) or baseline <= 0.0:
            raise ValueError("The governed option does not contain a valid hotspot baseline")
        observed_change = baseline - observed
        monitoring_start = required_text("monitoring_period_start", 64)
        monitoring_end = required_text("monitoring_period_end", 64)
        try:
            start_time = datetime.fromisoformat(monitoring_start.replace("Z", "+00:00"))
            end_time = datetime.fromisoformat(monitoring_end.replace("Z", "+00:00"))
        except ValueError as exc:
            raise ValueError("Monitoring period values must be ISO-8601 dates or timestamps") from exc
        if start_time.tzinfo is None:
            start_time = start_time.replace(tzinfo=timezone.utc)
        if end_time.tzinfo is None:
            end_time = end_time.replace(tzinfo=timezone.utc)
        if start_time > end_time:
            raise ValueError("monitoring_period_start must not be later than monitoring_period_end")

        payload = {
            "extension_id": "v5.0.17-U21",
            "network_result_hash": network_result_hash,
            "aurora_result_hash": aurora_result_cid,
            "intervention_governance_evidence_cid": str(
                metadata.get("intervention_governance_evidence_cid", "")
            ),
            "option_cid": option_cid,
            "intervention_id": intervention_id,
            "hotspot_targets": str(selected.get("hotspot_targets", "")),
            "baseline_hotspot_footprint_tco2": baseline,
            "observed_hotspot_footprint_tco2": observed,
            "observed_reduction_tco2": observed_change,
            "observed_reduction_fraction": observed_change / baseline,
            "predecision_scenario_status": str(selected.get("abatement_scenario_status", "Not quantified")),
            "predecision_expected_reduction_tco2": selected.get("scenario_expected_reduction_tco2"),
            "monitoring_period_start": monitoring_start,
            "monitoring_period_end": monitoring_end,
            "assessor_name": required_text("assessor_name", 256),
            "assessor_role": required_text("assessor_role", 256),
            "evidence_reference": required_text("evidence_reference", 1024),
            "monitoring_notes": str(observation.get("monitoring_notes", "") or "").strip()[:4000],
            "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
            "input_hashes": hashes,
            "claim_boundary": (
                "Observed reduction is a stakeholder-submitted monitoring result anchored to evidence. "
                "The platform verifies lineage and arithmetic, not the external truth of the measurement document."
            ),
        }
        performance_evidence_cid = store_content(
            payload, namespace="intervention_performance_evidence"
        )
        response_payload = {**payload, "performance_evidence_cid": performance_evidence_cid}
        return self._response(
            "intervention_performance_evidence",
            response_payload,
            {
                "intervention_id": intervention_id,
                "option_cid": option_cid,
                "performance_evidence_cid": performance_evidence_cid,
            },
            request_context=request_context,
        )

    def compute_sourcing_opportunities(
        self,
        year: int,
        network_result_hash: str,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        """Run AURORA using the exact fulfilled network/DLI evidence snapshot."""

        year = int(year)
        if year != 2017:
            raise ValueError("The governed AURORA assessment requires the 2017 decision year")
        hashes = active_input_hashes()
        _verified_active_network_2017_payload(str(network_result_hash), hashes)
        network_envelope = load_content(str(network_result_hash))
        if str(network_envelope.get("namespace", "")) != "network_and_critic_dli_analysis":
            raise ValueError("AURORA requires a content-addressed Network/CRITIC-DLI result")
        network_material = network_envelope.get("payload", {})
        if not isinstance(network_material, dict):
            raise ValueError("The supplied Network/DLI result envelope is malformed")
        if str(network_material.get("operation", "")) != "network_and_critic_dli_analysis":
            raise ValueError("The supplied evidence is not a Network/CRITIC-DLI response")
        network_payload = (
            network_material.get("payload", {})
            if isinstance(network_material, dict)
            else {}
        )
        if not isinstance(network_payload, dict):
            raise ValueError("The supplied Network/DLI payload is malformed")
        if int(network_payload.get("year", -1)) != year:
            raise ValueError("The Network/DLI result year does not match the AURORA request")
        if not bool(network_payload.get("pooled_critic_ready", False)):
            raise ValueError("AURORA requires the authoritative pooled 2014-2017 CRITIC-DLI result")
        if network_payload.get("input_hashes") != hashes:
            raise ValueError("The Network/DLI result is stale for the active validated inputs")
        weighting = network_payload.get("dli_weighting", {})
        if (
            not isinstance(weighting, dict)
            or str(weighting.get("method", "")) != "pooled Pearson-CRITIC"
            or str(weighting.get("scope", "")) != "2014-2017 pooled evaluation matrix"
            or bool(weighting.get("legacy_fixed_weights_used", True))
        ):
            raise ValueError("The Network/DLI result is not the authoritative pooled Pearson-CRITIC result")
        try:
            active_index = json.loads(RESULT_INDEX_PATH.read_text(encoding="utf-8"))
            active_network = active_index["results"]["network:2017"]
        except Exception as exc:
            raise RuntimeError("The active 2017 Network/DLI result index is unavailable") from exc
        if (
            str(active_network.get("content_hash", "")).lower()
            != str(network_result_hash).lower()
            or active_network.get("input_hashes") != hashes
        ):
            raise ValueError("AURORA must use the active 2017 Network/DLI result")
        dli_records = network_payload.get("dli_ranking", [])
        if not dli_records:
            raise ValueError(
                "The supplied network result did not contain a DLI ranking; "
                "a fulfilled network-analysis result is required."
            )

        my = ae.load_year(str(MRIO_PATH), year)
        dli_nodes = [str(row.get("node_code", "")) for row in dli_records if isinstance(row, dict)]
        expected_nodes = [str(value) for value in my.node_codes]
        if len(dli_nodes) != len(expected_nodes) or set(dli_nodes) != set(expected_nodes):
            raise ValueError("The authoritative DLI ranking does not cover the complete MRIO node universe")
        company_y = ae.load_company_Y(str(COMPANY_PATH), year)
        dli_df = pd.DataFrame(dli_records)

        # U9 derives the two structural-similarity thresholds from the complete
        # 2014 same-sector candidate universe using exact bin-free Otsu.  The
        # calibrated thresholds are then applied unchanged to the primary year
        # and the comparison year, before carbon, linkage, Pareto, and shortlist
        # decisions are evaluated.
        calibration_year = aurora.DEFAULT_THRESHOLD_CALIBRATION_YEAR
        calibration_my = ae.load_year(str(MRIO_PATH), calibration_year)
        calibration_y = ae.load_company_Y(str(COMPANY_PATH), calibration_year)
        calibrated_config, threshold_evidence = aurora.calibrate_exact_otsu_config(
            calibration_my,
            calibration_y,
        )
        result = aurora.analyse(my, company_y, dli_df, config=calibrated_config)
        result = aurora.attach_threshold_calibration(result, threshold_evidence)

        comparison_year = 2014
        comparison = None
        comparison_my = calibration_my
        comparison_y = calibration_y
        critic_path = ACTIVE_ANALYTICS_DIR / "critic_authoritative_dli_ranking.csv"
        critic_metadata_path = ACTIVE_ANALYTICS_DIR / "critic_authoritative_dli.json"
        if not critic_path.is_file() or not critic_metadata_path.is_file():
            raise FileNotFoundError("Authoritative pooled CRITIC-DLI evidence is unavailable")
        critic_metadata = json.loads(critic_metadata_path.read_text(encoding="utf-8"))
        if critic_metadata.get("input_hashes") != hashes:
            raise RuntimeError("Authoritative pooled CRITIC-DLI evidence is stale for the active inputs")
        if str(critic_metadata.get("correlation_method", "")).lower() != "pearson":
            raise RuntimeError("AURORA requires the authoritative Pearson-CRITIC evidence")
        if str(critic_metadata.get("scope", "")) != "pooled-2014-2017":
            raise RuntimeError("AURORA requires the pooled 2014-2017 CRITIC evaluation matrix")
        if bool(critic_metadata.get("legacy_fixed_weights_used", True)):
            raise RuntimeError("Legacy fixed DLI weights cannot supply governed AURORA evidence")
        if str(critic_metadata.get("critic_evidence_cid", "")) != str(
            weighting.get("critic_evidence_cid", "")
        ):
            raise RuntimeError("The pooled CRITIC evidence CID does not match the Network/DLI result")
        if sha256_file(critic_path) != str(critic_metadata.get("ranking_sha256", "")):
            raise RuntimeError("Authoritative pooled CRITIC-DLI ranking failed its SHA-256 check")
        critic_all = pd.read_csv(critic_path)
        comparison_dli = critic_all.loc[
            pd.to_numeric(critic_all["year"], errors="coerce") == comparison_year
        ].sort_values("dli_rank")
        comparison_nodes = comparison_dli.get(
            "node_code", pd.Series(dtype=str)
        ).astype(str).tolist()
        if (
            len(comparison_dli) != len(expected_nodes)
            or set(comparison_nodes) != set(expected_nodes)
        ):
            raise RuntimeError("The 2014 comparison DLI ranking is incomplete")
        comparison = aurora.analyse(
            comparison_my,
            comparison_y,
            comparison_dli,
            config=calibrated_config,
        )
        comparison = aurora.attach_threshold_calibration(
            comparison,
            threshold_evidence,
        )
        result = aurora.add_cross_year_stability(result, comparison)

        # Reporting enrichment exposes the Otsu-calibrated similarity gates and
        # the subsequent carbon, linkage, Pareto, DLI, display-cap and stability
        # decisions as explicit fields and decision-funnel summaries. It does
        # not change the decisions already produced by the calibrated engine.
        result = aurora_report.enrich_aurora_result(result, comparison)

        synthesis_path = ACTIVE_ANALYTICS_DIR / "spa_sda_critic_dli_node_synthesis.csv"
        if synthesis_path.is_file():
            synthesis = pd.read_csv(synthesis_path)
            lookup = synthesis.drop_duplicates("node_code").set_index("node_code").to_dict(orient="index")
            for collection in ("all_candidates", "eligible_candidates", "pareto_efficient_candidates", "recommended_opportunities"):
                for row in result.get(collection, []):
                    if not isinstance(row, dict):
                        continue
                    candidate = lookup.get(str(row.get("node_code", "")), {})
                    current = lookup.get(str(row.get("current_nodes", row.get("current_node", ""))).split("|")[0].strip(), {})
                    if candidate:
                        row["candidate_spa_relevance_level"] = candidate.get("spa_relevance_level")
                        row["candidate_temporal_status"] = candidate.get("node_temporal_status")
                        row["candidate_strategic_classification"] = candidate.get("strategic_classification")
                    if current:
                        row["current_node_spa_relevance_level"] = current.get("spa_relevance_level")
                        row["current_node_temporal_status"] = current.get("node_temporal_status")
                        row["current_node_strategic_classification"] = current.get("strategic_classification")
            result["pathway_driver_governance_context"] = {
                "available": True,
                "note": "SPA-SDA and CRITIC-DLI evidence is attached as governance context and is excluded from the weight-free Pareto vector.",
            }

        payload = {
            **result,
            "network_result_hash": str(network_result_hash),
            "input_hashes": {
                "mrio": sha256_file(MRIO_PATH),
                "focal_demand": sha256_file(COMPANY_PATH),
            },
        }
        auxiliary = {
            "recommended_count": len(result.get("recommended_opportunities", [])),
            "eligible_count": len(result.get("eligible_candidates", [])),
            "pareto_efficient_count": len(result.get("pareto_efficient_candidates", [])),
            "decision_funnel_summary": result.get("decision_funnel_summary", {}),
            "threshold_calibration": result.get("threshold_calibration", {}),
            "top_opportunities": result.get("recommended_opportunities", [])[:10],
            "claim_boundary": result.get("claim_boundary"),
            "non_additivity_note": result.get("non_additivity_note"),
        }
        response = self._response(
            "regional_sourcing_opportunity_analysis",
            payload,
            auxiliary,
            request_context=request_context,
        )

        # Write audit-friendly convenience exports after the authoritative
        # content-addressed response CID exists. Export failure does not alter
        # or invalidate the governed analytical result; the Streamlit page can
        # always rebuild the same workbook from the verified JSON payload.
        try:
            if active_input_hashes() != payload["input_hashes"]:
                raise RuntimeError(
                    "Active analytical inputs changed before AURORA export generation."
                )
            export_manifest = aurora_report.write_runtime_exports(
                payload,
                ACTIVE_ANALYTICS_DIR,
                year=year,
                source_result_cid=response.content_hash,
            )
            if active_input_hashes() != payload["input_hashes"]:
                raise RuntimeError(
                    "Active analytical inputs changed during AURORA export generation."
                )
        except Exception as exc:
            export_manifest = {
                "available": False,
                "error": str(exc),
                "authority_boundary": (
                    "A convenience-export failure does not change the content-addressed AURORA result."
                ),
            }

        # AURORA is an independently valid analytical result.  Stage 12 is
        # intentionally not materialized here: the focal-company user starts
        # intervention evidence computation explicitly from the Blockchain
        # control plane, mirroring the visible SPA/SDA execution pattern.
        record_active_result("aurora",
            str(year),
            response,
            input_hashes=payload["input_hashes"],
            metadata={
                "year": year,
                "network_result_hash": str(network_result_hash),
                "intervention_governance_evidence_cid": "",
                "intervention_materialization": {
                    "available": False,
                    "status": "pending-user-initiated-stage-12-computation",
                },
                "reporting_schema_version": payload.get("reporting_schema_version"),
                "exports": export_manifest,
            },
        )
        return response

    def process_query(
        self,
        requester: str,
        query_text: str,
        data_reference_cid: str = "",
        mode: str = "auto",
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        evidence_gate = self._require_current_query_methodology_gate()
        conversation_key = f"{requester.lower()}::{data_reference_cid or 'default'}"
        with self._query_lock:
            history = self._conversation_history.get(conversation_key, [])
            state = self._conversation_state.get(conversation_key, {})
            result = process_question(
                self.client,
                query_text,
                mode=mode,
                history=history,
                state=state,
            )
            self._conversation_history[conversation_key] = [
                *history,
                {"role": "user", "content": query_text},
                {"role": "assistant", "content": result.answer},
            ][-20:]
            self._conversation_state[conversation_key] = dict(result.state)

        # A local model response can take time.  Recheck the immutable evidence
        # chain before committing its governed CID so a mid-query input change
        # cannot publish an answer under the old analytical state.
        final_gate = self._require_current_query_methodology_gate()
        if final_gate != evidence_gate:
            raise RuntimeError(
                "Query execution is paused because governed evidence changed while the answer was generated"
            )

        result_dict = asdict(result)
        payload = {
            "requester": requester,
            "data_reference_cid": data_reference_cid,
            "requested_mode": mode,
            "conversation_key": conversation_key,
            "u19_methodology_gate": evidence_gate,
            "assistant_result": result_dict,
        }
        auxiliary = {
            "requested_mode": mode,
            "assistant_route": result.route,
            "blockchain_route": result.blockchain_route,
            "route_enum": ROUTE_ENUM[result.blockchain_route],
            "network_2017_cid": evidence_gate["network_2017_cid"],
            "aurora_2017_cid": evidence_gate["aurora_2017_cid"],
            "intervention_governance_dependency": "none",
        }
        response = self._response(
            "strategic_query",
            payload,
            auxiliary,
            request_context=request_context,
        )
        record_active_result(
            "query",
            conversation_key,
            response,
            input_hashes=evidence_gate["input_hashes"],
            metadata={
                "route": result.route,
                "network_2017_cid": evidence_gate["network_2017_cid"],
                "aurora_2017_cid": evidence_gate["aurora_2017_cid"],
            },
        )
        return response

    def record_error(
        self,
        operation: str,
        error: str,
        context: dict[str, Any] | None = None,
        request_context: dict[str, Any] | None = None,
    ) -> OrchestratorResponse:
        payload = {
            "operation": operation,
            "error": str(error),
            "context": context or {},
        }
        return self._response(
            "orchestrator_error",
            payload,
            request_context=request_context,
        )
