"""Small standard-library HTTP client used by the oracle adapters."""
from __future__ import annotations

import hashlib
import json
import os
import urllib.error
import urllib.request
from typing import Any


class OrchestratorClient:
    def __init__(self, base_url: str | None = None, timeout: float | None = None):
        self.base_url = (base_url or os.getenv("ORCHESTRATOR_URL", "http://127.0.0.1:8765")).rstrip("/")
        self.timeout = float(timeout or os.getenv("ORCHESTRATOR_TIMEOUT", "900"))

    def _request(self, method: str, path: str, payload: dict[str, Any] | None = None) -> dict[str, Any]:
        body = None
        headers = {"Accept": "application/json"}
        if payload is not None:
            body = json.dumps(payload, ensure_ascii=False, allow_nan=False, default=str).encode("utf-8")
            headers["Content-Type"] = "application/json"
        request = urllib.request.Request(
            f"{self.base_url}{path}",
            data=body,
            headers=headers,
            method=method,
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                data = json.loads(response.read().decode("utf-8"))
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            raise RuntimeError(f"Data Orchestrator returned HTTP {exc.code}: {detail}") from exc
        except (urllib.error.URLError, TimeoutError) as exc:
            raise RuntimeError(
                f"Cannot reach the Data Orchestrator at {self.base_url}: {exc}"
            ) from exc
        if not data.get("ok"):
            raise RuntimeError(str(data.get("error", "Data Orchestrator request failed")))
        return data

    def health(self) -> dict[str, Any]:
        return self._request("GET", "/health")

    @staticmethod
    def _normalize_cid(value: str, label: str = "content_hash") -> str:
        normalized = str(value or "").strip().lower()
        if len(normalized) != 64 or any(ch not in "0123456789abcdef" for ch in normalized):
            raise ValueError(f"{label} must be a 64-character SHA-256 hexadecimal value")
        return normalized

    def get_content(self, content_hash: str) -> dict[str, Any]:
        normalized = self._normalize_cid(content_hash)
        result = self.post("/v1/content/get", {"content_hash": normalized})
        returned_hash = str(result.get("content_hash", "")).strip().lower()
        if returned_hash != normalized:
            raise RuntimeError("Data Orchestrator returned a different content hash")
        content = result.get("content")
        if not isinstance(content, dict):
            raise RuntimeError("Data Orchestrator did not return a JSON content package")
        body = json.dumps(
            content,
            indent=2,
            sort_keys=True,
            ensure_ascii=False,
            allow_nan=False,
            default=str,
        ).encode("utf-8")
        if hashlib.sha256(body).hexdigest() != normalized:
            raise RuntimeError("Retrieved content does not match its SHA-256 identifier")
        return result

    def materialize_intervention_governance(
        self,
        network_result_hash: str,
        aurora_result_hash: str,
        request_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        """Retry the downstream U16 register for one fulfilled AURORA chain."""

        network_cid = self._normalize_cid(network_result_hash, "network_result_hash")
        aurora_cid = self._normalize_cid(aurora_result_hash, "aurora_result_hash")
        return self.post(
            "/v1/governance/intervention-materialize",
            {
                "network_result_hash": network_cid,
                "aurora_result_hash": aurora_cid,
                "request_context": dict(request_context or {}),
            },
        )

    def record_intervention_actionability(
        self,
        network_result_hash: str,
        candidate_id: str,
        assessment: dict[str, Any],
        request_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        network_cid = self._normalize_cid(network_result_hash, "network_result_hash")
        candidate_cid = self._normalize_cid(candidate_id, "candidate_id")
        if not isinstance(assessment, dict):
            raise TypeError("assessment must be a JSON object")
        return self.post(
            "/v1/governance/intervention-actionability",
            {
                "network_result_hash": network_cid,
                "candidate_id": candidate_cid,
                "assessment": assessment,
                "request_context": dict(request_context or {}),
            },
        )

    def record_intervention_performance(
        self,
        network_result_hash: str,
        option_cid: str,
        intervention_id: int,
        observation: dict[str, Any],
        request_context: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        network_cid = self._normalize_cid(network_result_hash, "network_result_hash")
        option_hash = self._normalize_cid(option_cid, "option_cid")
        if int(intervention_id) < 0:
            raise ValueError("intervention_id must be non-negative")
        if not isinstance(observation, dict):
            raise TypeError("observation must be a JSON object")
        return self.post(
            "/v1/governance/intervention-performance",
            {
                "network_result_hash": network_cid,
                "option_cid": option_hash,
                "intervention_id": int(intervention_id),
                "observation": observation,
                "request_context": dict(request_context or {}),
            },
        )

    def post(self, path: str, payload: dict[str, Any]) -> dict[str, Any]:
        data = self._request("POST", path, payload)
        result = data.get("result")
        if not isinstance(result, dict):
            raise RuntimeError("Data Orchestrator response did not contain a result object")
        return result
