"""State-controlled helpers for the Streamlit-guided blockchain lifecycle.

The module is the bridge between the progressively evolving ``deployment.json``
and the platform interface.  It does not perform analytical calculations or Oracle
fulfilments.  It deploys contracts from the stakeholder account responsible for
each domain, submits stakeholder registration requests, and reconstructs the
current lifecycle state from live on-chain records and content-addressed result
packages.
"""
from __future__ import annotations

import hashlib
import json
import math
from pathlib import Path
from typing import Any

from web3 import Web3

import aurora_lifecycle_policy as lifecycle_policy
from deploy_contracts import ROLE_CODES, ensure_artifacts, load_artifact, store_bootstrap_evidence
import input_onboarding as onboarding
import intervention_governance as intervention_gov
from transaction_inspector import safe_record_transaction

BASE_DIR = Path(__file__).resolve().parent
CONTENT_STORE = BASE_DIR / "content_store"
ACTIVE_ANALYTICS_DIR = BASE_DIR / "runtime" / "active_analytics"

CONTRACT_ARTIFACTS = {
    "Registration": "StrategicCarbonIntelligenceSystem_sol_Registration",
    "UpstreamCarbonEmissionsAnalysis": "StrategicCarbonIntelligenceSystem_sol_UpstreamCarbonEmissionsAnalysis",
    "HotspotsManagementAndGovernance": "StrategicCarbonIntelligenceSystem_sol_HotspotsManagementAndGovernance",
    "QueryManagement": "StrategicCarbonIntelligenceSystem_sol_QueryManagement",
}


def load_state(path: str | Path) -> dict[str, Any]:
    return json.loads(Path(path).read_text(encoding="utf-8"))


def save_state(path: str | Path, state: dict[str, Any]) -> None:
    target = Path(path)
    temporary = target.with_name(f".{target.name}.tmp")
    temporary.write_text(json.dumps(state, indent=2, default=str), encoding="utf-8")
    temporary.replace(target)


def connect(state: dict[str, Any]) -> Web3:
    w3 = Web3(
        Web3.HTTPProvider(
            state.get("rpc_url", "http://127.0.0.1:8545"),
            request_kwargs={"timeout": 20},
        )
    )
    if not w3.is_connected():
        raise RuntimeError("Ganache is not reachable.")
    if int(state.get("chain_id", -1)) != int(w3.eth.chain_id):
        raise RuntimeError(
            f"Guided deployment belongs to chain {state.get('chain_id')}, but Ganache is chain {w3.eth.chain_id}. Reset the guided deployment state."
        )
    return w3


def _receipt_summary(receipt: Any, sender: str) -> dict[str, Any]:
    return {
        "transaction_hash": receipt.transactionHash.hex(),
        "block_number": int(receipt.blockNumber),
        "gas_used": int(receipt.gasUsed),
        "status": int(receipt.status),
        "from": sender,
        "contract_address": receipt.contractAddress,
    }




def _audit_receipt(
    w3: Web3,
    path: str | Path,
    receipt: Any,
    *,
    actor_label: str,
    action: str,
    source: str = "streamlit-platform",
    contract_name_hint: str = "",
    function_signature_hint: str = "",
    decoded_inputs_hint: dict[str, Any] | None = None,
    request_id: int | None = None,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    return safe_record_transaction(
        w3,
        path,
        receipt.transactionHash,
        receipt=receipt,
        actor_label=actor_label,
        action=action,
        source=source,
        contract_name_hint=contract_name_hint,
        function_signature_hint=function_signature_hint,
        decoded_inputs_hint=decoded_inputs_hint,
        request_id=request_id,
        metadata=metadata or {},
    )

def _deploy(w3: Web3, artifact_name: str, sender: str, *args: Any):
    abi, bytecode = load_artifact(artifact_name)
    contract_type = w3.eth.contract(abi=abi, bytecode=bytecode)
    tx_hash = contract_type.constructor(*args).transact({"from": sender})
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
    if int(receipt.status) != 1 or not receipt.contractAddress:
        raise RuntimeError(f"Contract deployment failed: {artifact_name}")
    return abi, receipt


def _load_content(content_hash: str) -> dict[str, Any]:
    value = str(content_hash or "").strip().lower()
    if len(value) != 64:
        return {}
    for candidate in (CONTENT_STORE / f"{value}.json", CONTENT_STORE / value):
        if candidate.is_file():
            body = candidate.read_bytes()
            if hashlib.sha256(body).hexdigest() != value:
                return {}
            try:
                return json.loads(body.decode("utf-8"))
            except Exception:
                return {}
    return {}


def _content_payload(content_hash: str) -> dict[str, Any]:
    envelope = _load_content(content_hash)
    material = envelope.get("payload", {}) if isinstance(envelope, dict) else {}
    payload = material.get("payload", {}) if isinstance(material, dict) else {}
    return payload if isinstance(payload, dict) else {}


def _validated_operation_payload(
    content_hash: str,
    expected_hashes: dict[str, str],
    *,
    namespace: str,
    operation: str,
) -> dict[str, Any] | None:
    """Return a CID-verified operation payload or fail closed with ``None``."""

    envelope = _load_content(content_hash)
    if str(envelope.get("namespace", "")) != namespace:
        return None
    material = envelope.get("payload", {})
    if not isinstance(material, dict) or str(material.get("operation", "")) != operation:
        return None
    payload = material.get("payload", {})
    if not isinstance(payload, dict):
        return None
    hashes = payload.get("input_hashes", {})
    if not isinstance(hashes, dict) or any(
        not expected_hashes.get(key)
        or str(hashes.get(key, "")).lower()
        != str(expected_hashes.get(key, "")).lower()
        for key in ("mrio", "focal_demand")
    ):
        return None
    return payload


def _mrio_content_company_footprint(
    content_hash: str,
    expected_hashes: dict[str, str],
    expected_year: int,
) -> float | None:
    """Validate the MRIO result type/year and return its reconciled company total."""

    try:
        payload = _validated_operation_payload(
            content_hash,
            expected_hashes,
            namespace="mrio_carbon_accounting",
            operation="mrio_carbon_accounting",
        )
        if payload is None or int(payload.get("year", -1)) != int(expected_year):
            return None
        total = float(payload.get("company_footprint", float("nan")))
        rows = payload.get("all_hotspots", [])
        if not math.isfinite(total) or total <= 0.0 or not isinstance(rows, list) or not rows:
            return None
        contributions: list[float] = []
        node_codes: list[str] = []
        for row in rows:
            if not isinstance(row, dict):
                return None
            contribution = float(row.get("footprint_contribution", float("nan")))
            node_code = str(row.get("node_code", "")).strip()
            if not math.isfinite(contribution) or contribution < 0.0 or not node_code:
                return None
            contributions.append(contribution)
            node_codes.append(node_code)
        tolerance = max(1e-8, abs(total) * 1e-10)
        if len(set(node_codes)) != len(node_codes):
            return None
        if not math.isclose(
            math.fsum(contributions), total, rel_tol=1e-10, abs_tol=tolerance
        ):
            return None
        return total
    except (TypeError, ValueError, OverflowError):
        return None


def _sda_content_is_valid(
    content_hash: str,
    expected_hashes: dict[str, str],
    base_year: int,
    comparison_year: int,
) -> bool:
    try:
        payload = _validated_operation_payload(
            content_hash,
            expected_hashes,
            namespace="structural_decomposition_analysis",
            operation="structural_decomposition_analysis",
        )
        return bool(
            payload is not None
            and int(payload.get("base_year", -1)) == int(base_year)
            and int(payload.get("comparison_year", -1)) == int(comparison_year)
            and isinstance(payload.get("company_primary"), dict)
            and isinstance(payload.get("node_wise_sda"), dict)
        )
    except (TypeError, ValueError, OverflowError):
        return False


def _network_content_is_valid(
    content_hash: str,
    expected_hashes: dict[str, str],
    expected_year: int,
) -> bool:
    try:
        payload = _validated_operation_payload(
            content_hash,
            expected_hashes,
            namespace="network_and_critic_dli_analysis",
            operation="network_and_critic_dli_analysis",
        )
        if payload is None or int(payload.get("year", -1)) != int(expected_year):
            return False
        ranking = payload.get("dli_ranking", [])
        if not isinstance(ranking, list) or not ranking:
            return False
        nodes = [str(row.get("node_code", "")).strip() for row in ranking if isinstance(row, dict)]
        if len(nodes) != len(ranking) or not all(nodes) or len(set(nodes)) != len(nodes):
            return False
        if int(expected_year) == 2017:
            if payload.get("pooled_critic_ready") is not True:
                return False
            authority = payload.get("temporal_dli_authority", {})
            slices = payload.get("authoritative_dli_slices", {})
            temporal = payload.get("temporal_dli_comparison", [])
            weighting = payload.get("dli_weighting", {})
            weights = weighting.get("weights", {}) if isinstance(weighting, dict) else {}
            baseline_cid = str(
                authority.get("baseline_evidence_network_result_cid", "")
                if isinstance(authority, dict)
                else ""
            ).strip().lower()
            if (
                not isinstance(authority, dict)
                or authority.get("method")
                != "one pooled two-year Pearson-CRITIC calculation"
                or authority.get("years") != [2014, 2017]
                or len(baseline_cid) != 64
                or any(
                    character not in "0123456789abcdef"
                    for character in baseline_cid
                )
                or not isinstance(slices, dict)
                or not isinstance(temporal, list)
                or weighting.get("method") != "pooled Pearson-CRITIC"
                or set(weights) != {"BC", "PR", "CDR", "IC"}
                or not all(
                    math.isfinite(float(weights[criterion]))
                    and float(weights[criterion]) >= 0.0
                    for criterion in ("BC", "PR", "CDR", "IC")
                )
                or not math.isclose(
                    math.fsum(float(weights[criterion]) for criterion in ("BC", "PR", "CDR", "IC")),
                    1.0,
                    rel_tol=1e-10,
                    abs_tol=1e-12,
                )
            ):
                return False
            annual_nodes: dict[int, list[str]] = {}
            for reference_year in (2014, 2017):
                rows = slices.get(str(reference_year), [])
                if not isinstance(rows, list) or not rows:
                    return False
                row_nodes: list[str] = []
                ranks: list[int] = []
                for row in rows:
                    if not isinstance(row, dict):
                        return False
                    node = str(row.get("node_code", "")).strip()
                    score = float(row.get("DLI", float("nan")))
                    rank = int(row.get("dli_rank", -1))
                    if (
                        int(row.get("year", -1)) != reference_year
                        or not node
                        or not math.isfinite(score)
                        or rank <= 0
                    ):
                        return False
                    row_nodes.append(node)
                    ranks.append(rank)
                if len(set(row_nodes)) != len(row_nodes) or ranks != sorted(ranks):
                    return False
                annual_nodes[reference_year] = sorted(row_nodes)
            if annual_nodes[2014] != annual_nodes[2017]:
                return False
            if len(temporal) != len(annual_nodes[2017]):
                return False
            decision_rows = slices["2017"]
            if ranking != decision_rows:
                return False
        return True
    except (TypeError, ValueError, OverflowError):
        return False


def _aurora_content_is_valid(
    content_hash: str,
    expected_hashes: dict[str, str],
    expected_network_cid: str,
    expected_year: int = 2017,
) -> bool:
    try:
        payload = _validated_operation_payload(
            content_hash,
            expected_hashes,
            namespace="regional_sourcing_opportunity_analysis",
            operation="regional_sourcing_opportunity_analysis",
        )
        return bool(
            payload is not None
            and int(payload.get("year", -1)) == int(expected_year)
            and str(payload.get("network_result_hash", "")).strip().lower()
            == str(expected_network_cid).strip().lower()
        )
    except (TypeError, ValueError, OverflowError):
        return False


def _content_hashes_match(content_hash: str, expected: dict[str, str]) -> bool:
    payload = _content_payload(content_hash)
    hashes = payload.get("input_hashes", {}) if isinstance(payload, dict) else {}
    if not expected.get("mrio") or not expected.get("focal_demand"):
        return False
    return (
        str(hashes.get("mrio", "")).lower() == expected["mrio"].lower()
        and str(hashes.get("focal_demand", "")).lower()
        == expected["focal_demand"].lower()
    )


def _spa_content_is_coverage_complete(
    content_hash: str,
    expected_hashes: dict[str, str],
    expected_year: int,
    expected_total_footprint: float | None = None,
) -> bool:
    """Validate that a fulfilled SPA CID contains the agreed minimum 87% prefix.

    This is deliberately independent of the on-chain ``Fulfilled`` status. A
    malformed, stale or below-target CID is ignored during lifecycle
    reconstruction, which keeps SPA completion and every downstream stage
    locked.
    """

    try:
        envelope = _load_content(content_hash)
        if str(envelope.get("namespace", "")) != "structural_path_analysis":
            return False
        material = envelope.get("payload", {})
        if not isinstance(material, dict):
            return False
        if str(material.get("operation", "")) != "structural_path_analysis":
            return False
        payload = material.get("payload", {})
        if not isinstance(payload, dict):
            return False
        if int(payload.get("year", -1)) != int(expected_year):
            return False
        hashes = payload.get("input_hashes", {})
        if not isinstance(hashes, dict) or any(
            not expected_hashes.get(key)
            or str(hashes.get(key, "")).lower()
            != str(expected_hashes[key]).lower()
            for key in ("mrio", "focal_demand")
        ):
            return False

        target = float(payload.get("cumulative_target", float("nan")))
        total = float(payload.get("total_footprint", float("nan")))
        if (
            not math.isfinite(target)
            or not math.isclose(target, 0.87, rel_tol=0.0, abs_tol=1e-12)
            or not math.isfinite(total)
            or total <= 0.0
            or payload.get("threshold_reached") is not True
        ):
            return False
        if expected_total_footprint is not None:
            governed_total = float(expected_total_footprint)
            if not math.isfinite(governed_total) or governed_total <= 0.0:
                return False
            total_tolerance = max(1e-8, abs(governed_total) * 1e-10)
            if not math.isclose(
                total,
                governed_total,
                rel_tol=1e-10,
                abs_tol=total_tolerance,
            ):
                return False

        paths = payload.get("paths", [])
        if not isinstance(paths, list) or not paths:
            return False
        if int(payload.get("reported_path_count", -1)) != len(paths):
            return False
        contributions: list[float] = []
        path_codes: list[str] = []
        cumulative = 0.0
        required_row_fields = {
            "path_rank",
            "depth",
            "path_nodes",
            "individual_share_of_company_footprint",
            "cumulative_contribution",
            "cumulative_share",
        }
        for position, row in enumerate(paths, start=1):
            if not isinstance(row, dict):
                return False
            if not required_row_fields.issubset(row):
                return False
            contribution = float(row.get("contribution", float("nan")))
            path_code = str(row.get("path_codes", "")).strip()
            if not math.isfinite(contribution) or contribution < 0.0 or not path_code:
                return False
            if int(row.get("path_rank", -1)) != position:
                return False
            depth = int(row.get("depth", -1))
            path_nodes = row.get("path_nodes")
            if depth < 0 or not isinstance(path_nodes, (list, tuple)) or len(path_nodes) != depth + 1:
                return False
            cumulative += contribution
            individual_share = float(
                row.get("individual_share_of_company_footprint", float("nan"))
            )
            declared_cumulative = float(row.get("cumulative_contribution", float("nan")))
            declared_share = float(row.get("cumulative_share", float("nan")))
            if (
                not math.isfinite(individual_share)
                or not math.isclose(
                    individual_share,
                    contribution / total,
                    rel_tol=1e-10,
                    abs_tol=1e-12,
                )
                or not math.isfinite(declared_cumulative)
                or not math.isclose(
                    declared_cumulative,
                    cumulative,
                    rel_tol=1e-10,
                    abs_tol=max(1e-8, abs(total) * 1e-10),
                )
                or not math.isfinite(declared_share)
                or not math.isclose(
                    declared_share,
                    cumulative / total,
                    rel_tol=1e-10,
                    abs_tol=1e-12,
                )
            ):
                return False
            contributions.append(contribution)
            path_codes.append(path_code)
        if len(set(path_codes)) != len(path_codes):
            return False

        tolerance = max(1e-8, abs(total) * 1e-10)
        for previous, current in zip(contributions, contributions[1:]):
            if current > previous + tolerance:
                return False
        reported = math.fsum(contributions)
        required = target * total
        if reported + tolerance < required or reported > total + tolerance:
            return False
        if len(contributions) > 1 and math.fsum(contributions[:-1]) >= required - tolerance:
            return False

        declared_values = {
            "reported_path_footprint": (reported, tolerance),
            "target_footprint": (required, tolerance),
            "reported_cumulative_share": (reported / total, 1e-10),
            "cumulative_share": (reported / total, 1e-10),
        }
        for field, (computed, absolute_tolerance) in declared_values.items():
            declared = float(payload.get(field, float("nan")))
            if not math.isfinite(declared) or not math.isclose(
                declared,
                computed,
                rel_tol=1e-10,
                abs_tol=absolute_tolerance,
            ):
                return False
        shortfall = float(payload.get("target_shortfall", float("nan")))
        if not math.isfinite(shortfall) or shortfall > tolerance or shortfall < 0.0:
            return False
        overshoot = float(payload.get("target_overshoot", float("nan")))
        if not math.isfinite(overshoot) or not math.isclose(
            overshoot,
            max(0.0, reported - required),
            rel_tol=1e-10,
            abs_tol=tolerance,
        ):
            return False
        screened_count = int(payload.get("screened_path_count", -1))
        screened_share = float(payload.get("screened_cumulative_share", float("nan")))
        if (
            screened_count < len(paths)
            or not math.isfinite(screened_share)
            or screened_share + 1e-12 < reported / total
            or screened_share > 1.0 + 1e-8
        ):
            return False
        screened_artifact = payload.get("screened_paths_artifact", {})
        screened_hash = str(
            screened_artifact.get("sha256", "")
            if isinstance(screened_artifact, dict)
            else ""
        ).strip().lower()
        if (
            not isinstance(screened_artifact, dict)
            or str(screened_artifact.get("filename", ""))
            != f"spa_screened_paths_{int(expected_year)}.csv"
            or int(screened_artifact.get("row_count", -1)) != screened_count
            or len(screened_hash) != 64
            or any(character not in "0123456789abcdef" for character in screened_hash)
        ):
            return False
        reconciliation = payload.get("coverage_reconciliation", {})
        if not isinstance(reconciliation, dict):
            return False
        if not math.isclose(
            float(reconciliation.get("complete_focal_company_footprint", float("nan"))),
            total,
            rel_tol=1e-10,
            abs_tol=tolerance,
        ):
            return False
        components = [
            float(reconciliation.get(field, float("nan")))
            for field in (
                "reported_selected_paths",
                "screened_but_unreported_paths",
                "screening_and_pruning_residual_through_max_path_depth",
                "exact_depth_tail_beyond_max_path_depth",
            )
        ]
        if any(not math.isfinite(value) or value < -tolerance for value in components):
            return False
        screened_footprint = float(
            reconciliation.get("screened_path_footprint", float("nan"))
        )
        exact_through_depth = float(
            reconciliation.get(
                "exact_cumulative_footprint_through_max_path_depth",
                float("nan"),
            )
        )
        reconciliation_residual = float(
            reconciliation.get("reconciliation_residual", float("nan"))
        )
        target_identity_residual = float(
            reconciliation.get("target_identity_residual", float("nan"))
        )
        if (
            not math.isclose(components[0], reported, rel_tol=1e-10, abs_tol=tolerance)
            or not math.isfinite(screened_footprint)
            or not math.isclose(
                screened_footprint,
                screened_share * total,
                rel_tol=1e-10,
                abs_tol=tolerance,
            )
            or not math.isclose(
                components[1],
                screened_footprint - reported,
                rel_tol=1e-10,
                abs_tol=tolerance,
            )
            or not math.isfinite(exact_through_depth)
            or not math.isclose(
                components[2],
                exact_through_depth - screened_footprint,
                rel_tol=1e-10,
                abs_tol=tolerance,
            )
            or not math.isclose(
                components[3],
                total - exact_through_depth,
                rel_tol=1e-10,
                abs_tol=tolerance,
            )
            or not math.isfinite(reconciliation_residual)
            or abs(reconciliation_residual) > tolerance
            or not math.isfinite(target_identity_residual)
            or abs(target_identity_residual) > tolerance
        ):
            return False
        if not math.isclose(
            math.fsum(components), total, rel_tol=1e-10, abs_tol=tolerance
        ):
            return False
        attempts = payload.get("adaptive_expansion_attempts", [])
        if (
            not isinstance(attempts, list)
            or not attempts
            or not isinstance(attempts[-1], dict)
            or attempts[-1].get("threshold_reached") is not True
        ):
            return False
        return True
    except (TypeError, ValueError, OverflowError):
        return False


def deploy_registration(path: str | Path) -> dict[str, Any]:
    ensure_artifacts()
    state = load_state(path)
    if state.get("contracts", {}).get("Registration"):
        return refresh_lifecycle(path)
    w3 = connect(state)
    accounts = state["accounts"]
    abi, receipt = _deploy(
        w3,
        CONTRACT_ARTIFACTS["Registration"],
        accounts["regulator"],
        accounts["registration_oracle"],
    )
    state.setdefault("contracts", {})["Registration"] = {
        "address": receipt.contractAddress,
        "abi": abi,
    }
    state["deployment_block"] = int(receipt.blockNumber)
    # Save the address/ABI before inspection so constructor-emitted events can
    # be decoded against the newly deployed contract.
    save_state(path, state)
    audit = _audit_receipt(
        w3,
        path,
        receipt,
        actor_label="Regulatory Authority",
        action="Deploy Registration contract from StrategicCarbonIntelligenceSystem.sol",
        contract_name_hint="Registration",
        function_signature_hint="constructor(address)",
        decoded_inputs_hint={"registrationOracle": accounts["registration_oracle"]},
        metadata={"responsible_role": "RegulatoryAuthority"},
    )
    state = load_state(path)
    state.setdefault("deployment_receipts", {})["Registration"] = audit
    save_state(path, state)
    return refresh_lifecycle(path)


def assign_oracle_roles(path: str | Path) -> dict[str, Any]:
    state = load_state(path)
    w3 = connect(state)
    reg_spec = state.get("contracts", {}).get("Registration")
    if not reg_spec:
        raise RuntimeError("Deploy Registration contract (from StrategicCarbonIntelligenceSystem.sol) first.")
    reg = w3.eth.contract(address=reg_spec["address"], abi=reg_spec["abi"])
    regulator = state["accounts"]["regulator"]
    receipts = []
    # Registration Oracle is assigned by the constructor; the other three are
    # explicitly appointed by the Regulatory Authority.
    for role_key in ["upstream", "governance", "query"]:
        spec = state["oracle_roles"][role_key]
        role_code = int(spec["role_code"])
        address = spec["address"]
        current = reg.functions.oracleForRole(role_code).call()
        if current.lower() == address.lower() and int(reg.functions.roleOf(address).call()) == role_code:
            continue
        tx_hash = reg.functions.assignOracleRole(address, role_code).transact(
            {"from": regulator}
        )
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
        receipts.append(
            _audit_receipt(
                w3,
                path,
                receipt,
                actor_label="Regulatory Authority",
                action=f"Assign {spec['role_name']}",
                request_id=None,
                metadata={
                    "oracle_role": spec["role_name"],
                    "oracle_address": address,
                    "role_code": role_code,
                },
            )
        )
    state.setdefault("deployment_receipts", {})["OracleRoleAssignments"] = receipts
    save_state(path, state)
    return refresh_lifecycle(path)


def submit_stakeholder_registration(path: str | Path, stakeholder_key: str) -> dict[str, Any]:
    state = load_state(path)
    w3 = connect(state)
    reg_spec = state.get("contracts", {}).get("Registration")
    if not reg_spec:
        raise RuntimeError("Deploy Registration contract (from StrategicCarbonIntelligenceSystem.sol) first.")
    reg = w3.eth.contract(address=reg_spec["address"], abi=reg_spec["abi"])
    specs = {
        "mrio_provider": ("MRIODataProvider", ROLE_CODES["MRIODataProvider"]),
        "focal_company": ("FocalCompany", ROLE_CODES["FocalCompany"]),
    }
    if stakeholder_key == "regulator":
        if int(reg.functions.roleOf(state["accounts"]["regulator"]).call()) != ROLE_CODES["RegulatoryAuthority"]:
            raise RuntimeError("The Registration constructor did not establish the Regulatory Authority role.")
        return state
    if stakeholder_key not in specs:
        raise ValueError(stakeholder_key)
    role_name, role_code = specs[stakeholder_key]
    address = state["accounts"][stakeholder_key]
    if int(reg.functions.roleOf(address).call()) == role_code:
        return refresh_lifecycle(path)
    existing = state.get("stakeholder_registration_requests", {}).get(stakeholder_key)
    if existing is not None:
        stored = reg.functions.getRegistrationRequest(int(existing)).call()
        if int(stored[3]) in {0, 1}:
            return refresh_lifecycle(path)
    evidence_cid = store_bootstrap_evidence(stakeholder_key, address, role_code)
    tx_hash = reg.functions.requestRegistration(role_code, evidence_cid).transact(
        {"from": address}
    )
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
    event = reg.events.RegistrationRequested().process_receipt(receipt)[0]
    request_id = int(event["args"]["requestId"])
    state.setdefault("stakeholder_registration_requests", {})[
        stakeholder_key
    ] = request_id
    actor_label = {
        "mrio_provider": "MRIO Data Provider",
        "focal_company": "Focal Company",
    }[stakeholder_key]
    audit = _audit_receipt(
        w3,
        path,
        receipt,
        actor_label=actor_label,
        action=f"Request {role_name} registration",
        request_id=request_id,
        metadata={"requested_role": role_name, "evidence_cid": evidence_cid},
    )
    state.setdefault("deployment_receipts", {}).setdefault(
        "StakeholderRegistrationRequests", {}
    )[stakeholder_key] = audit
    save_state(path, state)
    return refresh_lifecycle(path)


def _fulfilled_upstream_results(
    contract: Any,
    expected_hashes: dict[str, str],
) -> dict[str, Any]:
    results: dict[str, Any] = {
        "mrio": {},
        "spa": {},
        "sda": {},
    }
    pending_spa: list[tuple[int, int, str, dict[str, Any]]] = []
    count = int(contract.functions.nextComputeRequestId().call())
    for request_id in range(count):
        try:
            record = contract.functions.getComputeRequest(request_id).call()
        except Exception:
            continue
        kind = int(record[1])
        base_year = int(record[2])
        comparison_year = int(record[3])
        result_hash = str(record[6])
        status = int(record[7])
        if status != 1:
            continue
        if str(record[4]).lower() != expected_hashes.get("mrio", "").lower():
            continue
        if str(record[5]).lower() != expected_hashes.get("focal_demand", "").lower():
            continue
        item = {
            "request_id": request_id,
            "content_hash": result_hash,
            "base_year": base_year,
            "comparison_year": comparison_year,
            "fulfilled_by": str(record[10]),
            "fulfilled_at": int(record[9]),
        }
        if kind == 0:
            company_footprint = _mrio_content_company_footprint(
                result_hash, expected_hashes, base_year
            )
            if company_footprint is None:
                continue
            item["company_footprint"] = company_footprint
            results["mrio"][str(base_year)] = item
        elif kind == 1:
            pending_spa.append((request_id, base_year, result_hash, item))
        elif kind == 2:
            if not _sda_content_is_valid(
                result_hash,
                expected_hashes,
                base_year,
                comparison_year,
            ):
                continue
            results["sda"][f"{base_year}-{comparison_year}"] = item

    # A self-consistent SPA package cannot choose its own denominator.  Admit
    # it only when its total equals the independently governed same-year MRIO
    # footprint already reconstructed from a fulfilled CID.
    for _request_id, base_year, result_hash, item in pending_spa:
        mrio_item = results["mrio"].get(str(base_year), {})
        governed_total = mrio_item.get("company_footprint")
        if governed_total is None or not _spa_content_is_coverage_complete(
            result_hash,
            expected_hashes,
            base_year,
            expected_total_footprint=float(governed_total),
        ):
            continue
        results["spa"][str(base_year)] = item
    return results


def _fulfilled_governance_results(
    contract: Any,
    expected_hashes: dict[str, str],
) -> dict[str, Any]:
    results: dict[str, Any] = {
        "network": {},
        "aurora": {},
        "hotspots": {},
        "interventions": {},
        "intervention_requests": {},
        "intervention_portfolio_status": {},
    }
    network_year_by_request: dict[int, int] = {}
    valid_network_by_request: dict[int, dict[str, Any]] = {}

    network_count = int(contract.functions.nextRequestId().call())
    for request_id in range(network_count):
        try:
            record = contract.functions.getNetworkRequest(request_id).call()
        except Exception:
            continue
        year = int(record[1])
        result_hash = str(record[2])
        network_year_by_request[request_id] = year
        if (
            int(record[3]) != 1
            or year not in {2014, 2017}
            or not _network_content_is_valid(result_hash, expected_hashes, year)
        ):
            continue
        valid_network_by_request[request_id] = {
            "request_id": request_id,
            "year": year,
            "content_hash": result_hash,
            "fulfilled_by": str(record[6]),
            "fulfilled_at": int(record[5]),
        }

    # Reconstruct one exact current temporal pair. The latest valid 2017
    # request is admitted only with the exact current-input 2014 baseline that
    # the contract bound at request creation. If no 2017 result exists yet, the
    # latest valid 2014 result remains available so the guided flow can proceed.
    latest_2014 = next(
        (
            valid_network_by_request[request_id]
            for request_id in sorted(valid_network_by_request, reverse=True)
            if int(valid_network_by_request[request_id].get("year", -1)) == 2014
        ),
        None,
    )
    bound_pair: tuple[dict[str, Any], dict[str, Any]] | None = None
    for request_id in sorted(valid_network_by_request, reverse=True):
        decision = valid_network_by_request[request_id]
        if int(decision.get("year", -1)) != 2017:
            continue
        try:
            baseline_request_id = int(
                contract.functions.getTemporalBaselineNetworkRequest(request_id).call()
            )
        except Exception:
            continue
        baseline = valid_network_by_request.get(baseline_request_id)
        if not baseline or int(baseline.get("year", -1)) != 2014:
            continue
        decision_payload = _content_payload(str(decision.get("content_hash", "")))
        temporal_authority = decision_payload.get("temporal_dli_authority", {})
        if (
            not isinstance(temporal_authority, dict)
            or str(
                temporal_authority.get(
                    "baseline_evidence_network_result_cid", ""
                )
            ).strip().lower()
            != str(baseline.get("content_hash", "")).strip().lower()
        ):
            continue
        decision = {
            **decision,
            "temporal_baseline_request_id": baseline_request_id,
            "temporal_baseline_content_hash": str(baseline.get("content_hash", "")),
        }
        bound_pair = (baseline, decision)
        break
    if bound_pair is not None:
        results["network"]["2014"], results["network"]["2017"] = bound_pair
    elif latest_2014 is not None:
        results["network"]["2014"] = latest_2014

    proposal_count = int(contract.functions.nextInterventionProposalRequestId().call())
    for proposal_request_id in range(proposal_count):
        try:
            proposal = contract.functions.getInterventionProposalRequest(
                proposal_request_id
            ).call()
        except Exception:
            continue
        network_request_id = int(proposal[1])
        year = network_year_by_request.get(network_request_id)
        if year is None:
            continue
        network_result_hash = str(proposal[2])
        active_network = results["network"].get(str(year), {})
        if (
            int(active_network.get("request_id", -1)) != network_request_id
            or str(active_network.get("content_hash", "")).lower()
            != network_result_hash.lower()
        ):
            continue

        item = {
            "proposal_request_id": proposal_request_id,
            "requester": str(proposal[0]),
            "network_request_id": network_request_id,
            "network_result_hash": network_result_hash,
            "node_code": str(proposal[3]),
            "option_cid": str(proposal[4]),
            "verification_cid": str(proposal[5]),
            "hotspot_id": int(proposal[6]),
            "intervention_id": int(proposal[7]),
            "status": int(proposal[8]),
            "requested_at": int(proposal[9]),
            "fulfilled_at": int(proposal[10]),
            "fulfilled_by": str(proposal[11]),
        }
        results["intervention_requests"].setdefault(str(year), []).append(item)

        if int(proposal[8]) != 1:
            continue
        try:
            hotspot = contract.functions.getHotspot(int(proposal[6])).call()
            intervention = contract.functions.getIntervention(int(proposal[7])).call()
            performance_evidence_cids = list(
                contract.functions.getInterventionPerformanceEvidenceCIDs(
                    int(proposal[7])
                ).call()
            )
        except Exception:
            continue
        results["hotspots"].setdefault(str(year), []).append(
            {
                "hotspot_id": int(proposal[6]),
                "source_request_id": int(hotspot[0]),
                "node_code": str(hotspot[1]),
                "dli_score_bps": int(hotspot[2]),
                "evidence_cid": str(hotspot[3]),
                "registered_at": int(hotspot[4]),
                "registered_by": str(hotspot[5]),
                "proposal_request_id": proposal_request_id,
            }
        )
        results["interventions"].setdefault(str(year), []).append(
            {
                "intervention_id": int(proposal[7]),
                "hotspot_id": int(intervention[0]),
                "category": str(intervention[1]),
                "action_cid": str(intervention[2]),
                "status": int(intervention[3]),
                "proposed_by": str(intervention[4]),
                "decided_by": str(intervention[5]),
                "proposed_at": int(intervention[6]),
                "decided_at": int(intervention[7]),
                "proposal_request_id": proposal_request_id,
                "network_result_hash": network_result_hash,
                "node_code": str(proposal[3]),
                "option_cid": str(proposal[4]),
                "verification_cid": str(proposal[5]),
                "requester": str(proposal[0]),
                "performance_evidence_cids": [str(value) for value in performance_evidence_cids],
            }
        )

    # Portfolio counts are read only for the active, current-input Network/DLI
    # request for each year. Historical same-year requests must not satisfy a
    # current lifecycle gate.
    for year_key, active_network in results["network"].items():
        request_id = int(active_network["request_id"])
        try:
            selected, fulfilled, decided, all_decided = (
                contract.functions.getInterventionPortfolioStatus(request_id).call()
            )
        except Exception:
            continue
        results["intervention_portfolio_status"][str(year_key)] = {
            "network_request_id": request_id,
            "selected": int(selected),
            "fulfilled": int(fulfilled),
            "decided": int(decided),
            "all_decided": bool(all_decided),
        }

    sourcing_count = int(contract.functions.nextSourcingRequestId().call())
    for request_id in range(sourcing_count):
        try:
            record = contract.functions.getSourcingOpportunityRequest(request_id).call()
        except Exception:
            continue
        year = int(record[1])
        # U19 treats principal-year AURORA as the analytical stage immediately
        # after the two-year Network/DLI evidence and before intervention
        # governance or Query Management. Another year cannot satisfy that gate.
        if year != 2017:
            continue
        active_network = results["network"].get("2017", {})
        source_request_id = int(record[2])
        source_network_hash = str(record[3])
        result_hash = str(record[4])
        if (
            int(record[5]) != 1
            or int(active_network.get("request_id", -1)) != source_request_id
            or str(active_network.get("content_hash", "")).lower()
            != source_network_hash.lower()
            or not _aurora_content_is_valid(
                result_hash,
                expected_hashes,
                source_network_hash,
                year,
            )
        ):
            continue
        results["aurora"]["2017"] = {
            "request_id": request_id,
            "year": year,
            "network_request_id": source_request_id,
            "network_result_hash": source_network_hash,
            "content_hash": result_hash,
            "fulfilled_by": str(record[8]),
            "fulfilled_at": int(record[7]),
        }
    return results


def _verified_intervention_governance_status(
    *,
    expected_hashes: dict[str, str],
    network_2017: dict[str, Any] | None,
    aurora_2017: dict[str, Any] | None,
    selected_intervention_count: int,
    all_selected_interventions_decided: bool,
) -> dict[str, Any]:
    """Assess the post-AURORA intervention register using governed evidence.

    The local evidence must be bound to the active input hashes and the active
    2017 Network/DLI CID. Missing, stale, malformed, or tampered evidence is an
    unresolved audit outcome; it is never interpreted as a valid empty
    portfolio. Current Query Management readiness requires this governance stage
    to end in an accountable decision or a verified no-option outcome.
    """

    def unresolved(reason: str) -> dict[str, Any]:
        result = lifecycle_policy.evaluate_intervention_governance(
            [],
            governance_ready_option_count=0,
            selected_intervention_count=selected_intervention_count,
            all_selected_interventions_decided=all_selected_interventions_decided,
            evidence_verified=False,
        )
        result["intervention_governance_evidence_error"] = reason
        result["intervention_governance_evidence_extension_id"] = ""
        result["intervention_governance_source_network_cid"] = ""
        result["intervention_governance_source_aurora_cid"] = ""
        return result

    if not network_2017:
        return unresolved("Active 2017 Network/DLI evidence is unavailable.")
    if not aurora_2017:
        return unresolved("Active 2017 AURORA evidence is unavailable.")
    if not expected_hashes.get("mrio") or not expected_hashes.get("focal_demand"):
        return unresolved("Active analytical input hashes are unavailable.")

    network_cid = str(network_2017.get("content_hash", ""))
    if len(network_cid) != 64:
        return unresolved("The active 2017 Network/DLI CID is invalid.")
    aurora_cid = str(aurora_2017.get("content_hash", ""))
    if len(aurora_cid) != 64:
        return unresolved("The active 2017 AURORA CID is invalid.")

    try:
        metadata = intervention_gov.verify_intervention_governance_artifacts(
            ACTIVE_ANALYTICS_DIR,
            expected_input_hashes=expected_hashes,
            expected_source_network_result_cid=network_cid,
            expected_source_aurora_result_cid=aurora_cid,
        )
        if int(metadata.get("year", -1)) != 2017:
            raise RuntimeError(
                "Intervention-governance evidence is not the principal 2017 assessment"
            )

        artifacts = metadata.get("artifacts", {})
        required_artifacts = {
            "eligibility": intervention_gov.ELIGIBILITY_FILENAME,
            "governance_ready_options": intervention_gov.GOVERNANCE_OPTIONS_FILENAME,
        }
        for key, expected_filename in required_artifacts.items():
            record = artifacts.get(key, {}) if isinstance(artifacts, dict) else {}
            if str(record.get("filename", "")) != expected_filename:
                raise RuntimeError(
                    f"Intervention-governance metadata does not bind {expected_filename}"
                )

        frames = intervention_gov.load_intervention_governance_frames(
            ACTIVE_ANALYTICS_DIR
        )
        eligibility = frames["eligibility"]
        governance_options = frames["governance_options"]
        if len(frames["candidates"]) != int(metadata.get("candidate_pair_count", -1)):
            raise RuntimeError(
                "Intervention candidate evidence does not match its verified metadata"
            )
        if len(eligibility) != int(metadata.get("candidate_pair_count", -1)):
            raise RuntimeError(
                "Intervention eligibility evidence does not match its verified metadata"
            )
        option_count = len(governance_options)
        if option_count != int(metadata.get("governance_ready_option_count", -1)):
            raise RuntimeError(
                "Governance-ready option evidence does not match its verified metadata"
            )

        result = lifecycle_policy.evaluate_intervention_governance(
            eligibility,
            governance_ready_option_count=option_count,
            selected_intervention_count=selected_intervention_count,
            all_selected_interventions_decided=all_selected_interventions_decided,
            evidence_verified=True,
        )
        result["intervention_governance_evidence_error"] = ""
        result["intervention_governance_evidence_extension_id"] = str(
            metadata.get("extension_id", "")
        )
        result["intervention_governance_source_network_cid"] = network_cid
        result["intervention_governance_source_aurora_cid"] = aurora_cid
        return result
    except Exception as exc:
        return unresolved(str(exc))

def refresh_lifecycle(path: str | Path) -> dict[str, Any]:
    state = load_state(path)
    w3 = connect(state)
    contracts = state.get("contracts", {})
    lifecycle = state.setdefault("lifecycle", {})
    active_results: dict[str, Any] = {
        "mrio": {},
        "spa": {},
        "sda": {},
        "network": {},
        "hotspots": {},
        "interventions": {},
        "intervention_requests": {},
        "intervention_portfolio_status": {},
        "aurora": {},
    }

    reg_spec = contracts.get("Registration")
    if reg_spec:
        reg = w3.eth.contract(address=reg_spec["address"], abi=reg_spec["abi"])
        regulator_ok = int(reg.functions.roleOf(state["accounts"]["regulator"]).call()) == 1
        roles_ok = all(
            int(reg.functions.roleOf(state["oracle_roles"][key]["address"]).call())
            == int(state["oracle_roles"][key]["role_code"])
            and str(reg.functions.oracleForRole(int(state["oracle_roles"][key]["role_code"])).call()).lower()
            == str(state["oracle_roles"][key]["address"]).lower()
            for key in ["registration", "upstream", "governance", "query"]
        )
        external_stakeholders_ok = all(
            int(reg.functions.roleOf(state["accounts"][key]).call()) == code
            for key, code in [("mrio_provider", 2), ("focal_company", 3)]
        )
    else:
        regulator_ok = False
        roles_ok = False
        external_stakeholders_ok = False

    expected_hashes = {
        "mrio": onboarding.active_input_hash("mrio"),
        "focal_demand": onboarding.active_input_hash("focal_demand"),
    }
    upstream_spec = contracts.get("UpstreamCarbonEmissionsAnalysis")
    mrio_validated = False
    demand_validated = False
    if upstream_spec:
        upstream = w3.eth.contract(address=upstream_spec["address"], abi=upstream_spec["abi"])
        onchain_mrio = str(upstream.functions.latestMRIODataHash().call() or "")
        onchain_demand = str(upstream.functions.latestFocalDemandDataHash().call() or "")
        mrio_validated = bool(
            expected_hashes["mrio"]
            and expected_hashes["mrio"].lower() == onchain_mrio.lower()
        )
        demand_validated = bool(
            expected_hashes["focal_demand"]
            and expected_hashes["focal_demand"].lower() == onchain_demand.lower()
        )
        if mrio_validated and demand_validated:
            active_results.update(_fulfilled_upstream_results(upstream, expected_hashes))

    mrio_2014 = "2014" in active_results["mrio"]
    mrio_2017 = "2017" in active_results["mrio"]
    spa_2014 = "2014" in active_results["spa"]
    spa_2017 = "2017" in active_results["spa"]
    sda_complete = "2014-2017" in active_results["sda"]
    baseline_complete = all([mrio_2014, mrio_2017, spa_2014, spa_2017, sda_complete])

    governance_spec = contracts.get("HotspotsManagementAndGovernance")
    # Do not reconstruct or expose any downstream governed result unless the
    # full upstream baseline includes two independently verified 87%-coverage
    # SPA results. This also fails closed for a directly fulfilled malformed SPA
    # CID even if a governance contract already exists on the chain.
    if governance_spec and mrio_validated and demand_validated and baseline_complete:
        governance = w3.eth.contract(address=governance_spec["address"], abi=governance_spec["abi"])
        active_results.update(_fulfilled_governance_results(governance, expected_hashes))

    network_2014 = "2014" in active_results["network"]
    network_2017 = "2017" in active_results["network"]
    active_network_2017 = active_results["network"].get("2017")
    temporal_dli_complete = network_2014 and network_2017
    active_aurora_2017 = active_results["aurora"].get("2017")
    aurora_complete = bool(active_aurora_2017)
    # Backward-compatible aggregate flag now means the two-year DLI baseline is complete.
    network_complete = temporal_dli_complete
    requests_2017 = active_results.get("intervention_requests", {}).get("2017", [])
    interventions_2017 = active_results.get("interventions", {}).get("2017", [])
    portfolio_status_2017 = active_results.get("intervention_portfolio_status", {}).get("2017", {})
    selected_intervention_count = int(portfolio_status_2017.get("selected", len(requests_2017)))
    proposed_intervention_count = int(portfolio_status_2017.get("fulfilled", len(interventions_2017)))
    decided_intervention_count = int(
        portfolio_status_2017.get(
            "decided",
            sum(int(item.get("status", 0)) in {1, 2} for item in interventions_2017),
        )
    )
    intervention_selected = selected_intervention_count > 0
    hotspot_registered = bool(active_results.get("hotspots", {}).get("2017"))
    intervention_proposed = proposed_intervention_count > 0
    intervention_decided = bool(portfolio_status_2017.get("all_decided", False))
    intervention_governance = _verified_intervention_governance_status(
        expected_hashes=expected_hashes,
        network_2017=active_network_2017,
        aurora_2017=active_aurora_2017,
        selected_intervention_count=selected_intervention_count,
        all_selected_interventions_decided=intervention_decided,
    )
    # Backward-compatible evidence flag: a current intervention register exists.
    # The workspace remains sequenced after AURORA. Its resolved evidence/audit
    # status is required before final Query Management decision support.
    intervention_portfolio_ready = bool(
        temporal_dli_complete
        and intervention_governance["intervention_governance_evidence_verified"]
    )
    aurora_request_ready = lifecycle_policy.aurora_request_ready(
        governance_deployed=bool(governance_spec),
        temporal_dli_complete=temporal_dli_complete,
    )
    intervention_workspace_ready = lifecycle_policy.intervention_workspace_ready(
        aurora_complete=aurora_complete,
    )
    query_management_ready = lifecycle_policy.query_management_ready(
        temporal_dli_complete=temporal_dli_complete,
        aurora_complete=aurora_complete,
        intervention_governance_resolved=bool(
            intervention_governance["intervention_governance_resolved"]
        ),
    )
    query_deployed = "QueryManagement" in contracts

    lifecycle.update(
        {
            "registration_deployed": bool(reg_spec),
            "regulatory_authority_bootstrapped": regulator_ok,
            "oracle_roles_assigned": roles_ok,
            "stakeholders_registered": regulator_ok and external_stakeholders_ok,
            "upstream_deployed": bool(upstream_spec),
            "mrio_data_validated": mrio_validated,
            "focal_demand_validated": demand_validated,
            "mrio_2014_complete": mrio_2014,
            "mrio_2017_complete": mrio_2017,
            "spa_2014_complete": spa_2014,
            "spa_2017_complete": spa_2017,
            "sda_complete": sda_complete,
            "upstream_baseline_complete": baseline_complete,
            "governance_deployed": bool(governance_spec),
            "network_2014_complete": network_2014,
            "network_2017_complete": network_2017,
            "temporal_dli_complete": temporal_dli_complete,
            "network_complete": network_complete,
            "intervention_portfolio_ready": intervention_portfolio_ready,
            "intervention_selected": intervention_selected,
            "selected_intervention_count": selected_intervention_count,
            "proposed_intervention_count": proposed_intervention_count,
            "decided_intervention_count": decided_intervention_count,
            "hotspot_registered": hotspot_registered,
            "intervention_proposed": intervention_proposed,
            "intervention_decided": intervention_decided,
            "all_selected_interventions_decided": intervention_decided,
            **intervention_governance,
            "aurora_request_ready": aurora_request_ready,
            "aurora_2017_complete": aurora_complete,
            "aurora_complete": aurora_complete,
            "aurora_bound_to_active_2017_network": aurora_complete,
            "intervention_workspace_ready": intervention_workspace_ready,
            "query_management_ready": query_management_ready,
            "query_deployed": query_deployed,
            "system_operational": bool(query_deployed and query_management_ready),
        }
    )
    state["active_input_hashes"] = expected_hashes
    state["active_results"] = active_results
    save_state(path, state)
    return state


def deploy_functional_contract(path: str | Path, contract_name: str) -> dict[str, Any]:
    ensure_artifacts()
    state = refresh_lifecycle(path)
    if contract_name in state.get("contracts", {}):
        return state
    lifecycle = state["lifecycle"]
    if not lifecycle.get("stakeholders_registered"):
        raise RuntimeError("The MRIO Data Provider and Focal Company must be approved before functional contracts are deployed.")
    if contract_name == "HotspotsManagementAndGovernance" and not lifecycle.get("upstream_baseline_complete"):
        raise RuntimeError(
            "Complete MRIO 2014/2017, SPA 2014/2017, and SDA 2014-2017 before deploying the Governance contract."
        )
    if contract_name == "QueryManagement":
        required = [
            ("governance_deployed", "Governance contract"),
            ("temporal_dli_complete", "Network/DLI results for 2014 and 2017"),
            ("aurora_2017_complete", "AURORA result for the active 2017 Network/DLI evidence"),
            (
                "intervention_governance_resolved",
                "resolved intervention governance decision or verified no-option outcome",
            ),
        ]
        missing = [label for key, label in required if not lifecycle.get(key)]
        if missing:
            raise RuntimeError(
                "Query Management is the final contract. Complete first: " + ", ".join(missing)
            )
    w3 = connect(state)
    registration_address = state["contracts"]["Registration"]["address"]
    sender_key = {
        "UpstreamCarbonEmissionsAnalysis": "mrio_provider",
        "HotspotsManagementAndGovernance": "focal_company",
        "QueryManagement": "focal_company",
    }[contract_name]
    required_role = {
        "UpstreamCarbonEmissionsAnalysis": 2,
        "HotspotsManagementAndGovernance": 3,
        "QueryManagement": 3,
    }[contract_name]
    reg = w3.eth.contract(
        address=registration_address,
        abi=state["contracts"]["Registration"]["abi"],
    )
    sender = state["accounts"][sender_key]
    if int(reg.functions.roleOf(sender).call()) != required_role:
        raise RuntimeError(f"{sender_key} does not hold the required on-chain role.")
    abi, receipt = _deploy(
        w3,
        CONTRACT_ARTIFACTS[contract_name],
        sender,
        registration_address,
    )
    state.setdefault("contracts", {})[contract_name] = {
        "address": receipt.contractAddress,
        "abi": abi,
    }
    save_state(path, state)
    actor_label = {
        "UpstreamCarbonEmissionsAnalysis": "MRIO Data Provider",
        "HotspotsManagementAndGovernance": "Focal Company",
        "QueryManagement": "Focal Company",
    }[contract_name]
    audit = _audit_receipt(
        w3,
        path,
        receipt,
        actor_label=actor_label,
        action=f"Deploy {contract_name} contract from StrategicCarbonIntelligenceSystem.sol",
        contract_name_hint=contract_name,
        function_signature_hint="constructor(address)",
        decoded_inputs_hint={"registrationAddress": registration_address},
        metadata={"responsible_role": state["contract_deployers"][contract_name]["role_name"]},
    )
    state = load_state(path)
    state.setdefault("deployment_receipts", {})[contract_name] = audit
    save_state(path, state)
    return refresh_lifecycle(path)


def available_sidebar_sections(state: dict[str, Any]) -> list[str]:
    """Return the progressive platform navigation permitted by current evidence."""
    lifecycle = state.get("lifecycle", {})
    results = state.get("active_results", {})
    sections: list[str] = []
    if lifecycle.get("mrio_2014_complete") and lifecycle.get("mrio_2017_complete"):
        sections.append("Carbon Footprint Intelligence")
    if results.get("mrio"):
        sections.append("Emissions Hotspot Intelligence")
    if results.get("spa"):
        sections.append("Structural Pathway Intelligence")
    if lifecycle.get("upstream_baseline_complete"):
        sections.append("Carbon-Change Decomposition")
    if lifecycle.get("network_2014_complete") or lifecycle.get("network_2017_complete"):
        sections.append("Network Leverage & DLI")
    if (
        lifecycle.get("spa_2014_complete")
        and lifecycle.get("spa_2017_complete")
        and lifecycle.get("sda_complete")
        and lifecycle.get("network_2014_complete")
        and lifecycle.get("network_2017_complete")
    ):
        sections.append("Integrated SPA–SDA & CRITIC-DLI")
    if lifecycle.get("upstream_baseline_complete"):
        sections.append("Strategic Scenario Analysis")
    if lifecycle.get("aurora_complete"):
        sections.append("AURORA Opportunity Intelligence")
    if lifecycle.get("intervention_governance_evidence_verified"):
        sections.append("Intervention Governance")
    if lifecycle.get("query_deployed") and lifecycle.get("query_management_ready"):
        sections.append("AI Decision Intelligence")
    sections.append("Governance & Audit Control")
    return sections
