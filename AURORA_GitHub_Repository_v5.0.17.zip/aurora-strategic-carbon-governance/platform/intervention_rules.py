"""Retired pre-U16 top-DLI intervention-rule interface.

U16 has one formal intervention authority: ``intervention_governance.py``.
The previous sector-rule/top-15-DLI generator is archived under
``assurance_history/legacy_modules`` for traceability and cannot generate
current intervention recommendations.
"""
from __future__ import annotations

LEGACY_FORMAL_AUTHORITY = False
RETIREMENT_REASON = (
    "Top-DLI sector rules do not connect producer-hotspot magnitude, signed "
    "node/path SDA drivers, producer-resolved linkage, and focal-company "
    "actionability. Use intervention_governance.py."
)


def generate_interventions(*args, **kwargs):
    """Fail closed instead of creating a competing intervention authority."""
    del args, kwargs
    raise RuntimeError(RETIREMENT_REASON)


__all__ = ("LEGACY_FORMAL_AUTHORITY", "RETIREMENT_REASON", "generate_interventions")
