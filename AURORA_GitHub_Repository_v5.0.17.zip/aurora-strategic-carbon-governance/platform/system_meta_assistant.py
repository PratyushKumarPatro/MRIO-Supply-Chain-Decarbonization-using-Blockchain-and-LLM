"""Evidence-grounded assistant for deployment and architecture questions.

System-level questions are related to the Strategic Carbon Intelligence & Governance project but normally do not
require MRIO, SPA, SDA, DLI, AURORA, scenario, or intervention computation. This
module retrieves only curated implementation evidence and synthesizes a coherent
answer while keeping analytical authority in strategic_assistant.py.
"""
from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

import query_intelligence as qi

BASE_DIR = Path(__file__).resolve().parent

SYSTEM_META_SYNTHESIS_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "answer_type": {"type": "string", "enum": ["system_meta"]},
        "narrative_answer": {
            "type": "string",
            "description": "A direct, coherent answer in connected paragraphs rather than disconnected evidence blocks.",
        },
        "covered_record_ids": {
            "type": "array",
            "maxItems": 10,
            "items": {"type": "string"},
        },
        "material_limitations_included": {"type": "boolean"},
    },
    "required": [
        "answer_type",
        "narrative_answer",
        "covered_record_ids",
        "material_limitations_included",
    ],
}

ASPECT_PATTERNS: dict[str, list[str]] = {
    "deployment": [r"\bdeploy", r"\bimplementation", r"\bproduction", r"\bentire system", r"\bwhole setup"],
    "architecture": [r"\barchitecture", r"\bdesign", r"\bhow .* system .* work", r"\bfour[- ]oracle"],
    "trust": [r"\btrust", r"\bcentral", r"\bdecentrali", r"\boracle consensus"],
    "security": [r"\bsecurity", r"\bcredential", r"\bprivate key", r"\bcompromise", r"\bharden"],
    "privacy": [r"\bprivacy", r"\bconfidential", r"\bsensitive", r"\bon[- ]chain text"],
    "storage": [r"\bstorage", r"\bcontent store", r"\bipfs", r"\bavailability", r"\bresult cid"],
    "data": [r"\bdata quality", r"\binput", r"\bmrio update", r"\bstale", r"\bfreshness"],
    "llm": [r"\bllm", r"\bollama", r"\bmodel", r"\bquery understanding", r"\birrelevant answer", r"\bhallucination", r"\bresponse"],
    "relevance": [r"\brelevant", r"\birrelevant", r"\bwrong answer", r"\bquery", r"\bunderstand"],
    "scalability": [r"\bscal", r"\bthroughput", r"\bconcurr", r"\bmany users", r"\bperformance", r"\blatency"],
    "operations": [r"\bmonitor", r"\brecovery", r"\bretry", r"\bheartbeat", r"\boperational", r"\bmaintain"],
    "reproducibility": [r"\breproduc", r"\bversion", r"\bupgrade", r"\bprompt"],
    "governance": [r"\bgovernance", r"\bhuman", r"\bstakeholder", r"\bdecision"],
    "improvement": [r"\bimprov", r"\benhanc", r"\bfix", r"\bchange", r"\broadmap", r"\bnext"],
    "blockchain": [r"\bblockchain", r"\bganache", r"\bchain", r"\bsmart contract"],
    "oracles": [r"\boracle"],
}

GENERIC_CHALLENGE_IDS = [
    "single_host_trust_boundary",
    "ganache_to_production_chain",
    "content_storage_availability",
    "query_privacy_on_chain",
    "input_data_quality_and_freshness",
    "llm_query_understanding_and_hallucination",
    "throughput_and_concurrency",
    "decision_boundary_and_human_governance",
]


@dataclass
class SystemMetaResult:
    question: str
    aspects: list[str]
    evidence: list[dict[str, Any]]
    answer: str
    alignment: dict[str, Any]
    model_metrics: dict[str, Any]


def _knowledge_path() -> Path:
    candidates = [
        BASE_DIR / "data" / "system_knowledge.json",
        BASE_DIR / "system_knowledge.json",
    ]
    for path in candidates:
        if path.exists():
            return path
    raise FileNotFoundError("system_knowledge.json was not found")


@lru_cache(maxsize=1)
def load_system_knowledge() -> dict[str, Any]:
    payload = json.loads(_knowledge_path().read_text(encoding="utf-8"))
    if not isinstance(payload, dict) or not isinstance(payload.get("records"), list):
        raise ValueError("system_knowledge.json must contain a records list")
    return payload


def _record_text(record: dict[str, Any]) -> str:
    return " ".join(
        [
            str(record.get("title", "")),
            " ".join(str(item) for item in record.get("aliases", [])),
            " ".join(str(item) for item in record.get("aspects", [])),
            str(record.get("direct_statement", "")),
            str(record.get("management_implication", "")),
            str(record.get("hardening_action", "")),
            str(record.get("claim_boundary", "")),
        ]
    )


@lru_cache(maxsize=1)
def _index():
    records = load_system_knowledge()["records"]
    corpus = [_record_text(record) for record in records]
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(corpus)
    return records, vectorizer, matrix


def detect_aspects(question: str) -> list[str]:
    q = str(question or "").casefold()
    aspects = [
        aspect
        for aspect, patterns in ASPECT_PATTERNS.items()
        if any(re.search(pattern, q) for pattern in patterns)
    ]
    challenge = bool(re.search(r"\b(challenge|limitation|risk|weakness|issue|problem|concern)s?\b", q))
    if challenge and "deployment" not in aspects:
        aspects.insert(0, "deployment")
    if not aspects:
        aspects = ["architecture", "deployment"]
    return list(dict.fromkeys(aspects))


def _alias_score(question: str, record: dict[str, Any]) -> float:
    q = re.sub(r"\s+", " ", str(question).casefold()).strip()
    best = 0.0
    for alias in record.get("aliases", []):
        label = str(alias).casefold().strip()
        if not label:
            continue
        if label == q:
            best = max(best, 0.45)
        elif label in q:
            best = max(best, 0.28 + min(0.10, 0.02 * len(label.split())))
    return best


def retrieve_system_evidence(question: str, top_n: int = 7) -> dict[str, Any]:
    records, vectorizer, matrix = _index()
    aspects = detect_aspects(question)
    similarities = cosine_similarity(vectorizer.transform([question]), matrix).flatten()
    challenge = bool(re.search(r"\b(challenge|limitation|risk|weakness|issue|problem|concern)s?\b", question, re.I))

    scored: list[tuple[float, int]] = []
    for index, record in enumerate(records):
        record_aspects = {str(item) for item in record.get("aspects", [])}
        aspect_overlap = len(record_aspects & set(aspects))
        aspect_boost = min(0.28, 0.07 * aspect_overlap)
        generic_boost = 0.12 if challenge and str(record.get("id")) in GENERIC_CHALLENGE_IDS else 0.0
        score = float(similarities[index]) + _alias_score(question, record) + aspect_boost + generic_boost
        scored.append((score, index))

    scored.sort(key=lambda item: item[0], reverse=True)
    minimum = 0.09
    selected: list[dict[str, Any]] = []
    selected_ids: set[str] = set()

    # A broad deployment-challenge question should cover several distinct risk
    # classes rather than returning several near-duplicate records.
    if challenge and ("deployment" in aspects or "architecture" in aspects):
        by_id = {str(record.get("id")): record for record in records}
        score_by_id = {str(records[index].get("id")): score for score, index in scored}
        for record_id in GENERIC_CHALLENGE_IDS:
            record = by_id.get(record_id)
            if not record:
                continue
            item = dict(record)
            item["relevance_score"] = float(score_by_id.get(record_id, 0.0))
            item["relevance_reason"] = "generic deployment-challenge coverage"
            selected.append(item)
            selected_ids.add(record_id)
            if len(selected) >= top_n:
                break

    for score, index in scored:
        record = records[index]
        record_id = str(record.get("id", index))
        if record_id in selected_ids or score < minimum:
            continue
        item = dict(record)
        item["relevance_score"] = float(score)
        item["relevance_reason"] = "TF-IDF plus alias/aspect relevance gate"
        selected.append(item)
        selected_ids.add(record_id)
        if len(selected) >= top_n:
            break

    return {
        "query": question,
        "aspects": aspects,
        "minimum_relevance_score": minimum,
        "retrieved": selected,
        "retrieved_count": len(selected),
        "corpus_version": load_system_knowledge().get("version"),
    }


def _join_sentences(items: list[str]) -> str:
    cleaned = [re.sub(r"\s+", " ", str(item)).strip() for item in items if str(item).strip()]
    return " ".join(cleaned)


def _serial_join(items: list[str]) -> str:
    cleaned = [
        re.sub(r"\s+", " ", str(item)).strip().rstrip(" .;:")
        for item in items
        if str(item).strip()
    ]
    if not cleaned:
        return ""
    lowered = [item[:1].lower() + item[1:] if item else item for item in cleaned]
    if len(lowered) == 1:
        return lowered[0]
    if len(lowered) == 2:
        return f"{lowered[0]} and {lowered[1]}"
    return "; ".join(lowered[:-1]) + f"; and {lowered[-1]}"


def _record_by_id(records: list[dict[str, Any]], record_id: str) -> dict[str, Any] | None:
    return next((row for row in records if str(row.get("id")) == record_id), None)


def deterministic_system_narrative(question: str, retrieval: dict[str, Any]) -> str:
    records = retrieval.get("retrieved", []) if isinstance(retrieval, dict) else []
    if not records:
        return (
            "The question concerns the deployed Strategic Carbon Intelligence & Governance system, but the packaged system-knowledge "
            "layer did not contain sufficiently relevant evidence to support a reliable answer."
        )

    q = str(question or "").casefold()
    challenge = bool(re.search(r"\b(challenge|limitation|risk|weakness|issue|problem|concern)s?\b", q))
    improvement = bool(re.search(r"\b(improv|enhanc|fix|harden|production|roadmap|change)\w*\b", q))
    records_by_id = {str(row.get("id")): row for row in records}

    if challenge:
        trust = records_by_id.get("single_host_trust_boundary") or records[0]
        chain = records_by_id.get("ganache_to_production_chain")
        storage = records_by_id.get("content_storage_availability")
        privacy = records_by_id.get("query_privacy_on_chain")
        data = records_by_id.get("input_data_quality_and_freshness")
        llm = records_by_id.get("llm_query_understanding_and_hallucination")
        scale = records_by_id.get("throughput_and_concurrency")
        governance = records_by_id.get("decision_boundary_and_human_governance")

        first_parts = [
            "The main deployment challenges are not in the smart-contract request lifecycle alone; they arise across trust, infrastructure, data, model behavior and operational governance.",
            trust.get("direct_statement", "") if trust else "",
            trust.get("management_implication", "") if trust else "",
        ]
        if chain:
            first_parts.append(
                "In addition, " + chain.get("direct_statement", "").replace("The packaged lifecycle", "the packaged lifecycle", 1)
            )
        if storage:
            storage_implication = str(storage.get("management_implication", "")).strip()
            first_parts.append(
                "The local content-addressed store creates a related availability concern because "
                + (storage_implication[:1].lower() + storage_implication[1:] if storage_implication else "durable retrieval is not guaranteed")
            )

        second_parts = []
        if privacy:
            second_parts.append(privacy.get("direct_statement", ""))
        if data:
            second_parts.append("Analytical reliability also depends on input quality. " + data.get("management_implication", ""))
        if llm:
            second_parts.append("At the interaction layer, " + llm.get("direct_statement", "").replace("The local LLM", "the local LLM", 1))
        if scale:
            second_parts.append(scale.get("management_implication", ""))

        third_parts = [
            "Taken together, these issues mean that production readiness requires coordinated hardening rather than only a larger language model or a different blockchain.",
        ]
        actions = []
        for record in [trust, chain, storage, privacy, data, llm, scale, governance]:
            if record and record.get("hardening_action"):
                actions.append(str(record["hardening_action"]))
        if actions:
            # Keep the prose connected while limiting the fallback to the most
            # material actions for readability.
            joined_actions = _serial_join(actions[:4])
            if joined_actions:
                third_parts.append("The immediate priorities are to " + joined_actions + ".")
        if governance:
            third_parts.append(governance.get("claim_boundary", ""))

        return "\n\n".join(
            paragraph
            for paragraph in [
                _join_sentences(first_parts),
                _join_sentences(second_parts),
                _join_sentences(third_parts),
            ]
            if paragraph
        )

    # Specific system questions use the strongest records and connect evidence,
    # implications and practical action in a compact narrative.
    lead = records[0]
    first = _join_sentences(
        [
            lead.get("direct_statement", ""),
            lead.get("management_implication", ""),
        ]
    )
    supporting = []
    for record in records[1:3]:
        supporting.append(record.get("direct_statement", ""))
    second = _join_sentences(supporting)
    action_parts = [lead.get("hardening_action", "")]
    if improvement:
        action_parts.extend(record.get("hardening_action", "") for record in records[1:3])
    action_parts.append(lead.get("claim_boundary", ""))
    third = _join_sentences(action_parts)
    return "\n\n".join(part for part in [first, second, third] if part)


def _allowed_grounding_text(retrieval: dict[str, Any], deterministic_draft: str) -> str:
    return json.dumps(retrieval, default=str) + " " + deterministic_draft


def _valid_model_answer(
    output: dict[str, Any],
    question: str,
    retrieval: dict[str, Any],
    deterministic_draft: str,
) -> tuple[bool, dict[str, Any]]:
    if not isinstance(output, dict) or output.get("answer_type") != "system_meta":
        return False, {"aligned": False, "reasons": ["invalid structured answer type"]}
    answer = str(output.get("narrative_answer", "")).strip()
    if len(answer) < 120:
        return False, {"aligned": False, "reasons": ["narrative answer is too short"]}

    allowed_ids = {str(row.get("id")) for row in retrieval.get("retrieved", [])}
    covered_ids = {str(item) for item in output.get("covered_record_ids", [])}
    if covered_ids and not covered_ids.issubset(allowed_ids):
        return False, {"aligned": False, "reasons": ["model cited an unavailable system record"]}

    prohibited = [
        "the prompt", "the schema", "we are given", "scope_guard", "private reasoning",
        "according to my training", "i cannot access the evidence",
    ]
    lower = answer.casefold()
    if any(item in lower for item in prohibited):
        return False, {"aligned": False, "reasons": ["model exposed internal instructions"]}

    allowed_text = _allowed_grounding_text(retrieval, deterministic_draft)
    allowed_numbers = set(re.findall(r"[-+]?\d+(?:\.\d+)?", allowed_text))
    output_numbers = set(re.findall(r"[-+]?\d+(?:\.\d+)?", answer))
    if any(number not in allowed_numbers for number in output_numbers):
        return False, {"aligned": False, "reasons": ["unsupported numerical claim"]}

    alignment = qi.assess_answer_alignment(question, answer, expected_mode="system_meta")
    if not alignment.get("aligned"):
        return False, alignment
    return True, alignment


def synthesize_system_answer(
    client: Any,
    question: str,
    retrieval: dict[str, Any],
    history: list[dict[str, Any]] | None = None,
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    deterministic_draft = deterministic_system_narrative(question, retrieval)
    deterministic_alignment = qi.assess_answer_alignment(
        question,
        deterministic_draft,
        expected_mode="system_meta",
    )

    system = (
        "You are the system-level reasoning and communication layer of a local Strategic Carbon Intelligence & Governance Strategic Carbon "
        "Intelligence application. Answer the user's actual question directly using only the supplied curated "
        "implementation evidence. Produce two or three coherent paragraphs with clear transitions. Integrate the "
        "direct answer, evidence, implications, recommended hardening and material limitations into a connected "
        "narrative. Do not expose evidence as disconnected definitions, headings or bullet lists unless the user "
        "explicitly asks for a list. Do not execute or invent MRIO, SPA, SDA, DLI, AURORA, scenario or intervention "
        "results. Do not claim live web verification. Return only JSON matching the schema."
    )
    payload = {
        "question": question,
        "detected_aspects": retrieval.get("aspects", []),
        "curated_system_evidence": retrieval.get("retrieved", []),
        "grounded_deterministic_draft": deterministic_draft,
        "style_requirement": (
            "Lead with the conclusion, connect each claim with because, however, in addition, therefore or taken "
            "together where appropriate, and finish with the most important limitation or next control."
        ),
    }
    model = os.getenv("OLLAMA_SYNTHESIS_MODEL", getattr(client, "model", ""))
    try:
        output = client.chat_json(
            system,
            json.dumps(payload, indent=2, default=str),
            SYSTEM_META_SYNTHESIS_SCHEMA,
            model=model or None,
            num_predict=1150,
            temperature=0.1,
        )
        valid, alignment = _valid_model_answer(output, question, retrieval, deterministic_draft)
        if valid:
            return str(output["narrative_answer"]).strip(), alignment, {
                "status": "ok",
                "model": model or getattr(client, "model", ""),
                "synthesis_source": "local_llm_validated",
                "covered_record_ids": output.get("covered_record_ids", []),
            }
        return deterministic_draft, deterministic_alignment, {
            "status": "rejected",
            "model": model or getattr(client, "model", ""),
            "synthesis_source": "deterministic_fallback",
            "rejection": alignment,
        }
    except Exception as exc:
        return deterministic_draft, deterministic_alignment, {
            "status": "fallback",
            "model": model or getattr(client, "model", ""),
            "synthesis_source": "deterministic_fallback",
            "error": str(exc),
        }


def answer_system_question(
    client: Any,
    question: str,
    *,
    history: list[dict[str, Any]] | None = None,
    top_n: int = 7,
) -> SystemMetaResult:
    retrieval = retrieve_system_evidence(question, top_n=top_n)
    answer, alignment, metrics = synthesize_system_answer(
        client,
        question,
        retrieval,
        history=history,
    )
    evidence = [
        {
            "tool": "system_knowledge",
            "parameters": {
                "query": question,
                "top_n": top_n,
                "aspects": retrieval.get("aspects", []),
                "minimum_relevance_score": retrieval.get("minimum_relevance_score"),
            },
            "source": "system_knowledge.json via system_meta_assistant.py",
            "data": retrieval,
        }
    ]
    return SystemMetaResult(
        question=question,
        aspects=list(retrieval.get("aspects", [])),
        evidence=evidence,
        answer=answer,
        alignment=alignment,
        model_metrics=metrics,
    )
