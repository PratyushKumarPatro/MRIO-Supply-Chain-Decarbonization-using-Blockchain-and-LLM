"""SPA-SDA-CRITIC-DLI integration for the U11 pathway-relevance method.

The module keeps three analytically distinct evidence layers:

1. emissions-weighted SPA pathway participation (current burden/relevance),
2. path-level permutation-averaged Shapley effects (temporal change and why),
3. CRITIC-DLI (systemic leverage, supplied later by the orchestrator).

SPA participation is non-additive across nodes: the same path may be associated
with a demand gateway, transmission node and terminal emitter.  Role-specific
columns preserve those distinctions and prevent a procurement gateway from
being misread as the physical emissions origin.
"""
from __future__ import annotations

from dataclasses import dataclass
from functools import cached_property
from itertools import permutations
from typing import Any, Iterable, Mapping, Sequence
import hashlib
import json
import math
import re

import numpy as np
import pandas as pd

FACTORS: tuple[str, ...] = ("intensity", "technology", "composition", "scale")
DIRECT_CLASS = "Direct final-demand pathways"
EMERGENT_CLASS = "Emergent post-baseline upstream pathways"
SHALLOW_CLASS = "Shallower, more domestically embedded upstream pathways"
DEEP_CLASS = "Deeper, more externally embedded and carbon-intensive pathways"


def exact_product_shapley(
    base_values: Sequence[float],
    comparison_values: Sequence[float],
    names: Sequence[str] = FACTORS,
) -> dict[str, float]:
    """Complete permutation-average Shapley decomposition of a product."""
    base = np.asarray(base_values, dtype=float)
    comparison = np.asarray(comparison_values, dtype=float)
    if len(base) != len(comparison) or len(base) != len(names):
        raise ValueError("Factor arrays and names must have identical lengths")
    effects = np.zeros(len(base), dtype=float)
    orders = list(permutations(range(len(base))))
    for order in orders:
        state = base.copy()
        for index in order:
            before = float(np.prod(state))
            state[index] = comparison[index]
            effects[index] += float(np.prod(state)) - before
    effects /= len(orders)
    return {str(names[index]): float(effects[index]) for index in range(len(base))}


def classify_signed_driver_effects(
    effects: Mapping[str, float],
    tolerance: float,
) -> dict[str, Any]:
    """Classify all signed SDA effects without discarding offsets.

    ``dominant_driver`` remains the largest absolute temporal influence.  The
    ``primary_adverse_driver`` is the largest positive contribution and is the
    normal first intervention priority when emissions growth is undesirable.
    The ``primary_beneficial_driver`` is the most negative contribution and
    should normally be preserved or strengthened.
    """
    signed = {name: float(effects.get(name, 0.0)) for name in FACTORS}
    absolute_total = float(sum(abs(value) for value in signed.values()))
    positives = sorted(
        ((name, value) for name, value in signed.items() if value > tolerance),
        key=lambda item: (-item[1], item[0]),
    )
    negatives = sorted(
        ((name, value) for name, value in signed.items() if value < -tolerance),
        key=lambda item: (item[1], item[0]),
    )
    if absolute_total <= tolerance:
        dominant_driver = ""
        dominance_share = np.nan
    else:
        dominant_driver = max(FACTORS, key=lambda name: abs(signed[name]))
        dominance_share = abs(signed[dominant_driver]) / absolute_total

    adverse_total = float(sum(value for _, value in positives))
    beneficial_total = float(sum(value for _, value in negatives))
    primary_adverse_driver = positives[0][0] if positives else ""
    primary_adverse_effect = float(positives[0][1]) if positives else 0.0
    primary_beneficial_driver = negatives[0][0] if negatives else ""
    primary_beneficial_effect = float(negatives[0][1]) if negatives else 0.0
    adverse_concentration = (
        primary_adverse_effect / adverse_total if adverse_total > tolerance else np.nan
    )
    beneficial_concentration = (
        abs(primary_beneficial_effect) / abs(beneficial_total)
        if abs(beneficial_total) > tolerance else np.nan
    )
    if not positives and not negatives:
        pattern = "no material driver"
    elif positives and negatives:
        pattern = "offsetting adverse and beneficial drivers"
    elif positives:
        pattern = (
            "concentrated adverse driver"
            if adverse_concentration >= 0.60
            else "multi-driver adverse change"
        )
    else:
        pattern = (
            "concentrated beneficial driver"
            if beneficial_concentration >= 0.60
            else "multi-driver beneficial change"
        )
    return {
        "absolute_driver_sum": absolute_total,
        "dominant_driver": dominant_driver,
        "driver_dominance_share": dominance_share,
        "primary_adverse_driver": primary_adverse_driver,
        "primary_adverse_effect_tco2": primary_adverse_effect,
        "secondary_adverse_drivers": "; ".join(
            f"{name}:{value:.12g}" for name, value in positives[1:]
        ),
        "total_adverse_effect_tco2": adverse_total,
        "adverse_driver_concentration": adverse_concentration,
        "primary_beneficial_driver": primary_beneficial_driver,
        "primary_beneficial_effect_tco2": primary_beneficial_effect,
        "secondary_beneficial_drivers": "; ".join(
            f"{name}:{value:.12g}" for name, value in negatives[1:]
        ),
        "total_beneficial_effect_tco2": beneficial_total,
        "beneficial_driver_concentration": beneficial_concentration,
        "driver_pattern": pattern,
    }


def annotate_path_reconfiguration(panel: pd.DataFrame) -> pd.DataFrame:
    """Mark exact-path persistence and route reconfiguration across years.

    Exact path identity is the complete ordered node sequence.  A common node
    is never forced to retain the same path.  When an emerging and a
    disappearing exact path share the same demand gateway and terminal emitter,
    they are labelled as members of one reconfigured route family.
    """
    out = panel.copy()
    if out.empty:
        for column in (
            "route_transition_id", "route_reconfiguration_status",
            "related_reconfigured_path_count",
        ):
            out[column] = pd.Series(dtype="object" if column != "related_reconfigured_path_count" else "int64")
        return out
    out["route_transition_id"] = ""
    out["route_reconfiguration_status"] = "not reconfigured"
    out["related_reconfigured_path_count"] = 0
    for (gateway, emitter), group in out.groupby(
        ["demand_gateway_node", "terminal_emitter_node"], sort=True, dropna=False
    ):
        emerging = group.index[group["path_identity_status"].eq("emerging exact path")].tolist()
        disappearing = group.index[group["path_identity_status"].eq("disappearing exact path")].tolist()
        if not emerging or not disappearing:
            continue
        transition_id = hashlib.sha256(
            f"{gateway}|{emitter}".encode("utf-8")
        ).hexdigest()[:16]
        members = emerging + disappearing
        out.loc[members, "route_transition_id"] = transition_id
        out.loc[emerging, "route_reconfiguration_status"] = "incoming member of reconfigured route"
        out.loc[disappearing, "route_reconfiguration_status"] = "outgoing member of reconfigured route"
        out.loc[members, "related_reconfigured_path_count"] = len(members)
    return out


def parse_path(value: Any) -> tuple[str, ...]:
    """Parse path codes from lists, tuples or serialized arrow-separated text."""
    if isinstance(value, (list, tuple, np.ndarray)):
        return tuple(str(item).strip() for item in value if str(item).strip())
    text = str(value or "").strip().strip("[]()")
    if not text:
        return tuple()
    parts = re.split(r"\s*(?:<-|←|->|→|\||,|;)\s*", text)
    return tuple(part.strip(" '\"\t") for part in parts if part.strip(" '\"\t"))


@dataclass
class ModelAdapter:
    year: int
    A: np.ndarray
    f: np.ndarray
    y: np.ndarray
    node_codes: list[str]

    @cached_property
    def index(self) -> dict[str, int]:
        return {str(code): index for index, code in enumerate(self.node_codes)}

    @classmethod
    def from_mrio(cls, mrio_year: Any, demand: np.ndarray) -> "ModelAdapter":
        A = np.zeros_like(np.asarray(mrio_year.Z, dtype=float))
        outputs = np.asarray(mrio_year.X, dtype=float)
        positive = outputs > 0
        A[:, positive] = np.asarray(mrio_year.Z, dtype=float)[:, positive] / outputs[positive][np.newaxis, :]
        return cls(
            year=int(mrio_year.year),
            A=A,
            f=np.asarray(mrio_year.fE, dtype=float).reshape(-1),
            y=np.asarray(demand, dtype=float).reshape(-1),
            node_codes=[str(code) for code in mrio_year.node_codes],
        )


def path_factors(path: Sequence[str], model: ModelAdapter) -> dict[str, Any]:
    nodes = tuple(str(node) for node in path)
    if not nodes:
        raise ValueError("Empty path")
    try:
        demand_index = model.index[nodes[0]]
        emitter_index = model.index[nodes[-1]]
    except KeyError as exc:
        raise KeyError(f"Unknown path node {exc}") from exc

    technology = 1.0
    edge_coefficients: list[float] = []
    for user, supplier in zip(nodes[:-1], nodes[1:]):
        coefficient = float(model.A[model.index[supplier], model.index[user]])
        edge_coefficients.append(coefficient)
        technology *= coefficient

    scale = float(model.y.sum())
    demand_value = float(model.y[demand_index])
    composition = demand_value / scale if scale else 0.0
    intensity = float(model.f[emitter_index])
    contribution = intensity * technology * demand_value
    return {
        "intensity": intensity,
        "technology": technology,
        "composition": composition,
        "scale": scale,
        "demand_value": demand_value,
        "contribution": contribution,
        "edge_coefficients": edge_coefficients,
    }


def _external_share(nodes: Sequence[str], focal_region: str = "ARE") -> float:
    if not nodes:
        return 0.0
    external = sum(
        1
        for node in nodes
        if str(node).split("-", 1)[0].upper() != focal_region.upper()
    )
    return external / len(nodes)


def build_path_panel(
    paths: Iterable[Sequence[str]],
    base: ModelAdapter,
    comparison: ModelAdapter,
    focal_region: str = "ARE",
    materiality_tolerance: float | None = None,
    *,
    base_selected_paths: Iterable[Sequence[str]] | None = None,
    comparison_selected_paths: Iterable[Sequence[str]] | None = None,
) -> pd.DataFrame:
    """Evaluate union-path identities in both annual MRIO states.

    Exact path identity is the complete ordered node sequence.  Every union
    path is evaluated under both annual coefficient/intensity/demand states,
    irrespective of whether the beam screen selected it in both years.  This
    avoids treating a beam-selection omission as a physical zero.  A path is
    classified as emerging or disappearing only when its evaluated contribution
    crosses the materiality boundary; a structurally absent route therefore has
    a natural zero product.  Selection-presence flags are reported separately.

    Common nodes are never required to retain the same complete route.
    """
    n = len(base.A)
    base_footprint = float(base.f @ np.linalg.solve(np.eye(n) - base.A, base.y))
    comparison_footprint = float(
        comparison.f @ np.linalg.solve(np.eye(n) - comparison.A, comparison.y)
    )
    tolerance = (
        float(materiality_tolerance)
        if materiality_tolerance is not None
        else max(1e-12, max(abs(base_footprint), abs(comparison_footprint)) * 1e-10)
    )

    rows: list[dict[str, Any]] = []
    unique_paths = sorted(set(tuple(str(node) for node in path) for path in paths if path))
    base_selected = (
        {tuple(str(node) for node in path) for path in base_selected_paths if path}
        if base_selected_paths is not None
        else set(unique_paths)
    )
    comparison_selected = (
        {tuple(str(node) for node in path) for path in comparison_selected_paths if path}
        if comparison_selected_paths is not None
        else set(unique_paths)
    )
    for path in unique_paths:
        try:
            base_factors = path_factors(path, base)
            comparison_factors = path_factors(path, comparison)
        except (KeyError, ValueError):
            continue
        effects = exact_product_shapley(
            [base_factors[name] for name in FACTORS],
            [comparison_factors[name] for name in FACTORS],
        )
        delta = float(comparison_factors["contribution"] - base_factors["contribution"])
        driver_classification = classify_signed_driver_effects(effects, tolerance)
        absolute_driver_sum = float(driver_classification["absolute_driver_sum"])
        dominant_driver = str(driver_classification["dominant_driver"])
        dominance_share = driver_classification["driver_dominance_share"]
        base_present = abs(float(base_factors["contribution"])) > tolerance
        comparison_present = abs(float(comparison_factors["contribution"])) > tolerance
        if base_present and comparison_present:
            path_identity_status = "persistent exact path"
        elif comparison_present:
            path_identity_status = "emerging exact path"
        elif base_present:
            path_identity_status = "disappearing exact path"
        else:
            path_identity_status = "inactive/negligible exact path"
        if absolute_driver_sum <= tolerance:
            temporal_status = "stable/no material temporal change"
            driver_profile = temporal_status
        else:
            if abs(delta) <= tolerance:
                temporal_status = "stable net/offsetting drivers"
            elif delta > 0:
                temporal_status = "worsening"
            else:
                temporal_status = "improving"
            priority = str(driver_classification["primary_adverse_driver"])
            if priority:
                driver_profile = f"{priority}-priority {temporal_status}; {driver_classification['driver_pattern']}"
            elif dominant_driver:
                driver_profile = f"{dominant_driver}-influenced {temporal_status}; no adverse driver"
            else:
                driver_profile = temporal_status

        depth = len(path) - 1
        baseline_technology = float(base_factors["technology"])
        geometric_mean = (
            abs(baseline_technology) ** (1.0 / depth)
            if depth > 0 and baseline_technology != 0
            else 0.0
        )
        rows.append(
            {
                "path_id": " <- ".join(path),
                "path_nodes": list(path),
                "demand_gateway_node": path[0],
                "terminal_emitter_node": path[-1],
                "depth": depth,
                "baseline_contribution": float(base_factors["contribution"]),
                "comparison_contribution": float(comparison_factors["contribution"]),
                "delta_path_contribution": delta,
                "baseline_footprint_share": (
                    float(base_factors["contribution"]) / base_footprint
                    if base_footprint
                    else np.nan
                ),
                "comparison_footprint_share": (
                    float(comparison_factors["contribution"]) / comparison_footprint
                    if comparison_footprint
                    else np.nan
                ),
                "baseline_terminal_intensity": float(base_factors["intensity"]),
                "comparison_terminal_intensity": float(comparison_factors["intensity"]),
                "baseline_geometric_mean_coefficient": geometric_mean,
                "external_node_share": _external_share(path, focal_region),
                **{f"delta_{name}": float(effects[name]) for name in FACTORS},
                "absolute_driver_sum": absolute_driver_sum,
                "dominant_driver": dominant_driver,
                "driver_dominance_share": dominance_share,
                **driver_classification,
                "path_present_in_baseline": bool(base_present),
                "path_present_in_comparison": bool(comparison_present),
                "selected_in_baseline_bounded_spa": bool(path in base_selected),
                "selected_in_comparison_bounded_spa": bool(path in comparison_selected),
                "bounded_spa_selection_status": (
                    "selected in both annual bounded SPA sets"
                    if path in base_selected and path in comparison_selected
                    else "selected in baseline bounded SPA only"
                    if path in base_selected
                    else "selected in comparison bounded SPA only"
                    if path in comparison_selected
                    else "not selected in either bounded SPA set"
                ),
                "path_identity_status": path_identity_status,
                "temporal_status": temporal_status,
                "driver_profile": driver_profile,
                "materiality_tolerance_tCO2": tolerance,
                "baseline_edge_coefficients": base_factors["edge_coefficients"],
                "comparison_edge_coefficients": comparison_factors["edge_coefficients"],
            }
        )
    return annotate_path_reconfiguration(pd.DataFrame(rows))


def _safe_log10(values: np.ndarray, floor: float = 1e-15) -> np.ndarray:
    return np.log10(np.maximum(np.asarray(values, dtype=float), floor))


def cluster_baseline_paths(
    panel: pd.DataFrame,
    random_state: int = 20260903,
    k_min: int = 2,
    k_max: int = 6,
    minimum_cluster_fraction: float = 0.01,
    stability_runs: int = 5,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, Any]]:
    """Classify baseline-positive upstream paths and freeze their classes.

    Contribution share, terminal intensity and coefficient strength are log
    transformed before z-standardization to reduce domination by extreme
    right-skewed values.  Candidate k values producing immaterial singleton or
    near-singleton clusters are rejected before silhouette-based selection.
    """
    from sklearn.cluster import KMeans
    from sklearn.metrics import adjusted_rand_score, silhouette_score

    out = panel.copy()
    out["cluster_id"] = np.nan
    out["structural_path_class"] = ""
    out.loc[out["depth"] == 0, "structural_path_class"] = DIRECT_CLASS

    if len(out) and "materiality_tolerance_tCO2" in out.columns:
        tolerance = float(pd.to_numeric(out["materiality_tolerance_tCO2"], errors="coerce").dropna().iloc[0])
    elif len(out):
        magnitude = max(
            float(pd.to_numeric(out.get("baseline_contribution", 0.0), errors="coerce").abs().max()),
            float(pd.to_numeric(out.get("comparison_contribution", 0.0), errors="coerce").abs().max()),
        )
        tolerance = max(1e-12, magnitude * 1e-10)
    else:
        tolerance = 1e-12
    emergent = (out["depth"] >= 1) & (out["baseline_contribution"].abs() <= tolerance) & (
        out["comparison_contribution"].abs() > tolerance
    )
    out.loc[emergent, "structural_path_class"] = EMERGENT_CLASS

    cluster_index = out.index[
        (out["depth"] >= 1)
        & (out["baseline_contribution"].abs() > tolerance)
    ]
    if len(cluster_index) < 4:
        out.loc[out["structural_path_class"] == "", "structural_path_class"] = (
            "Unclassified negligible upstream pathways"
        )
        return out, pd.DataFrame(), {
            "selected_k": 0,
            "silhouette": np.nan,
            "note": "Insufficient baseline-positive upstream paths for clustering",
        }

    raw_feature_names = [
        "baseline_footprint_share",
        "depth",
        "baseline_terminal_intensity",
        "baseline_geometric_mean_coefficient",
        "external_node_share",
    ]
    transformed_feature_names = [
        "log10_baseline_footprint_share",
        "depth",
        "log10_baseline_terminal_intensity",
        "log10_baseline_geometric_mean_coefficient",
        "external_node_share",
    ]

    raw = out.loc[cluster_index, raw_feature_names].replace([np.inf, -np.inf], np.nan).fillna(0.0)
    transformed = pd.DataFrame(
        {
            "log10_baseline_footprint_share": _safe_log10(raw["baseline_footprint_share"].abs().to_numpy()),
            "depth": raw["depth"].to_numpy(dtype=float),
            "log10_baseline_terminal_intensity": _safe_log10(raw["baseline_terminal_intensity"].abs().to_numpy()),
            "log10_baseline_geometric_mean_coefficient": _safe_log10(raw["baseline_geometric_mean_coefficient"].abs().to_numpy()),
            "external_node_share": raw["external_node_share"].to_numpy(dtype=float),
        },
        index=cluster_index,
    )
    means = transformed.mean(axis=0)
    stds = transformed.std(axis=0, ddof=0)
    stds = stds.where(stds.abs() > np.finfo(float).eps, 1.0)
    standardized = ((transformed - means) / stds).to_numpy(dtype=float)

    minimum_size = max(10, int(math.ceil(len(cluster_index) * minimum_cluster_fraction)))
    maximum_k = min(int(k_max), len(standardized) - 1)
    diagnostics: list[dict[str, Any]] = []
    candidates: list[tuple[float, int, KMeans, np.ndarray]] = []
    for k in range(int(k_min), maximum_k + 1):
        model = KMeans(n_clusters=k, n_init=10, max_iter=300, random_state=random_state)
        labels = model.fit_predict(standardized)
        counts = np.bincount(labels, minlength=k)
        valid_size = bool(counts.min() >= minimum_size)
        silhouette = (
            float(
                silhouette_score(
                    standardized,
                    labels,
                    sample_size=min(1500, len(standardized)),
                    random_state=random_state,
                )
            )
            if valid_size and len(set(labels)) > 1
            else np.nan
        )
        diagnostics.append(
            {
                "k": k,
                "silhouette": silhouette,
                "inertia": float(model.inertia_),
                "minimum_cluster_size": int(counts.min()),
                "maximum_cluster_size": int(counts.max()),
                "minimum_required_size": minimum_size,
                "eligible_for_selection": valid_size,
                "cluster_sizes": json.dumps(counts.tolist()),
            }
        )
        if valid_size and np.isfinite(silhouette):
            candidates.append((silhouette, k, model, labels))

    if not candidates:
        raise RuntimeError("No candidate k produced materially sized pathway clusters")
    silhouette, selected_k, selected_model, selected_labels = max(candidates, key=lambda item: (item[0], -item[1]))

    original_centroids = raw.assign(cluster_id=selected_labels).groupby("cluster_id").mean(numeric_only=True).reset_index()
    standardized_centroids = pd.DataFrame(
        selected_model.cluster_centers_, columns=transformed_feature_names
    )
    standardized_centroids.insert(0, "cluster_id", range(selected_k))

    if selected_k == 2:
        rank_score = (
            original_centroids["depth"].rank()
            + original_centroids["external_node_share"].rank()
            + original_centroids["baseline_terminal_intensity"].rank()
        )
        deep_cluster = int(original_centroids.loc[rank_score.idxmax(), "cluster_id"])
        other_cluster = next(cluster for cluster in range(selected_k) if cluster != deep_cluster)
        label_map = {deep_cluster: DEEP_CLASS, other_cluster: SHALLOW_CLASS}
    else:
        label_map = {
            cluster: f"Baseline upstream pathway cluster {cluster + 1}"
            for cluster in range(selected_k)
        }

    out.loc[cluster_index, "cluster_id"] = selected_labels
    out.loc[cluster_index, "structural_path_class"] = [
        label_map[int(label)] for label in selected_labels
    ]
    out.loc[out["structural_path_class"] == "", "structural_path_class"] = (
        "Unclassified negligible upstream pathways"
    )
    original_centroids["structural_path_class"] = original_centroids["cluster_id"].map(label_map)
    standardized_centroids["structural_path_class"] = standardized_centroids["cluster_id"].map(label_map)

    stability_scores: list[float] = []
    for offset in range(1, int(stability_runs) + 1):
        alternate = KMeans(
            n_clusters=selected_k,
            n_init=5,
            max_iter=300,
            random_state=random_state + offset,
        ).fit_predict(standardized)
        stability_scores.append(float(adjusted_rand_score(selected_labels, alternate)))

    leave_one_out: list[dict[str, Any]] = []
    for feature_index, feature_name in enumerate(transformed_feature_names):
        reduced = np.delete(standardized, feature_index, axis=1)
        alternate = KMeans(
            n_clusters=selected_k,
            n_init=10,
            max_iter=300,
            random_state=random_state,
        ).fit_predict(reduced)
        leave_one_out.append(
            {
                "excluded_feature": feature_name,
                "adjusted_rand_index": float(
                    adjusted_rand_score(selected_labels, alternate)
                ),
            }
        )

    cluster_information = {
        "selected_k": int(selected_k),
        "silhouette": float(silhouette),
        "random_state": int(random_state),
        "baseline_year": 2014,
        "classification_is_frozen": True,
        "raw_features": raw_feature_names,
        "transformed_features": transformed_feature_names,
        "feature_weighting": "log transforms where declared, followed by z-standardized symmetric Euclidean distance",
        "minimum_cluster_fraction": float(minimum_cluster_fraction),
        "silhouette_sample_size": int(min(1500, len(standardized))),
        "kmeans_n_init_candidate": 10,
        "kmeans_n_init_stability": 5,
        "minimum_cluster_size": int(minimum_size),
        "cluster_labels_assigned": "ex post from empirical centroids",
        "centroids": original_centroids.to_dict(orient="records"),
        "standardized_centroids": standardized_centroids.to_dict(orient="records"),
        "stability_adjusted_rand_index_min": float(min(stability_scores)),
        "stability_adjusted_rand_index_mean": float(np.mean(stability_scores)),
        "leave_one_feature_out": leave_one_out,
    }
    return out, pd.DataFrame(diagnostics), cluster_information


def mark_dominant_display_paths(
    panel: pd.DataFrame,
    target_share: float = 0.87,
    *,
    full_comparison_footprint: float | None = None,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Mark the smallest comparison-year path subset covering the target.

    U17 supplies ``full_comparison_footprint`` so the target is 87% of the
    complete focal-company footprint.  Omitting it preserves the historical
    represented-mass denominator for compatibility with archived validation.
    All bounded represented paths remain authoritative for participation.
    """
    target_share = float(target_share)
    if not np.isfinite(target_share) or not 0.0 < target_share <= 1.0:
        raise ValueError("Path display target_share must be finite and in (0, 1].")
    out = panel.copy()
    out["in_dominant_display_set"] = False
    ordered = out.sort_values(
        ["comparison_contribution", "path_id"], ascending=[False, True], kind="mergesort"
    )
    represented_total = float(ordered["comparison_contribution"].clip(lower=0).sum())
    denominator = (
        float(full_comparison_footprint)
        if full_comparison_footprint is not None
        else represented_total
    )
    if not np.isfinite(denominator) or denominator < 0.0:
        raise ValueError("Path display denominator must be finite and non-negative.")
    denominator_basis = (
        "complete focal-company footprint"
        if full_comparison_footprint is not None
        else "bounded represented path mass (legacy compatibility)"
    )
    if represented_total <= 0 or denominator <= 0:
        return out, {
            "target_share": target_share,
            "target_share_of_represented": target_share if full_comparison_footprint is None else None,
            "target_share_of_full_footprint": target_share if full_comparison_footprint is not None else None,
            "target_denominator": denominator_basis,
            "dominant_path_count": 0,
            "represented_total_tCO2": represented_total,
            "achieved_share_of_represented": 0.0,
            "achieved_share_of_full_footprint": 0.0,
            "threshold_reached": False,
            "target_shortfall_tCO2": target_share * denominator,
        }
    cumulative = ordered["comparison_contribution"].clip(lower=0).cumsum() / denominator
    reached = np.flatnonzero(cumulative.to_numpy(dtype=float) >= target_share)
    cutoff = int(reached[0]) + 1 if len(reached) else len(ordered)
    selected_index = ordered.iloc[:cutoff].index
    out.loc[selected_index, "in_dominant_display_set"] = True
    selected_total = float(
        out.loc[selected_index, "comparison_contribution"].clip(lower=0).sum()
    )
    achieved_represented = selected_total / represented_total if represented_total else 0.0
    achieved_full = (
        selected_total / float(full_comparison_footprint)
        if full_comparison_footprint
        else 0.0
    )
    achieved_target_basis = selected_total / denominator if denominator else 0.0
    return out, {
        "target_share": target_share,
        "target_share_of_represented": target_share if full_comparison_footprint is None else None,
        "target_share_of_full_footprint": target_share if full_comparison_footprint is not None else None,
        "target_denominator": denominator_basis,
        "dominant_path_count": int(cutoff),
        "represented_total_tCO2": represented_total,
        "selected_total_tCO2": selected_total,
        "achieved_share_of_represented": achieved_represented,
        "achieved_share_of_full_footprint": achieved_full,
        "achieved_share_on_target_denominator": achieved_target_basis,
        "threshold_reached": bool(achieved_target_basis >= target_share),
        "target_shortfall_tCO2": max(0.0, target_share * denominator - selected_total),
        "target_overshoot_tCO2": max(0.0, selected_total - target_share * denominator),
        "authority_boundary": (
            f"The {target_share:.0%} subset is for display and concise reporting on the {denominator_basis} denominator. "
            "All bounded represented paths are used for emissions-weighted pathway participation."
        ),
    }


def _relevance_levels(values: pd.Series) -> tuple[pd.Series, dict[str, float | None]]:
    numeric = pd.to_numeric(values, errors="coerce").fillna(0.0)
    positive = numeric[numeric > 0]
    if positive.empty:
        return pd.Series("None", index=values.index), {"q25": None, "q75": None}
    q25 = float(positive.quantile(0.25))
    q75 = float(positive.quantile(0.75))
    labels = pd.Series(index=values.index, dtype="object")
    labels.loc[numeric <= 0] = "None"
    labels.loc[(numeric > 0) & (numeric <= q25)] = "Low"
    labels.loc[(numeric > q25) & (numeric < q75)] = "Moderate"
    labels.loc[numeric >= q75] = "High"
    return labels.fillna("Moderate"), {"q25": q25, "q75": q75}


def compute_pathway_participation(
    panel: pd.DataFrame,
    node_codes: Sequence[str],
    full_comparison_footprint: float,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Compute non-additive emissions-weighted node participation by path role."""
    columns = (
        "any_role_mass",
        "demand_gateway_mass",
        "transmission_mass",
        "terminal_emitter_mass",
        "dominant_set_any_role_mass",
    )
    accumulator: dict[str, dict[str, float]] = {
        str(code): {column: 0.0 for column in columns} for code in node_codes
    }
    represented_total = float(panel["comparison_contribution"].clip(lower=0).sum())
    dominant_total = float(
        panel.loc[panel["in_dominant_display_set"], "comparison_contribution"]
        .clip(lower=0)
        .sum()
    )

    for record in panel.to_dict(orient="records"):
        contribution = max(float(record.get("comparison_contribution", 0.0)), 0.0)
        if contribution <= 0:
            continue
        nodes = [str(node) for node in record["path_nodes"]]
        for node in set(nodes):
            accumulator[node]["any_role_mass"] += contribution
            if bool(record.get("in_dominant_display_set", False)):
                accumulator[node]["dominant_set_any_role_mass"] += contribution
        accumulator[nodes[0]]["demand_gateway_mass"] += contribution
        accumulator[nodes[-1]]["terminal_emitter_mass"] += contribution
        for node in set(nodes[1:-1]):
            accumulator[node]["transmission_mass"] += contribution

    rows: list[dict[str, Any]] = []
    for node in node_codes:
        values = accumulator[str(node)]
        row: dict[str, Any] = {"node_code": str(node), **values}
        for name in (
            "any_role",
            "demand_gateway",
            "transmission",
            "terminal_emitter",
        ):
            mass = values[f"{name}_mass"]
            row[f"spa_{name}_participation_share_of_represented"] = (
                mass / represented_total if represented_total else 0.0
            )
            row[f"spa_{name}_participation_share_of_full_footprint"] = (
                mass / full_comparison_footprint if full_comparison_footprint else 0.0
            )
        row["spa_dominant_set_any_role_share"] = (
            values["dominant_set_any_role_mass"] / dominant_total
            if dominant_total
            else 0.0
        )
        row["appears_in_dominant_display_set"] = values["dominant_set_any_role_mass"] > 0
        rows.append(row)

    frame = pd.DataFrame(rows)
    frame["spa_relevance_level"], thresholds = _relevance_levels(
        frame["spa_any_role_participation_share_of_represented"]
    )
    frame = frame.sort_values(
        ["spa_any_role_participation_share_of_represented", "node_code"],
        ascending=[False, True],
        kind="mergesort",
    ).reset_index(drop=True)
    metadata = {
        "represented_path_mass_tCO2": represented_total,
        "complete_footprint_tCO2": float(full_comparison_footprint),
        "represented_footprint_share": (
            represented_total / full_comparison_footprint
            if full_comparison_footprint
            else 0.0
        ),
        "dominant_display_path_mass_tCO2": dominant_total,
        "spa_relevance_descriptive_quantiles": thresholds,
        "non_additivity_note": (
            "SPA participation is non-additive across nodes because one path can contain a demand gateway, transmission nodes and a terminal emitter. Do not sum node participation shares as an emissions inventory."
        ),
        "authoritative_calculation": "all bounded represented paths",
        "coverage_aligned_display_set_role": "display and concise reporting only",
    }
    return frame, metadata


def _edge_shapley(base_edges: Sequence[float], comparison_edges: Sequence[float]) -> np.ndarray:
    """Exact edge-level Shapley allocation for a product, using subsets.

    The subset form is algebraically equivalent to averaging all edge-change
    permutations but avoids factorial runtime for the tens of thousands of SPA
    paths processed by the integrated method.
    """
    from itertools import combinations
    from math import factorial

    base = np.asarray(base_edges, dtype=float)
    comparison = np.asarray(comparison_edges, dtype=float)
    n = len(base)
    if n == 0:
        return np.array([], dtype=float)
    if len(comparison) != n:
        raise ValueError("Base and comparison edge vectors must have equal length")

    effects = np.zeros(n, dtype=float)
    denominator = float(factorial(n))
    all_indices = tuple(range(n))
    for i in all_indices:
        others = tuple(j for j in all_indices if j != i)
        delta_i = float(comparison[i] - base[i])
        if delta_i == 0.0:
            continue
        value = 0.0
        for size in range(n):
            coefficient = factorial(size) * factorial(n - size - 1) / denominator
            for subset in combinations(others, size):
                selected = set(subset)
                product = delta_i
                for j in others:
                    product *= comparison[j] if j in selected else base[j]
                value += coefficient * product
        effects[i] = value
    return effects


def allocate_temporal_drivers_to_nodes(
    panel: pd.DataFrame,
    node_codes: Sequence[str],
) -> pd.DataFrame:
    """Allocate path-level temporal effects to nodes using role-consistent rules."""
    accumulator: dict[str, dict[str, float]] = {
        str(code): {f"node_delta_{factor}": 0.0 for factor in FACTORS}
        for code in node_codes
    }

    def add(node: str, factor: str, value: float) -> None:
        accumulator[str(node)][f"node_delta_{factor}"] += float(value)

    for record in panel.to_dict(orient="records"):
        nodes = [str(node) for node in record["path_nodes"]]
        add(nodes[-1], "intensity", float(record["delta_intensity"]))
        add(nodes[0], "composition", float(record["delta_composition"]))
        add(nodes[0], "scale", float(record["delta_scale"]))
        technology_effect = float(record["delta_technology"])
        if len(nodes) > 1:
            edge_effects = _edge_shapley(
                record["baseline_edge_coefficients"],
                record["comparison_edge_coefficients"],
            )
            denominator = float(edge_effects.sum())
            if abs(denominator) <= np.finfo(float).eps:
                allocation = np.repeat(
                    technology_effect / len(edge_effects), len(edge_effects)
                )
            else:
                allocation = technology_effect * edge_effects / denominator
            for supplier, value in zip(nodes[1:], allocation):
                add(supplier, "technology", float(value))

    frame = pd.DataFrame(
        [{"node_code": node, **values} for node, values in accumulator.items()]
    )
    effect_columns = [f"node_delta_{factor}" for factor in FACTORS]
    values = frame[effect_columns].to_numpy(dtype=float)
    frame["node_net_driver_effect"] = values.sum(axis=1)
    frame["node_absolute_driver_exposure"] = np.abs(values).sum(axis=1)
    dominant_indices = np.argmax(np.abs(values), axis=1)
    frame["node_dominant_driver"] = [FACTORS[index] for index in dominant_indices]
    frame["node_driver_dominance_share"] = np.divide(
        np.max(np.abs(values), axis=1),
        frame["node_absolute_driver_exposure"].to_numpy(dtype=float),
        out=np.full(len(frame), np.nan),
        where=frame["node_absolute_driver_exposure"].to_numpy(dtype=float) > np.finfo(float).eps,
    )
    tolerance = max(1e-12, float(frame["node_absolute_driver_exposure"].max()) * 1e-10)
    frame.loc[frame["node_absolute_driver_exposure"] <= tolerance, "node_dominant_driver"] = ""
    frame["node_temporal_status"] = np.select(
        [
            frame["node_absolute_driver_exposure"] <= tolerance,
            frame["node_net_driver_effect"].abs() <= tolerance,
            frame["node_net_driver_effect"] > tolerance,
        ],
        [
            "stable/no represented temporal change",
            "stable net/offsetting drivers",
            "worsening",
        ],
        default="improving",
    )
    return frame.sort_values(
        ["node_absolute_driver_exposure", "node_code"],
        ascending=[False, True],
        kind="mergesort",
    ).reset_index(drop=True)


# Backward-compatible name retained for U10 tests and callers.
def allocate_to_nodes(panel: pd.DataFrame, node_codes: Sequence[str] | None = None) -> pd.DataFrame:
    if node_codes is None:
        node_codes = sorted(
            {
                str(node)
                for nodes in panel["path_nodes"]
                for node in nodes
            }
        )
    return allocate_temporal_drivers_to_nodes(panel, node_codes)


def summarize_classes(
    panel: pd.DataFrame,
    base_footprint: float | None = None,
    comparison_footprint: float | None = None,
) -> pd.DataFrame:
    aggregations: dict[str, str] = {
        "path_id": "count",
        "depth": "mean",
        "external_node_share": "mean",
        "baseline_contribution": "sum",
        "comparison_contribution": "sum",
        "delta_path_contribution": "sum",
    }
    aggregations.update({f"delta_{factor}": "sum" for factor in FACTORS})
    out = (
        panel.groupby("structural_path_class", dropna=False)
        .agg(aggregations)
        .rename(columns={"path_id": "path_count"})
        .reset_index()
    )
    if base_footprint:
        out["baseline_share_of_full_footprint"] = out["baseline_contribution"] / base_footprint
    if comparison_footprint:
        out["comparison_share_of_full_footprint"] = out["comparison_contribution"] / comparison_footprint
    effect_columns = [f"delta_{factor}" for factor in FACTORS]
    values = out[effect_columns].to_numpy(dtype=float)
    dominant_indices = np.argmax(np.abs(values), axis=1)
    out["dominant_driver"] = [FACTORS[index] for index in dominant_indices]
    absolute_sums = np.abs(values).sum(axis=1)
    out["driver_dominance_share"] = np.divide(
        np.max(np.abs(values), axis=1),
        absolute_sums,
        out=np.full(len(out), np.nan),
        where=absolute_sums > np.finfo(float).eps,
    )
    out["temporal_status"] = np.select(
        [out["delta_path_contribution"] > 1e-12, out["delta_path_contribution"] < -1e-12],
        ["worsening", "improving"],
        default="stable",
    )
    out["driver_profile"] = [
        (f"{driver}-driven {status}" if pd.notna(share) and share >= 0.5 else f"mixed-driver {status}")
        for driver, share, status in zip(
            out["dominant_driver"], out["driver_dominance_share"], out["temporal_status"]
        )
    ]
    return out


def _dli_levels(values: pd.Series) -> tuple[pd.Series, dict[str, float]]:
    numeric = pd.to_numeric(values, errors="coerce")
    q25 = float(numeric.quantile(0.25))
    q75 = float(numeric.quantile(0.75))
    levels = pd.Series("Moderate", index=values.index)
    levels.loc[numeric <= q25] = "Low"
    levels.loc[numeric >= q75] = "High"
    return levels, {"q25": q25, "q75": q75}


def _spa_dli_matrix_class(dli_level: str, spa_level: str) -> str:
    mapping = {
        ("High", "High"): "Priority pathway-leverage node",
        ("High", "Moderate"): "Strategic leverage node",
        ("High", "Low"): "Network-leverage node",
        ("High", "None"): "System-level leverage node",
        ("Moderate", "High"): "Carbon-pathway priority node",
        ("Moderate", "Moderate"): "Balanced intervention node",
        ("Moderate", "Low"): "Secondary leverage node",
        ("Moderate", "None"): "Secondary system-level node",
        ("Low", "High"): "Pathway-critical, low-leverage node",
        ("Low", "Moderate"): "Pathway-relevant monitoring node",
        ("Low", "Low"): "Low-priority node",
        ("Low", "None"): "Peripheral node",
    }
    return mapping.get((str(dli_level), str(spa_level)), "Unclassified node")


def _strategic_classification(row: pd.Series) -> str:
    spa = str(row.get("spa_relevance_level", "None"))
    dli = str(row.get("dli_level", "Low"))
    status = str(row.get("node_temporal_status", "stable/no represented temporal change"))
    high_path = spa == "High"
    high_dli = dli == "High"
    worsening = status == "worsening"
    improving = status == "improving"
    stable = status.startswith("stable")

    if high_path and worsening and high_dli:
        return "Transformational pathway-leverage priority"
    if high_path and stable and high_dli:
        return "Persistent strategic carbon priority"
    if high_path and improving and high_dli:
        return "Material improving leverage node"
    if high_path and worsening:
        return "Urgent pathway-specific intervention"
    if high_path and stable:
        return "Persistent targeted decarbonization"
    if high_path and improving:
        return "Material improving pathway"
    if spa in {"Low", "None"} and worsening and high_dli:
        return "Emerging systemic carbon risk"
    if spa in {"Low", "None"} and stable and high_dli:
        return "System-level governance or monitoring node"
    if spa in {"Low", "None"} and improving and high_dli:
        return "Systemic node with improving carbon context"
    if spa == "Moderate" and worsening:
        return "Balanced targeted intervention"
    if spa == "Moderate" and stable:
        return "Pathway-relevant monitoring node"
    if spa == "Moderate" and improving:
        return "Improving pathway-relevant node"
    return "Lower current strategic priority"


def merge_node_strategy(
    participation: pd.DataFrame,
    temporal: pd.DataFrame,
    critic_ranking: pd.DataFrame,
) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Merge current SPA relevance, temporal drivers and systemic leverage."""
    required = {"node_code", "DLI", "dli_rank", "dominant_dli_component"}
    missing = sorted(required.difference(critic_ranking.columns))
    if missing:
        raise ValueError(f"CRITIC-DLI ranking is missing columns: {missing}")
    dli_columns = [
        column
        for column in [
            "node_code", "region", "sector", "DLI", "dli_rank",
            "dominant_dli_component",
            *[f"{factor}_norm_critic" for factor in ("BC", "PR", "CDR", "IC")],
            *[f"{factor}_critic_weight_contribution" for factor in ("BC", "PR", "CDR", "IC")],
            *[f"weight_{factor}" for factor in ("BC", "PR", "CDR", "IC")],
        ]
        if column in critic_ranking.columns
    ]
    out = participation.merge(temporal, on="node_code", how="outer")
    out = out.merge(
        critic_ranking[dli_columns].drop_duplicates("node_code"),
        on="node_code",
        how="left",
    )
    out["dli_level"], dli_thresholds = _dli_levels(out["DLI"])
    out["spa_dli_matrix_class"] = [
        _spa_dli_matrix_class(dli, spa)
        for dli, spa in zip(out["dli_level"], out["spa_relevance_level"])
    ]
    out["strategic_classification"] = out.apply(_strategic_classification, axis=1)
    out["strategic_interpretation"] = (
        "Current pathway relevance="
        + out["spa_relevance_level"].astype(str)
        + "; temporal status="
        + out["node_temporal_status"].astype(str)
        + "; systemic leverage="
        + out["dli_level"].astype(str)
        + "."
    )
    out["classification_note"] = (
        "H/M/L categories are descriptive distributional summaries; continuous SPA participation, temporal Shapley effects and CRITIC-DLI remain authoritative."
    )
    out = out.sort_values(["dli_rank", "node_code"], kind="mergesort").reset_index(drop=True)
    return out, {
        "dli_descriptive_quantiles": dli_thresholds,
        "spa_dli_matrix_is_weight_free": True,
        "additional_composite_score_created": False,
    }
