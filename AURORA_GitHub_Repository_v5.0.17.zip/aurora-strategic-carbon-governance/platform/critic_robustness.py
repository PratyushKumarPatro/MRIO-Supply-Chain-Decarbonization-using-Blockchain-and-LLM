"""Weight robustness centred exclusively on the authoritative CRITIC vector."""
from __future__ import annotations
from pathlib import Path
import json
import math
import os
import numpy as np
import pandas as pd

from critic_dli_core import CRITERIA, critic_weights, pooled_minmax, score_and_rank


def _spearman(a: np.ndarray, b: np.ndarray) -> float:
    return float(pd.Series(a).rank(method="average").corr(pd.Series(b).rank(method="average"), method="pearson"))


def _renormalized_change(base: np.ndarray, idx: int, delta: float) -> np.ndarray:
    w = base.astype(float).copy()
    target = min(max(w[idx] + delta, 1e-8), 1.0 - 3e-8)
    remaining_old = float(w.sum() - w[idx])
    if remaining_old <= 0:
        raise ValueError("Invalid base weights")
    scale = (1.0 - target) / remaining_old
    for j in range(len(w)):
        if j != idx:
            w[j] *= scale
    w[idx] = target
    return w / w.sum()


def _scenario_metrics(nodes: pd.DataFrame, base_ranks: np.ndarray, base_top: set[str], weights: np.ndarray, top_k: int) -> dict:
    z = nodes[[f"{c}_norm_critic" for c in CRITERIA]].to_numpy(dtype=float)
    scores = z @ weights
    order = np.argsort(-scores, kind="mergesort")
    ranks = np.empty(len(order), dtype=int); ranks[order] = np.arange(1, len(order)+1)
    top_nodes = set(nodes.iloc[order[:top_k]]["node_code"].astype(str))
    overlap = len(base_top & top_nodes)
    union = len(base_top | top_nodes)
    return {
        "spearman_rank_correlation": _spearman(base_ranks, ranks),
        "top_k_overlap_count": overlap,
        "top_k_overlap_proportion": overlap / top_k,
        "top_k_jaccard": overlap / union if union else 1.0,
        "max_abs_rank_change": int(np.max(np.abs(ranks-base_ranks))),
        "mean_abs_rank_change": float(np.mean(np.abs(ranks-base_ranks))),
        "top_k_node_codes": " | ".join(nodes.iloc[order[:top_k]]["node_code"].astype(str)),
        "ranks": ranks,
        "scores": scores,
    }


def run_critic_robustness(runtime_dir: str | Path | None = None, samples: int = 5000, concentration: float = 80.0, seed: int = 20260902, top_k: int = 15) -> dict:
    runtime = Path(runtime_dir or os.environ.get("SCIG_RUNTIME_DIR") or Path(__file__).resolve().parent / "runtime")
    outdir = runtime / "active_analytics"
    raw_files = [outdir / f"critic_raw_network_metrics_{y}.csv" for y in (2014, 2017)]
    if not all(p.exists() for p in raw_files):
        raise FileNotFoundError("Both annual raw network metric files are required before CRITIC robustness can run")
    pooled = pd.concat([pd.read_csv(p) for p in raw_files], ignore_index=True)
    critic = critic_weights(pooled, correlation_method="pearson", scope="pooled-2014-2017")
    scored = score_and_rank(pooled, critic)
    target_year = 2017
    nodes = scored.loc[scored["year"] == target_year].sort_values("dli_rank").reset_index(drop=True)
    base_ranks = nodes["dli_rank"].to_numpy(dtype=int)
    base_top = set(nodes.nsmallest(top_k, "dli_rank")["node_code"].astype(str))
    base_w = np.array([critic.weights[c] for c in CRITERIA], dtype=float)
    rows = []
    rank_samples = []
    score_samples = []
    sid = 0
    for idx, c in enumerate(CRITERIA):
        for delta in (-0.10, -0.05, 0.05, 0.10):
            w = _renormalized_change(base_w, idx, delta)
            m = _scenario_metrics(nodes, base_ranks, base_top, w, top_k)
            sid += 1
            rows.append({"scenario_id": f"one_way_{c}_{delta:+.2f}", "analysis_mode": "one_way", **{f"weight_{cc}": w[j] for j,cc in enumerate(CRITERIA)}, **{k:v for k,v in m.items() if k not in {"ranks","scores"}}})
            rank_samples.append(m["ranks"]); score_samples.append(m["scores"])
    rng = np.random.default_rng(int(seed))
    alpha = np.maximum(base_w * float(concentration), 1e-8)
    mc_rows = []
    mc_ranks = []
    mc_scores = []
    for s, w in enumerate(rng.dirichlet(alpha, size=int(samples)), start=1):
        m = _scenario_metrics(nodes, base_ranks, base_top, w, top_k)
        mc_rows.append({"scenario_id": f"monte_carlo_{s:05d}", "analysis_mode": "monte_carlo", **{f"weight_{cc}": w[j] for j,cc in enumerate(CRITERIA)}, **{k:v for k,v in m.items() if k not in {"ranks","scores"}}})
        mc_ranks.append(m["ranks"]); mc_scores.append(m["scores"])
    one_way = pd.DataFrame(rows)
    monte = pd.DataFrame(mc_rows)
    rr = np.vstack(mc_ranks); ss = np.vstack(mc_scores)
    stability = nodes[["node_code", "dli_rank", "DLI"]].rename(columns={"dli_rank":"baseline_rank", "DLI":"baseline_dli"})
    stability["monte_carlo_rank_min"] = rr.min(axis=0)
    stability["monte_carlo_rank_max"] = rr.max(axis=0)
    stability["monte_carlo_mean_rank"] = rr.mean(axis=0)
    stability["monte_carlo_score_min"] = ss.min(axis=0)
    stability["monte_carlo_score_max"] = ss.max(axis=0)
    stability["monte_carlo_top5_inclusion_probability"] = (rr <= 5).mean(axis=0)
    stability[f"monte_carlo_top{top_k}_inclusion_probability"] = (rr <= top_k).mean(axis=0)
    summary = {
        "method": "CRITIC-centred DLI robustness",
        "reference_year": target_year,
        "critic_weights": critic.weights,
        "samples": int(samples),
        "concentration": float(concentration),
        "seed": int(seed),
        "top_k": int(top_k),
        "mean_spearman": float(monte["spearman_rank_correlation"].mean()),
        "mean_top_k_overlap": float(monte["top_k_overlap_count"].mean()),
        "exact_top_k_probability": float((monte["top_k_overlap_count"] == top_k).mean()),
    }
    one_way.to_csv(outdir / "critic_one_way_weight_scenarios.csv", index=False)
    monte.to_csv(outdir / "critic_monte_carlo_weight_scenarios.csv", index=False)
    stability.to_csv(outdir / "critic_node_rank_stability.csv", index=False)
    (outdir / "critic_dli_robustness_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")
    try:
        with pd.ExcelWriter(outdir / "CRITIC_DLI_Robustness_Results.xlsx", engine="openpyxl") as writer:
            pd.DataFrame([summary | {"critic_weights": json.dumps(critic.weights)}]).to_excel(
                writer, sheet_name="Summary", index=False
            )
            one_way.to_excel(writer, sheet_name="One_Way", index=False)
            monte.to_excel(writer, sheet_name="Monte_Carlo", index=False)
            stability.to_excel(writer, sheet_name="Node_Stability", index=False)
    except Exception:
        pass
    return summary
