"""Read-only post-deployment audit for the current governed methodology lifecycle.

The validator refreshes the lifecycle against the live chain and immutable
content store by giving :func:`dapp_lifecycle.refresh_lifecycle` a temporary
copy of ``deployment.json``.  The deployed state file, contracts, governed
inputs, and analytical artifacts are therefore never changed by this audit.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from release_identity import RELEASE_IDENTITY


PACKAGE_ROOT = Path(__file__).resolve().parent
DEFAULT_DEPLOYMENT_STATE = PACKAGE_ROOT / "deployment.json"
SCHEMA_VERSION = "intervention_abatement_governance_runtime_validation_v1"
SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")


def _lifecycle_module():
    """Import the Web3 lifecycle only when a live refresh is requested."""

    import dapp_lifecycle

    return dapp_lifecycle


def _load_verified_content(content_hash: str) -> dict[str, Any]:
    return _lifecycle_module()._load_content(content_hash)


def _refresh_lifecycle(path: str | Path) -> dict[str, Any]:
    return _lifecycle_module().refresh_lifecycle(path)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256_bytes(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def _is_sha256(value: Any) -> bool:
    return bool(SHA256_RE.fullmatch(str(value or "").strip()))


def _integer_equals(value: Any, expected: int) -> bool:
    try:
        return int(value) == int(expected)
    except (TypeError, ValueError, OverflowError):
        return False


def _nonnegative_integer(value: Any) -> int:
    try:
        return max(0, int(value or 0))
    except (TypeError, ValueError, OverflowError):
        return 0


def _normalised_hashes(value: Any) -> dict[str, str]:
    source = value if isinstance(value, dict) else {}
    return {
        "mrio": str(source.get("mrio", "")).strip().lower(),
        "focal_demand": str(source.get("focal_demand", "")).strip().lower(),
    }


def _result_record(
    active_results: dict[str, Any], kind: str, key: str
) -> dict[str, Any]:
    collection = active_results.get(kind, {})
    if not isinstance(collection, dict):
        return {}
    record = collection.get(key, {})
    return record if isinstance(record, dict) else {}


def _check(
    checks: list[dict[str, Any]],
    check_id: str,
    passed: Any,
    detail: str,
    *,
    observed: Any = None,
) -> None:
    item: dict[str, Any] = {
        "id": check_id,
        "required": True,
        "passed": bool(passed),
        "detail": detail,
    }
    if observed is not None:
        item["observed"] = observed
    checks.append(item)


def _inspect_content_lineage(
    *,
    stage: str,
    record: dict[str, Any],
    expected_operation: str,
    expected_hashes: dict[str, str],
    content_loader: Callable[[str], dict[str, Any]],
    year: int | None = None,
    base_year: int | None = None,
    comparison_year: int | None = None,
) -> dict[str, Any]:
    """Verify one active on-chain result through its immutable local CID."""

    cid = str(record.get("content_hash", "")).strip().lower()
    conditions: dict[str, bool] = {
        "record_present": bool(record),
        "cid_is_sha256": _is_sha256(cid),
    }
    envelope: dict[str, Any] = {}
    if conditions["cid_is_sha256"]:
        try:
            loaded = content_loader(cid)
            envelope = loaded if isinstance(loaded, dict) else {}
        except Exception:
            envelope = {}
    conditions["cid_content_verified"] = bool(envelope)

    material = envelope.get("payload", {}) if isinstance(envelope, dict) else {}
    payload = material.get("payload", {}) if isinstance(material, dict) else {}
    if not isinstance(payload, dict):
        payload = {}
    conditions.update(
        {
            "namespace_matches": str(envelope.get("namespace", ""))
            == expected_operation,
            "operation_matches": str(material.get("operation", ""))
            == expected_operation,
            "active_inputs_match": _normalised_hashes(payload.get("input_hashes"))
            == expected_hashes,
        }
    )

    if year is not None:
        conditions["payload_year_matches"] = _integer_equals(
            payload.get("year"), year
        )
        record_year = record.get("year", record.get("base_year", -1))
        conditions["record_year_matches"] = _integer_equals(record_year, year)
    if base_year is not None:
        conditions["payload_base_year_matches"] = _integer_equals(
            payload.get("base_year"), base_year
        )
        conditions["record_base_year_matches"] = _integer_equals(
            record.get("base_year"), base_year
        )
    if comparison_year is not None:
        conditions["payload_comparison_year_matches"] = _integer_equals(
            payload.get("comparison_year"), comparison_year
        )
        conditions["record_comparison_year_matches"] = _integer_equals(
            record.get("comparison_year"), comparison_year
        )
    if expected_operation == "network_and_critic_dli_analysis" and year == 2017:
        authority = payload.get("temporal_dli_authority", {})
        slices = payload.get("authoritative_dli_slices", {})
        weighting = payload.get("dli_weighting", {})
        weights = weighting.get("weights", {}) if isinstance(weighting, dict) else {}
        weights_valid = False
        try:
            weights_valid = bool(
                weighting.get("method") == "pooled Pearson-CRITIC"
                and set(weights) == {"BC", "PR", "CDR", "IC"}
                and all(
                    math.isfinite(float(weights[criterion]))
                    and float(weights[criterion]) >= 0.0
                    for criterion in ("BC", "PR", "CDR", "IC")
                )
                and math.isclose(
                    math.fsum(
                        float(weights[criterion])
                        for criterion in ("BC", "PR", "CDR", "IC")
                    ),
                    1.0,
                    rel_tol=1e-10,
                    abs_tol=1e-12,
                )
            )
        except (TypeError, ValueError, OverflowError):
            weights_valid = False
        conditions.update(
            {
                "pooled_critic_ready": payload.get("pooled_critic_ready") is True,
                "pooled_authority_declared": isinstance(authority, dict)
                and authority.get("method")
                == "one pooled two-year Pearson-CRITIC calculation"
                and authority.get("years") == [2014, 2017],
                "both_authoritative_slices_present": isinstance(slices, dict)
                and all(
                    isinstance(slices.get(str(reference_year)), list)
                    and bool(slices.get(str(reference_year)))
                    for reference_year in (2014, 2017)
                ),
                "pooled_critic_weights_valid": weights_valid,
            }
        )

    result = {
        "stage": stage,
        "content_hash": cid,
        "operation": expected_operation,
        "passed": all(conditions.values()),
        "checks": conditions,
    }
    if "network_result_hash" in payload:
        result["payload_network_result_hash"] = str(
            payload.get("network_result_hash", "")
        ).strip().lower()
    authority = payload.get("temporal_dli_authority", {})
    if isinstance(authority, dict) and "baseline_evidence_network_result_cid" in authority:
        result["payload_temporal_baseline_cid"] = str(
            authority.get("baseline_evidence_network_result_cid", "")
        ).strip().lower()
    return result


def _payload_from_record(
    record: dict[str, Any],
    content_loader: Callable[[str], dict[str, Any]],
) -> dict[str, Any]:
    """Load a CID-verified payload already admitted by the lifecycle refresh."""

    cid = str(record.get("content_hash", "")).strip().lower()
    if not _is_sha256(cid):
        return {}
    try:
        envelope = content_loader(cid)
        material = envelope.get("payload", {})
        payload = material.get("payload", {}) if isinstance(material, dict) else {}
        return payload if isinstance(payload, dict) else {}
    except Exception:
        return {}


def _spa_minimum_prefix_audit(
    spa_payload: dict[str, Any], mrio_payload: dict[str, Any]
) -> dict[str, Any]:
    """Independently verify the complete-footprint denominator and 87% prefix."""

    conditions: dict[str, Any] = {}
    try:
        governed_total = float(mrio_payload.get("company_footprint", float("nan")))
        hotspots = mrio_payload.get("all_hotspots", [])
        hotspot_values = [
            float(row.get("footprint_contribution", float("nan")))
            for row in hotspots
            if isinstance(row, dict)
        ] if isinstance(hotspots, list) else []
        tolerance = max(1e-8, abs(governed_total) * 1e-10)
        conditions["governed_mrio_total_is_reconciled"] = bool(
            math.isfinite(governed_total)
            and governed_total > 0.0
            and hotspot_values
            and all(math.isfinite(value) and value >= 0.0 for value in hotspot_values)
            and math.isclose(
                math.fsum(hotspot_values),
                governed_total,
                rel_tol=1e-10,
                abs_tol=tolerance,
            )
        )

        target = float(spa_payload.get("cumulative_target", float("nan")))
        declared_total = float(spa_payload.get("total_footprint", float("nan")))
        paths = spa_payload.get("paths", [])
        contributions = [
            float(row.get("contribution", float("nan")))
            for row in paths
            if isinstance(row, dict)
        ] if isinstance(paths, list) else []
        reported = math.fsum(contributions)
        required = target * governed_total
        conditions.update(
            {
                "target_is_87_percent": math.isclose(
                    target, 0.87, rel_tol=0.0, abs_tol=1e-12
                ),
                "denominator_equals_governed_mrio_total": math.isfinite(declared_total)
                and math.isclose(
                    declared_total,
                    governed_total,
                    rel_tol=1e-10,
                    abs_tol=tolerance,
                ),
                "reported_count_matches_rows": bool(paths)
                and len(contributions) == len(paths)
                and _integer_equals(spa_payload.get("reported_path_count"), len(paths)),
                "contributions_are_finite_nonnegative_and_sorted": bool(contributions)
                and all(math.isfinite(value) and value >= 0.0 for value in contributions)
                and all(
                    current <= previous + tolerance
                    for previous, current in zip(contributions, contributions[1:])
                ),
                "prefix_reaches_target": reported + tolerance >= required
                and reported <= governed_total + tolerance,
                "prefix_is_minimum": len(contributions) == 1
                or math.fsum(contributions[:-1]) < required - tolerance,
                "threshold_flag_is_true": spa_payload.get("threshold_reached") is True,
                "reported_footprint_reconciles": math.isclose(
                    float(spa_payload.get("reported_path_footprint", float("nan"))),
                    reported,
                    rel_tol=1e-10,
                    abs_tol=tolerance,
                ),
                "reported_share_reconciles": math.isclose(
                    float(spa_payload.get("reported_cumulative_share", float("nan"))),
                    reported / governed_total,
                    rel_tol=1e-10,
                    abs_tol=1e-10,
                ),
                "shortfall_is_zero": 0.0
                <= float(spa_payload.get("target_shortfall", float("nan")))
                <= tolerance,
                "overshoot_reconciles": math.isclose(
                    float(spa_payload.get("target_overshoot", float("nan"))),
                    max(0.0, reported - required),
                    rel_tol=1e-10,
                    abs_tol=tolerance,
                ),
            }
        )
    except (TypeError, ValueError, OverflowError, ZeroDivisionError):
        conditions["payload_arithmetic_is_valid"] = False
    return {
        "passed": bool(conditions) and all(bool(value) for value in conditions.values()),
        "checks": conditions,
    }


def assess_refreshed_state(
    state: dict[str, Any],
    *,
    deployment_state: str | Path,
    content_loader: Callable[[str], dict[str, Any]] = _load_verified_content,
    query_contract_code_present: bool | None,
) -> dict[str, Any]:
    """Assess a state already reconstructed by ``refresh_lifecycle``.

    This function is intentionally pure apart from content reads so it can be
    regression-tested independently of Ganache.
    """

    lifecycle = state.get("lifecycle", {})
    if not isinstance(lifecycle, dict):
        lifecycle = {}
    active_results = state.get("active_results", {})
    if not isinstance(active_results, dict):
        active_results = {}
    active_hashes = _normalised_hashes(state.get("active_input_hashes"))
    checks: list[dict[str, Any]] = []

    expected_architecture = RELEASE_IDENTITY["architecture_version"]
    _check(
        checks,
        "deployment_identity",
        state.get("architecture_version") == expected_architecture,
        "Deployment state uses the current intervention-abatement governance architecture.",
        observed=state.get("architecture_version"),
    )
    _check(
        checks,
        "active_governed_inputs",
        all(_is_sha256(active_hashes[key]) for key in ("mrio", "focal_demand"))
        and bool(lifecycle.get("mrio_data_validated"))
        and bool(lifecycle.get("focal_demand_validated")),
        "Both active governed input hashes are present and match the on-chain validated inputs.",
        observed=active_hashes,
    )

    required_stages = [
        (
            "mrio_2014",
            "mrio",
            "2014",
            "mrio_2014_complete",
            "mrio_carbon_accounting",
            {"year": 2014},
        ),
        (
            "mrio_2017",
            "mrio",
            "2017",
            "mrio_2017_complete",
            "mrio_carbon_accounting",
            {"year": 2017},
        ),
        (
            "spa_2014",
            "spa",
            "2014",
            "spa_2014_complete",
            "structural_path_analysis",
            {"year": 2014},
        ),
        (
            "spa_2017",
            "spa",
            "2017",
            "spa_2017_complete",
            "structural_path_analysis",
            {"year": 2017},
        ),
        (
            "sda_2014_2017",
            "sda",
            "2014-2017",
            "sda_complete",
            "structural_decomposition_analysis",
            {"base_year": 2014, "comparison_year": 2017},
        ),
        (
            "network_dli_2014",
            "network",
            "2014",
            "network_2014_complete",
            "network_and_critic_dli_analysis",
            {"year": 2014},
        ),
        (
            "network_dli_2017",
            "network",
            "2017",
            "network_2017_complete",
            "network_and_critic_dli_analysis",
            {"year": 2017},
        ),
        (
            "aurora_2017",
            "aurora",
            "2017",
            "aurora_2017_complete",
            "regional_sourcing_opportunity_analysis",
            {"year": 2017},
        ),
    ]

    lineage: list[dict[str, Any]] = []
    records: dict[str, dict[str, Any]] = {}
    for stage, kind, key, flag, operation, period in required_stages:
        record = _result_record(active_results, kind, key)
        records[stage] = record
        _check(
            checks,
            f"{stage}_active_result",
            bool(lifecycle.get(flag)) and bool(record),
            f"The refreshed lifecycle contains the active {stage.replace('_', ' ')} result.",
            observed={"lifecycle_flag": bool(lifecycle.get(flag)), "request_id": record.get("request_id")},
        )
        lineage.append(
            _inspect_content_lineage(
                stage=stage,
                record=record,
                expected_operation=operation,
                expected_hashes=active_hashes,
                content_loader=content_loader,
                **period,
            )
        )

    temporal_dli = bool(
        lifecycle.get("temporal_dli_complete")
        and records["network_dli_2014"]
        and records["network_dli_2017"]
    )
    _check(
        checks,
        "temporal_network_dli_complete",
        temporal_dli,
        "Both annual Network/CRITIC-DLI results form the temporal DLI evidence set.",
    )

    # Do not trust the lifecycle's SPA-complete flags alone: independently
    # recompute each minimum whole-path prefix against the same-year governed
    # MRIO total from the immutable result envelopes.
    spa_coverage: dict[str, Any] = {}
    for reference_year in (2014, 2017):
        spa_audit = _spa_minimum_prefix_audit(
            _payload_from_record(
                records[f"spa_{reference_year}"], content_loader
            ),
            _payload_from_record(
                records[f"mrio_{reference_year}"], content_loader
            ),
        )
        spa_coverage[str(reference_year)] = spa_audit
        _check(
            checks,
            f"spa_{reference_year}_minimum_87_percent_prefix",
            spa_audit["passed"],
            "SPA uses the governed complete-company footprint and the minimum whole-path prefix reaching 87%.",
            observed=spa_audit["checks"],
        )

    baseline_network = records["network_dli_2014"]
    decision_network = records["network_dli_2017"]
    temporal_binding_ok = bool(
        temporal_dli
        and _integer_equals(
            decision_network.get("temporal_baseline_request_id"),
            baseline_network.get("request_id", -1),
        )
        and str(
            decision_network.get("temporal_baseline_content_hash", "")
        ).strip().lower()
        == str(baseline_network.get("content_hash", "")).strip().lower()
        and str(
            next(
                (
                    item.get("payload_temporal_baseline_cid", "")
                    for item in lineage
                    if item.get("stage") == "network_dli_2017"
                ),
                "",
            )
        ).strip().lower()
        == str(baseline_network.get("content_hash", "")).strip().lower()
    )
    _check(
        checks,
        "exact_temporal_network_lineage",
        temporal_binding_ok,
        "The active 2017 decision result is bound to the exact fulfilled 2014 Network request and CID reconstructed from chain.",
    )

    network_2017 = records["network_dli_2017"]
    aurora_2017 = records["aurora_2017"]
    aurora_lineage = next(
        (item for item in lineage if item["stage"] == "aurora_2017"), {}
    )
    active_network_cid = str(network_2017.get("content_hash", "")).lower()
    aurora_binding_ok = bool(
        lifecycle.get("aurora_bound_to_active_2017_network")
        and aurora_2017
        and _integer_equals(
            aurora_2017.get("network_request_id"),
            network_2017.get("request_id", -2),
        )
        and str(aurora_2017.get("network_result_hash", "")).lower()
        == active_network_cid
        and str(aurora_lineage.get("payload_network_result_hash", "")).lower()
        == active_network_cid
    )
    _check(
        checks,
        "aurora_bound_to_active_2017_network",
        aurora_binding_ok,
        "The fulfilled 2017 AURORA result cites the active 2017 Network/DLI request and CID.",
        observed={
            "active_network_request_id": network_2017.get("request_id"),
            "aurora_network_request_id": aurora_2017.get("network_request_id"),
            "active_network_content_hash": active_network_cid,
            "aurora_network_result_hash": aurora_2017.get("network_result_hash"),
        },
    )

    cid_lineage_ok = bool(lineage) and all(item["passed"] for item in lineage)
    _check(
        checks,
        "immutable_cid_lineage",
        cid_lineage_ok and aurora_binding_ok,
        "Every required result has a SHA-256-verified envelope, expected operation/period, current inputs, and coherent AURORA source binding.",
    )

    query_spec = state.get("contracts", {}).get("QueryManagement", {})
    if not isinstance(query_spec, dict):
        query_spec = {}
    query_address = str(query_spec.get("address", ""))
    query_ready = bool(lifecycle.get("query_management_ready"))
    query_deployed = bool(lifecycle.get("query_deployed") and query_spec)
    intervention_resolved = bool(lifecycle.get("intervention_governance_resolved"))
    _check(
        checks,
        "intervention_governance_resolved",
        intervention_resolved,
        "The intervention branch has an on-chain decision or a verified no-option outcome.",
    )
    _check(
        checks,
        "query_management_ready",
        query_ready and temporal_dli and temporal_binding_ok and aurora_binding_ok and intervention_resolved,
        "Final Query Management support is unlocked by temporal DLI, active-bound AURORA, and resolved intervention governance.",
    )
    _check(
        checks,
        "query_management_deployed",
        query_deployed
        and bool(re.fullmatch(r"0x[0-9a-fA-F]{40}", query_address))
        and query_contract_code_present is True,
        "QueryManagement has a valid deployed address and non-empty live-chain bytecode.",
        observed={
            "address": query_address,
            "live_chain_code_present": query_contract_code_present,
        },
    )
    _check(
        checks,
        "system_operational",
        bool(lifecycle.get("system_operational")) and query_ready and query_deployed,
        "The refreshed lifecycle identifies the governed query layer as operational.",
    )

    intervention = {
        "required_for_validation_pass": True,
        "workspace_ready": bool(lifecycle.get("intervention_workspace_ready")),
        "evidence_verified": bool(
            lifecycle.get("intervention_governance_evidence_verified")
        ),
        "evidence_error": str(
            lifecycle.get("intervention_governance_evidence_error", "")
        ),
        "selected_count": _nonnegative_integer(
            lifecycle.get("selected_intervention_count")
        ),
        "proposed_count": _nonnegative_integer(
            lifecycle.get("proposed_intervention_count")
        ),
        "decided_count": _nonnegative_integer(
            lifecycle.get("decided_intervention_count")
        ),
        "all_selected_decided": bool(
            lifecycle.get("all_selected_interventions_decided")
        ),
        "resolved": intervention_resolved,
        "note": (
            "AURORA remains pre-governance, while final Query Management support requires an "
            "on-chain decision or a verified no-option governance outcome."
        ),
    }

    failed = [item["id"] for item in checks if item["required"] and not item["passed"]]
    return {
        "schema_version": SCHEMA_VERSION,
        "validator": "Intervention-abatement governance runtime coherence",
        "generated_at_utc": _utc_now(),
        "deployment_state": str(Path(deployment_state).resolve()),
        "architecture_version": state.get("architecture_version"),
        "active_input_hashes": active_hashes,
        "status": "pass" if not failed else "fail",
        "summary": {
            "required_check_count": len(checks),
            "passed_required_check_count": len(checks) - len(failed),
            "failed_required_check_count": len(failed),
            "failed_check_ids": failed,
        },
        "required_checks": checks,
        "cid_lineage": lineage,
        "spa_coverage": spa_coverage,
        "intervention_governance": intervention,
    }


def refresh_state_read_only(deployment_state: str | Path) -> tuple[dict[str, Any], str]:
    """Refresh a temporary state copy and prove the source file stayed unchanged."""

    source = Path(deployment_state).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError(f"Deployment state is unavailable: {source}")
    original_body = source.read_bytes()
    original_sha256 = _sha256_bytes(original_body)
    with tempfile.TemporaryDirectory(prefix="governed-runtime-methodology-") as temporary:
        audit_copy = Path(temporary) / "deployment.json"
        audit_copy.write_bytes(original_body)
        refreshed = _refresh_lifecycle(audit_copy)
    if not source.is_file() or _sha256_bytes(source.read_bytes()) != original_sha256:
        raise RuntimeError(
            "The deployment state changed during the read-only audit; validation stopped."
        )
    return refreshed, original_sha256


def _query_contract_code_present(state: dict[str, Any]) -> bool:
    spec = state.get("contracts", {}).get("QueryManagement", {})
    address = spec.get("address") if isinstance(spec, dict) else None
    if not address:
        return False
    w3 = _lifecycle_module().connect(state)
    return len(bytes(w3.eth.get_code(address))) > 0


def validate_runtime(deployment_state: str | Path = DEFAULT_DEPLOYMENT_STATE) -> dict[str, Any]:
    """Run the live, read-only governed runtime audit and return its JSON-safe report."""

    source = Path(deployment_state).expanduser().resolve()
    try:
        refreshed, source_sha256 = refresh_state_read_only(source)
        report = assess_refreshed_state(
            refreshed,
            deployment_state=source,
            query_contract_code_present=_query_contract_code_present(refreshed),
        )
        report["deployment_state_sha256"] = source_sha256
        report["read_only_refresh"] = True
        return report
    except Exception as exc:
        return {
            "schema_version": SCHEMA_VERSION,
            "validator": "Intervention-abatement governance runtime coherence",
            "generated_at_utc": _utc_now(),
            "deployment_state": str(source),
            "status": "fail",
            "summary": {
                "required_check_count": 1,
                "passed_required_check_count": 0,
                "failed_required_check_count": 1,
                "failed_check_ids": ["live_read_only_refresh"],
            },
            "required_checks": [
                {
                    "id": "live_read_only_refresh",
                    "required": True,
                    "passed": False,
                    "detail": str(exc),
                }
            ],
            "cid_lineage": [],
            "intervention_governance": {
                "required_for_validation_pass": False,
                "note": "Intervention status could not be reconstructed because the live refresh failed.",
            },
            "read_only_refresh": True,
        }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Read-only live-chain and CID audit of the governed deployment methodology."
        )
    )
    parser.add_argument(
        "deployment_state",
        nargs="?",
        type=Path,
        help="Deployment state path (default: package deployment.json).",
    )
    parser.add_argument(
        "--deployment",
        dest="deployment_option",
        type=Path,
        help="Explicit deployment state path; overrides the positional path.",
    )
    parser.add_argument(
        "--output",
        type=Path,
        help="Optionally write the same JSON report to this path.",
    )
    args = parser.parse_args(argv)
    deployment_state = (
        args.deployment_option
        or args.deployment_state
        or DEFAULT_DEPLOYMENT_STATE
    )
    report = validate_runtime(deployment_state)
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0 if report.get("status") == "pass" else 1


if __name__ == "__main__":
    raise SystemExit(main())
