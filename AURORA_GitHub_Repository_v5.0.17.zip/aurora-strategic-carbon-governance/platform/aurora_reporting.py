"""Presentation, decision-trace, and export helpers for AURORA results.

This module exposes the AURORA decision path, including the exact bin-free Otsu
similarity-threshold calibration used by the U9 analytical workflow. It does not
change the Pareto definition, recommendation order, DLI governance role, or
cross-year stability rule. The content-addressed AURORA JSON package remains the
authoritative analytical result.
"""
from __future__ import annotations

from copy import deepcopy
from io import BytesIO
from pathlib import Path
import hashlib
import json
import os
from typing import Any, Iterable

import pandas as pd
from openpyxl import load_workbook
from openpyxl.cell.cell import ILLEGAL_CHARACTERS_RE
from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
from openpyxl.utils import get_column_letter

REPORTING_SCHEMA_VERSION = "1.1"
REPORTING_RELEASE_ID = "v5.0.17-U10"

PERCENT_FIELDS = {
    "share_of_sector_demand",
    "relative_multiplier_reduction",
    "opportunity_share_of_company_footprint",
    "focal_consumer_intermediate_sales_share",
    "focal_region_intermediate_sales_share",
    "gcc_intermediate_sales_share",
    "comparison_relative_multiplier_reduction",
    "comparison_focal_region_intermediate_sales_share",
}

SIMILARITY_FIELDS = {
    "production_sector_similarity",
    "production_region_similarity",
    "market_sector_similarity",
    "market_region_similarity",
    "comparison_production_sector_similarity",
    "comparison_market_sector_similarity",
    "production_similarity_threshold_used",
    "market_similarity_threshold_used",
}

DLI_FIELDS = {"DLI", "BC_norm", "PR_norm", "CDR_norm", "IC_norm"}

INTEGER_FIELDS = {
    "dli_rank",
    "observed_linkage_code",
    "comparison_observed_linkage_code",
    "comparison_year",
    "candidate_rank_within_sector",
    "pareto_rank_within_sector",
    "recommendation_rank_within_sector",
    "stage_order",
    "count",
    "candidate_count",
    "production_similarity_pass_count",
    "structural_analogue_count",
    "lower_carbon_structural_analogue_count",
    "relevant_linkage_count",
    "eligible_candidate_count",
    "pareto_efficient_count",
    "recommended_count",
    "stable_recommended_count",
}

RECOMMENDED_COLUMNS = [
    "sector",
    "current_nodes",
    "node_code",
    "region",
    "sector_demand",
    "baseline_embodied_multiplier",
    "candidate_embodied_multiplier",
    "production_sector_similarity",
    "production_similarity_threshold_used",
    "market_sector_similarity",
    "market_similarity_threshold_used",
    "similarity_threshold_method",
    "similarity_threshold_calibration_year",
    "relative_multiplier_reduction",
    "focal_region_intermediate_sales_share",
    "observed_linkage_tier",
    "eligible_for_regional_investigation",
    "pareto_efficient",
    "selected_within_display_cap",
    "modelled_full_reallocation_opportunity",
    "opportunity_share_of_company_footprint",
    "DLI",
    "dli_rank",
    "BC_norm",
    "PR_norm",
    "CDR_norm",
    "IC_norm",
    "dominant_dli_component",
    "dli_governance_lens",
    "stable_reference_year_signal",
    "recommendation_rank_within_sector",
    "recommendation",
]

DECISION_TRACE_COLUMNS = [
    "sector",
    "node_code",
    "region",
    "same_sector_candidate",
    "positive_output_candidate",
    "production_similarity_threshold_used",
    "production_similarity_gate_passed",
    "market_similarity_threshold_used",
    "market_similarity_gate_passed",
    "similarity_threshold_method",
    "similarity_threshold_calibration_year",
    "structural_analogue",
    "carbon_improvement_gate_passed",
    "linkage_gate_passed",
    "eligible_for_regional_investigation",
    "pareto_efficient",
    "selected_within_display_cap",
    "recommended_for_investigation",
    "decision_status",
    "exclusion_reason",
    "decision_trace",
]

CROSS_YEAR_COLUMNS = [
    "sector",
    "node_code",
    "region",
    "recommended_for_investigation",
    "stable_reference_year_signal",
    "comparison_year",
    "comparison_year_available",
    "production_sector_similarity",
    "comparison_production_sector_similarity",
    "market_sector_similarity",
    "comparison_market_sector_similarity",
    "relative_multiplier_reduction",
    "comparison_relative_multiplier_reduction",
    "observed_linkage_tier",
    "comparison_observed_linkage_tier",
    "structural_analogue_in_both_reference_years",
    "lower_carbon_in_both_reference_years",
    "comparison_eligible_for_regional_investigation",
]


def _as_bool(value: Any) -> bool:
    if isinstance(value, str):
        return value.strip().lower() in {"true", "1", "yes", "y", "pass", "passed"}
    return bool(value)


def _as_float(value: Any, default: float = 0.0) -> float:
    try:
        if value is None or value == "":
            return default
        return float(value)
    except (TypeError, ValueError):
        return default


def _as_int(value: Any, default: int = 0) -> int:
    try:
        if value is None or value == "":
            return default
        return int(value)
    except (TypeError, ValueError):
        return default


def _safe_json(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _flatten_cell(value: Any) -> Any:
    if isinstance(value, (list, tuple, set, dict)):
        return _safe_json(value)
    return value


def _clean_text(value: Any) -> Any:
    if isinstance(value, str):
        return ILLEGAL_CHARACTERS_RE.sub("", value)
    return value


def _subset_frame(rows: Iterable[dict[str, Any]], preferred: list[str] | None = None) -> pd.DataFrame:
    frame = pd.DataFrame(list(rows))
    if frame.empty:
        return frame
    if preferred:
        ordered = [column for column in preferred if column in frame.columns]
        remainder = [column for column in frame.columns if column not in ordered]
        frame = frame[ordered + remainder]
    for column in frame.columns:
        frame[column] = frame[column].map(_flatten_cell).map(_clean_text)
    return frame


def _decision_status(row: dict[str, Any]) -> tuple[str, str]:
    if not _as_bool(row.get("production_similarity_gate_passed")):
        return "Ineligible — production similarity", "Production similarity is below the configured threshold."
    if not _as_bool(row.get("market_similarity_gate_passed")):
        return "Ineligible — market similarity", "Market similarity is below the configured threshold."
    if not _as_bool(row.get("carbon_improvement_gate_passed")):
        return "Ineligible — no carbon improvement", "The candidate embodied-carbon multiplier is not lower than the current-mix benchmark."
    if not _as_bool(row.get("linkage_gate_passed")):
        return "Ineligible — linkage", "No eligible UAE/GCC intermediate-market linkage was observed."
    if not _as_bool(row.get("pareto_efficient")):
        return "Eligible — Pareto dominated", "Another eligible candidate is at least as good on all Pareto dimensions and strictly better on at least one."
    if not _as_bool(row.get("recommended_for_investigation")):
        return "Pareto efficient — outside display cap", "The candidate is non-dominated but falls outside the configured per-sector display cap."
    return "Recommended for investigation", "All eligibility gates passed, the candidate is Pareto efficient, and it was selected within the display cap."


def _decision_trace(row: dict[str, Any]) -> str:
    labels = [
        ("same sector", row.get("same_sector_candidate")),
        ("positive output", row.get("positive_output_candidate")),
        ("production similarity", row.get("production_similarity_gate_passed")),
        ("market similarity", row.get("market_similarity_gate_passed")),
        ("carbon improvement", row.get("carbon_improvement_gate_passed")),
        ("relevant linkage", row.get("linkage_gate_passed")),
        ("eligible", row.get("eligible_for_regional_investigation")),
        ("Pareto efficient", row.get("pareto_efficient")),
        ("within display cap", row.get("selected_within_display_cap")),
    ]
    return " -> ".join(f"{label}={'pass' if _as_bool(value) else 'fail'}" for label, value in labels)


def _comparison_map(comparison: dict[str, Any] | None) -> dict[tuple[str, str], dict[str, Any]]:
    if not isinstance(comparison, dict):
        return {}
    return {
        (str(row.get("sector", "")), str(row.get("node_code", ""))): row
        for row in comparison.get("all_candidates", [])
        if isinstance(row, dict)
    }


def enrich_aurora_result(
    result: dict[str, Any],
    comparison: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Add transparent reporting fields without changing AURORA decisions.

    Existing ``eligible_for_regional_investigation``, ``pareto_efficient`` and
    ``recommended_for_investigation`` values remain authoritative. Recomputed
    gate flags are added only to expose how the existing decision propagated.
    """

    enriched = deepcopy(result)
    configuration = dict(enriched.get("configuration", {}) or {})
    production_threshold = _as_float(configuration.get("production_similarity_threshold"), 0.80)
    market_threshold = _as_float(configuration.get("market_similarity_threshold"), 0.70)
    minimum_carbon = _as_float(configuration.get("minimum_carbon_improvement"), 0.0)
    display_cap = _as_int(configuration.get("top_candidates_per_sector"), 3)
    threshold_calibration = dict(enriched.get("threshold_calibration", {}) or {})
    other_map = _comparison_map(comparison)
    comparison_year = comparison.get("year") if isinstance(comparison, dict) else None

    candidates = [dict(row) for row in enriched.get("all_candidates", []) if isinstance(row, dict)]
    for row in candidates:
        production_pass = _as_float(row.get("production_sector_similarity")) >= production_threshold
        market_pass = _as_float(row.get("market_sector_similarity")) >= market_threshold
        carbon_pass = _as_float(row.get("relative_multiplier_reduction")) > minimum_carbon
        linkage_pass = _as_int(row.get("observed_linkage_code"), 4) <= 3
        structural = production_pass and market_pass
        recomputed_eligible = structural and carbon_pass and linkage_pass

        row["same_sector_candidate"] = True
        row["positive_output_candidate"] = True
        row["production_similarity_threshold_used"] = _as_float(
            row.get("production_similarity_threshold_used"), production_threshold
        )
        row["market_similarity_threshold_used"] = _as_float(
            row.get("market_similarity_threshold_used"), market_threshold
        )
        row["similarity_threshold_method"] = str(
            row.get("similarity_threshold_method")
            or configuration.get("similarity_threshold_method")
            or threshold_calibration.get("method")
            or "fixed_legacy"
        )
        row["similarity_threshold_calibration_year"] = row.get(
            "similarity_threshold_calibration_year",
            configuration.get("similarity_threshold_calibration_year", threshold_calibration.get("calibration_year")),
        )
        row["production_similarity_gate_passed"] = production_pass
        row["market_similarity_gate_passed"] = market_pass
        row["carbon_improvement_gate_passed"] = carbon_pass
        row["linkage_gate_passed"] = linkage_pass
        row["structural_analogue"] = _as_bool(row.get("structural_analogue", structural))
        row["lower_carbon_multiplier"] = _as_bool(row.get("lower_carbon_multiplier", carbon_pass))
        row["eligible_for_regional_investigation"] = _as_bool(
            row.get("eligible_for_regional_investigation", recomputed_eligible)
        )
        row["eligibility_reconciliation_passed"] = (
            row["eligible_for_regional_investigation"] == recomputed_eligible
        )
        row["pareto_efficient"] = _as_bool(row.get("pareto_efficient"))
        row["recommended_for_investigation"] = _as_bool(row.get("recommended_for_investigation"))
        row["selected_within_display_cap"] = row["recommended_for_investigation"]

        other = other_map.get((str(row.get("sector", "")), str(row.get("node_code", ""))))
        if other is not None:
            row["comparison_year"] = comparison_year
            row["comparison_year_available"] = True
            row["comparison_production_sector_similarity"] = other.get("production_sector_similarity")
            row["comparison_market_sector_similarity"] = other.get("market_sector_similarity")
            row["comparison_relative_multiplier_reduction"] = other.get("relative_multiplier_reduction")
            row["comparison_focal_region_intermediate_sales_share"] = other.get(
                "focal_region_intermediate_sales_share"
            )
            row["comparison_observed_linkage_tier"] = other.get("observed_linkage_tier")
            row["comparison_observed_linkage_code"] = other.get("observed_linkage_code")
            row["comparison_baseline_embodied_multiplier"] = other.get("baseline_embodied_multiplier")
            row["comparison_candidate_embodied_multiplier"] = other.get("candidate_embodied_multiplier")
            row["comparison_structural_analogue"] = _as_bool(other.get("structural_analogue"))
            row["comparison_lower_carbon_multiplier"] = _as_bool(other.get("lower_carbon_multiplier"))
            row["comparison_eligible_for_regional_investigation"] = _as_bool(
                other.get("eligible_for_regional_investigation")
            )
            row["comparison_pareto_efficient"] = _as_bool(other.get("pareto_efficient"))
            row["comparison_recommended_for_investigation"] = _as_bool(
                other.get("recommended_for_investigation")
            )
            row["structural_analogue_in_both_reference_years"] = bool(
                row["structural_analogue"] and row["comparison_structural_analogue"]
            )
            row["lower_carbon_in_both_reference_years"] = bool(
                row["lower_carbon_multiplier"] and row["comparison_lower_carbon_multiplier"]
            )
            # Preserve the implemented stability rule: a primary-year recommendation
            # is stable when the same candidate remains fully eligible in the
            # comparison year; identical Pareto/recommendation status is not required.
            row["stable_reference_year_signal"] = bool(
                row["recommended_for_investigation"]
                and row["comparison_eligible_for_regional_investigation"]
            )
        else:
            row.setdefault("comparison_year", comparison_year)
            row.setdefault("comparison_year_available", False)
            for key in [
                "comparison_production_sector_similarity",
                "comparison_market_sector_similarity",
                "comparison_relative_multiplier_reduction",
                "comparison_focal_region_intermediate_sales_share",
                "comparison_observed_linkage_tier",
                "comparison_observed_linkage_code",
                "comparison_baseline_embodied_multiplier",
                "comparison_candidate_embodied_multiplier",
                "comparison_structural_analogue",
                "comparison_lower_carbon_multiplier",
                "comparison_eligible_for_regional_investigation",
                "comparison_pareto_efficient",
                "comparison_recommended_for_investigation",
            ]:
                row.setdefault(key, None)
            row.setdefault("structural_analogue_in_both_reference_years", False)
            row.setdefault("lower_carbon_in_both_reference_years", False)
            row.setdefault("stable_reference_year_signal", False)

        status, reason = _decision_status(row)
        row["decision_status"] = status
        row["exclusion_reason"] = reason
        row["decision_trace"] = _decision_trace(row)

    # Preserve the analytical order produced by the engine and add explicit ranks.
    grouped: dict[str, list[dict[str, Any]]] = {}
    for row in candidates:
        grouped.setdefault(str(row.get("sector", "")), []).append(row)
    for rows in grouped.values():
        pareto_rank = 0
        recommendation_rank = 0
        for candidate_rank, row in enumerate(rows, start=1):
            row["candidate_rank_within_sector"] = candidate_rank
            if row["eligible_for_regional_investigation"] and row["pareto_efficient"]:
                pareto_rank += 1
                row["pareto_rank_within_sector"] = pareto_rank
            else:
                row["pareto_rank_within_sector"] = None
            if row["recommended_for_investigation"]:
                recommendation_rank += 1
                row["recommendation_rank_within_sector"] = recommendation_rank
            else:
                row["recommendation_rank_within_sector"] = None

    recommended = [row for row in candidates if row["recommended_for_investigation"]]
    recommended.sort(
        key=lambda row: (
            not _as_bool(row.get("stable_reference_year_signal")),
            -_as_float(row.get("modelled_full_reallocation_opportunity")),
        )
    )
    eligible = [row for row in candidates if row["eligible_for_regional_investigation"]]
    pareto = [
        row
        for row in eligible
        if row["pareto_efficient"]
    ]

    existing_summaries = {
        str(row.get("sector", "")): dict(row)
        for row in enriched.get("sector_summaries", [])
        if isinstance(row, dict)
    }
    sector_summaries: list[dict[str, Any]] = []
    for sector in sorted(grouped):
        rows = grouped[sector]
        base = existing_summaries.get(sector, {})
        summary = {
            **base,
            "sector": sector,
            "candidate_count": len(rows),
            "production_similarity_pass_count": sum(
                _as_bool(row.get("production_similarity_gate_passed")) for row in rows
            ),
            "structural_analogue_count": sum(_as_bool(row.get("structural_analogue")) for row in rows),
            "lower_carbon_structural_analogue_count": sum(
                _as_bool(row.get("structural_analogue"))
                and _as_bool(row.get("carbon_improvement_gate_passed"))
                for row in rows
            ),
            "relevant_linkage_count": sum(_as_bool(row.get("linkage_gate_passed")) for row in rows),
            "eligible_candidate_count": sum(
                _as_bool(row.get("eligible_for_regional_investigation")) for row in rows
            ),
            "pareto_efficient_count": sum(
                _as_bool(row.get("eligible_for_regional_investigation"))
                and _as_bool(row.get("pareto_efficient"))
                for row in rows
            ),
            "recommended_count": sum(_as_bool(row.get("recommended_for_investigation")) for row in rows),
            "stable_recommended_count": sum(
                _as_bool(row.get("recommended_for_investigation"))
                and _as_bool(row.get("stable_reference_year_signal"))
                for row in rows
            ),
        }
        sector_summaries.append(summary)

    nested_counts = {
        "same_sector_candidates": len(candidates),
        "production_similarity_gate_passed": sum(
            _as_bool(row.get("production_similarity_gate_passed")) for row in candidates
        ),
        "both_similarity_gates_passed": sum(
            _as_bool(row.get("structural_analogue")) for row in candidates
        ),
        "structural_and_carbon_gates_passed": sum(
            _as_bool(row.get("structural_analogue"))
            and _as_bool(row.get("carbon_improvement_gate_passed"))
            for row in candidates
        ),
        "all_eligibility_gates_passed": len(eligible),
        "pareto_efficient_candidates": len(pareto),
        "displayed_recommendations": len(recommended),
        "stable_displayed_recommendations": sum(
            _as_bool(row.get("stable_reference_year_signal")) for row in recommended
        ),
    }
    decision_funnel = [
        {
            "stage_order": 1,
            "stage": "Same-sector candidates",
            "count": nested_counts["same_sector_candidates"],
            "condition": "Same MRIO sector, positive output, and not already in the current regional mix.",
        },
        {
            "stage_order": 2,
            "stage": "Production similarity gate passed",
            "count": nested_counts["production_similarity_gate_passed"],
            "condition": f"Production-sector cosine similarity >= {production_threshold:.4f}.",
        },
        {
            "stage_order": 3,
            "stage": "Both structural similarity gates passed",
            "count": nested_counts["both_similarity_gates_passed"],
            "condition": f"Production similarity >= {production_threshold:.4f} and market similarity >= {market_threshold:.4f}.",
        },
        {
            "stage_order": 4,
            "stage": "Structural analogue with carbon improvement",
            "count": nested_counts["structural_and_carbon_gates_passed"],
            "condition": f"Both similarity gates passed and relative multiplier reduction > {minimum_carbon:.2f}.",
        },
        {
            "stage_order": 5,
            "stage": "All eligibility gates passed",
            "count": nested_counts["all_eligibility_gates_passed"],
            "condition": "Structural analogue, lower-carbon multiplier, and eligible UAE/GCC linkage tier.",
        },
        {
            "stage_order": 6,
            "stage": "Pareto efficient",
            "count": nested_counts["pareto_efficient_candidates"],
            "condition": "Non-dominated on production similarity, market similarity, UAE intermediate-sales share, and carbon improvement.",
        },
        {
            "stage_order": 7,
            "stage": "Displayed recommendations",
            "count": nested_counts["displayed_recommendations"],
            "condition": f"Pareto efficient and selected within the display cap of {display_cap} candidate(s) per demanded sector.",
        },
        {
            "stage_order": 8,
            "stage": "Post-decision two-period stable signal",
            "count": nested_counts["stable_displayed_recommendations"],
            "condition": (
                "Robustness annotation only: a primary-year recommendation remains fully eligible "
                "in the comparison year; stability is not a mandatory recommendation gate."
            ),
        },
    ]

    enriched["reporting_schema_version"] = REPORTING_SCHEMA_VERSION
    enriched["reporting_release_id"] = REPORTING_RELEASE_ID
    enriched["candidates"] = candidates
    enriched["all_candidates"] = candidates
    enriched["eligible_candidates"] = eligible
    enriched["pareto_efficient_candidates"] = pareto
    enriched["recommended_opportunities"] = recommended
    enriched["sector_summaries"] = sector_summaries
    enriched["decision_funnel"] = decision_funnel
    enriched["decision_funnel_summary"] = nested_counts
    enriched["cross_year_evidence"] = [
        row for row in candidates if _as_bool(row.get("comparison_year_available"))
    ]
    enriched["selection_logic"] = {
        "same_sector_required": True,
        "positive_output_required": True,
        "production_similarity_threshold": production_threshold,
        "market_similarity_threshold": market_threshold,
        "similarity_threshold_method": configuration.get(
            "similarity_threshold_method", threshold_calibration.get("method", "fixed_legacy")
        ),
        "similarity_threshold_calibration_year": configuration.get(
            "similarity_threshold_calibration_year", threshold_calibration.get("calibration_year")
        ),
        "similarity_threshold_candidate_count": threshold_calibration.get("candidate_universe_count"),
        "minimum_carbon_improvement": minimum_carbon,
        "eligible_linkage_codes": [1, 2, 3],
        "pareto_dimensions": [
            "production_sector_similarity",
            "market_sector_similarity",
            "focal_region_intermediate_sales_share",
            "relative_multiplier_reduction",
        ],
        "DLI_in_eligibility_or_pareto": False,
        "top_candidates_per_sector_display_cap": display_cap,
        "stability_rule": (
            "A primary-year recommendation is stable when the same candidate remains fully eligible in the comparison year; identical Pareto status is not required."
        ),
        "stability_is_mandatory_for_recommendation": False,
        "full_reallocation_opportunities_are_additive": False,
    }
    enriched["units"] = {
        "sector_demand": "USD",
        "embodied_multiplier": "t CO2/USD",
        "modelled_full_reallocation_opportunity": "t CO2",
        "company_footprint": "t CO2",
        "intermediate_transaction_values": "million USD",
        "similarities_and_DLI": "dimensionless (0-1)",
        "shares_and_relative_reductions": "proportion (displayed as percent)",
    }
    enriched["non_additivity_note"] = (
        "Full-reallocation opportunities are candidate-specific counterfactual screening envelopes. "
        "Alternative candidates for the same demanded sector are mutually exclusive and must not be summed as an implementable total."
    )
    enriched["display_cap_note"] = (
        "The per-sector candidate cap controls the visible management shortlist only. "
        "All eligible, Pareto-efficient, dominated, and ineligible candidates remain in the complete candidate table."
    )
    enriched["reporting_boundary"] = (
        "The reporting extension exposes decision propagation and the exact bin-free Otsu calibration used by the deterministic AURORA workflow. "
        "It does not change the Pareto rule, shortlist ordering, DLI governance role, or stability definition."
    )
    return enriched



def _data_dictionary_rows() -> list[dict[str, str]]:
    """Return a compact dictionary for the principal AURORA result fields."""

    rows = [
        ("sector", "MRIO sector code demanded by the focal company.", "code", "Candidate identity"),
        ("current_nodes", "Country-sector node(s) in the focal company's current regional mix for the sector.", "node code list", "Reference construction"),
        ("node_code", "Alternative same-sector country-sector node evaluated by AURORA.", "node code", "Candidate identity"),
        ("region", "Candidate region code.", "region code", "Candidate identity"),
        ("sector_demand", "Total focal-company demand allocated to the demanded sector.", "USD", "Reference construction"),
        ("baseline_embodied_multiplier", "Demand-share-weighted embodied-carbon multiplier of the current regional mix.", "t CO2/USD", "Carbon comparison"),
        ("candidate_embodied_multiplier", "Embodied-carbon multiplier of the candidate country-sector node.", "t CO2/USD", "Carbon comparison"),
        ("relative_multiplier_reduction", "Relative reduction of the candidate multiplier against the current-mix multiplier.", "proportion; displayed as %", "Carbon gate and Pareto objective"),
        ("modelled_full_reallocation_opportunity", "Counterfactual screening envelope if the full modeled sector demand used the candidate multiplier.", "t CO2", "Impact interpretation; not additive within a sector"),
        ("opportunity_share_of_company_footprint", "Full-reallocation screening envelope divided by the focal-company footprint.", "proportion; displayed as %", "Impact interpretation"),
        ("production_sector_similarity", "Cosine similarity between current-mix and candidate production-input profiles aggregated by sector.", "dimensionless (0-1)", "Production-similarity gate and Pareto objective"),
        ("production_similarity_threshold_used", "Exact bin-free Otsu production-similarity threshold calibrated from the complete calibration-year candidate universe.", "dimensionless (0-1)", "Production-similarity gate"),
        ("market_sector_similarity", "Cosine similarity between current-mix and candidate downstream intermediate-market profiles aggregated by sector.", "dimensionless (0-1)", "Market-similarity gate and Pareto objective"),
        ("market_similarity_threshold_used", "Exact bin-free Otsu market-similarity threshold calibrated from the complete calibration-year candidate universe.", "dimensionless (0-1)", "Market-similarity gate"),
        ("similarity_threshold_method", "Method used to derive the two structural-similarity thresholds.", "category", "Calibration provenance"),
        ("similarity_threshold_calibration_year", "MRIO reference year used to calibrate the thresholds before applying them to the primary assessment year.", "year", "Calibration provenance"),
        ("direct_flow_to_focal_region_construction", "Observed intermediate transaction from the candidate to UAE construction.", "million USD", "Linkage evidence"),
        ("intermediate_sales_to_focal_region", "Candidate's total observed intermediate sales to UAE industries.", "million USD", "Linkage evidence"),
        ("focal_region_intermediate_sales_share", "Share of the candidate's total intermediate sales absorbed by UAE industries.", "proportion; displayed as %", "Pareto objective"),
        ("observed_linkage_tier", "Highest-priority observed linkage: UAE construction, another UAE industry, GCC user, or no relevant flow.", "category", "Linkage gate and recommendation wording"),
        ("production_similarity_gate_passed", "Whether production similarity meets the configured threshold.", "Boolean", "Decision trace"),
        ("market_similarity_gate_passed", "Whether market similarity meets the configured threshold.", "Boolean", "Decision trace"),
        ("carbon_improvement_gate_passed", "Whether the candidate multiplier is lower than the current-mix multiplier by more than the configured minimum.", "Boolean", "Decision trace"),
        ("linkage_gate_passed", "Whether the observed linkage code is eligible (1, 2, or 3).", "Boolean", "Decision trace"),
        ("eligible_for_regional_investigation", "Whether all structural, carbon, and linkage gates pass.", "Boolean", "Eligibility decision"),
        ("pareto_efficient", "Whether no other eligible same-sector candidate weakly outperforms it on all four Pareto dimensions and strictly outperforms it on at least one.", "Boolean", "Non-dominance decision"),
        ("selected_within_display_cap", "Whether the Pareto-efficient candidate is retained within the configured per-sector management display cap.", "Boolean", "Presentation selection"),
        ("recommended_for_investigation", "Final management-facing AURORA recommendation flag.", "Boolean", "Final shortlist"),
        ("decision_status", "Human-readable stage at which the candidate is retained or excluded.", "category", "Decision trace"),
        ("exclusion_reason", "Reason the candidate did not progress further, or confirmation that it passed all stages.", "text", "Decision trace"),
        ("DLI", "Decarbonization Leverage Index attached as governance evidence only.", "dimensionless (0-1)", "Governance lens; excluded from eligibility and Pareto"),
        ("BC_norm", "Normalized betweenness-centrality component of DLI.", "dimensionless (0-1)", "Governance lens"),
        ("PR_norm", "Normalized PageRank component of DLI.", "dimensionless (0-1)", "Governance lens"),
        ("CDR_norm", "Normalized Carbon Dependency Risk component of DLI.", "dimensionless (0-1)", "Governance lens"),
        ("IC_norm", "Normalized Intervention Criticality component of DLI.", "dimensionless (0-1)", "Governance lens"),
        ("dominant_dli_component", "Largest weighted DLI component for the candidate.", "category", "Governance interpretation"),
        ("stable_reference_year_signal", "Whether a primary-year recommendation remains fully eligible in the comparison year.", "Boolean", "Post-decision two-period robustness signal"),
        ("comparison_production_sector_similarity", "Production similarity calculated for the same candidate in the comparison year.", "dimensionless (0-1)", "Cross-year evidence"),
        ("comparison_market_sector_similarity", "Market similarity calculated for the same candidate in the comparison year.", "dimensionless (0-1)", "Cross-year evidence"),
        ("comparison_relative_multiplier_reduction", "Relative multiplier reduction calculated in the comparison year.", "proportion; displayed as %", "Cross-year evidence"),
        ("comparison_eligible_for_regional_investigation", "Whether the candidate passes all eligibility gates in the comparison year.", "Boolean", "Cross-year evidence"),
        ("recommendation", "Management-facing interpretation determined by the existing AURORA linkage and shortlist logic.", "text", "Final communication"),
    ]
    return [
        {"field": field, "definition": definition, "unit_or_scale": unit, "decision_role": role}
        for field, definition, unit, role in rows
    ]


def _threshold_calibration_rows(result: dict[str, Any]) -> list[dict[str, Any]]:
    calibration = dict(result.get("threshold_calibration", {}) or {})
    rows: list[dict[str, Any]] = []
    for key, label in (("production", "Production-input similarity"), ("market", "Intermediate-market similarity")):
        evidence = dict(calibration.get(key, {}) or {})
        if not evidence:
            continue
        rows.append(
            {
                "similarity_dimension": label,
                "method": calibration.get("method", evidence.get("method")),
                "release_id": calibration.get("release_id"),
                "calibration_year": calibration.get("calibration_year"),
                "candidate_universe_count": calibration.get("candidate_universe_count"),
                "threshold": evidence.get("threshold"),
                "sample_count": evidence.get("sample_count"),
                "distinct_value_count": evidence.get("distinct_value_count"),
                "split_index": evidence.get("split_index"),
                "lower_class_count": evidence.get("lower_class_count"),
                "upper_class_count": evidence.get("upper_class_count"),
                "lower_class_mean": evidence.get("lower_class_mean"),
                "upper_class_mean": evidence.get("upper_class_mean"),
                "lower_boundary_value": evidence.get("lower_boundary_value"),
                "upper_boundary_value": evidence.get("upper_boundary_value"),
                "between_class_variance": evidence.get("between_class_variance"),
                "candidate_universe_definition": calibration.get("candidate_universe_definition"),
                "calibration_order": calibration.get("calibration_order"),
                "claim_boundary": calibration.get("claim_boundary"),
            }
        )
    return rows


def build_export_frames(result: dict[str, Any]) -> dict[str, pd.DataFrame]:
    """Create the workbook/CSV frames from an enriched AURORA result."""

    enriched = enrich_aurora_result(result)
    all_candidates = enriched.get("all_candidates", [])
    eligible = enriched.get("eligible_candidates", [])
    pareto = enriched.get("pareto_efficient_candidates", [])
    recommended = enriched.get("recommended_opportunities", [])

    summary_rows = [
        {"metric": "Method", "value": enriched.get("method"), "unit": "", "interpretation": enriched.get("method_name", "")},
        {"metric": "Primary year", "value": enriched.get("year"), "unit": "year", "interpretation": "AURORA assessment year."},
        {"metric": "Company footprint", "value": enriched.get("company_footprint"), "unit": "t CO2", "interpretation": "Focal-company consumption-based footprint used for opportunity shares."},
        {"metric": "Demanded sectors", "value": enriched.get("demanded_sector_count"), "unit": "count", "interpretation": "Sectors with positive focal-company demand."},
        {"metric": "Same-sector candidates", "value": len(all_candidates), "unit": "count", "interpretation": "Positive-output regional variants of demanded sectors."},
        {"metric": "Eligible candidates", "value": len(eligible), "unit": "count", "interpretation": "Candidates passing structural, carbon, and linkage gates."},
        {"metric": "Pareto-efficient candidates", "value": len(pareto), "unit": "count", "interpretation": "Eligible non-dominated candidates."},
        {"metric": "Displayed recommendations", "value": len(recommended), "unit": "count", "interpretation": "Pareto candidates retained within the per-sector display cap."},
        {"metric": "Stable displayed recommendations", "value": sum(_as_bool(row.get("stable_reference_year_signal")) for row in recommended), "unit": "count", "interpretation": "Recommendations that remain eligible in the comparison year."},
        {"metric": "Production similarity threshold", "value": (enriched.get("configuration", {}) or {}).get("production_similarity_threshold"), "unit": "dimensionless", "interpretation": "Exact bin-free Otsu threshold calibrated from the 2014 complete candidate universe."},
        {"metric": "Market similarity threshold", "value": (enriched.get("configuration", {}) or {}).get("market_similarity_threshold"), "unit": "dimensionless", "interpretation": "Exact bin-free Otsu threshold calibrated from the 2014 complete candidate universe."},
        {"metric": "Threshold calibration method", "value": (enriched.get("threshold_calibration", {}) or {}).get("method"), "unit": "", "interpretation": "Data-driven structural-similarity calibration method."},
        {"metric": "Reporting schema", "value": enriched.get("reporting_schema_version"), "unit": "", "interpretation": "AURORA decision-trace export schema."},
        {"metric": "Reporting release", "value": enriched.get("reporting_release_id"), "unit": "", "interpretation": "AURORA decision-trace and complete-export extension."},
    ]

    cross_year = [
        {key: row.get(key) for key in CROSS_YEAR_COLUMNS}
        for row in enriched.get("cross_year_evidence", [])
    ]
    decision_trace = [
        {key: row.get(key) for key in DECISION_TRACE_COLUMNS}
        for row in all_candidates
    ]

    config_rows = [
        {"parameter": key, "value": _flatten_cell(value), "role": "AURORA analytical configuration"}
        for key, value in (enriched.get("configuration", {}) or {}).items()
    ]
    config_rows.extend(
        {"parameter": key, "value": _flatten_cell(value), "role": "Decision-reporting interpretation"}
        for key, value in (enriched.get("selection_logic", {}) or {}).items()
    )

    note_rows = [
        {"item": "Source result CID", "detail": enriched.get("source_result_cid", "")},
        {"item": "Claim boundary", "detail": enriched.get("claim_boundary", "")},
        {"item": "DLI rule", "detail": enriched.get("dli_rule", "")},
        {"item": "Non-additivity", "detail": enriched.get("non_additivity_note", "")},
        {"item": "Display cap", "detail": enriched.get("display_cap_note", "")},
        {"item": "Reporting boundary", "detail": enriched.get("reporting_boundary", "")},
        {"item": "Units", "detail": _safe_json(enriched.get("units", {}))},
        {"item": "Cross-year comparison", "detail": _safe_json(enriched.get("cross_year_comparison", {}))},
        {"item": "Input hashes", "detail": _safe_json(enriched.get("input_hashes", {}))},
        {"item": "Network result hash", "detail": enriched.get("network_result_hash", "")},
        {"item": "Threshold calibration", "detail": _safe_json(enriched.get("threshold_calibration", {}))},
    ]

    return {
        "AURORA_Summary": _subset_frame(summary_rows),
        "Threshold_Calibration": _subset_frame(_threshold_calibration_rows(enriched)),
        "Decision_Funnel": _subset_frame(enriched.get("decision_funnel", [])),
        "Sector_Funnel": _subset_frame(enriched.get("sector_summaries", [])),
        "Recommended": _subset_frame(recommended, RECOMMENDED_COLUMNS),
        "Pareto_Candidates": _subset_frame(pareto, RECOMMENDED_COLUMNS),
        "Eligible_Candidates": _subset_frame(eligible, RECOMMENDED_COLUMNS),
        "Decision_Trace": _subset_frame(decision_trace, DECISION_TRACE_COLUMNS),
        "All_Candidates": _subset_frame(all_candidates),
        "Cross_Year_Evidence": _subset_frame(cross_year, CROSS_YEAR_COLUMNS),
        "Current_Mix": _subset_frame(enriched.get("current_mix", [])),
        "Configuration": _subset_frame(config_rows),
        "Data_Dictionary": _subset_frame(_data_dictionary_rows()),
        "Provenance_Notes": _subset_frame(note_rows),
    }


def _safe_sheet_name(name: str) -> str:
    cleaned = "".join(character for character in name if character not in "[]:*?/\\")
    return cleaned[:31] or "Sheet"


def _format_workbook(body: bytes) -> bytes:
    stream = BytesIO(body)
    workbook = load_workbook(stream)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    title_fill = PatternFill("solid", fgColor="D9EAF7")
    thin_blue = Side(style="thin", color="5B9BD5")
    section_border = Border(bottom=thin_blue)

    for worksheet in workbook.worksheets:
        worksheet.sheet_view.showGridLines = False
        worksheet.freeze_panes = "A2"
        if worksheet.max_row >= 1 and worksheet.max_column >= 1:
            worksheet.auto_filter.ref = worksheet.dimensions
        for cell in worksheet[1]:
            cell.fill = header_fill
            cell.font = header_font
            cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            cell.border = section_border
        worksheet.row_dimensions[1].height = 32

        headers = {cell.column: str(cell.value or "") for cell in worksheet[1]}
        for column_index, header in headers.items():
            lower = header.lower()
            for row_index in range(2, worksheet.max_row + 1):
                cell = worksheet.cell(row=row_index, column=column_index)
                cell.alignment = Alignment(vertical="top", wrap_text=(len(lower) > 24 or "note" in lower or "reason" in lower or "trace" in lower or "recommendation" in lower or "lens" in lower))
                if header in PERCENT_FIELDS or "share" in lower or "relative_multiplier_reduction" in lower:
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = "0.00%"
                elif header in SIMILARITY_FIELDS or header in DLI_FIELDS or "similarity" in lower or lower.startswith("dli") or lower.endswith("_norm"):
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = "0.0000"
                elif "sector_demand" in lower or "company_demand" in lower:
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = '$#,##0.00'
                elif "full_reallocation_opportunity" in lower or "company_footprint" in lower:
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = '0.000000'
                elif "multiplier" in lower:
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = '0.000000000'
                elif "intermediate_sales" in lower or "direct_flow" in lower:
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = '0.000000'
                elif header in INTEGER_FIELDS or "count" in lower or "rank" in lower or lower.endswith("_code") or lower == "year":
                    if isinstance(cell.value, (int, float)):
                        cell.number_format = '0'

        for column_index in range(1, worksheet.max_column + 1):
            values = [worksheet.cell(row=row, column=column_index).value for row in range(1, min(worksheet.max_row, 250) + 1)]
            max_length = max((len(str(value)) for value in values if value is not None), default=8)
            header = headers.get(column_index, "").lower()
            if any(token in header for token in ("recommendation", "reason", "trace", "lens", "condition", "interpretation", "detail")):
                width = min(max(max_length + 2, 28), 70)
            else:
                width = min(max(max_length + 2, 11), 34)
            worksheet.column_dimensions[get_column_letter(column_index)].width = width

        if worksheet.title in {"AURORA_Summary", "Threshold_Calibration", "Decision_Funnel", "Sector_Funnel"}:
            worksheet.sheet_properties.tabColor = "5B9BD5"
        elif worksheet.title in {"Recommended", "Pareto_Candidates", "Eligible_Candidates"}:
            worksheet.sheet_properties.tabColor = "70AD47"
        elif worksheet.title in {"Decision_Trace", "All_Candidates", "Cross_Year_Evidence"}:
            worksheet.sheet_properties.tabColor = "ED7D31"
        elif worksheet.title == "Data_Dictionary":
            worksheet.sheet_properties.tabColor = "8064A2"
        else:
            worksheet.sheet_properties.tabColor = "A5A5A5"

    output = BytesIO()
    workbook.save(output)
    return output.getvalue()


def build_excel_workbook_bytes(
    result: dict[str, Any],
    *,
    source_result_cid: str = "",
) -> bytes:
    """Build the complete audit-friendly AURORA workbook in memory."""

    enriched = enrich_aurora_result(result)
    if source_result_cid:
        enriched["source_result_cid"] = str(source_result_cid)
        enriched.setdefault("input_hashes", result.get("input_hashes", {}))
    frames = build_export_frames(enriched)
    raw = BytesIO()
    with pd.ExcelWriter(raw, engine="openpyxl") as writer:
        for name, frame in frames.items():
            frame.to_excel(writer, sheet_name=_safe_sheet_name(name), index=False)
    return _format_workbook(raw.getvalue())


def _atomic_write(path: Path, body: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{os.getpid()}.tmp")
    temporary.write_bytes(body)
    temporary.replace(path)


def _sha256_bytes(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def write_runtime_exports(
    result: dict[str, Any],
    output_dir: str | Path,
    *,
    year: int,
    source_result_cid: str,
) -> dict[str, Any]:
    """Write complete AURORA convenience exports and return their provenance."""

    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    enriched = enrich_aurora_result(result)
    enriched["source_result_cid"] = str(source_result_cid)
    frames = build_export_frames(enriched)
    stem = f"aurora_{int(year)}"

    workbook_path = output / f"{stem}_complete_results.xlsx"
    workbook_body = build_excel_workbook_bytes(enriched, source_result_cid=source_result_cid)
    _atomic_write(workbook_path, workbook_body)

    csv_map = {
        "threshold_calibration": "Threshold_Calibration",
        "recommended": "Recommended",
        "pareto_candidates": "Pareto_Candidates",
        "eligible_candidates": "Eligible_Candidates",
        "decision_funnel": "Decision_Funnel",
        "sector_funnel": "Sector_Funnel",
        "decision_trace": "Decision_Trace",
        "all_candidates": "All_Candidates",
        "cross_year_evidence": "Cross_Year_Evidence",
        "current_mix": "Current_Mix",
        "configuration": "Configuration",
        "data_dictionary": "Data_Dictionary",
        "provenance_notes": "Provenance_Notes",
    }
    files: dict[str, dict[str, Any]] = {
        "workbook": {
            "path": str(workbook_path),
            "sha256": _sha256_bytes(workbook_body),
            "size_bytes": len(workbook_body),
        }
    }
    for key, sheet_name in csv_map.items():
        path = output / f"{stem}_{key}.csv"
        body = frames[sheet_name].to_csv(index=False).encode("utf-8-sig")
        _atomic_write(path, body)
        files[key] = {
            "path": str(path),
            "sha256": _sha256_bytes(body),
            "size_bytes": len(body),
        }

    manifest = {
        "kind": "aurora_reporting_exports",
        "reporting_schema_version": REPORTING_SCHEMA_VERSION,
        "reporting_release_id": REPORTING_RELEASE_ID,
        "year": int(year),
        "source_result_cid": str(source_result_cid),
        "input_hashes": enriched.get("input_hashes", {}),
        "files": files,
        "authority_boundary": (
            "These files are convenience exports of the content-addressed AURORA result. "
            "The source result CID remains the authoritative analytical record."
        ),
    }
    manifest_path = output / f"{stem}_exports.json"
    manifest_body = json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True).encode("utf-8")
    _atomic_write(manifest_path, manifest_body)
    manifest["manifest_path"] = str(manifest_path)
    manifest["manifest_sha256"] = _sha256_bytes(manifest_body)
    return manifest

