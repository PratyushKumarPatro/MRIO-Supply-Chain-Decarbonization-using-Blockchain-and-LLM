"""Run an auditable analytical and computational validation report.

This command validates the deterministic calculation chain against the active
MRIO and focal-demand workbooks.  It is deliberately separate from the live
LLM evaluator: a successful run confirms internal implementation consistency,
not empirical truth of input data or causal intervention effectiveness.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

import analytics_engine as ae
import input_onboarding as onboarding
import network_engine as net
import sda_engine as sda
import spa_engine as spa


PACKAGE_ROOT = Path(__file__).resolve().parent
DEFAULT_MRIO = PACKAGE_ROOT / "input_mrio_completed.xlsx"
DEFAULT_FOCAL_DEMAND = PACKAGE_ROOT / "Focal_Company_Demand_Converted.xlsx"
DEFAULT_YEARS = (2014, 2017)
ANALYTICAL_VALIDATION_SCHEMA_VERSION = "analytical_computational_validation_v2"
ABSOLUTE_TOLERANCE = 1e-8
RELATIVE_TOLERANCE = 1e-9
SPA_TIER_RELATIVE_TOLERANCE = 1e-5


class AnalyticalValidationError(RuntimeError):
    """Raised when a mandatory deterministic consistency gate fails."""


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_default(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Cannot serialise {type(value).__name__}")


def _is_close(left: float, right: float, *, absolute: float = ABSOLUTE_TOLERANCE, relative: float = RELATIVE_TOLERANCE) -> bool:
    """Finite absolute-and-relative numerical equality check."""
    if not math.isfinite(float(left)) or not math.isfinite(float(right)):
        return False
    return abs(float(left) - float(right)) <= float(absolute) + float(relative) * max(
        1.0, abs(float(left)), abs(float(right))
    )


def _require_finite(name: str, values: Any, *, non_negative: bool = False) -> np.ndarray:
    array = np.asarray(values, dtype=float)
    if not np.isfinite(array).all():
        raise AnalyticalValidationError(f"{name} contains non-finite values.")
    if non_negative and (array < -ABSOLUTE_TOLERANCE).any():
        raise AnalyticalValidationError(f"{name} contains negative values.")
    return array


def _package_provenance() -> dict[str, Any]:
    version_path = PACKAGE_ROOT / "VERSION.txt"
    manifest_path = PACKAGE_ROOT / "BUILD_MANIFEST_SHA256.txt"
    return {
        "package_root": str(PACKAGE_ROOT),
        "version_file_sha256": _sha256_file(version_path) if version_path.is_file() else None,
        "version_text": version_path.read_text(encoding="utf-8") if version_path.is_file() else None,
        "build_manifest_sha256": _sha256_file(manifest_path) if manifest_path.is_file() else None,
    }


def _validate_workbook_schema_and_alignment(mrio_path: Path, focal_demand_path: Path) -> dict[str, Any]:
    """Run the same schema/node-order guards used by governed input onboarding."""
    mrio_validation = onboarding.validate_mrio_bytes(Path(mrio_path).read_bytes())
    focal_validation = onboarding.validate_focal_demand_bytes(
        Path(focal_demand_path).read_bytes(),
        expected_node_codes=list(mrio_validation["node_codes"]),
    )
    return {
        "mrio": {key: value for key, value in mrio_validation.items() if key != "node_codes"},
        "focal_demand": {key: value for key, value in focal_validation.items() if key != "node_codes"},
        "node_order_alignment": True,
    }


def bind_input_provenance(
    mrio_path: Path,
    focal_demand_path: Path,
    *,
    allow_unmanaged_inputs: bool = False,
) -> dict[str, Any]:
    """Bind a validation run to active governed bytes, or label an explicit external run.

    Default mode is deliberately fail-closed: merely passing two readable
    workbooks must not allow a report to claim validation of the deployed
    active input set.
    """
    mrio_path = Path(mrio_path).resolve()
    focal_demand_path = Path(focal_demand_path).resolve()
    if not mrio_path.is_file() or not focal_demand_path.is_file():
        raise FileNotFoundError("Both MRIO and focal-demand paths must reference existing workbooks.")
    source_hashes = {"mrio": _sha256_file(mrio_path), "focal_demand": _sha256_file(focal_demand_path)}
    workbook_validation = _validate_workbook_schema_and_alignment(mrio_path, focal_demand_path)
    canonical_paths = {
        "mrio": (PACKAGE_ROOT / onboarding.KIND_CONFIG["mrio"]["canonical_name"]).resolve(),
        "focal_demand": (PACKAGE_ROOT / onboarding.KIND_CONFIG["focal_demand"]["canonical_name"]).resolve(),
    }
    base = {
        "input_hashes": source_hashes,
        "input_paths": {"mrio": str(mrio_path), "focal_demand": str(focal_demand_path)},
        "canonical_paths": {key: str(value) for key, value in canonical_paths.items()},
        "workbook_schema_and_alignment": workbook_validation,
        "package": _package_provenance(),
    }
    if allow_unmanaged_inputs:
        return {
            **base,
            "input_mode": "unmanaged_external_exploration",
            "claim_boundary": (
                "This run used explicitly unmanaged external workbooks. It is an exploratory implementation check "
                "and must not be reported as validation of the active governed deployment inputs."
            ),
            "active_input_records": None,
        }
    active_hashes = onboarding.active_input_hashes(require_both=True)
    active_records = {
        key: onboarding.active_input_record(key)
        for key in ("mrio", "focal_demand")
    }
    if not all(isinstance(record, dict) and record.get("status") == "active" for record in active_records.values()):
        raise AnalyticalValidationError("Both input records must be active before a managed validation run.")
    canonical_hashes: dict[str, str] = {}
    for key, path in canonical_paths.items():
        if not path.is_file():
            raise AnalyticalValidationError(f"The active canonical {key.replace('_', '-')} workbook is unavailable: {path}")
        canonical_hashes[key] = _sha256_file(path)
    if source_hashes != active_hashes or canonical_hashes != active_hashes:
        raise AnalyticalValidationError(
            "Validation workbooks do not exactly match the currently active governed input hashes. "
            "Use the promoted canonical inputs or add --allow-unmanaged-inputs for an explicitly external exploration."
        )
    return {
        **base,
        "input_mode": "active_governed_inputs",
        "active_input_hashes": dict(active_hashes),
        "canonical_input_hashes": canonical_hashes,
        "active_input_records": active_records,
        "claim_boundary": "Inputs were bound to the currently active governed workbook hashes before validation.",
    }


def verify_input_snapshot(mrio_path: Path, focal_demand_path: Path, provenance: dict[str, Any]) -> None:
    """Reject time-of-check/time-of-use changes before a report is published."""
    expected = dict(provenance.get("input_hashes", {}))
    current = {"mrio": _sha256_file(mrio_path), "focal_demand": _sha256_file(focal_demand_path)}
    if current != expected:
        raise AnalyticalValidationError(
            "A validation input changed while the calculation was running. No report was published; run again."
        )
    if provenance.get("input_mode") == "active_governed_inputs":
        active_hashes = onboarding.active_input_hashes(require_both=True)
        canonical = {
            "mrio": _sha256_file(PACKAGE_ROOT / onboarding.KIND_CONFIG["mrio"]["canonical_name"]),
            "focal_demand": _sha256_file(PACKAGE_ROOT / onboarding.KIND_CONFIG["focal_demand"]["canonical_name"]),
        }
        if active_hashes != expected or canonical != expected:
            raise AnalyticalValidationError(
                "The active governed input set changed during validation. No report was published; run again."
            )


def _technical_coefficients(my: ae.MRIOYear) -> np.ndarray:
    matrix = np.zeros_like(my.Z, dtype=float)
    positive_output = np.asarray(my.X, dtype=float) > 0.0
    matrix[:, positive_output] = my.Z[:, positive_output] / my.X[positive_output][np.newaxis, :]
    return _require_finite("Technical-coefficient matrix", matrix, non_negative=True)


def _spa_exact_tier_check(my: ae.MRIOYear, demand: np.ndarray, config: spa.SPAConfig) -> dict[str, Any]:
    """Check the independent exact tier sum used to validate bounded paths."""
    matrix = _technical_coefficients(my)
    vector = _require_finite("SPA demand vector", demand, non_negative=True).reshape(-1).copy()
    total = float(my.footprint(vector))
    if not math.isfinite(total) or total < -ABSOLUTE_TOLERANCE:
        raise AnalyticalValidationError(f"SPA reference footprint for {my.year} is non-finite or negative.")
    cumulative = 0.0
    previous = 0.0
    tiers: list[dict[str, float | int]] = []
    for depth in range(int(config.exact_max_tier) + 1):
        if depth:
            vector = matrix @ vector
        tier = float(my.fE @ vector)
        if not math.isfinite(tier) or tier < -ABSOLUTE_TOLERANCE:
            raise AnalyticalValidationError(f"Exact SPA tier {depth} for {my.year} is non-finite or negative.")
        cumulative += tier
        if not math.isfinite(cumulative) or cumulative + ABSOLUTE_TOLERANCE < previous:
            raise AnalyticalValidationError(f"Exact SPA cumulative tiers are non-monotonic for {my.year}.")
        previous = cumulative
        tiers.append(
            {
                "depth": int(depth),
                "tier_footprint": tier,
                "cumulative_footprint": cumulative,
                "coverage": cumulative / total if total else 0.0,
            }
        )
    coverage = cumulative / total if total else 1.0
    if not math.isfinite(coverage):
        raise AnalyticalValidationError(f"Exact SPA coverage is non-finite for {my.year}.")
    if coverage < -RELATIVE_TOLERANCE or coverage > 1.0 + RELATIVE_TOLERANCE:
        raise AnalyticalValidationError(
            f"Exact SPA tier series overshoots the reference footprint for {my.year}: coverage={coverage:.8f}."
        )
    return {
        "exact_max_tier": int(config.exact_max_tier),
        "exact_cumulative_footprint": cumulative,
        "total_footprint": total,
        "coverage": coverage,
        "absolute_residual": abs(total - cumulative),
        "tiers": tiers,
    }


def _validate_demand(demand: np.ndarray, year: int) -> dict[str, Any]:
    values = _require_finite(f"Focal demand for {year}", demand, non_negative=True).reshape(-1)
    if len(values) != ae.N:
        raise AnalyticalValidationError(f"Focal demand for {year} has {len(values)} elements; expected {ae.N}.")
    return {
        "node_count": int(len(values)),
        "total_demand": float(values.sum()),
        "finite": True,
        "non_negative": True,
    }


def _year_validation(my: ae.MRIOYear, demand: np.ndarray) -> tuple[dict[str, Any], pd.DataFrame]:
    mrio = ae.validate(my)
    for field in ("max_abs_diff_X", "direct_emissions_total", "footprint_of_economy_wide_Y"):
        if not math.isfinite(float(mrio.get(field, float("nan")))):
            raise AnalyticalValidationError(f"MRIO identity diagnostic {field} is non-finite for {my.year}.")
    if not mrio.get("L_at_Y_economy_matches_X") or not mrio.get("emissions_identity_holds"):
        raise AnalyticalValidationError(f"MRIO identity validation failed for {my.year}: {mrio}")
    demand_check = _validate_demand(demand, my.year)
    total = float(my.footprint(demand))
    hotspot_values = _require_finite(
        f"Hotspot contributions for {my.year}", my.footprint_by_node(demand), non_negative=True
    )
    node_sum = float(hotspot_values.sum())
    if not math.isfinite(total) or total < -ABSOLUTE_TOLERANCE:
        raise AnalyticalValidationError(f"Focal-company footprint is non-finite or negative for {my.year}.")
    footprint_residual = abs(total - node_sum)
    if not _is_close(total, node_sum):
        raise AnalyticalValidationError(
            f"Hotspot contribution reconciliation failed for {my.year}; residual={footprint_residual:.3e}."
        )
    initial_config = spa.SPAConfig()
    (
        screened_paths,
        reported_paths,
        spa_total,
        config,
        adaptive_attempts,
    ) = spa.trace_paths_to_threshold_adaptive(my, demand, initial_config)
    threshold_reached = bool(
        adaptive_attempts and adaptive_attempts[-1].get("threshold_reached", False)
    )
    reported_footprint = float(
        pd.to_numeric(reported_paths.get("contribution", pd.Series(dtype=float)), errors="coerce")
        .fillna(0.0)
        .sum()
    )
    reported_share = reported_footprint / total if total else 0.0
    if total > ABSOLUTE_TOLERANCE and not threshold_reached:
        raise AnalyticalValidationError(
            f"U17 SPA explicit paths do not reach the required {config.cumulative_target:.2%} "
            f"of the complete focal-company footprint for {my.year}; achieved {reported_share:.8%}."
        )
    if threshold_reached and len(reported_paths) > 1:
        prior_share = float(reported_paths["cumulative_share"].iloc[-2])
        if prior_share >= config.cumulative_target:
            raise AnalyticalValidationError(
                f"U17 SPA selection is not the minimum ranked prefix for {my.year}."
            )
    exact = _spa_exact_tier_check(my, demand, config)
    if not _is_close(float(spa_total), total):
        raise AnalyticalValidationError(f"SPA reported total is non-finite or differs from the MRIO reference for {my.year}.")
    if not _is_close(
        float(exact["exact_cumulative_footprint"]),
        total,
        absolute=ABSOLUTE_TOLERANCE,
        relative=SPA_TIER_RELATIVE_TOLERANCE,
    ) or not (1.0 - SPA_TIER_RELATIVE_TOLERANCE <= float(exact["coverage"]) <= 1.0 + RELATIVE_TOLERANCE):
        raise AnalyticalValidationError(
            f"Exact SPA tier coverage/reconciliation is insufficient for {my.year}: {exact['coverage']:.8f}."
        )
    raw_network = net.compute_raw_metrics(my, demand)
    required_raw_columns = {"year", "node_code", "region", "sector", *net.CRITERIA}
    missing_raw_columns = sorted(required_raw_columns.difference(raw_network.columns))
    if missing_raw_columns:
        raise AnalyticalValidationError(
            f"Raw network metrics for {my.year} are missing columns: {missing_raw_columns}."
        )
    if (
        len(raw_network) != ae.N
        or raw_network["node_code"].isna().any()
        or raw_network["node_code"].astype(str).str.casefold().duplicated().any()
    ):
        raise AnalyticalValidationError(
            f"Raw network metric node universe is incomplete or non-unique for {my.year}."
        )
    raw_years = pd.to_numeric(raw_network["year"], errors="coerce")
    if raw_years.isna().any() or set(raw_years.astype(int)) != {int(my.year)}:
        raise AnalyticalValidationError(f"Raw network metrics carry an invalid year label for {my.year}.")
    for criterion in net.CRITERIA:
        _require_finite(
            f"Raw network criterion {criterion} for {my.year}",
            raw_network[criterion],
            non_negative=True,
        )
    return {
        "mrio_internal_identity": mrio,
        "focal_demand": demand_check,
        "focal_company_footprint": total,
        "hotspot_sum": node_sum,
        "hotspot_reconciliation_residual": footprint_residual,
        "spa": {
            "coverage_target": float(config.cumulative_target),
            "coverage_target_basis": "complete focal-company footprint",
            "coverage_target_footprint": float(config.cumulative_target * total),
            "screened_path_count": int(len(screened_paths)),
            "reported_path_count": int(len(reported_paths)),
            "reported_path_footprint": reported_footprint,
            "threshold_reached": bool(threshold_reached),
            "screened_cumulative_share": float(screened_paths["cumulative_share"].iloc[-1]) if not screened_paths.empty else 0.0,
            "reported_cumulative_share": reported_share,
            "target_shortfall": max(0.0, config.cumulative_target * total - reported_footprint),
            "target_overshoot": max(0.0, reported_footprint - config.cumulative_target * total),
            "adaptive_expansion_attempts": adaptive_attempts,
            "exact_tier_check": exact,
        },
        "network_raw_metrics": {
            "node_count": int(len(raw_network)),
            "criteria": list(net.CRITERIA),
            "finite": True,
            "non_negative": True,
        },
    }, raw_network


def _validate_authoritative_pooled_dli(
    scored: pd.DataFrame,
    critic_result: Any,
    *,
    years: tuple[int, int],
) -> tuple[dict[str, Any], dict[int, pd.DataFrame], dict[int, dict[str, Any]]]:
    """Validate the one authoritative pooled Pearson-CRITIC ranking.

    The deployed method normalises the combined 2014/2017 observation matrix,
    derives one Pearson-CRITIC weight vector, and applies that same vector to
    both annual slices.  This gate intentionally contains no legacy fixed-
    weight comparison or within-year normalisation path.
    """
    if dict(getattr(net, "DLI_WEIGHTS", {})):
        raise AnalyticalValidationError(
            "The deployed network engine exposes non-empty fixed DLI weights; pooled CRITIC is not authoritative."
        )
    if str(getattr(critic_result, "scope", "")) != "pooled-2014-2017":
        raise AnalyticalValidationError("Authoritative CRITIC scope must be pooled-2014-2017.")
    if str(getattr(critic_result, "correlation_method", "")).lower() != "pearson":
        raise AnalyticalValidationError("Authoritative CRITIC correlation method must be Pearson.")

    weights = dict(getattr(critic_result, "weights", {}))
    if set(weights) != set(net.CRITERIA):
        raise AnalyticalValidationError(
            f"Authoritative CRITIC weights must contain exactly {list(net.CRITERIA)}."
        )
    weight_values = _require_finite("Authoritative CRITIC weights", list(weights.values()), non_negative=True)
    if not _is_close(float(weight_values.sum()), 1.0):
        raise AnalyticalValidationError("Authoritative CRITIC weights do not sum to one.")

    required = {
        "year",
        "node_code",
        "region",
        "sector",
        *net.CRITERIA,
        *[f"{criterion}_norm_critic" for criterion in net.CRITERIA],
        *[f"{criterion}_critic_weight_contribution" for criterion in net.CRITERIA],
        *[f"weight_{criterion}" for criterion in net.CRITERIA],
        "DLI",
        "dli_rank",
        "dominant_dli_component",
        "dli_weighting_method",
        "dli_weighting_scope",
        "critic_correlation_method",
    }
    missing = sorted(required.difference(scored.columns))
    if missing:
        raise AnalyticalValidationError(f"Pooled CRITIC-DLI ranking is missing columns: {missing}.")
    if len(scored) != ae.N * len(years):
        raise AnalyticalValidationError(
            f"Pooled CRITIC-DLI ranking has {len(scored)} rows; expected {ae.N * len(years)}."
        )

    numeric_years = pd.to_numeric(scored["year"], errors="coerce")
    if numeric_years.isna().any():
        raise AnalyticalValidationError("Pooled CRITIC-DLI ranking contains a missing or non-numeric year.")
    observed_years = set(numeric_years.astype(int))
    if observed_years != set(years):
        raise AnalyticalValidationError(
            f"Pooled CRITIC-DLI ranking years {sorted(observed_years)} do not match {list(years)}."
        )
    if set(scored["dli_weighting_method"].astype(str)) != {"CRITIC"}:
        raise AnalyticalValidationError("Pooled DLI rows are not uniformly labelled CRITIC.")
    if set(scored["dli_weighting_scope"].astype(str)) != {"pooled-2014-2017"}:
        raise AnalyticalValidationError("Pooled DLI rows carry an invalid weighting scope.")
    if set(scored["critic_correlation_method"].astype(str).str.lower()) != {"pearson"}:
        raise AnalyticalValidationError("Pooled DLI rows carry a non-Pearson CRITIC method.")

    pooled_raw = scored.loc[:, list(net.CRITERIA)].apply(pd.to_numeric, errors="coerce")
    if pooled_raw.isna().any().any() or not np.isfinite(pooled_raw.to_numpy(dtype=float)).all():
        raise AnalyticalValidationError("Pooled CRITIC evaluation matrix contains non-finite raw criteria.")
    result_minima = dict(getattr(critic_result, "minima", {}))
    result_maxima = dict(getattr(critic_result, "maxima", {}))
    if set(result_minima) != set(net.CRITERIA) or set(result_maxima) != set(net.CRITERIA):
        raise AnalyticalValidationError("CRITIC pooled minimum/maximum metadata is incomplete.")
    _require_finite("CRITIC pooled minima", list(result_minima.values()))
    _require_finite("CRITIC pooled maxima", list(result_maxima.values()))
    maximum_normalization_residual = 0.0
    for criterion in net.CRITERIA:
        raw_values = pooled_raw[criterion].to_numpy(dtype=float)
        minimum = float(np.min(raw_values))
        maximum = float(np.max(raw_values))
        if not _is_close(float(result_minima.get(criterion, float("nan"))), minimum):
            raise AnalyticalValidationError(f"CRITIC minimum metadata is inconsistent for {criterion}.")
        if not _is_close(float(result_maxima.get(criterion, float("nan"))), maximum):
            raise AnalyticalValidationError(f"CRITIC maximum metadata is inconsistent for {criterion}.")
        span = maximum - minimum
        expected_normalized = (
            np.zeros(len(raw_values), dtype=float)
            if abs(span) <= np.finfo(float).eps
            else (raw_values - minimum) / span
        )
        stored_normalized = _require_finite(
            f"Pooled CRITIC {criterion}_norm_critic",
            scored[f"{criterion}_norm_critic"],
        )
        maximum_normalization_residual = max(
            maximum_normalization_residual,
            float(np.max(np.abs(stored_normalized - expected_normalized))),
        )
    if maximum_normalization_residual > ABSOLUTE_TOLERANCE:
        raise AnalyticalValidationError(
            "CRITIC normalisation was not computed over the pooled 2014-2017 matrix; "
            f"residual={maximum_normalization_residual:.3e}."
        )

    annual_frames: dict[int, pd.DataFrame] = {}
    annual_summaries: dict[int, dict[str, Any]] = {}
    maximum_score_residual = 0.0
    maximum_contribution_residual = 0.0
    maximum_weight_column_residual = 0.0
    for year in years:
        annual = scored.loc[
            pd.to_numeric(scored["year"], errors="coerce") == int(year)
        ].copy()
        annual = annual.sort_values(["dli_rank", "node_code"], kind="mergesort").reset_index(drop=True)
        if (
            len(annual) != ae.N
            or annual["node_code"].isna().any()
            or annual["node_code"].astype(str).str.casefold().duplicated().any()
        ):
            raise AnalyticalValidationError(
                f"Authoritative CRITIC-DLI node universe is incomplete or non-unique for {year}."
            )

        contribution_sum = np.zeros(len(annual), dtype=float)
        contribution_residual = 0.0
        weight_column_residual = 0.0
        for criterion in net.CRITERIA:
            normalized_column = f"{criterion}_norm_critic"
            contribution_column = f"{criterion}_critic_weight_contribution"
            normalized = _require_finite(
                f"Pooled CRITIC {normalized_column} for {year}", annual[normalized_column]
            )
            if ((normalized < -ABSOLUTE_TOLERANCE) | (normalized > 1.0 + ABSOLUTE_TOLERANCE)).any():
                raise AnalyticalValidationError(
                    f"Pooled CRITIC {normalized_column} is outside [0, 1] for {year}."
                )
            contribution = _require_finite(
                f"Pooled CRITIC {contribution_column} for {year}", annual[contribution_column]
            )
            expected_contribution = float(weights[criterion]) * normalized
            contribution_residual = max(
                contribution_residual,
                float(np.max(np.abs(contribution - expected_contribution))),
            )
            stored_weights = _require_finite(
                f"Pooled CRITIC weight_{criterion} for {year}", annual[f"weight_{criterion}"]
            )
            weight_column_residual = max(
                weight_column_residual,
                float(np.max(np.abs(stored_weights - float(weights[criterion])))),
            )
            contribution_sum += contribution

        dli_values = _require_finite(f"Pooled CRITIC DLI for {year}", annual["DLI"])
        if ((dli_values < -ABSOLUTE_TOLERANCE) | (dli_values > 1.0 + ABSOLUTE_TOLERANCE)).any():
            raise AnalyticalValidationError(f"Pooled CRITIC DLI is outside [0, 1] for {year}.")
        score_residual = float(np.max(np.abs(dli_values - contribution_sum)))
        if contribution_residual > ABSOLUTE_TOLERANCE:
            raise AnalyticalValidationError(
                f"CRITIC contribution recomposition failed for {year}; residual={contribution_residual:.3e}."
            )
        if weight_column_residual > ABSOLUTE_TOLERANCE:
            raise AnalyticalValidationError(
                f"CRITIC weight metadata is inconsistent for {year}; residual={weight_column_residual:.3e}."
            )
        if score_residual > ABSOLUTE_TOLERANCE:
            raise AnalyticalValidationError(
                f"CRITIC DLI recomposition failed for {year}; residual={score_residual:.3e}."
            )

        stored_ranks = pd.to_numeric(annual["dli_rank"], errors="coerce")
        expected_ranks = pd.Series(dli_values).rank(method="min", ascending=False).astype(int)
        if stored_ranks.isna().any() or not np.array_equal(
            stored_ranks.astype(int).to_numpy(), expected_ranks.to_numpy()
        ):
            raise AnalyticalValidationError(f"CRITIC DLI ranks are inconsistent with scores for {year}.")

        maximum_score_residual = max(maximum_score_residual, score_residual)
        maximum_contribution_residual = max(maximum_contribution_residual, contribution_residual)
        maximum_weight_column_residual = max(maximum_weight_column_residual, weight_column_residual)
        annual_frames[int(year)] = annual
        annual_summaries[int(year)] = {
            "node_count": int(len(annual)),
            "method": "pooled Pearson-CRITIC DLI",
            "scope": "pooled-2014-2017",
            "correlation_method": "pearson",
            "weights": {criterion: float(weights[criterion]) for criterion in net.CRITERIA},
            "legacy_fixed_weights_used": False,
            "score_recomposition_max_abs_difference": score_residual,
            "contribution_recomposition_max_abs_difference": contribution_residual,
            "weight_metadata_max_abs_difference": weight_column_residual,
            "ranking_unique": True,
            "normalised_components_in_unit_interval": True,
            "top_15": annual[["node_code", "DLI", "dli_rank"]].head(15).to_dict(orient="records"),
        }

    node_sets = {
        year: set(frame["node_code"].astype(str).str.casefold())
        for year, frame in annual_frames.items()
    }
    if node_sets[years[0]] != node_sets[years[1]]:
        raise AnalyticalValidationError("Annual pooled CRITIC-DLI slices do not share the same node universe.")

    summary = {
        "method": "pooled Pearson-CRITIC DLI",
        "scope": "pooled-2014-2017",
        "correlation_method": "pearson",
        "reference_years": list(years),
        "observation_count": int(len(scored)),
        "node_count_per_year": ae.N,
        "criteria": list(net.CRITERIA),
        "normalised_columns": [f"{criterion}_norm_critic" for criterion in net.CRITERIA],
        "weights": {criterion: float(weights[criterion]) for criterion in net.CRITERIA},
        "legacy_fixed_weights_used": False,
        "normalization_max_abs_difference": maximum_normalization_residual,
        "score_recomposition_max_abs_difference": maximum_score_residual,
        "contribution_recomposition_max_abs_difference": maximum_contribution_residual,
        "weight_metadata_max_abs_difference": maximum_weight_column_residual,
    }
    return summary, annual_frames, annual_summaries


def run_validation(
    mrio_path: Path,
    focal_demand_path: Path,
    years: tuple[int, int],
    *,
    input_provenance: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Run MRIO, SPA, SDA and DLI implementation-consistency gates."""
    if tuple(years) != DEFAULT_YEARS:
        raise AnalyticalValidationError(
            "The authoritative pooled CRITIC validation requires reference years 2014 then 2017."
        )
    provenance = input_provenance or bind_input_provenance(mrio_path, focal_demand_path)
    models: dict[int, ae.MRIOYear] = {}
    demands: dict[int, np.ndarray] = {}
    raw_metrics: dict[int, pd.DataFrame] = {}
    rankings: dict[int, pd.DataFrame] = {}
    annual: dict[str, Any] = {}
    for year in years:
        model = ae.load_year(str(mrio_path), int(year))
        demand = ae.load_company_Y(str(focal_demand_path), int(year))
        result, raw_network = _year_validation(model, demand)
        models[int(year)] = model
        demands[int(year)] = demand
        raw_metrics[int(year)] = raw_network
        annual[str(year)] = result

    pooled_scored, critic_result = net.compute_pooled_dli(
        raw_metrics[years[0]],
        raw_metrics[years[1]],
        correlation_method="pearson",
    )
    pooled_summary, rankings, annual_dli = _validate_authoritative_pooled_dli(
        pooled_scored,
        critic_result,
        years=years,
    )
    for year in years:
        annual[str(year)]["dli"] = annual_dli[int(year)]

    inputs_base = sda.SDAInputs.from_year(models[years[0]], demands[years[0]])
    inputs_comp = sda.SDAInputs.from_year(models[years[1]], demands[years[1]])
    effects = sda.sda_decompose(inputs_base, inputs_comp)
    if not all(math.isfinite(float(value)) for value in effects.values()):
        raise AnalyticalValidationError("SDA produced a non-finite decomposition effect.")
    true_change = float(inputs_comp.footprint() - inputs_base.footprint())
    if not math.isfinite(true_change):
        raise AnalyticalValidationError("SDA true footprint change is non-finite.")
    sda_residual = float(sum(float(value) for value in effects.values()) - true_change)
    if not _is_close(sum(float(value) for value in effects.values()), true_change, absolute=1e-6, relative=RELATIVE_TOLERANCE):
        raise AnalyticalValidationError(f"SDA reconciliation failed; residual={sda_residual:.3e}.")
    temporal = net.compute_temporal_dli(
        rankings[years[0]], rankings[years[1]], base_year=years[0], comparison_year=years[1]
    )
    if len(temporal) != ae.N or temporal["node_code"].astype(str).str.casefold().duplicated().any():
        raise AnalyticalValidationError("Temporal DLI result does not contain the complete node universe.")
    if "two_period_status" not in temporal.columns:
        raise AnalyticalValidationError("Temporal DLI result is missing its two-period status classification.")
    verify_input_snapshot(mrio_path, focal_demand_path, provenance)
    return {
        "validation_scope": (
            "Internal analytical and computational consistency checks only; this output does not independently validate "
            "input-data quality, DLI construct validity, weight preference validity, or causal intervention effects."
        ),
        "input_provenance": provenance,
        "reference_years": list(years),
        "annual": annual,
        "pooled_critic_dli": pooled_summary,
        "sda": {
            "effects": {key: float(value) for key, value in effects.items()},
            "true_change": true_change,
            "reconciliation_residual": sda_residual,
        },
        "temporal_dli": {
            "node_count": int(len(temporal)),
            "complete_node_universe": True,
            "two_period_status_counts": {
                str(key): int(value)
                for key, value in temporal["two_period_status"].value_counts().items()
            },
        },
    }


def _report(result: dict[str, Any], *, mrio_path: Path, focal_path: Path, hashes: dict[str, str]) -> str:
    input_provenance = result.get("input_provenance", {})
    input_mode = str(input_provenance.get("input_mode", "not recorded"))
    lines = [
        "# Analytical and computational validation report",
        "",
        "## Scope",
        "",
        result["validation_scope"],
        "",
        "## Input provenance",
        "",
        f"- MRIO workbook: `{mrio_path.resolve()}`",
        f"- MRIO SHA-256: `{hashes['mrio']}`",
        f"- Focal-demand workbook: `{focal_path.resolve()}`",
        f"- Focal-demand SHA-256: `{hashes['focal_demand']}`",
        f"- Input mode: `{input_mode}`",
        f"- Input binding: {input_provenance.get('claim_boundary', 'not recorded')}",
        "",
        "## Annual gates",
        "",
        "| Year | MRIO X residual | MRIO emissions residual | Hotspot residual | Exact SPA tier coverage | Pooled CRITIC-DLI residual |",
        "|---:|---:|---:|---:|---:|---:|",
    ]
    for year in result["reference_years"]:
        annual = result["annual"][str(year)]
        mrio = annual["mrio_internal_identity"]
        spa_check = annual["spa"]["exact_tier_check"]
        dli = annual["dli"]
        emissions_residual = abs(
            float(mrio["direct_emissions_total"]) - float(mrio["footprint_of_economy_wide_Y"])
        )
        lines.append(
            f"| {year} | {float(mrio['max_abs_diff_X']):.3e} | {emissions_residual:.3e} | "
            f"{annual['hotspot_reconciliation_residual']:.3e} | {spa_check['coverage']:.8f} | "
            f"{dli['score_recomposition_max_abs_difference']:.3e} |"
        )
    pooled = result.get("pooled_critic_dli", {})
    lines.extend(
        [
            "",
            "## Cross-year gates",
            "",
            f"- SDA reconciliation residual: `{result['sda']['reconciliation_residual']:.3e}`",
            f"- Temporal DLI node universe: `{result['temporal_dli']['node_count']}` nodes (complete)",
            f"- DLI weighting method: `{pooled.get('method', 'not recorded')}`",
            f"- CRITIC scope: `{pooled.get('scope', 'not recorded')}`",
            f"- CRITIC correlation: `{pooled.get('correlation_method', 'not recorded')}`",
            f"- Shared CRITIC weights: `{pooled.get('weights', {})}`",
            f"- Legacy fixed weights used: `{pooled.get('legacy_fixed_weights_used', 'not recorded')}`",
            "",
            "## Interpretation",
            "",
            "All listed checks passed. This supports reproducible internal operation of the deterministic implementation. "
            "The exact SPA tier calculation is an independent matrix-power series check of the Leontief footprint; "
            "the bounded path list remains an explanatory screen, not a complete path enumeration. The annual DLI rankings "
            "were validated as two slices of one pooled 2014-2017 Pearson-CRITIC evaluation matrix using a shared objective "
            "weight vector; no legacy fixed DLI weights were used. Independent expert decision-support review is still "
            "required before making broader claims about construct validity, practical usefulness or causal effectiveness.",
            "",
        ]
    )
    return "\n".join(lines)


def write_result(
    result: dict[str, Any],
    *,
    mrio_path: Path,
    focal_path: Path,
    output_dir: Path | None = None,
) -> Path:
    """Persist a report without modifying analytical or blockchain runtime state."""
    if output_dir is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        output_dir = Path(__file__).resolve().parent / "analytical_computational_validation_results" / stamp
    output = Path(output_dir).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Refusing to overwrite non-empty validation directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    hashes = {"mrio": _sha256_file(mrio_path), "focal_demand": _sha256_file(focal_path)}
    provenance = result.get("input_provenance", {})
    if isinstance(provenance, dict):
        verify_input_snapshot(mrio_path, focal_path, provenance)
    summary = {
        "schema_version": ANALYTICAL_VALIDATION_SCHEMA_VERSION,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "input_hashes": hashes,
        "input_provenance": provenance,
        "run_configuration": {"reference_years": result.get("reference_years", [])},
        "package": _package_provenance(),
        "result": result,
    }
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False, default=_json_default) + "\n", encoding="utf-8"
    )
    (output / "report.md").write_text(
        _report(result, mrio_path=mrio_path, focal_path=focal_path, hashes=hashes), encoding="utf-8"
    )
    return output


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description="Validate deterministic MRIO, SPA, SDA and DLI implementation consistency for two reference years."
    )
    parser.add_argument("--mrio", type=Path, default=DEFAULT_MRIO, help="Validated MRIO workbook path.")
    parser.add_argument("--focal-demand", type=Path, default=DEFAULT_FOCAL_DEMAND, help="Validated focal-demand workbook path.")
    parser.add_argument("--years", nargs=2, type=int, default=list(DEFAULT_YEARS), metavar=("BASE", "COMPARISON"))
    parser.add_argument("--output-dir", type=Path, default=None, help="Empty directory for report outputs.")
    parser.add_argument("--dry-run", action="store_true", help="Check that workbooks can be located before running calculations.")
    parser.add_argument(
        "--allow-unmanaged-inputs",
        action="store_true",
        help=(
            "Allow explicitly external workbooks for an exploratory implementation check. "
            "The report will not claim validation of active governed inputs."
        ),
    )
    args = parser.parse_args(argv)
    mrio_path = Path(args.mrio)
    focal_path = Path(args.focal_demand)
    if not mrio_path.is_file() or not focal_path.is_file():
        raise FileNotFoundError("Both --mrio and --focal-demand must reference existing validated workbooks.")
    years = (int(args.years[0]), int(args.years[1]))
    provenance = bind_input_provenance(
        mrio_path,
        focal_path,
        allow_unmanaged_inputs=bool(args.allow_unmanaged_inputs),
    )
    if args.dry_run:
        print(
            f"Validated input binding: mode={provenance['input_mode']}; "
            f"MRIO={mrio_path}; focal demand={focal_path}; years={years}."
        )
        return 0
    result = run_validation(mrio_path, focal_path, years, input_provenance=provenance)
    output = write_result(result, mrio_path=mrio_path, focal_path=focal_path, output_dir=args.output_dir)
    print(f"Analytical/computational validation results written to {output}")
    print(f"Read {output / 'report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
