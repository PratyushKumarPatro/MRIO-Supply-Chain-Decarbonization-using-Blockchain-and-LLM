"""Compatibility routing helpers and task-aware answer-alignment checks.

V5.0.17 uses :mod:`llm_first_orchestrator` as the primary Auto/Research task
interpreter. This module retains the validated deterministic system-meta signals,
legacy route helpers, output-contract parsing, and lightweight post-generation
alignment checks used across the package. Project-specific quantitative authority
remains with the closed deterministic tools.
"""
from __future__ import annotations

import json
import os
import re
from typing import Any

from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

QUERY_UNDERSTANDING_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "primary_intent": {
            "type": "string",
            "enum": [
                "research_concept",
                "research_method",
                "research_analytics",
                "research_strategy",
                "research_scenario",
                "system_meta",
                "general",
                "hybrid",
                "ambiguous",
            ],
        },
        "domain_relevance": {
            "type": "string",
            "enum": ["project", "general", "mixed", "unclear"],
        },
        "requires_project_evidence": {"type": "boolean"},
        "requires_deterministic_computation": {"type": "boolean"},
        "requires_architecture_knowledge": {"type": "boolean"},
        "requires_general_reasoning": {"type": "boolean"},
        "user_goal": {"type": "string"},
        "confidence": {"type": "number", "minimum": 0.0, "maximum": 1.0},
    },
    "required": [
        "primary_intent",
        "domain_relevance",
        "requires_project_evidence",
        "requires_deterministic_computation",
        "requires_architecture_knowledge",
        "requires_general_reasoning",
        "user_goal",
        "confidence",
    ],
}

PROJECT_REFERENCE_PATTERNS = [
    r"\bthis entire system\b",
    r"\bthe entire system\b",
    r"\bthis system\b",
    r"\bour system\b",
    r"\bthis architecture\b",
    r"\bour architecture\b",
    r"\bthis deployment\b",
    r"\bour deployment\b",
    r"\bthe deployment package\b",
    r"\bthis package\b",
    r"\bthis application\b",
    r"\b(?:the|this|our) assistant\b",
    r"\b(?:the|this|our) query (?:layer|router|response|process)\b",
    r"\bthis framework\b",
    r"\bour framework\b",
    r"\brq3\s*/?\s*rq4\b",
    r"\bfour[- ]oracle\b",
    r"\bquery management\b",
    r"\bquery oracle\b",
    r"\bgovernance oracle\b",
    r"\bdata orchestrator\b",
    r"\bganache\b",
    r"\bstreamlit\b",
    r"\bollama\b",
    r"\bsmart contracts?\b",
    r"\bcontent[- ]addressed\b",
    r"\bcontent store\b",
    r"\bthe whole setup\b",
    r"\bour setup\b",
]

SYSTEM_META_TASK_PATTERNS = [
    r"\bchallenges?\b",
    r"\blimitations?\b",
    r"\brisks?\b",
    r"\bweakness(?:es)?\b",
    r"\bshortcomings?\b",
    r"\bconcerns?\b",
    r"\bissues?\b",
    r"\bproblems?\b",
    r"\bwhat could go wrong\b",
    r"\bfail(?:ure|ures|ing)?\b",
    r"\breliab(?:le|ility)\b",
    r"\bscal(?:e|es|ing|ability|able)\b",
    r"\bdeploy(?:ment|ing|ed)?\b",
    r"\bproduction(?:[- ]ready| deployment)?\b",
    r"\bimplementation\b",
    r"\bmigrat(?:e|ion|ing)\b",
    r"\bsecurity\b",
    r"\bprivacy\b",
    r"\btrust boundary\b",
    r"\bcentralization\b",
    r"\bdecentrali[sz]ation\b",
    r"\bperformance\b",
    r"\blatency\b",
    r"\bavailability\b",
    r"\bmaintain(?:ability|ing)?\b",
    r"\bmonitor(?:ing)?\b",
    r"\bharden(?:ing)?\b",
    r"\bimprov(?:e|ed|ement|ements|ing)\b",
    r"\benhance(?:d|ment|ments|ing)?\b",
    r"\bimplications?\b",
    r"\bcritique\b",
    r"\bevaluat(?:e|ed|ion|ing)\b",
    r"\bpros? and cons?\b",
    r"\badvantages? and disadvantages?\b",
    r"\barchitecture\b",
    r"\bdesign choice\b",
    r"\bwhy (?:did|does|is) (?:the|this|our) (?:system|assistant|query|response)\b",
    r"\bwhy (?:did|does) it (?:answer|respond|route|retrieve)\b",
    r"\bhow (?:does|would|can) (?:the|this|our) (?:system|architecture|deployment|package|framework|assistant|query (?:layer|router|process))\b",
    r"\bhow (?:is|are) (?:the|this|our) (?:system|architecture|deployment|package|framework|assistant)\b",
    r"\bhandle(?:s|d|ing)? (?:query|request|response|routing|failure|error)\b",
]

STRONG_RESEARCH_PATTERNS = [
    r"\bcarbon accounting\b",
    r"\bcarbon footprint\b",
    r"\bembodied carbon\b",
    r"\bconsumption[- ]based\b",
    r"\bmrio\b",
    r"\bmulti[- ]regional input[- ]output\b",
    r"\bstructural path(?: analysis)?\b",
    r"\bspa\b",
    r"\bstructural decomposition(?: analysis)?\b",
    r"\bsda\b",
    r"\bdli\b",
    r"\bdecarboni[sz]ation leverage\b",
    r"\bemissions? hotspots?\b",
    r"\bcountry[- ]sector\b",
    r"\bwhich node\b",
    r"\bnode profile\b",
    r"\bintervention(?:s)?\b",
    r"\baurora\b",
    r"\bsourcing opportunit(?:y|ies)\b",
    r"\bcounterfactual\b",
    r"\bcompany[- ]share scenario\b",
    r"\b(?:2014|2017)\b.*\b(?:footprint|dli|hotspot|spa|sda|node)\b",
    r"\b[A-Z]{3}[-_][A-Za-z0-9]+\b",
]

HYBRID_PATTERNS = [
    r"\bbroader (?:context|perspective)\b",
    r"\bconventional (?:practice|approach|supplier engagement|method)\b",
    r"\bbest practice\b",
    r"\breal[- ]world\b",
    r"\boutside (?:this|the) (?:study|model|framework)\b",
    r"\bcompare (?:our|this)\b",
    r"\bmanagerial implications?\b",
    r"\bpolicy implications?\b",
]

FOLLOW_UP_META_PATTERNS = [
    r"\bhow can (?:we|it) improve\b",
    r"\bwhat about (?:security|privacy|scalability|production)\b",
    r"\band the risks?\b",
    r"\band the limitations?\b",
    r"\btell me more\b",
    r"\belaborate\b",
    r"\bwhat should we change\b",
    r"\bhow do we fix (?:that|it)\b",
]


def _contains(patterns: list[str], text: str) -> bool:
    return any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in patterns)


def _project_reference(question: str) -> bool:
    return _contains(PROJECT_REFERENCE_PATTERNS, question)


def _system_meta_task(question: str) -> bool:
    return _contains(SYSTEM_META_TASK_PATTERNS, question)


def deterministic_understanding(
    question: str,
    *,
    last_route: str = "",
    research_signal: bool = False,
    hybrid_signal: bool = False,
) -> dict[str, Any]:
    """Return a conservative, auditable interpretation without model authority."""

    q = str(question or "").strip()
    project_reference = _project_reference(q)
    meta_task = _system_meta_task(q)
    strong_research = research_signal or _contains(STRONG_RESEARCH_PATTERNS, q)
    follow_up_meta = last_route == "system_meta" and _contains(FOLLOW_UP_META_PATTERNS, q)
    system_meta = (project_reference and meta_task) or follow_up_meta

    if system_meta:
        primary = "system_meta"
        domain = "project"
        confidence = 0.98 if project_reference and meta_task else 0.88
        goal = "Assess, explain, or improve the deployed system and its architecture."
        route_hint = "system_meta"
    elif hybrid_signal or (strong_research and _contains(HYBRID_PATTERNS, q)):
        primary = "hybrid"
        domain = "mixed"
        confidence = 0.94
        goal = "Combine validated project evidence with broader contextual interpretation."
        route_hint = "hybrid"
    elif strong_research:
        primary = "research_analytics"
        domain = "project"
        confidence = 0.93
        goal = "Answer using validated Strategic Carbon Intelligence & Governance concepts, methods, or deterministic evidence."
        route_hint = "research"
    elif project_reference:
        primary = "ambiguous"
        domain = "unclear"
        confidence = 0.58
        goal = "Resolve whether the user is asking about project analytics or the system itself."
        route_hint = "ambiguous"
    else:
        primary = "general"
        domain = "general"
        confidence = 0.90
        goal = "Provide ordinary general-purpose assistance."
        route_hint = "general"

    return {
        "primary_intent": primary,
        "domain_relevance": domain,
        "requires_project_evidence": primary in {"system_meta", "research_analytics", "hybrid"},
        "requires_deterministic_computation": primary in {"research_analytics", "hybrid"},
        "requires_architecture_knowledge": primary == "system_meta",
        "requires_general_reasoning": primary in {"general", "hybrid", "system_meta"},
        "user_goal": goal,
        "confidence": confidence,
        "route_hint": route_hint,
        "signals": {
            "project_reference": project_reference,
            "system_meta_task": meta_task,
            "strong_research": strong_research,
            "hybrid": bool(hybrid_signal),
            "follow_up_meta": follow_up_meta,
        },
        "source": "deterministic",
    }


def _normalise_model_understanding(raw: dict[str, Any]) -> dict[str, Any] | None:
    if not isinstance(raw, dict):
        return None
    allowed = {
        "research_concept",
        "research_method",
        "research_analytics",
        "research_strategy",
        "research_scenario",
        "system_meta",
        "general",
        "hybrid",
        "ambiguous",
    }
    primary = str(raw.get("primary_intent", "")).strip()
    if primary not in allowed:
        return None
    try:
        confidence = max(0.0, min(1.0, float(raw.get("confidence", 0.0))))
    except (TypeError, ValueError):
        confidence = 0.0
    return {
        "primary_intent": primary,
        "domain_relevance": str(raw.get("domain_relevance", "unclear")),
        "requires_project_evidence": bool(raw.get("requires_project_evidence")),
        "requires_deterministic_computation": bool(raw.get("requires_deterministic_computation")),
        "requires_architecture_knowledge": bool(raw.get("requires_architecture_knowledge")),
        "requires_general_reasoning": bool(raw.get("requires_general_reasoning")),
        "user_goal": str(raw.get("user_goal", "")).strip(),
        "confidence": confidence,
        "source": "local_llm",
    }


def interpret_ambiguous_query(
    client: Any,
    question: str,
    baseline: dict[str, Any],
) -> dict[str, Any]:
    """Consult Ollama only when deterministic signals leave Auto routing unclear."""

    enabled = os.getenv("OLLAMA_SEMANTIC_ROUTER_ENABLED", "1").strip().casefold()
    if enabled in {"0", "false", "no", "off"}:
        return {**baseline, "model_status": "disabled"}
    if baseline.get("route_hint") != "ambiguous":
        return {**baseline, "model_status": "not_needed"}

    system = (
        "Classify the user's task for a local Strategic Carbon Intelligence application. "
        "Return only JSON matching the schema. Distinguish: (1) project research concepts, "
        "methods, calculations, rankings, scenarios, and interventions; (2) system_meta questions "
        "about deployment, architecture, limitations, security, privacy, scalability, oracle design, "
        "the Query Management response process, or improvements to the application; (3) ordinary "
        "general questions; and (4) hybrid requests that combine project analytical evidence with "
        "broader external context. Do not answer the question and do not invent project facts."
    )
    payload = {
        "question": question,
        "deterministic_baseline": baseline,
        "classification_rule": (
            "A question may be highly relevant to the Strategic Carbon Intelligence & Governance project without requiring MRIO, SPA, "
            "SDA, DLI, AURORA, or intervention computation. Architecture and deployment critique is system_meta."
        ),
    }
    model = os.getenv("OLLAMA_ROUTER_MODEL", getattr(client, "model", ""))
    try:
        raw = client.chat_json(
            system,
            json.dumps(payload, indent=2, default=str),
            QUERY_UNDERSTANDING_SCHEMA,
            model=model or None,
            num_predict=360,
            temperature=0.0,
        )
        parsed = _normalise_model_understanding(raw)
        if parsed is None:
            return {**baseline, "model_status": "rejected", "model_output": raw}
        parsed["model_status"] = "ok"
        parsed["deterministic_baseline"] = baseline
        return parsed
    except Exception as exc:
        return {**baseline, "model_status": "fallback", "model_error": str(exc)}


def guarded_route_from_understanding(
    understanding: dict[str, Any],
    baseline: dict[str, Any],
) -> str:
    """Convert semantic interpretation to a route without weakening hard signals."""

    base_route = str(baseline.get("route_hint", "general"))
    signals = baseline.get("signals", {}) if isinstance(baseline.get("signals"), dict) else {}
    if signals.get("system_meta_task") and signals.get("project_reference"):
        return "system_meta"
    if signals.get("strong_research") and base_route in {"research", "hybrid"}:
        return base_route

    primary = str(understanding.get("primary_intent", "ambiguous"))
    try:
        confidence = float(understanding.get("confidence", 0.0))
    except (TypeError, ValueError):
        confidence = 0.0

    if primary == "system_meta" and confidence >= 0.65:
        return "system_meta"
    if primary == "hybrid" and confidence >= 0.65:
        return "hybrid"
    if primary.startswith("research_") and confidence >= 0.65:
        return "research"
    if primary == "general" and confidence >= 0.72:
        return "general"
    return "general" if base_route == "ambiguous" else base_route


DOMAIN_ALIAS_EXPANSIONS = [
    (r"\bmrio\b", "multiregional input output"),
    (r"\bspa\b", "structural path analysis"),
    (r"\bsda\b", "structural decomposition analysis"),
    (r"\bdli\b", "decarbonization leverage index"),
    (r"\baurora\b", "analogue based upstream regional opportunity and resilience assessment"),
]


def _expand_domain_aliases(text: str) -> str:
    expanded = str(text or "").casefold()
    for pattern, replacement in DOMAIN_ALIAS_EXPANSIONS:
        expanded = re.sub(pattern, replacement, expanded, flags=re.IGNORECASE)
    return expanded


def _content_tokens(text: str) -> set[str]:
    stop = {
        "a", "an", "and", "are", "as", "at", "be", "by", "do", "does", "for", "from",
        "how", "i", "in", "is", "it", "of", "on", "or", "our", "see", "that", "the",
        "this", "to", "what", "when", "where", "which", "why", "with", "you", "your",
    }
    return {
        token
        for token in re.findall(r"[a-z0-9]+", _expand_domain_aliases(text))
        if len(token) > 2 and token not in stop
    }


def _semantic_similarity(question: str, answer: str) -> float:
    try:
        vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
        matrix = vectorizer.fit_transform([_expand_domain_aliases(question), _expand_domain_aliases(answer)])
        return float(cosine_similarity(matrix[0:1], matrix[1:2])[0, 0])
    except Exception:
        q_tokens = _content_tokens(question)
        a_tokens = _content_tokens(answer)
        return len(q_tokens & a_tokens) / max(1, len(q_tokens))


def infer_answer_requirements(question: str, expected_mode: str = "") -> dict[str, Any]:
    q = str(question or "").casefold()
    count = 0
    for pattern in (
        r"\btop\s+(\d{1,2})\b",
        r"\b(\d{1,2})\s+(?:suggestions?|recommendations?|priorities?|ideas?|ways?|actions?|steps?|measures?|options?|examples?|reasons?|risks?|challenges?)\b",
    ):
        match = re.search(pattern, q)
        if match:
            count = max(1, min(20, int(match.group(1))))
            break
    if not count:
        number_words = {
            "one": 1, "two": 2, "three": 3, "four": 4, "five": 5,
            "six": 6, "seven": 7, "eight": 8, "nine": 9, "ten": 10,
            "eleven": 11, "twelve": 12, "thirteen": 13, "fourteen": 14,
            "fifteen": 15, "sixteen": 16, "seventeen": 17, "eighteen": 18,
            "nineteen": 19, "twenty": 20,
        }
        match = re.search(
            r"\b(" + "|".join(number_words) + r")\s+(?:suggestions?|recommendations?|priorities?|ideas?|ways?|actions?|steps?|measures?|options?|examples?|reasons?|risks?|challenges?)\b",
            q,
        )
        if match:
            count = number_words[match.group(1)]
    recommendation = bool(
        re.search(
            r"\b(suggest|recommend|advice|actions?|measures?|ways? to|what should|how should|roadmap|strategy|strategies|priorities?|improve|reduce|decarboni[sz]e|prioriti[sz])\b",
            q,
        )
    )
    return {
        "challenge": bool(re.search(r"\b(challenge|limitation|risk|weakness|issue|problem|concern)s?\b", q)),
        "priority": bool(re.search(r"\b(prioriti[sz]|which node|where should .*focus|highest[- ]priority)\b", q)),
        "reason": bool(re.search(r"\bwhy\b|\breason\b", q)),
        "action": bool(re.search(r"\b(action|recommend|what should|how can we improve|fix)\b", q)),
        "recommendation": recommendation,
        "definition": bool(re.search(r"^\s*(what is|define|explain)\b", q)),
        "method": bool(re.search(r"\b(method|methodology|calculated|computed|implemented|procedure)\b", q)),
        "comparison": bool(re.search(r"\b(compare|versus|vs\.?|difference|differ)\b", q)),
        "list_requested": bool(count or re.search(r"\b(list|rank(?:ing)?)\b", q)),
        "requested_count": count,
        "expected_mode": expected_mode,
    }


def assess_narrative_quality(answer: str, *, list_requested: bool = False) -> dict[str, Any]:
    text = str(answer or "").strip()
    nonempty_lines = [line.strip() for line in text.splitlines() if line.strip()]
    bullets = [line for line in nonempty_lines if re.match(r"^(?:[-*]|\d+[.)])\s+", line)]
    headings = [line for line in nonempty_lines if line.startswith("#") or re.match(r"^\*\*[^*]+:\*\*", line)]
    sentences = [item for item in re.split(r"(?<=[.!?])\s+", re.sub(r"\s+", " ", text)) if item]
    bullet_ratio = len(bullets) / max(1, len(nonempty_lines))
    coherent = bool(text) and len(sentences) >= 1
    if not list_requested and (len(headings) > 1 or len(bullets) > 2 or bullet_ratio > 0.25):
        coherent = False
    return {
        "coherent": coherent,
        "headings": len(headings),
        "bullets": len(bullets),
        "bullet_ratio": bullet_ratio,
        "sentence_count": len(sentences),
    }


def assess_answer_alignment(
    question: str,
    answer: str,
    *,
    expected_mode: str = "",
    required_anchor: str = "",
) -> dict[str, Any]:
    """Check task coverage, semantic overlap, and narrative form.

    This is intentionally conservative and transparent. It does not judge the
    truth of deterministic evidence; it checks whether the returned prose is
    answering the task that was asked.
    """

    text = str(answer or "").strip()
    lower = text.casefold()
    req = infer_answer_requirements(question, expected_mode)
    reasons: list[str] = []
    gates: list[bool] = []

    if len(text) < 40:
        reasons.append("answer is too short to address the task")
        gates.append(False)

    if req["challenge"]:
        ok = _contains(
            [
                r"\bchallenge", r"\brisk", r"\blimitation", r"\bconstraint", r"\bconcern",
                r"\bissue", r"\bbarrier", r"\bvulnerab", r"\bsecurity", r"\bprivacy",
                r"\bscalab", r"\bavailability", r"\btrust boundary",
            ],
            lower,
        )
        gates.append(ok)
        if not ok:
            reasons.append("the requested challenges or risks are not discussed")

    if req["priority"]:
        ok = bool(re.search(r"\b(prioriti[sz]|priority|focus|target)\b", lower))
        gates.append(ok)
        if not ok:
            reasons.append("the requested priority recommendation is not stated")

    if req["reason"]:
        ok = bool(re.search(r"\b(because|since|supported by|reflects|indicates|rationale|therefore|taken together|due to)\b", lower))
        gates.append(ok)
        if not ok:
            reasons.append("the answer does not connect the conclusion to a reason")

    if req.get("recommendation"):
        ok = bool(
            re.search(
                r"\b(should|recommend|prioriti[sz](?:e|ed|ing|ation)?|implement|adopt|develop|engage|reduce|require|establish|integrate)\b",
                lower,
            )
        )
        gates.append(ok)
        if not ok:
            reasons.append("the requested recommendation or action is not provided")

    requested_count = int(req.get("requested_count", 0) or 0)
    if requested_count:
        item_count = len(
            [
                line
                for line in text.splitlines()
                if re.match(r"^\s*(?:\d+[.)]|[-*])\s+", line)
            ]
        )
        ok = item_count == requested_count
        gates.append(ok)
        if not ok:
            reasons.append(
                f"the user requested exactly {requested_count} items but the answer contains {item_count}"
            )

    if expected_mode == "system_meta":
        ok = _contains(
            [
                r"\boracle", r"\borchestrator", r"\bblockchain", r"\bganache", r"\bollama",
                r"\bquery", r"\bcontent", r"\bdeployment", r"\barchitecture", r"\bsystem",
            ],
            lower,
        )
        gates.append(ok)
        if not ok:
            reasons.append("the answer does not engage with the deployed system")

    if required_anchor:
        ok = required_anchor.casefold() in lower
        gates.append(ok)
        if not ok:
            reasons.append(f"required evidence anchor `{required_anchor}` is missing")

    similarity = _semantic_similarity(question, text)
    q_tokens = _content_tokens(question)
    a_tokens = _content_tokens(text)
    overlap = sorted(q_tokens & a_tokens)
    semantic_ok = similarity >= 0.025 or len(overlap) >= 2 or bool(required_anchor)
    if expected_mode == "system_meta" and req["challenge"]:
        challenge_language = _contains(
            [r"\bchallenge", r"\brisk", r"\blimitation", r"\bconstraint", r"\bconcern", r"\bissue", r"\bvulnerab"],
            lower,
        )
        system_language = _contains(
            [r"\boracle", r"\borchestrator", r"\bblockchain", r"\bganache", r"\bquery", r"\bdeployment", r"\barchitecture", r"\bsystem"],
            lower,
        )
        semantic_ok = semantic_ok or (challenge_language and system_language)
    gates.append(semantic_ok)
    if not semantic_ok:
        reasons.append("question-answer semantic overlap is too weak")

    narrative = assess_narrative_quality(text, list_requested=req["list_requested"])
    gates.append(bool(narrative["coherent"]))
    if not narrative["coherent"]:
        reasons.append("the answer is formatted as disconnected evidence fragments")

    aligned = all(gates) if gates else bool(text)
    score = max(0.0, min(1.0, 0.55 * similarity + 0.45 * (sum(gates) / max(1, len(gates)))))
    return {
        "aligned": aligned,
        "score": score,
        "similarity": similarity,
        "overlap_terms": overlap[:20],
        "requirements": req,
        "narrative_quality": narrative,
        "reasons": reasons,
    }
