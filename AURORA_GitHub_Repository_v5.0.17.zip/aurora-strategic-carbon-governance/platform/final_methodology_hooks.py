"""Deprecated compatibility shim for pre-U16 evidence patching.

U16 removed import-time monkey-patching. Analytical outputs are joined through
explicit orchestrator and service calls so provenance is deterministic and
testable. ``install_evidence_patch`` is retained as a no-op only for historical
validation scripts that import it; production modules do not call it.
"""
from __future__ import annotations
from typing import Any, MutableMapping


def enrich_payload(value: Any) -> Any:
    """Return *value* unchanged; explicit U16 evidence joins are authoritative."""
    return value


def install_evidence_patch(namespace: MutableMapping[str, Any]) -> None:
    """No-op compatibility function. U16 performs no import-time patching."""
    del namespace
    return None


__all__ = ("enrich_payload", "install_evidence_patch")
