"""Streamlit workspace for the operational U17 integrated methodology."""
from __future__ import annotations

from pathlib import Path
import json
import os

import pandas as pd
import plotly.express as px
import streamlit as st

from orchestrator_client import OrchestratorClient
from plot_style import style_plotly_axes


def _runtime_dir() -> Path:
    root = Path(
        os.environ.get("SCIG_RUNTIME_DIR")
        or Path(__file__).resolve().parent / "runtime"
    )
    return root / "active_analytics"


def _load_csv(name: str) -> pd.DataFrame:
    path = _runtime_dir() / name
    return pd.read_csv(path) if path.is_file() else pd.DataFrame()


def _result_payload() -> dict:
    path = _runtime_dir() / "spa_sda_critic_dli_integrated_result.json"
    if not path.is_file():
        return {}
    return json.loads(path.read_text(encoding="utf-8"))


def render_integrated_methodology_workspace() -> None:
    st.title("Integrated Impact, Node-SDA, Union Path-SDA, Leverage & Governance Evidence")
    st.caption(
        "The governed method integrates dynamic ≥87%-of-total SPA reporting with producer-origin impact assessment, authoritative all-node signed four-factor SDA, union-aligned path-SDA, pooled Pearson-CRITIC DLI, producer-resolved CDR linkage, dual-denominator structural coverage, and the single actionability-gated intervention funnel."
    )

    if st.button(
        "Run / refresh integrated SPA–SDA–DLI analysis",
        type="primary",
        use_container_width=True,
        key="run_u16_integrated_methodology",
    ):
        try:
            with st.spinner(
                "Verifying producer-node SDA, active SPA evidence, hotspot-leverage portfolios and pooled CRITIC-DLI, "
                "then rebuilding the integrated governed evidence..."
            ):
                client = OrchestratorClient(timeout=2400.0)
                client.post(
                    "/v1/governance/final-methodology",
                    {"request_context": {"trigger": "streamlit_u16_refresh"}},
                )
            st.success("The integrated evidence was regenerated from the active governed inputs.")
            st.rerun()
        except Exception as exc:
            st.error(f"The integrated methodology could not be completed: {exc}")

    payload = _result_payload()
    if not payload:
        st.info(
            "Complete SPA for 2014 and 2017, the governed 2014-2017 SDA (including node-wise SDA), and Network analysis for both years. "
            "The pooled CRITIC ranking and integrated workspace are generated automatically when the 2017 Network request is completed after 2014."
        )
        return

    summary = payload.get("summary", {})
    col1, col2, col3, col4, col5, col6 = st.columns(6)
    col1.metric("Union exact paths", f"{int(summary.get('union_exact_path_count', 0)):,}")
    col2.metric("Persistent", f"{int(summary.get('persistent_exact_path_count', 0)):,}")
    col3.metric("Emerging", f"{int(summary.get('emerging_exact_path_count', 0)):,}")
    col4.metric("Disappearing", f"{int(summary.get('disappearing_exact_path_count', 0)):,}")
    col5.metric("Reconfigured members", f"{int(summary.get('reconfigured_exact_path_member_count', 0)):,}")
    col6.metric(
        "2017 footprint represented",
        f"{100 * float(summary.get('represented_current_footprint_share') or 0):.1f}%",
    )

    st.info(
        "The producer top-80% set remains the separate governance hotspot definition. The coverage-aligned path set targets at least 87% of the complete focal-company footprint. Cross-year path analysis uses the union of complete ordered path identities: a common node is allowed to follow a different route in 2014 and 2017, producing persistent, emerging, disappearing, or reconfigured path evidence."
    )
    st.caption(
        f"Authoritative producer-node SDA: {int(summary.get('comparison_top80_hotspot_count', 0))} comparison-year hotspots cover "
        f"{100 * float(summary.get('comparison_top80_hotspot_coverage') or 0):.2f}% of the focal-company footprint."
    )
    st.caption(
        f"Coverage-aligned path display: {int(summary.get('dominant_display_path_count', 0)):,} complete paths cover "
        f"{100 * float(summary.get('dominant_display_share_of_full_footprint') or 0):.2f}% of the complete 2017 footprint; "
        f"87% target reached: {bool(summary.get('dominant_display_target_reached', False))}."
    )

    tabs = st.tabs(
        [
            "Classification details",
            "SPA pathway participation",
            "Path classes × SDA drivers",
            "Union path-level SDA evidence",
            "Node SPA–SDA–DLI synthesis",
            "CRITIC-DLI",
            "Authoritative node-wise SDA",
            "Hotspot-leverage diagnostics",
            "Downloads & provenance",
        ]
    )

    with tabs[0]:
        cluster = payload.get("cluster_information", {})
        st.subheader("Baseline-frozen pathway classification")
        st.write(
            "Depth-zero paths are retained as a direct final-demand class. Baseline-positive upstream paths are clustered using 2014 characteristics; "
            "their structural class is frozen before the 2014–2017 Shapley decomposition."
        )
        st.json(
            {
                "baseline_year": cluster.get("baseline_year"),
                "selected_k": cluster.get("selected_k"),
                "silhouette": cluster.get("silhouette"),
                "minimum_cluster_size": cluster.get("minimum_cluster_size"),
                "feature_weighting": cluster.get("feature_weighting"),
                "classification_is_frozen": cluster.get("classification_is_frozen"),
                "ARI_min": cluster.get("stability_adjusted_rand_index_min"),
                "ARI_mean": cluster.get("stability_adjusted_rand_index_mean"),
            }
        )
        st.markdown("**Clustering features**")
        st.dataframe(
            pd.DataFrame(
                {
                    "raw feature": cluster.get("raw_features", []),
                    "transformed feature": cluster.get("transformed_features", []),
                }
            ),
            use_container_width=True,
            hide_index=True,
        )
        diagnostics = _load_csv("spa_path_cluster_diagnostics.csv")
        if not diagnostics.empty:
            st.subheader("Candidate-k diagnostics")
            st.dataframe(diagnostics, use_container_width=True, hide_index=True)
            valid = diagnostics.loc[diagnostics.get("eligible_for_selection", False) == True]  # noqa: E712
            if not valid.empty:
                figure = px.line(
                    valid,
                    x="k",
                    y="silhouette",
                    markers=True,
                    title="Silhouette performance of materially sized cluster solutions",
                )
                style_plotly_axes(figure)
                st.plotly_chart(figure, use_container_width=True)
        centroids = _load_csv("spa_path_cluster_centroids.csv")
        if not centroids.empty:
            st.subheader("Empirical cluster centroids and ex-post labels")
            st.dataframe(centroids, use_container_width=True, hide_index=True)
        feature_robustness = pd.DataFrame(cluster.get("leave_one_feature_out", []))
        if not feature_robustness.empty:
            st.subheader("Leave-one-feature-out robustness")
            st.dataframe(feature_robustness, use_container_width=True, hide_index=True)

    with tabs[1]:
        participation = _load_csv("spa_emissions_weighted_node_participation.csv")
        if participation.empty:
            st.warning("No pathway-participation table is available.")
        else:
            st.subheader("Role-specific emissions-weighted pathway participation")
            st.caption(
                "Demand-gateway, transmission, and terminal-emitter roles are separated. The any-role measure counts each path once for a node even when that node has multiple conceptual roles."
            )
            display_columns = [
                column
                for column in [
                    "node_code",
                    "spa_relevance_level",
                    "appears_in_dominant_display_set",
                    "spa_any_role_participation_share_of_represented",
                    "spa_demand_gateway_participation_share_of_represented",
                    "spa_transmission_participation_share_of_represented",
                    "spa_terminal_emitter_participation_share_of_represented",
                    "spa_any_role_participation_share_of_full_footprint",
                ]
                if column in participation.columns
            ]
            st.dataframe(
                participation[display_columns], use_container_width=True, hide_index=True
            )
            top = participation.head(30).copy()
            if "spa_any_role_participation_share_of_represented" in top:
                figure = px.bar(
                    top,
                    x="spa_any_role_participation_share_of_represented",
                    y="node_code",
                    orientation="h",
                    color="spa_relevance_level",
                    title="Leading node participation in the represented SPA pathway mass",
                )
                figure.update_layout(yaxis={"autorange": "reversed"})
                style_plotly_axes(figure)
                st.plotly_chart(figure, use_container_width=True)

    with tabs[2]:
        classes = _load_csv("spa_sda_path_class_driver_matrix.csv")
        if classes.empty:
            st.warning("No class-driver matrix is available.")
        else:
            st.subheader("Structural pathway class × temporal driver")
            st.dataframe(classes, use_container_width=True, hide_index=True)
            effect_columns = [
                column
                for column in [
                    "delta_intensity", "delta_technology", "delta_composition", "delta_scale"
                ]
                if column in classes.columns
            ]
            if effect_columns:
                long = classes.melt(
                    id_vars=["structural_path_class"],
                    value_vars=effect_columns,
                    var_name="driver",
                    value_name="effect_tCO2",
                )
                figure = px.bar(
                    long,
                    x="structural_path_class",
                    y="effect_tCO2",
                    color="driver",
                    barmode="relative",
                    title="Path-class Shapley effects, 2014–2017",
                )
                style_plotly_axes(figure)
                st.plotly_chart(figure, use_container_width=True)
            st.caption(
                "Company-level SDA remains the complete decomposition. These class effects localize only the portion represented by the bounded SPA path universe."
            )

    with tabs[3]:
        paths = _load_csv("spa_sda_integrated_paths.csv")
        if paths.empty:
            st.warning("No path-level evidence is available.")
        else:
            class_values = ["All", *sorted(paths["structural_path_class"].dropna().astype(str).unique())]
            selected_class = st.selectbox(
                "Structural pathway class",
                class_values,
                key="u16_path_class_filter",
            )
            path_status_column = "path_identity_status" if "path_identity_status" in paths.columns else "temporal_status"
            status_values = ["All", *sorted(paths[path_status_column].dropna().astype(str).unique())]
            selected_status = st.selectbox(
                "Exact cross-year path status",
                status_values,
                key="u16_path_status_filter",
            )
            filtered = paths
            if selected_class != "All":
                filtered = filtered.loc[filtered["structural_path_class"] == selected_class]
            if selected_status != "All":
                filtered = filtered.loc[filtered[path_status_column] == selected_status]
            st.dataframe(filtered.head(5000), use_container_width=True, hide_index=True)
            st.caption(
                "The full CSV retains the union of exact ordered bounded paths. Absent-year contributions are evaluated as zero, so emerging and disappearing routes are not lost. The largest positive effect is the primary adverse pathway driver; negative effects remain beneficial/offsetting evidence. The 87%-of-total coverage-aligned subset remains display-only; all bounded paths remain authoritative for participation and path-SDA."
            )

        transitions = _load_csv("spa_path_transitions_2014_2017.csv")
        pair_paths = _load_csv("hotspot_leverage_pathway_evidence_2017.csv")
        with st.expander("Emerging, disappearing, and reconfigured route transitions"):
            if transitions.empty:
                st.info("No cross-year route transition table is available.")
            else:
                st.dataframe(transitions, use_container_width=True, hide_index=True)
        with st.expander("Path-SDA evidence attached to hotspot–leverage pairs"):
            if pair_paths.empty:
                st.info("No hotspot–leverage path evidence is available.")
            else:
                st.dataframe(pair_paths.head(5000), use_container_width=True, hide_index=True)

    with tabs[4]:
        strategy = _load_csv("spa_sda_critic_dli_node_synthesis.csv")
        if strategy.empty:
            st.warning("No integrated node synthesis is available.")
        else:
            st.subheader("Current pathway relevance + temporal driver + systemic leverage")
            display_columns = [
                column
                for column in [
                    "dli_rank", "node_code", "region", "sector", "DLI", "dli_level",
                    "spa_relevance_level", "spa_dli_matrix_class",
                    "spa_any_role_participation_share_of_represented",
                    "node_temporal_status", "node_dominant_driver",
                    "node_primary_adverse_driver", "node_primary_adverse_effect_tco2",
                    "node_primary_beneficial_driver", "node_primary_beneficial_effect_tco2",
                    "node_driver_pattern", "node_driver_dominance_share", "in_comparison_top_80_hotspot_set",
                    "hotspot_structural_influence_fraction", "affected_hotspot_count",
                    "intervention_route", "integrated_decision_role", "strategic_classification",
                ]
                if column in strategy.columns
            ]
            st.dataframe(strategy[display_columns], use_container_width=True, hide_index=True)
            st.caption(
                "No extra composite score is created. Producer-node SDA is the primary temporal attribution, SPA shows focal-company pathway participation, path-level SDA is a secondary mechanism drill-down, and CRITIC-DLI measures systemic leverage."
            )

    with tabs[5]:
        weights = _load_csv("critic_authoritative_weights.csv")
        ranking = _load_csv("critic_authoritative_dli_ranking.csv")
        st.subheader("Authoritative pooled Pearson-CRITIC weights")
        st.dataframe(weights, use_container_width=True, hide_index=True)
        if not ranking.empty and "year" in ranking:
            ranking17 = ranking.loc[pd.to_numeric(ranking["year"], errors="coerce") == 2017]
            st.subheader("2017 CRITIC-DLI ranking")
            st.dataframe(
                ranking17.sort_values("dli_rank").head(100),
                use_container_width=True,
                hide_index=True,
            )
        st.caption(
            "Theory selects BC, PR, CDR and IC. CRITIC derives their pooled two-period weights from contrast and non-redundancy; no fixed DLI weights are used."
        )

    with tabs[6]:
        node_sda = _load_csv("spa_sda_node_driver_evidence.csv")
        path_allocated = _load_csv("represented_path_effect_allocation_by_node.csv")
        st.subheader("Authoritative producer-node four-factor SDA")
        st.caption(
            "Each producer node reconciles to its observed footprint change, and each factor column reconciles to the complete company SDA. Intervention priority follows the largest positive adverse node-SDA effect, while negative beneficial effects are preserved. The path-allocated table below is only a represented-path explanatory allocation, not a competing node-SDA result."
        )
        if node_sda.empty:
            st.warning("No authoritative node-wise SDA table is available.")
        else:
            hotspot_only = node_sda.loc[node_sda.get("in_comparison_top_80_hotspot_set", False).astype(bool)]
            st.dataframe(hotspot_only, use_container_width=True, hide_index=True)
        with st.expander("Represented-path effect allocation by participating node"):
            if path_allocated.empty:
                st.info("No bounded-path node allocation is available.")
            else:
                st.dataframe(path_allocated, use_container_width=True, hide_index=True)

    with tabs[7]:
        node_summary = _load_csv("hotspot_leverage_node_summary_2017.csv")
        hybrid = _load_csv("hotspot_leverage_hybrid_portfolio_2017.csv")
        direct = _load_csv("hotspot_leverage_direct_portfolio_2017.csv")
        mediated = _load_csv("hotspot_leverage_governance_mediated_portfolio_2017.csv")
        st.subheader("Route-specific structural diagnostics retained for comparison")
        st.warning(
            "These direct, mediated, and hybrid tables are retained as route-specific diagnostics only. Formal intervention authority uses one separate governance-ready funnel after adverse-driver mechanism mapping and actionability verification. These are structural diagnostics, not expected or guaranteed abatement."
        )
        if not node_summary.empty:
            st.dataframe(node_summary.head(100), use_container_width=True, hide_index=True)
        p1, p2, p3 = st.tabs(["Hybrid", "Direct hotspot", "Governance-mediated"])
        with p1:
            st.dataframe(hybrid, use_container_width=True, hide_index=True)
        with p2:
            st.dataframe(direct, use_container_width=True, hide_index=True)
        with p3:
            st.dataframe(mediated, use_container_width=True, hide_index=True)

    with tabs[8]:
        downloads = [
            ("SPA_SDA_CRITIC_DLI_Integrated_Results.xlsx", "Integrated Excel workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
            ("spa_sda_integrated_paths.csv", "Complete path evidence CSV", "text/csv"),
            ("spa_emissions_weighted_node_participation.csv", "SPA node participation CSV", "text/csv"),
            ("spa_sda_node_driver_evidence.csv", "Authoritative producer-node SDA CSV", "text/csv"),
            ("represented_path_effect_allocation_by_node.csv", "Represented-path effect allocation by node", "text/csv"),
            ("node_wise_sda_2014_2017.csv", "Complete node-wise SDA CSV", "text/csv"),
            ("node_wise_sda_hotspots_2014_2017.csv", "Top-80% hotspot node-SDA CSV", "text/csv"),
            ("NODE_WISE_SDA_2014_2017_RESULTS.xlsx", "Node-wise SDA workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
            ("hotspot_leverage_node_summary_2017.csv", "Hotspot-leverage node summary", "text/csv"),
            ("hotspot_leverage_pair_evidence_2017.csv", "Node-to-hotspot linkage evidence", "text/csv"),
            ("hotspot_leverage_pathway_evidence_2017.csv", "Hotspot–leverage evidence with path-SDA drill-down", "text/csv"),
            ("spa_path_transitions_2014_2017.csv", "Persistent/emerging/disappearing/reconfigured path transitions", "text/csv"),
            ("hotspot_leverage_hybrid_portfolio_2017.csv", "Hybrid compact portfolio", "text/csv"),
            ("HOTSPOT_LEVERAGE_STRUCTURAL_COVERAGE_2017.xlsx", "Hotspot-leverage workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
            ("spa_sda_critic_dli_node_synthesis.csv", "Integrated node synthesis CSV", "text/csv"),
            ("CRITIC_DLI_Authoritative_Results.xlsx", "CRITIC-DLI workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
            ("CRITIC_DLI_Robustness_Results.xlsx", "CRITIC robustness workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
        ]
        for filename, label, mime in downloads:
            path = _runtime_dir() / filename
            if path.is_file():
                st.download_button(
                    label,
                    path.read_bytes(),
                    file_name=filename,
                    mime=mime,
                    use_container_width=True,
                )
        st.subheader("Evidence and artifact CIDs")
        st.json(
            {
                "integrated_evidence_cid": payload.get("integrated_evidence_cid"),
                "source_metadata": payload.get("source_metadata", {}),
                "artifact_cids": payload.get("artifact_cids", {}),
                "artifact_sha256": payload.get("artifact_sha256", {}),
            }
        )
