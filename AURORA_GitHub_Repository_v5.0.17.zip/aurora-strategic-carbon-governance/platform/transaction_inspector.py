"""Blockchain transaction inspection and local audit indexing.

This module adds an explorer-style audit layer to the progressive governance platform without
changing any smart-contract or analytical logic.  It reads mined transactions
and receipts from the active chain, decodes contract calls and Solidity events
from the ABIs stored in ``deployment.json``, calculates gas/fee information,
and appends a compact JSON record to ``runtime/transaction_audit.jsonl``.

The blockchain remains authoritative.  The JSONL file is only a local index for
fast Streamlit filtering and can be deleted/rebuilt without changing on-chain
state.
"""
from __future__ import annotations

import json
import os
import time
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path
from typing import Any, Iterable

from web3 import Web3
from web3._utils.events import get_event_data

AUDIT_FILENAME = "transaction_audit.jsonl"
LOCK_FILENAME = "transaction_audit.lock"


def _hex(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, str):
        return value
    if hasattr(value, "hex"):
        try:
            text = value.hex()
            return text if str(text).startswith("0x") else "0x" + str(text)
        except Exception:
            pass
    if isinstance(value, (bytes, bytearray)):
        return "0x" + bytes(value).hex()
    return str(value)


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, (bytes, bytearray)) or hasattr(value, "hex"):
        return _hex(value)
    if isinstance(value, dict):
        return {str(k): _jsonable(v) for k, v in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(v) for v in value]
    try:
        return {str(k): _jsonable(v) for k, v in dict(value).items()}
    except Exception:
        return str(value)


def _read_deployment(path: str | Path) -> dict[str, Any]:
    try:
        value = json.loads(Path(path).read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _contract_by_address(deployment: dict[str, Any]) -> dict[str, tuple[str, dict[str, Any]]]:
    result: dict[str, tuple[str, dict[str, Any]]] = {}
    for name, spec in (deployment.get("contracts") or {}).items():
        if not isinstance(spec, dict) or not spec.get("address"):
            continue
        result[str(spec["address"]).lower()] = (str(name), spec)
    return result


def _event_topic(event_abi: dict[str, Any]) -> str:
    signature = f"{event_abi.get('name', '')}({','.join(str(item.get('type', '')) for item in event_abi.get('inputs', []))})"
    return Web3.keccak(text=signature).hex().lower()


def _decode_events(
    w3: Web3,
    receipt: Any,
    deployment: dict[str, Any],
) -> list[dict[str, Any]]:
    contracts = _contract_by_address(deployment)
    decoded: list[dict[str, Any]] = []
    for raw_log in list(receipt.get("logs", []) or []):
        address = str(raw_log.get("address", ""))
        contract_name = "Unknown"
        spec: dict[str, Any] = {}
        if address.lower() in contracts:
            contract_name, spec = contracts[address.lower()]
        topics = list(raw_log.get("topics", []) or [])
        topic0 = _hex(topics[0]).lower() if topics else ""
        event_abi = None
        for item in spec.get("abi", []) if isinstance(spec, dict) else []:
            if not isinstance(item, dict) or item.get("type") != "event" or item.get("anonymous"):
                continue
            try:
                if _event_topic(item) == topic0:
                    event_abi = item
                    break
            except Exception:
                continue
        base = {
            "contract": contract_name,
            "contract_address": address,
            "block_number": int(raw_log.get("blockNumber", receipt.get("blockNumber", 0)) or 0),
            "transaction_hash": _hex(raw_log.get("transactionHash", receipt.get("transactionHash"))),
            "transaction_index": int(raw_log.get("transactionIndex", receipt.get("transactionIndex", 0)) or 0),
            "log_index": int(raw_log.get("logIndex", 0) or 0),
            "topics": [_hex(topic) for topic in topics],
            "data": _hex(raw_log.get("data")),
            "removed": bool(raw_log.get("removed", False)),
        }
        if event_abi is None:
            base.update({"event": "Unknown", "signature": "", "args": {}})
            decoded.append(base)
            continue
        try:
            material = get_event_data(w3.codec, event_abi, raw_log)
            signature = f"{event_abi['name']}({','.join(str(item.get('type', '')) for item in event_abi.get('inputs', []))})"
            base.update(
                {
                    "event": str(material.get("event", event_abi.get("name", ""))),
                    "signature": signature,
                    "args": _jsonable(material.get("args", {})),
                }
            )
        except Exception as exc:
            base.update(
                {
                    "event": str(event_abi.get("name", "Unknown")),
                    "signature": "",
                    "args": {},
                    "decode_error": str(exc),
                }
            )
        decoded.append(base)
    return decoded


def _decode_function(
    w3: Web3,
    transaction: Any,
    deployment: dict[str, Any],
    *,
    contract_name_hint: str = "",
    function_signature_hint: str = "",
    decoded_inputs_hint: dict[str, Any] | None = None,
) -> dict[str, Any]:
    to_address = transaction.get("to")
    contracts = _contract_by_address(deployment)
    if to_address:
        matched = contracts.get(str(to_address).lower())
        if matched:
            contract_name, spec = matched
            try:
                contract = w3.eth.contract(address=spec["address"], abi=spec["abi"])
                function, inputs = contract.decode_function_input(transaction.get("input", "0x"))
                function_abi = getattr(function, "abi", {}) or {}
                signature = f"{function_abi.get('name', getattr(function, 'fn_name', ''))}({','.join(str(item.get('type', '')) for item in function_abi.get('inputs', []))})"
                return {
                    "transaction_type": "contract_call",
                    "contract": contract_name,
                    "contract_address": spec["address"],
                    "function": str(getattr(function, "fn_name", function_abi.get("name", ""))),
                    "signature": signature,
                    "inputs": _jsonable(inputs),
                }
            except Exception as exc:
                return {
                    "transaction_type": "contract_call",
                    "contract": contract_name,
                    "contract_address": spec["address"],
                    "function": function_signature_hint.split("(", 1)[0] if function_signature_hint else "Unknown",
                    "signature": function_signature_hint,
                    "inputs": _jsonable(decoded_inputs_hint or {}),
                    "decode_error": str(exc),
                }
    return {
        "transaction_type": "contract_deployment" if not to_address else "value_or_unknown_call",
        "contract": contract_name_hint or "Unknown",
        "contract_address": "",
        "function": "constructor" if not to_address else (function_signature_hint.split("(", 1)[0] if function_signature_hint else "Unknown"),
        "signature": function_signature_hint or ("constructor" if not to_address else ""),
        "inputs": _jsonable(decoded_inputs_hint or {}),
    }


def inspect_transaction(
    w3: Web3,
    deployment_path: str | Path,
    transaction_hash: Any,
    *,
    receipt: Any | None = None,
    actor_label: str = "",
    action: str = "",
    source: str = "",
    contract_name_hint: str = "",
    function_signature_hint: str = "",
    decoded_inputs_hint: dict[str, Any] | None = None,
    request_id: int | None = None,
    record_id: int | None = None,
    result_cid: str = "",
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Return a complete explorer-style transaction record."""

    deployment_path = Path(deployment_path)
    deployment = _read_deployment(deployment_path)
    tx_hash_hex = _hex(transaction_hash)
    transaction = w3.eth.get_transaction(tx_hash_hex)
    receipt = receipt or w3.eth.get_transaction_receipt(tx_hash_hex)
    block = w3.eth.get_block(receipt["blockNumber"], full_transactions=False)

    gas_limit = int(transaction.get("gas", 0) or 0)
    gas_used = int(receipt.get("gasUsed", 0) or 0)
    effective_gas_price = int(
        receipt.get("effectiveGasPrice")
        or transaction.get("gasPrice")
        or transaction.get("maxFeePerGas")
        or 0
    )
    fee_wei = gas_used * effective_gas_price
    fee_eth = Decimal(fee_wei) / Decimal(10**18)
    timestamp = int(block.get("timestamp", 0) or 0)
    mined_at = (
        datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat()
        if timestamp
        else ""
    )

    decoded_call = _decode_function(
        w3,
        transaction,
        deployment,
        contract_name_hint=contract_name_hint,
        function_signature_hint=function_signature_hint,
        decoded_inputs_hint=decoded_inputs_hint,
    )
    if receipt.get("contractAddress"):
        decoded_call["contract_address"] = str(receipt.get("contractAddress"))

    events = _decode_events(w3, receipt, deployment)
    if request_id is None:
        for item in events:
            args = item.get("args", {})
            if isinstance(args, dict) and "requestId" in args:
                try:
                    request_id = int(args["requestId"])
                    break
                except Exception:
                    pass
    if not result_cid:
        for item in events:
            args = item.get("args", {})
            if not isinstance(args, dict):
                continue
            for key in ("resultCID", "resultHash", "validationHash", "verificationCID", "errorCID", "errorHash", "evidenceCID", "actionCID"):
                value = str(args.get(key, "") or "").strip()
                if value:
                    result_cid = value
                    break
            if result_cid:
                break

    block_header = {
        "number": int(block.get("number", 0) or 0),
        "hash": _hex(block.get("hash")),
        "parentHash": _hex(block.get("parentHash")),
        "timestamp": timestamp,
        "timestamp_utc": mined_at,
        "miner": str(block.get("miner", "")),
        "gasLimit": int(block.get("gasLimit", 0) or 0),
        "gasUsed": int(block.get("gasUsed", 0) or 0),
        "baseFeePerGas": int(block.get("baseFeePerGas", 0) or 0),
        "transaction_count": len(block.get("transactions", []) or []),
    }

    record = {
        "audit_schema_version": "1.0",
        "recorded_at_utc": datetime.now(timezone.utc).isoformat(),
        "architecture_version": str(deployment.get("architecture_version", "")),
        "chain_id": int(w3.eth.chain_id),
        "source": source or "blockchain",
        "actor_label": actor_label,
        "action": action or decoded_call.get("function", ""),
        "request_id": request_id,
        "record_id": record_id,
        "result_cid": result_cid,
        "status": int(receipt.get("status", 0) or 0),
        "status_label": "Success" if int(receipt.get("status", 0) or 0) == 1 else "Failed/Reverted",
        "transaction_hash": _hex(receipt.get("transactionHash", tx_hash_hex)),
        "block_hash": _hex(receipt.get("blockHash")),
        "block_number": int(receipt.get("blockNumber", 0) or 0),
        "transaction_index": int(receipt.get("transactionIndex", 0) or 0),
        "from": str(transaction.get("from", "")),
        "to": str(transaction.get("to") or ""),
        "created_contract_address": str(receipt.get("contractAddress") or ""),
        "nonce": int(transaction.get("nonce", 0) or 0),
        "value_wei": int(transaction.get("value", 0) or 0),
        "value_eth": str(Decimal(int(transaction.get("value", 0) or 0)) / Decimal(10**18)),
        "transaction_type": int(transaction.get("type", 0) or 0),
        "gas_limit": gas_limit,
        "gas_used": gas_used,
        "gas_utilization_pct": round((gas_used / gas_limit * 100.0), 4) if gas_limit else None,
        "cumulative_gas_used": int(receipt.get("cumulativeGasUsed", 0) or 0),
        "effective_gas_price_wei": effective_gas_price,
        "max_fee_per_gas_wei": int(transaction.get("maxFeePerGas", 0) or 0),
        "max_priority_fee_per_gas_wei": int(transaction.get("maxPriorityFeePerGas", 0) or 0),
        "transaction_fee_wei": fee_wei,
        "transaction_fee_eth": format(fee_eth, "f"),
        "block_timestamp": timestamp,
        "block_timestamp_utc": mined_at,
        "decoded_call": decoded_call,
        "events": events,
        "metadata": _jsonable(metadata or {}),
        "raw_transaction": _jsonable(transaction),
        "raw_receipt": _jsonable(receipt),
        "block_header": block_header,
    }
    return record


def _audit_paths(deployment_path: str | Path) -> tuple[Path, Path]:
    root = Path(deployment_path).resolve().parent
    runtime = root / "runtime"
    runtime.mkdir(parents=True, exist_ok=True)
    return runtime / AUDIT_FILENAME, runtime / LOCK_FILENAME


def append_audit_record(deployment_path: str | Path, record: dict[str, Any]) -> None:
    """Append a JSONL audit record using a small cross-process lock file.

    Audit indexing must never prevent a successful blockchain transaction from
    completing.  If another process holds the lock for too long, the record is
    skipped and can still be reconstructed directly from its transaction hash.
    """

    audit_path, lock_path = _audit_paths(deployment_path)
    acquired = False
    deadline = time.time() + 5.0
    while time.time() < deadline:
        try:
            fd = os.open(str(lock_path), os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.close(fd)
            acquired = True
            break
        except FileExistsError:
            try:
                if time.time() - lock_path.stat().st_mtime > 30:
                    lock_path.unlink(missing_ok=True)
                    continue
            except Exception:
                pass
            time.sleep(0.05)
    if not acquired:
        return
    try:
        with audit_path.open("a", encoding="utf-8", newline="\n") as handle:
            handle.write(json.dumps(_jsonable(record), ensure_ascii=False, separators=(",", ":")) + "\n")
    finally:
        lock_path.unlink(missing_ok=True)


def record_transaction(
    w3: Web3,
    deployment_path: str | Path,
    transaction_hash: Any,
    **kwargs: Any,
) -> dict[str, Any]:
    record = inspect_transaction(w3, deployment_path, transaction_hash, **kwargs)
    append_audit_record(deployment_path, record)
    return record


def safe_record_transaction(
    w3: Web3,
    deployment_path: str | Path,
    transaction_hash: Any,
    **kwargs: Any,
) -> dict[str, Any]:
    """Best-effort audit recording that never changes transaction semantics."""

    try:
        return record_transaction(w3, deployment_path, transaction_hash, **kwargs)
    except Exception as exc:
        return {
            "transaction_hash": _hex(transaction_hash),
            "status": None,
            "status_label": "Inspection unavailable",
            "actor_label": kwargs.get("actor_label", ""),
            "action": kwargs.get("action", ""),
            "inspection_error": str(exc),
        }


def load_audit_records(deployment_path: str | Path) -> list[dict[str, Any]]:
    audit_path, _ = _audit_paths(deployment_path)
    if not audit_path.is_file():
        return []
    merged: dict[str, dict[str, Any]] = {}
    order: list[str] = []
    try:
        lines = audit_path.read_text(encoding="utf-8", errors="replace").splitlines()
    except Exception:
        return []
    for line in lines:
        try:
            item = json.loads(line)
        except Exception:
            continue
        if not isinstance(item, dict):
            continue
        key = str(item.get("transaction_hash", "") or f"line-{len(order)}").lower()
        if key not in merged:
            order.append(key)
            merged[key] = item
        else:
            current = merged[key]
            current.update({k: v for k, v in item.items() if v not in (None, "", [], {})})
    values = [merged[key] for key in order]
    values.sort(
        key=lambda item: (
            int(item.get("block_number") or 0),
            int(item.get("transaction_index") or 0),
            str(item.get("recorded_at_utc", "")),
        )
    )
    return values


def find_audit_records(
    deployment_path: str | Path,
    *,
    request_id: int | None = None,
    action: str = "",
    transaction_hash: str = "",
) -> list[dict[str, Any]]:
    values = load_audit_records(deployment_path)
    result: list[dict[str, Any]] = []
    for item in values:
        if request_id is not None and item.get("request_id") != request_id:
            continue
        if action and action.lower() not in str(item.get("action", "")).lower():
            continue
        if transaction_hash and str(item.get("transaction_hash", "")).lower() != transaction_hash.lower():
            continue
        result.append(item)
    return result
