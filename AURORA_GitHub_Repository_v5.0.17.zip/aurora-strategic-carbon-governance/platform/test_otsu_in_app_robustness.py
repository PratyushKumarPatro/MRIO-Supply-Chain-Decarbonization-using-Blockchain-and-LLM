"""Regression tests for U9 exact-Otsu AURORA and in-app DLI robustness."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

import numpy as np
import pandas as pd

import critic_robustness as dli
import sourcing_opportunity_engine as aurora

ROOT = Path(__file__).resolve().parent


class ExactOtsuTests(unittest.TestCase):
    def test_exact_bin_free_otsu_uses_observed_splits(self):
        result = aurora.exact_bin_free_otsu([0.10, 0.20, 0.80, 0.90])
        self.assertEqual(result["method"], "exact_bin_free_otsu")
        self.assertAlmostEqual(result["threshold"], 0.50, places=12)
        self.assertEqual(result["lower_class_count"], 2)
        self.assertEqual(result["upper_class_count"], 2)
        self.assertAlmostEqual(result["lower_boundary_value"], 0.20)
        self.assertAlmostEqual(result["upper_boundary_value"], 0.80)
        self.assertFalse(result["constant_distribution"])

    def test_exact_bin_free_otsu_handles_constant_distribution(self):
        result = aurora.exact_bin_free_otsu([0.75, 0.75, 0.75])
        self.assertEqual(result["threshold"], 0.75)
        self.assertTrue(result["constant_distribution"])
        self.assertEqual(result["upper_class_count"], 3)

    def test_calibration_uses_complete_candidate_universe_before_later_gates(self):
        candidates = [
            {"production_sector_similarity": 0.10, "market_sector_similarity": 0.20},
            {"production_sector_similarity": 0.20, "market_sector_similarity": 0.30},
            {"production_sector_similarity": 0.80, "market_sector_similarity": 0.70},
            {"production_sector_similarity": 0.90, "market_sector_similarity": 0.80},
        ]
        calibration_year = SimpleNamespace(year=2014)
        with patch.object(aurora, "analyse", return_value={"all_candidates": candidates}) as mocked:
            config, evidence = aurora.calibrate_exact_otsu_config(
                calibration_year,
                np.array([1.0]),
            )
        probe = mocked.call_args.kwargs["config"]
        self.assertEqual(probe.production_similarity_threshold, -1.0)
        self.assertEqual(probe.market_similarity_threshold, -1.0)
        self.assertEqual(probe.similarity_threshold_method, "exact_bin_free_otsu_calibration_probe")
        self.assertAlmostEqual(config.production_similarity_threshold, 0.50)
        self.assertAlmostEqual(config.market_similarity_threshold, 0.50)
        self.assertEqual(config.similarity_threshold_method, "exact_bin_free_otsu")
        self.assertEqual(config.similarity_threshold_calibration_year, 2014)
        self.assertEqual(evidence["candidate_universe_count"], 4)
        self.assertIn("before carbon improvement", evidence["calibration_order"])

    def test_calibration_metadata_is_attached_to_result(self):
        evidence = {
            "method": "exact_bin_free_otsu",
            "calibration_year": 2014,
            "production": {"threshold": 0.751},
            "market": {"threshold": 0.746},
        }
        result = aurora.attach_threshold_calibration({"configuration": {}}, evidence)
        self.assertEqual(result["threshold_calibration"], evidence)
        self.assertEqual(result["configuration"]["similarity_threshold_method"], "exact_bin_free_otsu")
        self.assertEqual(result["configuration"]["similarity_threshold_calibration_year"], 2014)
        self.assertAlmostEqual(result["configuration"]["production_similarity_threshold"], 0.751)
        self.assertAlmostEqual(result["configuration"]["market_similarity_threshold"], 0.746)


class InAppDLIRobustnessTests(unittest.TestCase):
    def test_runtime_callable_publishes_without_command_line(self):
        with tempfile.TemporaryDirectory() as tmp:
            runtime = Path(tmp) / "runtime"
            active = runtime / "active_analytics"
            active.mkdir(parents=True)
            for year, offset in ((2014, 0.0), (2017, 0.1)):
                pd.DataFrame(
                    {
                        "year": [year, year, year],
                        "node_code": ["A", "B", "C"],
                        "BC": [0.9 + offset, 0.4, 0.1],
                        "PR": [0.2, 0.8 + offset, 0.3],
                        "CDR": [0.7, 0.2, 0.9 + offset],
                        "IC": [0.3, 0.6, 0.1 + offset],
                    }
                ).to_csv(
                    active / f"critic_raw_network_metrics_{year}.csv", index=False
                )
            published = dli.run_critic_robustness(
                runtime, samples=25, concentration=80.0, seed=42, top_k=2
            )
            self.assertEqual(published["method"], "CRITIC-centred DLI robustness")
            self.assertEqual(published["samples"], 25)
            self.assertEqual(set(published["critic_weights"]), {"BC", "PR", "CDR", "IC"})
            for filename in (
                "critic_one_way_weight_scenarios.csv",
                "critic_monte_carlo_weight_scenarios.csv",
                "critic_node_rank_stability.csv",
                "critic_dli_robustness_summary.json",
            ):
                self.assertTrue((active / filename).is_file(), filename)

    def test_ui_has_in_app_control_and_no_required_shell_command(self):
        source = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        self.assertIn("Run / refresh CRITIC-DLI robustness", source)
        self.assertIn('"/v1/governance/dli-robustness"', source)
        self.assertIn("One-way and Dirichlet Monte Carlo scenarios", source)
        self.assertNotIn("Run the command below in PowerShell", source)
        self.assertNotIn(".\\.venv\\Scripts\\python.exe .\\dli_weight_sensitivity.py --runtime-year", source)

    def test_orchestrator_automatically_runs_companion_robustness(self):
        source = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        self.assertIn("self.compute_dli_weight_robustness(", source)
        self.assertIn('"trigger": "automatic_after_authoritative_critic_dli"', source)
        self.assertIn('record_active_result(\n            "dli_sensitivity"', source)
        self.assertIn("CRITIC-centred criterion weights", source)

    def test_server_and_launcher_require_u9_extensions(self):
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        self.assertIn('RELEASE_IDENTITY["aurora_similarity_threshold_extension_id"]', server)
        self.assertIn('RELEASE_IDENTITY["dli_in_app_execution_extension_id"]', server)
        self.assertIn('elif path == "/v1/governance/dli-robustness"', server)
        self.assertIn('$ExpectedAuroraThreshold = Get-RqVersionValue -Key "aurora_similarity_threshold_extension_id"', launcher)
        self.assertIn('$ExpectedDliExecution = Get-RqVersionValue -Key "dli_in_app_execution_extension_id"', launcher)
        self.assertIn('$candidate.aurora_similarity_threshold_extension -eq $ExpectedAuroraThreshold', launcher)
        self.assertIn('$candidate.dli_in_app_execution_extension -eq $ExpectedDliExecution', launcher)

    def test_version_declares_u9_release(self):
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8")
        self.assertIn("U11_SPA_SDA_DLI_PATHWAY_RELEVANCE", version)
        self.assertIn("aurora_similarity_threshold_extension_id=v5.0.17-U11-exact-bin-free-otsu", version)
        self.assertIn("dli_in_app_execution_extension_id=v5.0.17-U11", version)


if __name__ == "__main__":
    unittest.main(verbosity=2)
