param(
    [switch]$Reset
)

$ErrorActionPreference = "Stop"
Set-Location $PSScriptRoot

function Get-RqVersionValue {
    param([Parameter(Mandatory = $true)][string]$Key)
    $versionPath = Join-Path $PSScriptRoot "VERSION.txt"
    if (-not (Test-Path -LiteralPath $versionPath -PathType Leaf)) {
        throw "VERSION.txt was not found at $versionPath"
    }
    $pattern = '^\s*' + [Regex]::Escape($Key) + '\s*='
    $matchingLines = @(
        Get-Content -LiteralPath $versionPath |
            Where-Object { $_ -match $pattern }
    )
    if ($matchingLines.Count -ne 1) {
        throw "VERSION.txt must contain exactly one $Key entry."
    }
    $value = (($matchingLines[0] -split '=', 2)[1]).Trim()
    if ([string]::IsNullOrWhiteSpace($value)) {
        throw "VERSION.txt contains an empty $Key entry."
    }
    return $value
}

function Invoke-RqNativeCommand {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)][string]$FilePath,
        [string[]]$ArgumentList = @()
    )
    $savedErrorActionPreference = $ErrorActionPreference
    try {
        # Windows PowerShell 5 can promote routine native stderr to a terminating
        # NativeCommandError when the caller uses ErrorActionPreference=Stop.
        $ErrorActionPreference = "Continue"
        & $FilePath @ArgumentList 2>&1 | Out-Host
        $exitCode = $LASTEXITCODE
    }
    finally {
        $ErrorActionPreference = $savedErrorActionPreference
    }
    return [int]$exitCode
}

$ExpectedReleasePatch = Get-RqVersionValue -Key "release_patch"
$ExpectedArchitectureVersion = Get-RqVersionValue -Key "architecture_version"
$ExpectedIntegratedMethodology = Get-RqVersionValue -Key "integrated_methodology_extension_id"
$ExpectedSpaPathwayRelevance = Get-RqVersionValue -Key "spa_pathway_relevance_extension_id"
$ExpectedSpaReporting = Get-RqVersionValue -Key "spa_reporting_extension_id"
$ExpectedDliWeighting = Get-RqVersionValue -Key "dli_objective_weighting_extension_id"
$ExpectedAuroraThreshold = Get-RqVersionValue -Key "aurora_similarity_threshold_extension_id"
$ExpectedDliExecution = Get-RqVersionValue -Key "dli_in_app_execution_extension_id"
$ExpectedCdrLinkage = Get-RqVersionValue -Key "cdr_producer_linkage_extension_id"
$ExpectedPathAlignment = Get-RqVersionValue -Key "path_alignment_extension_id"
$ExpectedPathDriver = Get-RqVersionValue -Key "path_driver_extension_id"
$ExpectedNodeSda = Get-RqVersionValue -Key "node_wise_sda_extension_id"
$ExpectedHotspotLeverage = Get-RqVersionValue -Key "hotspot_leverage_extension_id"
$ExpectedInterventionGovernance = Get-RqVersionValue -Key "intervention_governance_extension_id"
$ExpectedAuroraLifecycle = Get-RqVersionValue -Key "aurora_lifecycle_extension_id"
$ExpectedMethodologyLifecycle = Get-RqVersionValue -Key "methodology_lifecycle_extension_id"
$ExpectedGovernanceInterface = Get-RqVersionValue -Key "governance_interface_extension_id"
$ExpectedAbatementScenario = Get-RqVersionValue -Key "abatement_scenario_extension_id"
$ExpectedPerformanceMonitoring = Get-RqVersionValue -Key "performance_monitoring_extension_id"
$ExpectedFinalDecisionSupportGate = Get-RqVersionValue -Key "final_decision_support_gate_extension_id"
$ExpectedBlockchainControlPlane = Get-RqVersionValue -Key "blockchain_control_plane_extension_id"

function Stop-RqPreviousBackgroundProcesses {
    $rootPattern = [Regex]::Escape([IO.Path]::GetFullPath($PSScriptRoot))
    $names = @("oracle_service.py", "orchestrator_server.py", "stakeholder_event_monitor.py", "streamlit run")
    try {
        Get-CimInstance Win32_Process -ErrorAction SilentlyContinue |
            Where-Object {
                $process = $_
                $matchesName = @($names | Where-Object { $process.CommandLine -like "*$_*" }).Count -gt 0
                $process.ProcessId -ne $PID -and
                $process.CommandLine -and
                $process.CommandLine -match $rootPattern -and
                $matchesName
            } | ForEach-Object {
                Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue
            }
    } catch {
        Write-Host "Could not inspect every previous background process; continuing with port checks." -ForegroundColor Yellow
    }
}

function Stop-RqPortListener([int]$Port) {
    try {
        Get-NetTCPConnection -LocalPort $Port -State Listen -ErrorAction SilentlyContinue |
            Select-Object -ExpandProperty OwningProcess -Unique |
            Where-Object { $_ -and $_ -ne $PID } |
            ForEach-Object { Stop-Process -Id $_ -Force -ErrorAction SilentlyContinue }
    } catch {
        # Get-NetTCPConnection can be restricted on some corporate Windows builds.
    }
}

# Always stop prior platform services on the package ports before starting.
# This prevents a browser from remaining connected to an older Streamlit build
# while a newly extracted package is launched.  The -Reset switch controls
# blockchain/deployment-state reset only; service restart is always safe.
Stop-RqPreviousBackgroundProcesses
Stop-RqPortListener 8765
Stop-RqPortListener 8501
Start-Sleep -Seconds 1

. (Join-Path $PSScriptRoot "python_runtime.ps1")

Ensure-RqApplicationPython -InstallIfMissing
$PythonExe = Get-RqPythonPath
$env:PYTHONNOUSERSITE = "1"
$env:PYTHONUTF8 = "1"
$env:DEPLOYMENT_JSON = Join-Path $PSScriptRoot "deployment.json"
# The supplied command sequence is a local deployment on fixed ports. Override
# stale parent-shell values so earlier sessions cannot redirect the current runtime.
$env:RPC_URL = "http://127.0.0.1:8545"
$env:ORCHESTRATOR_URL = "http://127.0.0.1:8765"
$env:ARTIFACT_DIR = $PSScriptRoot
if (-not $env:OLLAMA_BASE_URL) { $env:OLLAMA_BASE_URL = "http://127.0.0.1:11434" }
if (-not $env:OLLAMA_MODEL) { $env:OLLAMA_MODEL = "qwen3:4b" }
if (-not $env:OLLAMA_TIMEOUT) { $env:OLLAMA_TIMEOUT = "600" }
if (-not $env:OLLAMA_LLM_FIRST_ENABLED) { $env:OLLAMA_LLM_FIRST_ENABLED = "1" }
if (-not $env:OLLAMA_ORCHESTRATOR_MODEL) { $env:OLLAMA_ORCHESTRATOR_MODEL = $env:OLLAMA_MODEL }
if (-not $env:OLLAMA_ANSWER_MODEL) { $env:OLLAMA_ANSWER_MODEL = $env:OLLAMA_MODEL }
if (-not $env:OLLAMA_SYNTHESIS_MODEL) { $env:OLLAMA_SYNTHESIS_MODEL = $env:OLLAMA_MODEL }

# Fixed case-study presentation contract.  These values are repeated here to
# neutralize stale parent-shell overrides; the Streamlit source also hard-codes
# the same units and performs no numerical rescaling.
$env:SCIG_MRIO_MONETARY_UNIT = "million USD"
$env:SCIG_MRIO_EMISSIONS_UNIT = "Mt CO2"
$env:SCIG_FOCAL_DEMAND_UNIT = "USD"
$env:SCIG_FOCAL_EMISSIONS_UNIT = "t CO2"
$env:SCIG_CARBON_INTENSITY_UNIT = "t CO2/USD"

Write-Host "Launching the Strategic Carbon Intelligence & Governance Platform with temporal Network/DLI -> AURORA -> intervention scenario and formal decision -> final Query/LLM support, dynamic minimum-path reporting to at least 87% of the complete focal-company footprint, and post-deployment performance evidence (focal-company carbon results: t CO2)." -ForegroundColor Cyan
Write-Host "Preparing the guided governance platform deployment state." -ForegroundColor Cyan
Write-Host "No smart contract will be deployed by this PowerShell script." -ForegroundColor Yellow
$prepareArgs = @(".\prepare_dapp_lifecycle.py")
if ($Reset) { $prepareArgs += "--reset" }
$prepareExitCode = Invoke-RqNativeCommand -FilePath $PythonExe -ArgumentList $prepareArgs
if ($prepareExitCode -ne 0) {
    throw "Could not prepare the guided deployment state (exit code $prepareExitCode). Confirm Ganache is running on 127.0.0.1:8545 and npm dependencies are installed."
}

$runtimeDirectory = Join-Path $PSScriptRoot "runtime"
New-Item -ItemType Directory -Force -Path $runtimeDirectory | Out-Null
# Bind every UI and analytical reader to the same package-local runtime used by
# the Data Orchestrator. This prevents a parent-shell value or module location
# from redirecting the integrated SPA-SDA-DLI workspace to another directory.
$env:SCIG_RUNTIME_DIR = $runtimeDirectory
$orchestratorStdout = Join-Path $runtimeDirectory "orchestrator_stdout.log"
$orchestratorStderr = Join-Path $runtimeDirectory "orchestrator_stderr.log"
$orchestratorArgs = @(
    "-u",
    "orchestrator_server.py",
    "--host", "127.0.0.1",
    "--port", "8765",
    "--deployment", "deployment.json"
)
$orchestratorProcess = Start-Process -FilePath $PythonExe `
    -ArgumentList $orchestratorArgs `
    -WorkingDirectory $PSScriptRoot `
    -WindowStyle Hidden `
    -RedirectStandardOutput $orchestratorStdout `
    -RedirectStandardError $orchestratorStderr `
    -PassThru

$health = $null
$lastHealthCandidate = $null
$expectedRoot = [IO.Path]::GetFullPath($PSScriptRoot)
for ($attempt = 0; $attempt -lt 90; $attempt++) {
    try {
        $orchestratorProcess.Refresh()
        if ($orchestratorProcess.HasExited) {
            break
        }
    } catch {
    }
    try {
        $candidate = Invoke-RestMethod -Uri "$($env:ORCHESTRATOR_URL)/health" -Method Get -TimeoutSec 3
        $lastHealthCandidate = $candidate
        if (
            $candidate.service -eq "off-chain-data-orchestrator" -and
            $candidate.version -eq "5.0.17" -and
            $candidate.release_patch -eq $ExpectedReleasePatch -and
            $candidate.architecture_version -eq $ExpectedArchitectureVersion -and
            $candidate.integrated_methodology_extension -eq $ExpectedIntegratedMethodology -and
            $candidate.spa_pathway_relevance_extension -eq $ExpectedSpaPathwayRelevance -and
            $candidate.spa_reporting_extension -eq $ExpectedSpaReporting -and
            $candidate.dli_objective_weighting_extension -eq $ExpectedDliWeighting -and
            $candidate.aurora_similarity_threshold_extension -eq $ExpectedAuroraThreshold -and
            $candidate.dli_in_app_execution_extension -eq $ExpectedDliExecution -and
            $candidate.cdr_producer_linkage_extension -eq $ExpectedCdrLinkage -and
            $candidate.path_alignment_extension -eq $ExpectedPathAlignment -and
            $candidate.path_driver_extension -eq $ExpectedPathDriver -and
            $candidate.node_wise_sda_extension -eq $ExpectedNodeSda -and
            $candidate.hotspot_leverage_extension -eq $ExpectedHotspotLeverage -and
            $candidate.intervention_governance_extension -eq $ExpectedInterventionGovernance -and
            $candidate.aurora_lifecycle_extension -eq $ExpectedAuroraLifecycle -and
            $candidate.methodology_lifecycle_extension -eq $ExpectedMethodologyLifecycle -and
            $candidate.governance_interface_extension -eq $ExpectedGovernanceInterface -and
            $candidate.abatement_scenario_extension -eq $ExpectedAbatementScenario -and
            $candidate.performance_monitoring_extension -eq $ExpectedPerformanceMonitoring -and
            $candidate.final_decision_support_gate_extension -eq $ExpectedFinalDecisionSupportGate -and
            $candidate.blockchain_control_plane_extension -eq $ExpectedBlockchainControlPlane -and
            [IO.Path]::GetFullPath([string]$candidate.package_root) -eq $expectedRoot
        ) {
            $health = $candidate
            break
        }
    } catch {
    }
    Start-Sleep -Seconds 1
}
if ($null -eq $health) {
    Write-Host "Expected release patch: $ExpectedReleasePatch" -ForegroundColor Yellow
    Write-Host "Expected architecture version: $ExpectedArchitectureVersion" -ForegroundColor Yellow
    if ($null -ne $lastHealthCandidate) {
        Write-Host "Last health payload received:" -ForegroundColor Yellow
        $lastHealthCandidate | ConvertTo-Json -Depth 6 | Out-Host
    }
    foreach ($logPath in @($orchestratorStdout, $orchestratorStderr)) {
        if (Test-Path -LiteralPath $logPath) {
            Write-Host "---- $logPath (last 80 lines) ----" -ForegroundColor Yellow
            Get-Content -LiteralPath $logPath -Tail 80 -ErrorAction SilentlyContinue | Out-Host
        }
    }
    try {
        $orchestratorProcess.Refresh()
        if ($orchestratorProcess.HasExited) {
            Write-Host "Data Orchestrator process exited with code $($orchestratorProcess.ExitCode)." -ForegroundColor Yellow
        }
    } catch {
    }
    throw "The current Data Orchestrator did not become ready at $($env:ORCHESTRATOR_URL). The launcher printed the available runtime diagnostics above."
}
Write-Host "Data Orchestrator is running (PID $($health.pid))." -ForegroundColor Green

$notificationStdout = Join-Path $runtimeDirectory "stakeholder_event_monitor_stdout.log"
$notificationStderr = Join-Path $runtimeDirectory "stakeholder_event_monitor_stderr.log"
$notificationArgs = @(
    "-u",
    "stakeholder_event_monitor.py",
    "--deployment", "deployment.json",
    "--poll-interval", "1"
)
$notificationHeartbeat = Join-Path $runtimeDirectory "stakeholder_event_monitor_heartbeat.json"
Remove-Item -LiteralPath $notificationHeartbeat -Force -ErrorAction SilentlyContinue
$notificationProcess = Start-Process -FilePath $PythonExe `
    -ArgumentList $notificationArgs `
    -WorkingDirectory $PSScriptRoot `
    -WindowStyle Hidden `
    -RedirectStandardOutput $notificationStdout `
    -RedirectStandardError $notificationStderr `
    -PassThru

$notificationReady = $false
for ($attempt = 0; $attempt -lt 45; $attempt++) {
    try {
        $notificationProcess.Refresh()
        if ($notificationProcess.HasExited) {
            break
        }
        if (Test-Path $notificationHeartbeat) {
            $candidate = Get-Content $notificationHeartbeat -Raw | ConvertFrom-Json
            if ($candidate.service -eq "stakeholder-event-monitor" -and $candidate.status -eq "running") {
                $notificationReady = $true
                break
            }
        }
    } catch {
    }
    Start-Sleep -Seconds 1
}
if (-not $notificationReady) {
    Write-Host "Stakeholder Event Monitor did not report a ready heartbeat. The platform can still refresh notifications directly from chain." -ForegroundColor Yellow
    foreach ($logPath in @($notificationStdout, $notificationStderr)) {
        if (Test-Path -LiteralPath $logPath) {
            Write-Host "---- $logPath (last 40 lines) ----" -ForegroundColor Yellow
            Get-Content -LiteralPath $logPath -Tail 40 -ErrorAction SilentlyContinue | Out-Host
        }
    }
    try {
        $notificationProcess.Refresh()
        if ($notificationProcess.HasExited) {
            Write-Host "Stakeholder Event Monitor exited with code $($notificationProcess.ExitCode)." -ForegroundColor Yellow
        }
    } catch {
    }
} else {
    Write-Host "Stakeholder Event Monitor is running." -ForegroundColor Green
}

Write-Host "Opening the Streamlit governance platform." -ForegroundColor Cyan
Write-Host "Use Governance & Audit Control for the guided lifecycle and decoded Blockchain Audit & Transaction Explorer." -ForegroundColor Green
Set-Location (Join-Path $PSScriptRoot "streamlit_app")
$savedErrorActionPreference = $ErrorActionPreference
try {
    # Streamlit writes normal server messages to stderr on some releases. Do not
    # let Windows PowerShell 5 promote those messages to a terminating error.
    $ErrorActionPreference = "Continue"
    & $PythonExe -m streamlit run .\app.py --server.address 127.0.0.1 --server.port 8501 --browser.gatherUsageStats false
    $streamlitExitCode = $LASTEXITCODE
}
finally {
    $ErrorActionPreference = $savedErrorActionPreference
}
if ($streamlitExitCode -ne 0) {
    throw "Streamlit exited with code $streamlitExitCode. Review the messages printed above."
}
