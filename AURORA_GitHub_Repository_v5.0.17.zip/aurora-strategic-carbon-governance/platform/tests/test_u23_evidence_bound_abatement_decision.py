"""Regression tests for the explicit pre-decision abatement evidence gate."""
from __future__ import annotations

import unittest
from pathlib import Path

import pandas as pd

import intervention_governance as governance
import release_identity


ROOT = Path(__file__).resolve().parents[1]
CANDIDATE_ID = "a" * 64


def _candidate() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "candidate_id": CANDIDATE_ID,
                "intervention_node": "ARE-cns",
                "hotspot_producer_node": "ARE-nmm",
                "mechanism_code": "INTENSITY_DECARBONIZATION",
                "mechanism_mapping_status": "Mapped from primary adverse node-SDA driver",
                "linkage_gate_status": "Pass",
                "baseline_hotspot_footprint_tco2": 30.0,
                "avoided_hotspot_footprint_tco2": 20.0,
            }
        ]
    )


def _actionability() -> dict[str, object]:
    return {
        **{field: "Yes" for field in governance.ACTIONABILITY_FIELDS},
        "assessor_name": "Procurement manager",
        "assessor_role": "Accountable intervention owner",
        "evidence_reference": "GOV-023",
        "assessment_notes": "Reviewed governance and technical evidence.",
    }


def _assess(extra: dict[str, object]) -> pd.DataFrame:
    candidates = _candidate()
    assessments = governance.upsert_actionability_assessment(
        candidates,
        None,
        CANDIDATE_ID,
        {**_actionability(), **extra},
    )
    return governance.merge_actionability(candidates, assessments)


class EvidenceBoundAbatementDecisionTests(unittest.TestCase):
    def test_release_identity_adds_u23_gate_without_relabelling_driver_method(self):
        identity = release_identity.RELEASE_IDENTITY
        self.assertEqual(identity["release_patch"], "u23-evidence-bound-abatement-decision")
        self.assertEqual(identity["abatement_decision_gate_extension_id"], "v5.0.17-U23")
        self.assertEqual(identity["intervention_governance_extension_id"], "v5.0.17-U16")
        self.assertEqual(identity["blockchain_control_plane_extension_id"], "v5.0.17-U22")

    def test_silent_scenario_omission_cannot_become_governance_ready(self):
        row = _assess({}).iloc[0]
        self.assertEqual(row["assessment_status"], "Verified actionable")
        self.assertEqual(row["scenario_status"], "Not quantified")
        self.assertEqual(
            row["governance_eligibility_status"],
            "Conditionally eligible - scenario decision incomplete",
        )

    def test_documented_non_quantification_is_accountable_and_eligible(self):
        row = _assess(
            {
                "scenario_quantification_decision": "Proceed without quantification",
                "scenario_non_quantification_reason": "No intervention-specific field trial is currently available.",
                "scenario_assessor_name": "Carbon manager",
                "scenario_assessor_role": "Scenario evidence owner",
                "scenario_evidence_reference": "SCENARIO-WAIVER-023",
                "scenario_notes": "Quantify after the pilot procurement cycle.",
            }
        ).iloc[0]
        self.assertEqual(row["scenario_status"], "Documented unquantified")
        self.assertEqual(row["governance_eligibility_status"], governance.ELIGIBLE_STATUS)
        self.assertTrue(pd.isna(row["scenario_expected_reduction_tco2"]))
        self.assertEqual(len(str(row["scenario_id"])), 64)

    def test_incomplete_non_quantification_remains_blocked(self):
        row = _assess(
            {
                "scenario_quantification_decision": "Proceed without quantification",
                "scenario_non_quantification_reason": "No trial evidence.",
            }
        ).iloc[0]
        self.assertEqual(row["scenario_status"], "Incomplete scenario")
        self.assertNotEqual(row["governance_eligibility_status"], governance.ELIGIBLE_STATUS)

    def test_quantified_scenario_is_previewable_and_eligible(self):
        row = _assess(
            {
                "scenario_quantification_decision": "Quantify reduction scenario",
                "scenario_conservative_effectiveness_fraction": 0.10,
                "scenario_expected_effectiveness_fraction": 0.20,
                "scenario_ambitious_effectiveness_fraction": 0.30,
                "scenario_implementation_coverage_fraction": 0.50,
                "scenario_adoption_fraction": 0.80,
                "scenario_assessor_name": "Carbon manager",
                "scenario_assessor_role": "Scenario evidence owner",
                "scenario_evidence_reference": "SCENARIO-023",
                "scenario_confidence": "Medium",
                "scenario_notes": "No rebound effect modelled.",
            }
        ).iloc[0]
        self.assertEqual(row["scenario_status"], "Quantified scenario")
        self.assertAlmostEqual(float(row["scenario_conservative_reduction_tco2"]), 0.8)
        self.assertAlmostEqual(float(row["scenario_expected_reduction_tco2"]), 1.6)
        self.assertAlmostEqual(float(row["scenario_ambitious_reduction_tco2"]), 2.4)
        self.assertEqual(row["governance_eligibility_status"], governance.ELIGIBLE_STATUS)

    def test_blockchain_ui_requires_choice_and_review_confirmation(self):
        controls = (ROOT / "streamlit_app" / "intervention_control_ui.py").read_text(encoding="utf-8")
        blockchain = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        for token in (
            '"##### Required pre-decision abatement evidence choice"',
            '"Abatement evidence decision"',
            '"Proceed without quantification"',
            '"Expected preview"',
        ):
            self.assertIn(token, controls)
        self.assertIn('"I have reviewed the intervention mechanism, feasibility evidence, abatement "', blockchain)
        self.assertIn("disabled=not evidence_reviewed", blockchain)
        self.assertIn('"Scenario assumptions: No assumptions recorded."', blockchain)


if __name__ == "__main__":
    unittest.main()
