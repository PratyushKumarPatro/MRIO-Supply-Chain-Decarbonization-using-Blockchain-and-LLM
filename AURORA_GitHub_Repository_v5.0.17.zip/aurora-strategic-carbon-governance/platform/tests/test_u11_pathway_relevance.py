from __future__ import annotations

import unittest
from pathlib import Path

import pandas as pd

import spa_sda_pathway_bridge as bridge

ROOT = Path(__file__).resolve().parents[1]


class U11PathwayRelevanceTests(unittest.TestCase):
    def test_role_specific_participation_uses_all_bounded_paths(self):
        panel = pd.DataFrame(
            [
                {
                    "path_id": "ARE-cns <- ROW-ely",
                    "path_nodes": ["ARE-cns", "ROW-ely"],
                    "comparison_contribution": 8.0,
                    "in_dominant_display_set": True,
                },
                {
                    "path_id": "ARE-nmm <- ROW-oxt <- ROW-ely",
                    "path_nodes": ["ARE-nmm", "ROW-oxt", "ROW-ely"],
                    "comparison_contribution": 2.0,
                    "in_dominant_display_set": False,
                },
            ]
        )
        frame, metadata = bridge.compute_pathway_participation(
            panel,
            ["ARE-cns", "ARE-nmm", "ROW-oxt", "ROW-ely"],
            full_comparison_footprint=20.0,
        )
        indexed = frame.set_index("node_code")
        self.assertAlmostEqual(
            indexed.loc["ROW-ely", "spa_terminal_emitter_participation_share_of_represented"],
            1.0,
        )
        self.assertAlmostEqual(
            indexed.loc["ROW-oxt", "spa_transmission_participation_share_of_represented"],
            0.2,
        )
        self.assertAlmostEqual(
            indexed.loc["ARE-nmm", "spa_demand_gateway_participation_share_of_represented"],
            0.2,
        )
        self.assertEqual(metadata["authoritative_calculation"], "all bounded represented paths")
        self.assertEqual(metadata["coverage_aligned_display_set_role"], "display and concise reporting only")
        self.assertIn("non-additive", metadata["non_additivity_note"])

    def test_dominant_subset_is_display_only(self):
        panel = pd.DataFrame(
            {
                "path_id": ["a", "b", "c"],
                "comparison_contribution": [8.0, 1.0, 1.0],
            }
        )
        marked, metadata = bridge.mark_dominant_display_paths(panel, 0.80)
        self.assertEqual(int(marked["in_dominant_display_set"].sum()), 1)
        self.assertAlmostEqual(metadata["achieved_share_of_represented"], 0.8)
        self.assertIn("display", metadata["authority_boundary"])

    def test_u11_runtime_is_directly_wired(self):
        lifecycle = (ROOT / "dapp_lifecycle.py").read_text(encoding="utf-8")
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        ui = (ROOT / "final_methodology_ui.py").read_text(encoding="utf-8")
        self.assertIn('sections.append("Integrated SPA–SDA & CRITIC-DLI")', lifecycle)
        self.assertIn('elif page == "Integrated SPA–SDA & CRITIC-DLI"', app)
        self.assertIn('elif path == "/v1/governance/final-methodology"', server)
        self.assertIn("Run / refresh integrated SPA–SDA–DLI analysis", ui)

    def test_critic_is_authoritative_and_fixed_weights_are_disabled(self):
        network = (ROOT / "network_engine.py").read_text(encoding="utf-8")
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8")
        self.assertIn("DLI_WEIGHTS: dict[str, float] = {}", network)
        self.assertIn("legacy_fixed_dli_weights_used=false", version)
        self.assertIn("pooled-pearson-critic-authoritative", version)
        self.assertNotIn('"BC": 0.25', network)
        self.assertNotIn('"PR": 0.20', network)
        self.assertNotIn('"CDR": 0.30', network)
        self.assertNotIn('"IC": 0.25', network)

    def test_no_additional_spa_sda_dli_composite_score(self):
        source = (ROOT / "spa_sda_pathway_bridge.py").read_text(encoding="utf-8")
        self.assertIn('"additional_composite_score_created": False', source)
        self.assertIn('"spa_dli_matrix_is_weight_free": True', source)

    def test_exact_otsu_and_pareto_boundaries_are_retained(self):
        aurora = (ROOT / "sourcing_opportunity_engine.py").read_text(encoding="utf-8")
        self.assertIn("exact_bin_free_otsu", aurora)
        self.assertIn("pareto", aurora.lower())
        self.assertNotIn("production_similarity_threshold: float = 0.80", aurora)
        self.assertNotIn("market_similarity_threshold: float = 0.70", aurora)


if __name__ == "__main__":
    unittest.main(verbosity=2)
