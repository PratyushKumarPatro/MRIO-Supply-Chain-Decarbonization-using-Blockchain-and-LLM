"""Regression tests for the U13 producer-specific CDR linkage extension."""
from __future__ import annotations

import json
import tempfile
import unittest
from unittest import mock
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

import cdr_producer_linkage as linkage
import network_engine as network
import data_orchestrator as orchestrator
from critic_dli_core import CRITERIA

ROOT = Path(__file__).resolve().parents[1]


def _fixture():
    a = np.array(
        [
            [0.10, 0.20, 0.00],
            [0.10, 0.10, 0.30],
            [0.00, 0.10, 0.10],
        ],
        dtype=float,
    )
    x = np.array([100.0, 120.0, 80.0], dtype=float)
    z = a * x[np.newaxis, :]
    leontief = np.linalg.inv(np.eye(3) - a)
    intensity = np.array([0.001, 0.020, 0.005], dtype=float)
    demand = np.array([1000.0, 100.0, 50.0], dtype=float)
    model = SimpleNamespace(
        year=2017,
        Z=z,
        X=x,
        fE=intensity,
        L=leontief,
        node_codes=np.array(["ARE-cns", "ARE-ely", "ROW-x"]),
        regions=np.array(["ARE", "ARE", "ROW"]),
        sectors=np.array(["cns", "ely", "x"]),
    )
    model.footprint = lambda y: float(model.fE @ (model.L @ np.asarray(y, dtype=float)))
    return model, demand


def _legacy_cdr(model, demand):
    demand = np.asarray(demand, dtype=float).reshape(-1)
    n = len(demand)
    base_footprint = float(model.footprint(demand))
    a = np.zeros_like(model.Z, dtype=float)
    positive = np.asarray(model.X, dtype=float) > 0
    a[:, positive] = model.Z[:, positive] / model.X[positive][np.newaxis, :]
    result = np.zeros(n, dtype=float)
    identity = np.eye(n)
    for k in range(n):
        if demand[k] == 0 and a[:, k].sum() == 0 and a[k, :].sum() == 0:
            continue
        candidate = a.copy()
        candidate[k, :] = 0.0
        candidate[:, k] = 0.0
        leontief_reduced = np.linalg.inv(identity - candidate)
        reduced_demand = demand.copy()
        reduced_demand[k] = 0.0
        reduced_footprint = float(model.fE @ (leontief_reduced @ reduced_demand))
        result[k] = (
            (base_footprint - reduced_footprint) / base_footprint
            if base_footprint
            else 0.0
        )
    return result


class U13CDRProducerLinkageTests(unittest.TestCase):
    def setUp(self):
        self.model, self.demand = _fixture()
        self.result = linkage.compute_cdr_producer_linkage(self.model, self.demand)

    def test_cdr_vector_is_numerically_identical_to_pre_u13_algorithm(self):
        expected = _legacy_cdr(self.model, self.demand)
        np.testing.assert_array_equal(self.result.cdr, expected)
        np.testing.assert_array_equal(network.carbon_dependency_risk(self.model, self.demand), expected)

        graph = network.build_graph(self.model)
        expected_frame = pd.DataFrame(
            {
                "year": int(self.model.year),
                "node_code": self.model.node_codes.astype(str),
                "region": self.model.regions.astype(str),
                "sector": self.model.sectors.astype(str),
                "BC": network.betweenness(graph),
                "PR": network.pagerank(graph),
                "CDR": expected,
                "IC": self.model.L @ self.demand,
                "company_demand": self.demand,
            }
        ).sort_values("node_code", kind="mergesort").reset_index(drop=True)
        actual_frame = network.compute_raw_metrics(self.model, self.demand)
        pd.testing.assert_frame_equal(actual_frame, expected_frame, check_exact=True)

    def test_random_stable_systems_retain_exact_legacy_cdr_values(self):
        for seed in range(5):
            rng = np.random.default_rng(seed)
            n = 5
            a = rng.uniform(0.0, 0.04, size=(n, n))
            x = rng.uniform(50.0, 200.0, size=n)
            z = a * x[np.newaxis, :]
            leontief = np.linalg.inv(np.eye(n) - a)
            intensity = rng.uniform(0.001, 0.02, size=n)
            demand = rng.uniform(0.0, 1000.0, size=n)
            model = SimpleNamespace(
                year=2017,
                Z=z,
                X=x,
                fE=intensity,
                L=leontief,
                node_codes=np.array([f"N-{i}" for i in range(n)]),
                regions=np.array(["R"] * n),
                sectors=np.array([f"S{i}" for i in range(n)]),
            )
            model.footprint = lambda y, m=model: float(
                m.fE @ (m.L @ np.asarray(y, dtype=float))
            )
            result = linkage.compute_cdr_producer_linkage(model, demand)
            np.testing.assert_array_equal(result.cdr, _legacy_cdr(model, demand))

    def test_producer_rows_reconcile_to_total_cdr_effect(self):
        observed = self.result.avoided_producer_footprint.sum(axis=1)
        expected = self.result.cdr * self.result.baseline_total_footprint
        np.testing.assert_allclose(observed, expected, atol=1e-12, rtol=1e-12)
        np.testing.assert_allclose(
            observed,
            self.result.baseline_total_footprint - self.result.counterfactual_total_footprint,
            atol=1e-12,
            rtol=1e-12,
        )
        self.result.assert_reconciled(absolute_tolerance=1e-12)

    def test_are_cns_to_are_ely_pair_uses_declared_equation(self):
        pair = self.result.pair_record("ARE-cns", "ARE-ely")
        k = self.result.node_position("ARE-cns")
        j = self.result.node_position("ARE-ely")
        expected = (
            self.result.baseline_producer_footprint[j]
            - (
                self.result.baseline_producer_footprint[j]
                - self.result.avoided_producer_footprint[k, j]
            )
        )
        self.assertAlmostEqual(pair["avoided_producer_footprint_tco2"], expected, places=12)
        self.assertAlmostEqual(
            pair["baseline_producer_footprint_tco2"]
            - pair["counterfactual_producer_footprint_tco2"],
            pair["avoided_producer_footprint_tco2"],
            places=12,
        )

    def test_pairwise_table_is_complete_and_unique(self):
        frame = self.result.pairwise_frame()
        self.assertEqual(len(frame), 9)
        self.assertEqual(
            len(frame[["intervention_node", "producer_node"]].drop_duplicates()),
            9,
        )
        self.assertEqual(set(frame["intervention_node"]), {"ARE-cns", "ARE-ely", "ROW-x"})
        self.assertEqual(set(frame["producer_node"]), {"ARE-cns", "ARE-ely", "ROW-x"})
        self.assertTrue(
            {
                "intervention_region",
                "intervention_sector",
                "producer_region",
                "producer_sector",
            }.issubset(frame.columns)
        )

    def test_artifacts_are_hash_verified_and_bound_to_network_result(self):
        with tempfile.TemporaryDirectory() as directory:
            input_hashes = {"mrio": "a" * 64, "focal_demand": "b" * 64}
            metadata = linkage.write_cdr_producer_linkage_artifacts(
                directory,
                self.result,
                input_hashes=input_hashes,
                preferred_pair=("ARE-cns", "ARE-ely"),
            )
            self.assertEqual(metadata["pair_count"], 9)
            self.assertEqual(
                metadata["preferred_pair"]["producer_node"],
                "ARE-ely",
            )
            source_cid = "c" * 64
            evidence_cid = "d" * 64
            linkage.bind_cdr_linkage_metadata_to_network_result(
                directory, 2017, source_cid, evidence_cid
            )
            verified = linkage.verify_cdr_linkage_artifacts(
                directory,
                2017,
                expected_input_hashes=input_hashes,
                expected_source_result_cid=source_cid,
                expected_evidence_cid=evidence_cid,
                expected_evidence_basis=metadata,
            )
            pair_path = Path(directory) / verified["artifacts"]["pairwise"]["filename"]
            intervention_path = (
                Path(directory) / verified["artifacts"]["intervention_summary"]["filename"]
            )
            producer_path = (
                Path(directory) / verified["artifacts"]["producer_baseline"]["filename"]
            )
            frame = pd.read_csv(pair_path, compression="gzip")
            intervention = pd.read_csv(intervention_path)
            producer = pd.read_csv(producer_path)
            linkage.validate_cdr_linkage_frames(verified, frame, intervention, producer)
            self.assertEqual(len(frame), 9)
            self.assertEqual(verified["source_network_result_cid"], source_cid)
            self.assertEqual(verified["linkage_evidence_cid"], evidence_cid)

            tampered = frame.copy()
            tampered.loc[0, "avoided_producer_footprint_tco2"] += 1.0
            with self.assertRaises(RuntimeError):
                linkage.validate_cdr_linkage_frames(
                    verified, tampered, intervention, producer
                )

            # A coordinated edit of the CSV and adjacent metadata must still
            # fail because the original hashes are embedded in the immutable
            # Network/DLI evidence basis.
            tampered.to_csv(pair_path, index=False, compression="gzip")
            metadata_path = Path(directory) / linkage.METADATA_FILENAME_TEMPLATE.format(year=2017)
            modified_metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
            modified_metadata["artifacts"]["pairwise"]["sha256"] = linkage._sha256_file(pair_path)
            metadata_path.write_text(json.dumps(modified_metadata, indent=2), encoding="utf-8")
            with self.assertRaises(RuntimeError):
                linkage.verify_cdr_linkage_artifacts(
                    directory,
                    2017,
                    expected_input_hashes=input_hashes,
                    expected_source_result_cid=source_cid,
                    expected_evidence_cid=evidence_cid,
                    expected_evidence_basis=metadata,
                )

    def test_intensity_only_change_at_k_does_not_change_other_producer_contributions(self):
        base_output = self.model.L @ self.demand
        baseline = self.model.fE * base_output
        changed_intensity = self.model.fE.copy()
        changed_intensity[0] *= 0.5
        changed = changed_intensity * base_output
        self.assertNotEqual(changed[0], baseline[0])
        self.assertEqual(changed[1], baseline[1])
        self.assertEqual(changed[2], baseline[2])

    def test_streamlit_linkage_module_is_a_small_root_authority_bridge(self):
        bridge = (ROOT / "streamlit_app" / "cdr_producer_linkage.py").read_text(encoding="utf-8")
        self.assertIn("Compatibility bridge to the single authoritative U16 module", bridge)
        self.assertIn("parent.parent / 'cdr_producer_linkage.py'", bridge)
        self.assertLess(len(bridge), 1500)

    def test_extension_does_not_add_a_fifth_dli_criterion(self):
        self.assertEqual(tuple(CRITERIA), ("BC", "PR", "CDR", "IC"))
        core = (ROOT / "critic_dli_core.py").read_text(encoding="utf-8")
        self.assertNotIn("producer_linkage", core.lower())
        self.assertNotIn("Delta C", core)

    def test_streamlit_exposes_verified_linkage_workspace(self):
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        ui = (ROOT / "streamlit_app" / "cdr_linkage_ui.py").read_text(encoding="utf-8")
        self.assertIn('"CDR producer linkage"', app)
        self.assertIn("render_cdr_producer_linkage_workspace", app)
        self.assertIn("verify_cdr_linkage_artifacts", ui)
        self.assertIn("ARE-cns", ui)
        self.assertIn("ARE-ely", ui)
        self.assertIn("not the effect of reducing only k's own direct carbon intensity", ui)

    def test_network_orchestrator_generates_and_binds_pairwise_artifacts(self):
        with tempfile.TemporaryDirectory() as directory:
            active_dir = Path(directory) / "active_analytics"
            hashes = {"mrio": "a" * 64, "focal_demand": "b" * 64}
            evidence_cid = "c" * 64
            response_cid = "d" * 64
            service = orchestrator.DataOrchestrator(
                deployment_path=Path(directory) / "missing-deployment.json",
                client=object(),
            )
            with (
                mock.patch.object(orchestrator, "ACTIVE_ANALYTICS_DIR", active_dir),
                mock.patch.object(orchestrator, "active_input_hashes", return_value=hashes),
                mock.patch.object(orchestrator.ae, "load_year", return_value=self.model),
                mock.patch.object(orchestrator.ae, "load_company_Y", return_value=self.demand),
                mock.patch.object(
                    orchestrator, "load_verified_active_frame", side_effect=FileNotFoundError
                ),
                mock.patch.object(
                    orchestrator, "store_content", side_effect=[evidence_cid, response_cid]
                ),
                mock.patch.object(orchestrator, "write_active_frame_artifact"),
                mock.patch.object(orchestrator, "store_active_analytics_frame"),
                mock.patch.object(orchestrator, "record_active_result"),
            ):
                response = service.compute_network(2017)

            self.assertEqual(response.content_hash, response_cid)
            payload = response.payload["cdr_producer_linkage"]
            self.assertTrue(payload["available"])
            self.assertEqual(payload["evidence_cid"], evidence_cid)
            self.assertEqual(payload["preferred_pair"]["intervention_node"], "ARE-cns")
            self.assertEqual(payload["preferred_pair"]["producer_node"], "ARE-ely")
            verified = linkage.verify_cdr_linkage_artifacts(
                active_dir,
                2017,
                expected_input_hashes=hashes,
                expected_source_result_cid=response_cid,
                expected_evidence_cid=evidence_cid,
                expected_evidence_basis=payload,
            )
            pairwise = pd.read_csv(
                active_dir / verified["artifacts"]["pairwise"]["filename"],
                compression="gzip",
            )
            intervention = pd.read_csv(
                active_dir / verified["artifacts"]["intervention_summary"]["filename"]
            )
            producer = pd.read_csv(
                active_dir / verified["artifacts"]["producer_baseline"]["filename"]
            )
            linkage.validate_cdr_linkage_frames(
                verified, pairwise, intervention, producer
            )

    def test_orchestrator_records_linkage_without_using_it_in_dli(self):
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        self.assertIn("compute_raw_metrics_with_cdr_linkage", orchestrator)
        self.assertIn('"cdr_producer_linkage"', orchestrator)
        self.assertIn('namespace="cdr_producer_linkage"', orchestrator)
        self.assertIn("dli_authority_boundary", orchestrator)


if __name__ == "__main__":
    unittest.main(verbosity=2)
