"""U17 regression tests for dynamic 87%-of-total SPA reporting."""
from __future__ import annotations

import sys
import ast
import hashlib
import json
import re
import tempfile
import types
import unittest
from pathlib import Path
from typing import Any
from unittest import mock

import numpy as np
import pandas as pd
import pandas.testing as pdt

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

import spa_engine as spa  # noqa: E402
import release_identity  # noqa: E402
from spa_sda_pathway_bridge import mark_dominant_display_paths  # noqa: E402


def _extracted_dapp_spa_namespace(content_store: Path) -> dict[str, Any]:
    """Load the actual SPA lifecycle validators without optional web3 imports."""

    tree = ast.parse((ROOT / "dapp_lifecycle.py").read_text(encoding="utf-8"))
    wanted = {
        "_load_content",
        "_content_payload",
        "_validated_operation_payload",
        "_mrio_content_company_footprint",
        "_sda_content_is_valid",
        "_content_hashes_match",
        "_spa_content_is_coverage_complete",
        "_fulfilled_upstream_results",
    }
    nodes = [node for node in tree.body if isinstance(node, ast.FunctionDef) and node.name in wanted]
    module = ast.fix_missing_locations(ast.Module(body=nodes, type_ignores=[]))
    namespace: dict[str, Any] = {
        "Any": Any,
        "CONTENT_STORE": content_store,
        "hashlib": hashlib,
        "json": json,
        "math": __import__("math"),
    }
    exec(compile(module, str(ROOT / "dapp_lifecycle.py"), "exec"), namespace)
    return namespace


def _extracted_compute_spa(namespace: dict[str, Any]):
    """Load DataOrchestrator.compute_spa without importing optional services."""

    tree = ast.parse((ROOT / "data_orchestrator.py").read_text(encoding="utf-8"))
    source_class = next(
        node
        for node in tree.body
        if isinstance(node, ast.ClassDef) and node.name == "DataOrchestrator"
    )
    method = next(
        node
        for node in source_class.body
        if isinstance(node, ast.FunctionDef) and node.name == "compute_spa"
    )
    test_class = ast.ClassDef(
        name="_ExtractedOrchestrator",
        bases=[],
        keywords=[],
        body=[method],
        decorator_list=[],
    )
    module = ast.fix_missing_locations(ast.Module(body=[test_class], type_ignores=[]))
    namespace.update({"Any": Any, "OrchestratorResponse": object})
    exec(compile(module, str(ROOT / "data_orchestrator.py"), "exec"), namespace)
    return namespace["_ExtractedOrchestrator"]().compute_spa


def _path_frame(contributions: list[float], names: list[str] | None = None) -> pd.DataFrame:
    names = names or [f"P{i:03d}" for i in range(len(contributions))]
    return pd.DataFrame(
        {
            "depth": [0] * len(contributions),
            "path_codes": names,
            "contribution": contributions,
            # Deliberately wrong values prove authoritative selection recomputes them.
            "cumulative_share": [0.999] * len(contributions),
        }
    )


class _SmallMRIO:
    def __init__(self, A: np.ndarray, fE: np.ndarray) -> None:
        self.Z = np.asarray(A, dtype=float)
        self.X = np.ones(len(fE), dtype=float)
        self.fE = np.asarray(fE, dtype=float)
        self.node_codes = np.asarray([f"N{i}" for i in range(len(fE))])
        self.L = np.linalg.inv(np.eye(len(fE)) - self.Z)

    def footprint(self, demand: np.ndarray) -> float:
        return float(self.fE @ (self.L @ demand))

    def footprint_by_node(self, demand: np.ndarray) -> np.ndarray:
        return self.fE * (self.L @ demand)


class U17DynamicSPACoverageTests(unittest.TestCase):
    def test_default_target_is_87_percent_without_fixed_report_cap(self):
        cfg = spa.SPAConfig()
        self.assertEqual(cfg.cumulative_target, 0.87)
        self.assertIsNone(cfg.max_reported_paths)

    def test_release_identity_exposes_u17_spa_reporting_extension(self):
        identity = release_identity.RELEASE_IDENTITY
        self.assertEqual(
            identity["release_patch"],
            "u23-evidence-bound-abatement-decision",
        )
        self.assertEqual(identity["aurora_lifecycle_extension_id"], "v5.0.17-U18")
        self.assertEqual(
            identity["methodology_lifecycle_extension_id"], "v5.0.17-U19"
        )
        self.assertEqual(identity["integrated_methodology_extension_id"], "v5.0.17-U17")
        self.assertEqual(identity["spa_reporting_extension_id"], "v5.0.17-U17")
        self.assertEqual(identity["spa_coverage_target"], "0.87")
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8-sig")
        self.assertIn('RELEASE_IDENTITY["spa_reporting_extension_id"]', server)
        self.assertIn('Get-RqVersionValue -Key "spa_reporting_extension_id"', launcher)
        self.assertIn('$candidate.spa_reporting_extension -eq $ExpectedSpaReporting', launcher)

    def test_exact_boundary_returns_minimum_whole_path_prefix(self):
        source = _path_frame([13.0, 17.0, 50.0, 20.0], ["D", "C", "A", "B"])
        original = source.copy(deep=True)
        selected, reached = spa.top_paths_to_threshold(source, spa.SPAConfig(), 100.0)
        self.assertTrue(reached)
        self.assertEqual(selected["path_codes"].tolist(), ["A", "B", "C"])
        self.assertAlmostEqual(float(selected["contribution"].sum()), 87.0)
        self.assertAlmostEqual(float(selected["cumulative_share"].iloc[-1]), 0.87)
        self.assertLess(float(selected["cumulative_share"].iloc[-2]), 0.87)
        pdt.assert_frame_equal(source, original)

    def test_whole_final_path_can_overshoot_target(self):
        selected, reached = spa.top_paths_to_threshold(
            _path_frame([50.0, 20.0, 18.0, 12.0]), spa.SPAConfig(), 100.0
        )
        self.assertTrue(reached)
        self.assertEqual(selected["contribution"].tolist(), [50.0, 20.0, 18.0])
        self.assertAlmostEqual(float(selected["contribution"].sum()), 88.0)
        self.assertAlmostEqual(float(selected["cumulative_share"].iloc[-1]), 0.88)

    def test_dynamic_result_can_include_more_than_50_paths(self):
        selected, reached = spa.top_paths_to_threshold(
            _path_frame([1.0] * 100), spa.SPAConfig(), 100.0
        )
        self.assertTrue(reached)
        self.assertEqual(len(selected), 87)
        self.assertAlmostEqual(float(selected["contribution"].sum()), 87.0)

    def test_unreachable_target_returns_complete_bounded_universe(self):
        selected, reached = spa.top_paths_to_threshold(
            _path_frame([1.0] * 60), spa.SPAConfig(), 100.0
        )
        self.assertFalse(reached)
        self.assertEqual(len(selected), 60)
        self.assertAlmostEqual(float(selected["cumulative_share"].iloc[-1]), 0.60)
        self.assertAlmostEqual(0.87 * 100.0 - float(selected["contribution"].sum()), 27.0)

    def test_ties_use_depth_then_path_identity_deterministically(self):
        source = pd.DataFrame(
            {
                "depth": [1, 0, 0, 0],
                "path_codes": ["B", "Z", "A", "BASE"],
                "contribution": [6.0, 7.0, 7.0, 80.0],
                "cumulative_share": [0.0] * 4,
            }
        )
        selected, reached = spa.top_paths_to_threshold(source, spa.SPAConfig(), 100.0)
        self.assertTrue(reached)
        self.assertEqual(selected["path_codes"].tolist(), ["BASE", "A"])

    def test_invalid_selection_inputs_fail_closed(self):
        with self.assertRaises(ValueError):
            spa.top_paths_to_threshold(_path_frame([1.0]), spa.SPAConfig(cumulative_target=1.1), 1.0)
        with self.assertRaises(ValueError):
            spa.top_paths_to_threshold(_path_frame([-1.0]), spa.SPAConfig(), 1.0)
        with self.assertRaises(ValueError):
            spa.top_paths_to_threshold(_path_frame([1.0]), spa.SPAConfig(), float("nan"))
        duplicate = _path_frame([0.6, 0.4], ["same", "same"])
        with self.assertRaises(ValueError):
            spa.top_paths_to_threshold(duplicate, spa.SPAConfig(), 1.0)

    def test_zero_intensity_intermediary_is_still_expanded(self):
        A = np.zeros((3, 3), dtype=float)
        A[1, 0] = 0.5
        A[2, 1] = 0.5
        model = _SmallMRIO(A, np.array([0.0, 0.0, 10.0]))
        paths, _ = spa.trace_paths(
            model,
            np.array([1.0, 0.0, 0.0]),
            spa.SPAConfig(max_depth=2, top_k_per_hop=3, beam_width=10, min_coefficient=0.0),
        )
        terminal = paths.loc[paths["path_codes"].eq("N0 <- N1 <- N2")]
        self.assertEqual(len(terminal), 1)
        self.assertAlmostEqual(float(terminal.iloc[0]["contribution"]), 2.5)

    def test_repeated_node_walks_are_retained_within_depth_bound(self):
        model = _SmallMRIO(np.array([[0.2]]), np.array([1.0]))
        paths, _ = spa.trace_paths(
            model,
            np.array([1.0]),
            spa.SPAConfig(max_depth=2, top_k_per_hop=1, beam_width=10, min_coefficient=0.0),
        )
        self.assertEqual(
            paths["path_codes"].tolist(),
            ["N0", "N0 <- N0", "N0 <- N0 <- N0"],
        )
        np.testing.assert_allclose(paths["contribution"], [1.0, 0.2, 0.04])

    def test_bounded_adaptive_expansion_reaches_target_before_acceptance(self):
        model = _SmallMRIO(np.array([[0.5]]), np.array([1.0]))
        screened, reported, total, selected_config, attempts = (
            spa.trace_paths_to_threshold_adaptive(
                model,
                np.array([1.0]),
                spa.SPAConfig(
                    max_depth=0,
                    exact_max_tier=8,
                    top_k_per_hop=1,
                    beam_width=1,
                    min_coefficient=0.0,
                    cumulative_target=0.87,
                ),
            )
        )
        self.assertEqual(len(attempts), 3)
        self.assertFalse(bool(attempts[0]["threshold_reached"]))
        self.assertFalse(bool(attempts[1]["threshold_reached"]))
        self.assertTrue(bool(attempts[2]["threshold_reached"]))
        self.assertEqual(selected_config.max_depth, 2)
        self.assertAlmostEqual(total, 2.0)
        self.assertEqual(len(screened), 3)
        self.assertEqual(len(reported), 3)
        self.assertAlmostEqual(float(reported["cumulative_share"].iloc[-1]), 0.875)

    def test_orchestrator_does_not_commit_a_below_target_spa_result(self):
        model = _SmallMRIO(np.zeros((1, 1)), np.array([1.0]))
        screened = _path_frame([60.0])
        screened["cumulative_share"] = [0.60]
        config = spa.SPAConfig()
        attempts = [
            {
                "attempt": 3,
                "reported_cumulative_share": 0.60,
                "threshold_reached": False,
            }
        ]
        response = mock.Mock()
        artifact = mock.Mock()
        mirror = mock.Mock()
        result_index = mock.Mock()
        spa_proxy = types.SimpleNamespace(
            SPAConfig=spa.SPAConfig,
            SPA_COVERAGE_TOLERANCE=spa.SPA_COVERAGE_TOLERANCE,
            trace_paths_to_threshold_adaptive=mock.Mock(
                return_value=(screened, screened, 100.0, config, attempts)
            ),
        )
        namespace = {
            "active_input_hashes": mock.Mock(return_value={"mrio": "a" * 64, "focal_demand": "b" * 64}),
            "ae": types.SimpleNamespace(
                load_year=mock.Mock(return_value=model),
                load_company_Y=mock.Mock(return_value=np.array([1.0])),
            ),
            "MRIO_PATH": ROOT / "input_mrio_completed.xlsx",
            "COMPANY_PATH": ROOT / "Focal_Company_Demand_Converted.xlsx",
            "spa": spa_proxy,
            "write_active_frame_artifact": artifact,
            "store_active_analytics_frame": mirror,
            "record_active_result": result_index,
        }
        compute_spa = _extracted_compute_spa(namespace)
        compute_spa.__self__._response = response
        with self.assertRaisesRegex(RuntimeError, "failed closed"):
            compute_spa(2017)
        response.assert_not_called()
        artifact.assert_not_called()
        mirror.assert_not_called()
        result_index.assert_not_called()

    def test_lifecycle_rejects_fulfilled_spa_cid_below_target(self):
        expected = {"mrio": "a" * 64, "focal_demand": "b" * 64}

        def store_payload(
            directory: Path,
            payload: dict,
            *,
            namespace: str = "structural_path_analysis",
            operation: str = "structural_path_analysis",
        ) -> str:
            envelope = {
                "namespace": namespace,
                "payload": {
                    "operation": operation,
                    "payload": payload,
                },
            }
            body = json.dumps(envelope, sort_keys=True).encode("utf-8")
            cid = hashlib.sha256(body).hexdigest()
            (directory / f"{cid}.json").write_bytes(body)
            return cid

        valid_payload = {
            "year": 2017,
            "input_hashes": expected,
            "cumulative_target": 0.87,
            "total_footprint": 100.0,
            "threshold_reached": True,
            "reported_path_count": 3,
            "paths": [
                {
                    "path_rank": 1,
                    "depth": 0,
                    "path_nodes": ["A"],
                    "path_codes": "A",
                    "contribution": 50.0,
                    "individual_share_of_company_footprint": 0.50,
                    "cumulative_contribution": 50.0,
                    "cumulative_share": 0.50,
                },
                {
                    "path_rank": 2,
                    "depth": 0,
                    "path_nodes": ["B"],
                    "path_codes": "B",
                    "contribution": 20.0,
                    "individual_share_of_company_footprint": 0.20,
                    "cumulative_contribution": 70.0,
                    "cumulative_share": 0.70,
                },
                {
                    "path_rank": 3,
                    "depth": 0,
                    "path_nodes": ["C"],
                    "path_codes": "C",
                    "contribution": 17.0,
                    "individual_share_of_company_footprint": 0.17,
                    "cumulative_contribution": 87.0,
                    "cumulative_share": 0.87,
                },
            ],
            "reported_path_footprint": 87.0,
            "target_footprint": 87.0,
            "reported_cumulative_share": 0.87,
            "cumulative_share": 0.87,
            "target_shortfall": 0.0,
            "target_overshoot": 0.0,
            "screened_path_count": 3,
            "screened_cumulative_share": 0.87,
            "screened_paths_artifact": {
                "filename": "spa_screened_paths_2017.csv",
                "row_count": 3,
                "sha256": "d" * 64,
            },
            "coverage_reconciliation": {
                "complete_focal_company_footprint": 100.0,
                "reported_selected_paths": 87.0,
                "screened_but_unreported_paths": 0.0,
                "screening_and_pruning_residual_through_max_path_depth": 13.0,
                "exact_depth_tail_beyond_max_path_depth": 0.0,
                "exact_cumulative_footprint_through_max_path_depth": 100.0,
                "screened_path_footprint": 87.0,
                "reconciliation_residual": 0.0,
                "target_identity_residual": 0.0,
            },
            "adaptive_expansion_attempts": [{"threshold_reached": True}],
        }
        with tempfile.TemporaryDirectory() as directory_name:
            directory = Path(directory_name)
            valid_cid = store_payload(directory, valid_payload)
            invalid_payload = dict(valid_payload)
            invalid_payload.update(
                {
                    "threshold_reached": False,
                    "reported_path_count": 1,
                    "paths": [{"path_codes": "A", "contribution": 60.0}],
                    "reported_path_footprint": 60.0,
                    "reported_cumulative_share": 0.60,
                    "cumulative_share": 0.60,
                    "target_shortfall": 27.0,
                    "adaptive_expansion_attempts": [{"threshold_reached": False}],
                }
            )
            invalid_cid = store_payload(directory, invalid_payload)
            mrio_cid = store_payload(
                directory,
                {
                    "year": 2017,
                    "input_hashes": expected,
                    "company_footprint": 100.0,
                    "all_hotspots": [
                        {"node_code": "A", "footprint_contribution": 100.0}
                    ],
                },
                namespace="mrio_carbon_accounting",
                operation="mrio_carbon_accounting",
            )

            class _Call:
                def __init__(self, value):
                    self.value = value

                def call(self):
                    return self.value

            class _Functions:
                def __init__(self, cid: str):
                    self.cid = cid

                def nextComputeRequestId(self):
                    return _Call(2)

                def getComputeRequest(self, request_id: int):
                    if request_id == 0:
                        return _Call(
                            [
                                0,
                                0,
                                2017,
                                0,
                                expected["mrio"],
                                expected["focal_demand"],
                                mrio_cid,
                                1,
                                0,
                                122,
                                "0xOracle",
                            ]
                        )
                    return _Call(
                        [
                            1,
                            1,
                            2017,
                            0,
                            expected["mrio"],
                            expected["focal_demand"],
                            self.cid,
                            1,
                            0,
                            123,
                            "0xOracle",
                        ]
                    )

            class _Contract:
                def __init__(self, cid: str):
                    self.functions = _Functions(cid)

            lifecycle = _extracted_dapp_spa_namespace(directory)
            with self.subTest("valid CID accepted"):
                self.assertTrue(
                    lifecycle["_spa_content_is_coverage_complete"](
                        valid_cid, expected, 2017
                    )
                )
            with self.subTest("below-target CID rejected"):
                self.assertFalse(
                    lifecycle["_spa_content_is_coverage_complete"](
                        invalid_cid, expected, 2017
                    )
                )
            with self.subTest("valid on-chain fulfilment unlocks SPA"):
                self.assertIn(
                    "2017",
                    lifecycle["_fulfilled_upstream_results"](
                        _Contract(valid_cid), expected
                    )["spa"],
                )
            with self.subTest("invalid on-chain fulfilment remains locked"):
                self.assertNotIn(
                    "2017",
                    lifecycle["_fulfilled_upstream_results"](
                        _Contract(invalid_cid), expected
                    )["spa"],
                )

    def test_downstream_reconstruction_requires_complete_verified_spa_baseline(self):
        lifecycle_source = (ROOT / "dapp_lifecycle.py").read_text(encoding="utf-8")
        normalized = re.sub(r"\s+", " ", lifecycle_source)
        self.assertIn(
            "if governance_spec and mrio_validated and demand_validated and baseline_complete:",
            normalized,
        )

    def test_integrated_display_can_use_complete_footprint_denominator(self):
        panel = pd.DataFrame(
            {
                "path_id": ["A", "B", "C", "D"],
                "comparison_contribution": [50.0, 20.0, 18.0, 12.0],
            }
        )
        marked, metadata = mark_dominant_display_paths(
            panel, 0.87, full_comparison_footprint=100.0
        )
        self.assertTrue(metadata["threshold_reached"])
        self.assertEqual(metadata["dominant_path_count"], 3)
        self.assertAlmostEqual(metadata["achieved_share_of_full_footprint"], 0.88)
        self.assertEqual(marked["in_dominant_display_set"].tolist(), [True, True, True, False])

    def test_u17_ui_and_payload_have_no_fixed_50_path_cap(self):
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        spa_block = app.split('elif page == "Structural Pathway Intelligence":', 1)[1].split(
            'elif page == "Carbon-Change Decomposition":', 1
        )[0]
        self.assertNotIn(".head(50)", spa_block)
        self.assertNotIn('"top_paths": reported_paths.head(50)', orchestrator)
        for marker in (
            '"target_footprint"',
            '"reported_path_footprint"',
            '"target_shortfall"',
            '"target_overshoot"',
            '"hotspot_alignment"',
            '"fixed_reported_path_cap_applied"',
        ):
            self.assertIn(marker, orchestrator)


if __name__ == "__main__":
    unittest.main(verbosity=2)
