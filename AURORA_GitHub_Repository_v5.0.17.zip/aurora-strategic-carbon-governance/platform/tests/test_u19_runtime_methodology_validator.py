"""Focused tests for the read-only U19 post-deployment methodology audit."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import validate_u19_runtime_methodology as validator


MRIO_HASH = "a" * 64
DEMAND_HASH = "b" * 64
STAGE_CIDS = {
    "mrio_2014": "1" * 64,
    "mrio_2017": "2" * 64,
    "spa_2014": "3" * 64,
    "spa_2017": "4" * 64,
    "sda_2014_2017": "5" * 64,
    "network_dli_2014": "6" * 64,
    "network_dli_2017": "7" * 64,
    "aurora_2017": "8" * 64,
}


def _envelope(operation: str, **period: object) -> dict:
    return {
        "namespace": operation,
        "payload": {
            "operation": operation,
            "payload": {
                **period,
                "input_hashes": {
                    "mrio": MRIO_HASH,
                    "focal_demand": DEMAND_HASH,
                },
            },
        },
    }


def _mrio_fields(year: int) -> dict:
    return {
        "year": year,
        "company_footprint": 100.0,
        "all_hotspots": [
            {"node_code": f"N-{year}", "footprint_contribution": 100.0}
        ],
    }


def _spa_fields(year: int) -> dict:
    return {
        "year": year,
        "cumulative_target": 0.87,
        "total_footprint": 100.0,
        "threshold_reached": True,
        "reported_path_count": 3,
        "paths": [
            {"path_codes": "A", "contribution": 50.0},
            {"path_codes": "B", "contribution": 20.0},
            {"path_codes": "C", "contribution": 17.0},
        ],
        "reported_path_footprint": 87.0,
        "reported_cumulative_share": 0.87,
        "target_shortfall": 0.0,
        "target_overshoot": 0.0,
    }


def _fixture() -> tuple[dict, dict[str, dict]]:
    network_request_id = 31
    state = {
        "architecture_version": validator.RELEASE_IDENTITY["architecture_version"],
        "active_input_hashes": {
            "mrio": MRIO_HASH,
            "focal_demand": DEMAND_HASH,
        },
        "contracts": {
            "QueryManagement": {
                "address": "0x" + "9" * 40,
                "abi": [],
            }
        },
        "lifecycle": {
            "mrio_data_validated": True,
            "focal_demand_validated": True,
            "mrio_2014_complete": True,
            "mrio_2017_complete": True,
            "spa_2014_complete": True,
            "spa_2017_complete": True,
            "sda_complete": True,
            "network_2014_complete": True,
            "network_2017_complete": True,
            "temporal_dli_complete": True,
            "aurora_2017_complete": True,
            "aurora_bound_to_active_2017_network": True,
            "query_management_ready": True,
            "query_deployed": True,
            "system_operational": True,
            "intervention_workspace_ready": True,
            "intervention_governance_evidence_verified": True,
            "intervention_governance_evidence_error": "",
            "intervention_governance_resolved": True,
            "verified_no_governance_ready_intervention": True,
            "selected_intervention_count": 0,
            "proposed_intervention_count": 0,
            "decided_intervention_count": 0,
            "all_selected_interventions_decided": False,
        },
        "active_results": {
            "mrio": {
                "2014": {
                    "request_id": 1,
                    "base_year": 2014,
                    "comparison_year": 0,
                    "content_hash": STAGE_CIDS["mrio_2014"],
                },
                "2017": {
                    "request_id": 2,
                    "base_year": 2017,
                    "comparison_year": 0,
                    "content_hash": STAGE_CIDS["mrio_2017"],
                },
            },
            "spa": {
                "2014": {
                    "request_id": 3,
                    "base_year": 2014,
                    "comparison_year": 0,
                    "content_hash": STAGE_CIDS["spa_2014"],
                },
                "2017": {
                    "request_id": 4,
                    "base_year": 2017,
                    "comparison_year": 0,
                    "content_hash": STAGE_CIDS["spa_2017"],
                },
            },
            "sda": {
                "2014-2017": {
                    "request_id": 5,
                    "base_year": 2014,
                    "comparison_year": 2017,
                    "content_hash": STAGE_CIDS["sda_2014_2017"],
                }
            },
            "network": {
                "2014": {
                    "request_id": 30,
                    "year": 2014,
                    "content_hash": STAGE_CIDS["network_dli_2014"],
                },
                "2017": {
                    "request_id": network_request_id,
                    "year": 2017,
                    "content_hash": STAGE_CIDS["network_dli_2017"],
                    "temporal_baseline_request_id": 30,
                    "temporal_baseline_content_hash": STAGE_CIDS["network_dli_2014"],
                },
            },
            "aurora": {
                "2017": {
                    "request_id": 40,
                    "year": 2017,
                    "network_request_id": network_request_id,
                    "network_result_hash": STAGE_CIDS["network_dli_2017"],
                    "content_hash": STAGE_CIDS["aurora_2017"],
                }
            },
            "hotspots": {},
            "interventions": {},
            "intervention_requests": {},
            "intervention_portfolio_status": {},
        },
    }
    envelopes = {
        STAGE_CIDS["mrio_2014"]: _envelope(
            "mrio_carbon_accounting", **_mrio_fields(2014)
        ),
        STAGE_CIDS["mrio_2017"]: _envelope(
            "mrio_carbon_accounting", **_mrio_fields(2017)
        ),
        STAGE_CIDS["spa_2014"]: _envelope(
            "structural_path_analysis", **_spa_fields(2014)
        ),
        STAGE_CIDS["spa_2017"]: _envelope(
            "structural_path_analysis", **_spa_fields(2017)
        ),
        STAGE_CIDS["sda_2014_2017"]: _envelope(
            "structural_decomposition_analysis",
            base_year=2014,
            comparison_year=2017,
        ),
        STAGE_CIDS["network_dli_2014"]: _envelope(
            "network_and_critic_dli_analysis", year=2014
        ),
        STAGE_CIDS["network_dli_2017"]: _envelope(
            "network_and_critic_dli_analysis",
            year=2017,
            pooled_critic_ready=True,
            dli_weighting={
                "method": "pooled Pearson-CRITIC",
                "weights": {"BC": 0.25, "PR": 0.25, "CDR": 0.25, "IC": 0.25},
            },
            authoritative_dli_slices={
                "2014": [{"year": 2014, "node_code": "N", "DLI": 0.4, "dli_rank": 1}],
                "2017": [{"year": 2017, "node_code": "N", "DLI": 0.5, "dli_rank": 1}],
            },
            temporal_dli_authority={
                "method": "one pooled two-year Pearson-CRITIC calculation",
                "years": [2014, 2017],
                "baseline_evidence_network_result_cid": STAGE_CIDS["network_dli_2014"],
            },
        ),
        STAGE_CIDS["aurora_2017"]: _envelope(
            "regional_sourcing_opportunity_analysis",
            year=2017,
            network_result_hash=STAGE_CIDS["network_dli_2017"],
        ),
    }
    return state, envelopes


class U19RuntimeMethodologyValidatorTests(unittest.TestCase):
    def _assess(self, state: dict, envelopes: dict[str, dict]) -> dict:
        return validator.assess_refreshed_state(
            state,
            deployment_state="deployment.json",
            content_loader=lambda cid: envelopes.get(cid, {}),
            query_contract_code_present=True,
        )

    def test_complete_coherent_runtime_passes_with_verified_no_option(self):
        state, envelopes = _fixture()
        report = self._assess(state, envelopes)
        self.assertEqual(report["status"], "pass")
        self.assertEqual(report["summary"]["failed_check_ids"], [])
        self.assertTrue(all(row["passed"] for row in report["cid_lineage"]))
        self.assertTrue(
            report["intervention_governance"]["required_for_validation_pass"]
        )
        self.assertEqual(report["intervention_governance"]["selected_count"], 0)

    def test_missing_spa_year_fails_closed(self):
        state, envelopes = _fixture()
        state["active_results"]["spa"].pop("2017")
        state["lifecycle"]["spa_2017_complete"] = False
        report = self._assess(state, envelopes)
        self.assertEqual(report["status"], "fail")
        self.assertIn("spa_2017_active_result", report["summary"]["failed_check_ids"])
        self.assertIn("immutable_cid_lineage", report["summary"]["failed_check_ids"])

    def test_spa_denominator_below_governed_mrio_total_fails_closed(self):
        state, envelopes = _fixture()
        spa_payload = envelopes[STAGE_CIDS["spa_2017"]]["payload"]["payload"]
        spa_payload["total_footprint"] = 90.0
        report = self._assess(state, envelopes)
        self.assertEqual(report["status"], "fail")
        self.assertIn(
            "spa_2017_minimum_87_percent_prefix",
            report["summary"]["failed_check_ids"],
        )

    def test_nonminimum_spa_prefix_fails_closed(self):
        state, envelopes = _fixture()
        spa_payload = envelopes[STAGE_CIDS["spa_2017"]]["payload"]["payload"]
        spa_payload["paths"] = [
            {"path_codes": "A", "contribution": 87.0},
            {"path_codes": "B", "contribution": 1.0},
        ]
        spa_payload["reported_path_count"] = 2
        spa_payload["reported_path_footprint"] = 88.0
        spa_payload["reported_cumulative_share"] = 0.88
        spa_payload["target_overshoot"] = 1.0
        report = self._assess(state, envelopes)
        self.assertEqual(report["status"], "fail")
        self.assertFalse(report["spa_coverage"]["2017"]["checks"]["prefix_is_minimum"])

    def test_stale_aurora_network_binding_fails_closed(self):
        state, envelopes = _fixture()
        state["active_results"]["aurora"]["2017"]["network_result_hash"] = "f" * 64
        report = self._assess(state, envelopes)
        self.assertEqual(report["status"], "fail")
        self.assertIn(
            "aurora_bound_to_active_2017_network",
            report["summary"]["failed_check_ids"],
        )
        self.assertIn("query_management_ready", report["summary"]["failed_check_ids"])

    def test_cid_payload_bound_to_old_inputs_fails_closed(self):
        state, envelopes = _fixture()
        envelopes[STAGE_CIDS["network_dli_2017"]]["payload"]["payload"][
            "input_hashes"
        ]["mrio"] = "e" * 64
        report = self._assess(state, envelopes)
        self.assertEqual(report["status"], "fail")
        network_lineage = next(
            row
            for row in report["cid_lineage"]
            if row["stage"] == "network_dli_2017"
        )
        self.assertFalse(network_lineage["checks"]["active_inputs_match"])
        self.assertIn("immutable_cid_lineage", report["summary"]["failed_check_ids"])

    def test_unresolved_intervention_status_fails_final_support_gate(self):
        state, envelopes = _fixture()
        state["lifecycle"].update(
            {
                "intervention_workspace_ready": True,
                "intervention_governance_evidence_verified": False,
                "intervention_governance_evidence_error": "Optional evidence unavailable",
                "selected_intervention_count": 2,
                "proposed_intervention_count": 1,
                "decided_intervention_count": 0,
                "all_selected_interventions_decided": False,
                "intervention_governance_resolved": False,
            }
        )
        report = self._assess(state, envelopes)
        self.assertEqual(report["status"], "fail")
        self.assertIn("intervention_governance_resolved", report["summary"]["failed_check_ids"])
        self.assertIn("query_management_ready", report["summary"]["failed_check_ids"])
        self.assertEqual(report["intervention_governance"]["selected_count"], 2)
        self.assertFalse(report["intervention_governance"]["evidence_verified"])

    def test_missing_live_query_bytecode_fails(self):
        state, envelopes = _fixture()
        report = validator.assess_refreshed_state(
            state,
            deployment_state="deployment.json",
            content_loader=lambda cid: envelopes.get(cid, {}),
            query_contract_code_present=False,
        )
        self.assertEqual(report["status"], "fail")
        self.assertIn(
            "query_management_deployed", report["summary"]["failed_check_ids"]
        )

    def test_refresh_uses_temporary_copy_and_preserves_source_bytes(self):
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary) / "deployment.json"
            original = b'{"chain_id": 1337, "lifecycle": {}}\n'
            source.write_bytes(original)
            observed: dict[str, Path] = {}

            def fake_refresh(path: str | Path) -> dict:
                audit_copy = Path(path)
                observed["path"] = audit_copy
                self.assertNotEqual(audit_copy.resolve(), source.resolve())
                self.assertEqual(audit_copy.read_bytes(), original)
                audit_copy.write_text('{"refreshed": true}', encoding="utf-8")
                return {"refreshed": True}

            with mock.patch.object(
                validator, "_refresh_lifecycle", side_effect=fake_refresh
            ):
                refreshed, digest = validator.refresh_state_read_only(source)

            self.assertEqual(refreshed, {"refreshed": True})
            self.assertEqual(source.read_bytes(), original)
            self.assertEqual(digest, validator._sha256_bytes(original))
            self.assertFalse(observed["path"].exists())

    def test_cli_returns_nonzero_and_json_when_live_refresh_fails(self):
        with tempfile.TemporaryDirectory() as temporary:
            missing = Path(temporary) / "missing.json"
            with mock.patch("builtins.print") as output:
                exit_code = validator.main([str(missing)])
            self.assertEqual(exit_code, 1)
            rendered = output.call_args.args[0]
            report = json.loads(rendered)
            self.assertEqual(report["status"], "fail")
            self.assertEqual(
                report["summary"]["failed_check_ids"], ["live_read_only_refresh"]
            )


if __name__ == "__main__":
    unittest.main()
