"""Regression tests for intervention-abatement governance and monitoring."""
from __future__ import annotations

import json
import unittest
from pathlib import Path

import pandas as pd

import aurora_lifecycle_policy as policy
import intervention_governance as governance


ROOT = Path(__file__).resolve().parents[1]


def _candidate() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "candidate_id": "e" * 64,
                "intervention_node": "ARE-cns",
                "hotspot_producer_node": "ARE-nmm",
                "mechanism_code": "INTENSITY_DECARBONIZATION",
                "baseline_hotspot_footprint_tco2": 30.0,
                "avoided_hotspot_footprint_tco2": 20.0,
            }
        ]
    )


def _actionability() -> dict:
    return {
        **{field: "Yes" for field in governance.ACTIONABILITY_FIELDS},
        "assessor_name": "Procurement manager",
        "assessor_role": "Accountable owner",
        "evidence_reference": "GOV-001",
        "assessment_notes": "Reviewed evidence.",
    }


class InterventionAbatementGovernanceTests(unittest.TestCase):
    def test_scenario_range_is_capped_and_assumption_bound(self):
        assessment = {
            **_actionability(),
            "scenario_conservative_effectiveness_fraction": 0.10,
            "scenario_expected_effectiveness_fraction": 0.20,
            "scenario_ambitious_effectiveness_fraction": 0.30,
            "scenario_implementation_coverage_fraction": 0.50,
            "scenario_adoption_fraction": 0.80,
            "scenario_assessor_name": "Carbon manager",
            "scenario_assessor_role": "Scenario owner",
            "scenario_evidence_reference": "SCENARIO-001",
            "scenario_confidence": "Medium",
            "scenario_notes": "No substitution or rebound modelled.",
        }
        result = governance.upsert_actionability_assessment(
            _candidate(), None, "e" * 64, assessment
        ).iloc[0]
        self.assertEqual(result["scenario_status"], "Quantified scenario")
        self.assertAlmostEqual(result["scenario_addressable_footprint_tco2"], 20.0)
        self.assertAlmostEqual(result["scenario_conservative_reduction_tco2"], 0.8)
        self.assertAlmostEqual(result["scenario_expected_reduction_tco2"], 1.6)
        self.assertAlmostEqual(result["scenario_ambitious_reduction_tco2"], 2.4)
        self.assertEqual(len(str(result["scenario_id"])), 64)

    def test_actionability_can_be_recorded_without_inventing_abatement(self):
        result = governance.upsert_actionability_assessment(
            _candidate(), None, "e" * 64, _actionability()
        ).iloc[0]
        self.assertEqual(result["assessment_status"], "Verified actionable")
        self.assertEqual(result["scenario_status"], "Not quantified")
        self.assertTrue(pd.isna(result["scenario_expected_reduction_tco2"]))

    def test_invalid_scenario_order_fails_closed(self):
        assessment = {
            **_actionability(),
            **{field: 0.5 for field in governance.SCENARIO_NUMERIC_FIELDS},
            "scenario_conservative_effectiveness_fraction": 0.7,
            "scenario_expected_effectiveness_fraction": 0.4,
            "scenario_ambitious_effectiveness_fraction": 0.6,
            "scenario_assessor_name": "Carbon manager",
            "scenario_assessor_role": "Scenario owner",
            "scenario_evidence_reference": "SCENARIO-002",
        }
        with self.assertRaisesRegex(ValueError, "conservative <= expected <= ambitious"):
            governance.upsert_actionability_assessment(
                _candidate(), None, "e" * 64, assessment
            )

    def test_final_support_requires_resolved_governance(self):
        self.assertFalse(
            policy.query_management_ready(
                temporal_dli_complete=True,
                aurora_complete=True,
                intervention_governance_resolved=False,
            )
        )
        self.assertTrue(
            policy.query_management_ready(
                temporal_dli_complete=True,
                aurora_complete=True,
                intervention_governance_resolved=True,
            )
        )

    def test_contract_and_interface_expose_observed_performance_workflow(self):
        source = (ROOT / "contracts" / "StrategicCarbonIntelligenceSystem.sol").read_text(
            encoding="utf-8"
        )
        self.assertIn("function recordInterventionPerformance(", source)
        self.assertIn("intervention.status == InterventionStatus.Approved", source)
        self.assertIn("event InterventionPerformanceRecorded(", source)
        abi = json.loads(
            (ROOT / "StrategicCarbonIntelligenceSystem_sol_HotspotsManagementAndGovernance.abi").read_text(
                encoding="utf-8"
            )
        )
        names = {item.get("name") for item in abi}
        self.assertIn("recordInterventionPerformance", names)
        self.assertIn("getInterventionPerformanceEvidenceCIDs", names)

        ui = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        self.assertIn("Final intervention decision support", ui)
        self.assertIn("Verify evidence and record observed performance on-chain", ui)
        client = (ROOT / "orchestrator_client.py").read_text(encoding="utf-8")
        self.assertIn("/v1/governance/intervention-performance", client)
        self.assertIn("record_intervention_performance(", ui)
        self.assertIn("scenario_expected_reduction_tco2", ui)

    def test_performance_endpoint_is_strict_and_lineage_bound(self):
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        body = orchestrator.split("def record_intervention_performance_evidence(", 1)[1].split(
            "def compute_sourcing_opportunities(", 1
        )[0]
        self.assertIn("_verified_active_network_2017_payload", body)
        self.assertIn("_verified_active_aurora_cid", body)
        self.assertIn("verify_intervention_governance_artifacts", body)
        self.assertIn("observed_hotspot_footprint_tco2 must be a finite non-negative number", body)
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        self.assertIn('"/v1/governance/intervention-performance"', server)


if __name__ == "__main__":
    unittest.main()
