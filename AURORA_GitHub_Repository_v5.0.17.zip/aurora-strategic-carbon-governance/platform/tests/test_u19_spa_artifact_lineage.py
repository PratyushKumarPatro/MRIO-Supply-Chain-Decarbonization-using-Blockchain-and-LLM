"""Fail-closed lineage checks for downstream U19 SPA/SDA integration."""
from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import pandas as pd

import final_methodology_service as service


class U19SPAArtifactLineageTests(unittest.TestCase):
    def _fixture(self, root: Path) -> tuple[Path, dict[str, str], str]:
        runtime = root / "runtime"
        active = runtime / "active_analytics"
        content = root / "content_store"
        active.mkdir(parents=True)
        content.mkdir()
        hashes = {"mrio": "a" * 64, "focal_demand": "b" * 64}
        frame = pd.DataFrame(
            {
                "path_codes": ["A", "A > B"],
                "contribution": [80.0, 10.0],
                "depth": [0, 1],
            }
        )
        csv_path = active / "spa_screened_paths_2017.csv"
        frame.to_csv(csv_path, index=False)
        frame_hash = service._sha256_file(csv_path)
        envelope = {
            "namespace": "structural_path_analysis",
            "payload": {
                "operation": "structural_path_analysis",
                "payload": {
                    "year": 2017,
                    "input_hashes": hashes,
                    "screened_path_count": 2,
                    "screened_paths_artifact": {
                        "filename": csv_path.name,
                        "row_count": 2,
                        "sha256": frame_hash,
                    },
                },
            },
        }
        body = json.dumps(envelope, sort_keys=True).encode("utf-8")
        cid = hashlib.sha256(body).hexdigest()
        (content / f"{cid}.json").write_bytes(body)
        (active / "spa_screened_paths_2017.json").write_text(
            json.dumps(
                {
                    "input_hashes": hashes,
                    "frame_sha256": frame_hash,
                    "row_count": 2,
                    "screened_path_count": 2,
                    "committed_artifact_sha256": frame_hash,
                    "source_result_cid": cid,
                }
            ),
            encoding="utf-8",
        )
        (runtime / "result_index.json").write_text(
            json.dumps(
                {
                    "results": {
                        "spa:2017": {
                            "content_hash": cid,
                            "input_hashes": hashes,
                        }
                    }
                }
            ),
            encoding="utf-8",
        )
        return runtime, hashes, cid

    def test_current_cid_bound_artifact_is_accepted(self):
        with tempfile.TemporaryDirectory() as temporary:
            runtime, hashes, cid = self._fixture(Path(temporary))
            frame, metadata = service._load_spa_artifact(runtime, 2017, hashes)
            self.assertEqual(len(frame), 2)
            self.assertEqual(metadata["source_result_cid"], cid)

    def test_stale_result_index_binding_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            runtime, hashes, _cid = self._fixture(Path(temporary))
            index_path = runtime / "result_index.json"
            index = json.loads(index_path.read_text(encoding="utf-8"))
            index["results"]["spa:2017"]["content_hash"] = "f" * 64
            index_path.write_text(json.dumps(index), encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "active result CID"):
                service._load_spa_artifact(runtime, 2017, hashes)

    def test_uncommitted_csv_replacement_is_rejected(self):
        with tempfile.TemporaryDirectory() as temporary:
            runtime, hashes, _cid = self._fixture(Path(temporary))
            csv_path = runtime / "active_analytics" / "spa_screened_paths_2017.csv"
            csv_path.write_text(
                "path_codes,contribution,depth\nX,90.0,0\n",
                encoding="utf-8",
            )
            meta_path = csv_path.with_suffix(".json")
            metadata = json.loads(meta_path.read_text(encoding="utf-8"))
            replacement_hash = service._sha256_file(csv_path)
            metadata["frame_sha256"] = replacement_hash
            metadata["committed_artifact_sha256"] = replacement_hash
            metadata["row_count"] = 1
            metadata["screened_path_count"] = 1
            meta_path.write_text(json.dumps(metadata), encoding="utf-8")
            with self.assertRaisesRegex(RuntimeError, "not committed"):
                service._load_spa_artifact(runtime, 2017, hashes)


if __name__ == "__main__":
    unittest.main()
