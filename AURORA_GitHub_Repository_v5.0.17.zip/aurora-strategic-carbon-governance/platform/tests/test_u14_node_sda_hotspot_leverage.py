"""Numerical and integration tests for the U14 node-SDA/hotspot-leverage extension."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

import cdr_producer_linkage as cdr_linkage
import hotspot_leverage as hotspot
import node_sda_engine as node_sda
from critic_dli_core import CRITERIA

ROOT = Path(__file__).resolve().parents[1]


def _make_model(year: int, a: np.ndarray, f: np.ndarray) -> SimpleNamespace:
    n = len(f)
    x = np.linspace(100.0, 180.0, n)
    z = np.asarray(a, dtype=float) * x[np.newaxis, :]
    leontief = np.linalg.inv(np.eye(n) - np.asarray(a, dtype=float))
    model = SimpleNamespace(
        year=int(year),
        Z=z,
        X=x,
        fE=np.asarray(f, dtype=float),
        L=leontief,
        node_codes=np.asarray(["ARE-cns", "ARE-ely", "ARE-nmm", "ROW-ely", "ROW-x"]),
        regions=np.asarray(["ARE", "ARE", "ARE", "ROW", "ROW"]),
        sectors=np.asarray(["cns", "ely", "nmm", "ely", "x"]),
    )
    model.footprint = lambda y, m=model: float(m.fE @ (m.L @ np.asarray(y, dtype=float)))
    return model


def _fixture():
    a0 = np.array(
        [
            [0.04, 0.06, 0.02, 0.00, 0.01],
            [0.16, 0.05, 0.08, 0.02, 0.00],
            [0.12, 0.05, 0.03, 0.02, 0.00],
            [0.02, 0.01, 0.04, 0.04, 0.02],
            [0.01, 0.01, 0.02, 0.03, 0.02],
        ],
        dtype=float,
    )
    a1 = np.array(
        [
            [0.05, 0.08, 0.03, 0.00, 0.01],
            [0.21, 0.05, 0.11, 0.03, 0.00],
            [0.14, 0.06, 0.03, 0.02, 0.00],
            [0.03, 0.01, 0.05, 0.04, 0.02],
            [0.01, 0.01, 0.02, 0.03, 0.02],
        ],
        dtype=float,
    )
    base = _make_model(2014, a0, np.array([0.0010, 0.0300, 0.0120, 0.0200, 0.0030]))
    comparison = _make_model(2017, a1, np.array([0.0012, 0.0260, 0.0140, 0.0180, 0.0035]))
    y0 = np.array([800.0, 80.0, 120.0, 40.0, 20.0])
    y1 = np.array([1100.0, 90.0, 150.0, 55.0, 25.0])
    ranking = pd.DataFrame(
        {
            "year": [2017] * 5,
            "node_code": comparison.node_codes,
            "region": comparison.regions,
            "sector": comparison.sectors,
            "DLI": [0.99, 0.95, 0.44, 0.32, 0.10],
            "dli_rank": [1, 2, 3, 4, 5],
        }
    )
    return base, y0, comparison, y1, ranking


def _joint_counterfactual_hotspot_reduction(model, demand, removed_codes, hotspot_codes):
    a = np.zeros_like(model.Z, dtype=float)
    positive = np.asarray(model.X, dtype=float) > 0
    a[:, positive] = model.Z[:, positive] / model.X[positive][np.newaxis, :]
    reduced_a = a.copy()
    reduced_y = np.asarray(demand, dtype=float).copy()
    lookup = {str(code): i for i, code in enumerate(model.node_codes)}
    for code in removed_codes:
        k = lookup[str(code)]
        reduced_a[k, :] = 0.0
        reduced_a[:, k] = 0.0
        reduced_y[k] = 0.0
    baseline_output = model.L @ np.asarray(demand, dtype=float)
    counter_output = np.linalg.inv(np.eye(len(reduced_y)) - reduced_a) @ reduced_y
    hotspot_indices = [lookup[str(code)] for code in hotspot_codes]
    baseline = float(sum(model.fE[i] * baseline_output[i] for i in hotspot_indices))
    counter = float(sum(model.fE[i] * counter_output[i] for i in hotspot_indices))
    return baseline - counter, baseline


class U14NodeSDAAndHotspotLeverageTests(unittest.TestCase):
    def setUp(self):
        self.base, self.y0, self.comparison, self.y1, self.ranking = _fixture()
        self.node_result = node_sda.compute_node_wise_sda(
            self.base, self.y0, self.comparison, self.y1, hotspot_threshold=0.80
        )
        self.linkage = cdr_linkage.compute_cdr_producer_linkage(self.comparison, self.y1)
        self.hotspot_result = hotspot.compute_hotspot_leverage(
            self.comparison,
            self.y1,
            self.linkage,
            self.node_result.frame,
            self.ranking,
            hotspot_threshold=0.80,
            high_dli_quantile=0.75,
            target_coverage=0.80,
        )

    def test_node_sda_reconciles_each_node_and_company_factor_columns(self):
        frame = self.node_result.frame
        effects = frame[[f"node_delta_{name}" for name in node_sda.FACTOR_NAMES]].sum(axis=1)
        np.testing.assert_allclose(effects, frame["node_footprint_change_tco2"], rtol=1e-10, atol=1e-10)
        for factor in node_sda.FACTOR_NAMES:
            self.assertAlmostEqual(
                float(frame[f"node_delta_{factor}"].sum()),
                float(self.node_result.company_effects[factor]),
                places=10,
            )
        self.assertLessEqual(self.node_result.maximum_row_residual, 1e-9)
        self.assertLessEqual(self.node_result.maximum_column_residual, 1e-9)

    def test_node_sda_uses_exact_four_factors_and_demand_is_only_a_family(self):
        self.assertEqual(
            tuple(node_sda.FACTOR_NAMES),
            ("intensity", "technology", "composition", "scale"),
        )
        frame = self.node_result.frame
        np.testing.assert_allclose(
            frame["node_delta_demand"],
            frame["node_delta_composition"] + frame["node_delta_scale"],
            rtol=0.0,
            atol=1e-12,
        )
        mapping = dict(zip(frame["node_dominant_driver"], frame["node_dominant_driver_family"]))
        for driver, family in mapping.items():
            if driver == "technology":
                self.assertEqual(family, "production_structure")
            elif driver in {"composition", "scale"}:
                self.assertEqual(family, "demand")

    def test_top80_set_is_the_smallest_ranked_producer_set_reaching_threshold(self):
        frame = self.node_result.frame.sort_values("comparison_hotspot_rank")
        selected = frame.loc[frame["in_comparison_top_80_hotspot_set"]]
        self.assertGreaterEqual(float(selected["comparison_share_of_company_footprint"].sum()), 0.80)
        self.assertEqual(len(selected), self.node_result.comparison_hotspot_count)
        if len(selected) > 1:
            prior = selected.iloc[:-1]
            self.assertLess(float(prior["comparison_share_of_company_footprint"].sum()), 0.80)
        self.assertAlmostEqual(
            float(selected["comparison_share_of_company_footprint"].sum()),
            self.node_result.comparison_hotspot_coverage,
            places=12,
        )

    def test_all_nodes_are_computed_while_reporting_filters_top80(self):
        self.assertEqual(self.node_result.node_count, 5)
        self.assertEqual(len(self.node_result.frame), 5)
        self.assertEqual(len(self.node_result.hotspot_frame), self.node_result.comparison_hotspot_count)
        self.assertLessEqual(len(self.node_result.hotspot_frame), 5)

    def test_455_node_diagonal_smoke_and_reconciliation(self):
        n = 455
        codes = np.asarray([f"R{i:03d}-S" for i in range(n)])
        regions = np.asarray([f"R{i:03d}" for i in range(n)])
        sectors = np.asarray(["S"] * n)
        a0 = np.diag(np.linspace(0.01, 0.05, n))
        a1 = np.diag(np.linspace(0.015, 0.055, n))
        x = np.full(n, 100.0)
        def model(year, a, f):
            m = SimpleNamespace(
                year=year,
                Z=a * x[np.newaxis, :],
                X=x,
                fE=f,
                L=np.linalg.inv(np.eye(n) - a),
                node_codes=codes,
                regions=regions,
                sectors=sectors,
            )
            return m
        m0 = model(2014, a0, np.linspace(0.001, 0.01, n))
        m1 = model(2017, a1, np.linspace(0.0012, 0.0095, n))
        y0 = np.linspace(1.0, 455.0, n)
        y1 = y0 * 1.1
        result = node_sda.compute_node_wise_sda(m0, y0, m1, y1)
        self.assertEqual(result.node_count, 455)
        self.assertGreater(result.comparison_hotspot_count, 0)
        self.assertLessEqual(result.maximum_row_residual, 1e-7)
        self.assertLessEqual(result.maximum_column_residual, 1e-7)

    def test_node_sda_artifacts_are_hash_verified_and_tamper_evident(self):
        with tempfile.TemporaryDirectory() as directory:
            hashes = {"mrio": "a" * 64, "focal_demand": "b" * 64}
            meta = node_sda.write_node_sda_artifacts(directory, self.node_result, input_hashes=hashes)
            node_sda.bind_node_sda_metadata(directory, "c" * 64, "d" * 64)
            verified = node_sda.verify_node_sda_artifacts(
                directory,
                expected_input_hashes=hashes,
                expected_source_sda_result_cid="c" * 64,
            )
            self.assertEqual(verified["node_count"], 5)
            all_path = Path(directory) / meta["artifacts"]["all_nodes"]["filename"]
            all_path.write_text(all_path.read_text() + "\n", encoding="utf-8")
            with self.assertRaises(RuntimeError):
                node_sda.verify_node_sda_artifacts(directory, expected_input_hashes=hashes)

    def test_pair_evidence_covers_every_intervention_node_and_top80_hotspot(self):
        expected = len(self.comparison.node_codes) * self.node_result.comparison_hotspot_count
        self.assertEqual(len(self.hotspot_result.pair_evidence), expected)
        self.assertEqual(
            len(self.hotspot_result.pair_evidence[["intervention_node", "hotspot_producer_node"]].drop_duplicates()),
            expected,
        )
        self.assertTrue(
            {
                "hotspot_intensity_effect_tco2",
                "hotspot_technology_effect_tco2",
                "hotspot_composition_effect_tco2",
                "hotspot_scale_effect_tco2",
                "hotspot_dominant_driver_family",
            }.issubset(self.hotspot_result.pair_evidence.columns)
        )

    def test_hsi_equals_signed_u13_linkage_sum_over_top80_hotspots(self):
        hotspot_codes = self.hotspot_result.hotspot_nodes["node_code"].astype(str).tolist()
        code_to_index = {str(c): i for i, c in enumerate(self.linkage.node_codes)}
        indices = [code_to_index[c] for c in hotspot_codes]
        expected = self.linkage.avoided_producer_footprint[:, indices].sum(axis=1)
        observed = self.hotspot_result.node_summary.set_index("intervention_node").loc[
            self.linkage.node_codes, "hotspot_structural_influence_tco2"
        ].to_numpy()
        np.testing.assert_allclose(observed, expected, rtol=1e-12, atol=1e-12)

    def test_candidate_policies_are_direct_mediated_and_hybrid_without_new_score(self):
        hotspot_codes = set(self.hotspot_result.hotspot_nodes["node_code"].astype(str))
        summary = self.hotspot_result.node_summary.set_index("intervention_node")
        direct_candidates = hotspot_codes
        mediated_candidates = set(summary.index[summary["is_high_dli_upper_quartile"] & ~summary["is_direct_hotspot_node"]])
        hybrid_candidates = direct_candidates | set(summary.index[summary["is_high_dli_upper_quartile"]])
        selected_direct = set(self.hotspot_result.portfolios["direct"].frame["intervention_node"])
        selected_mediated = set(self.hotspot_result.portfolios["governance_mediated"].frame["intervention_node"])
        selected_hybrid = set(self.hotspot_result.portfolios["hybrid"].frame["intervention_node"])
        self.assertTrue(selected_direct <= direct_candidates)
        self.assertTrue(selected_mediated <= mediated_candidates)
        self.assertTrue(selected_hybrid <= hybrid_candidates)
        self.assertEqual(tuple(CRITERIA), ("BC", "PR", "CDR", "IC"))
        source = (ROOT / "critic_dli_core.py").read_text(encoding="utf-8")
        self.assertNotIn("hotspot_structural_influence", source)
        self.assertNotIn("node_delta_intensity", source)

    def test_each_portfolio_row_matches_independent_joint_counterfactual(self):
        hotspot_codes = self.hotspot_result.hotspot_nodes["node_code"].astype(str).tolist()
        for name, portfolio in self.hotspot_result.portfolios.items():
            selected: list[str] = []
            previous = 0.0
            for _, row in portfolio.frame.iterrows():
                selected.append(str(row["intervention_node"]))
                reduction, baseline = _joint_counterfactual_hotspot_reduction(
                    self.comparison, self.y1, selected, hotspot_codes
                )
                self.assertAlmostEqual(
                    float(row["cumulative_hotspot_structural_reduction_tco2"]),
                    reduction,
                    places=9,
                    msg=name,
                )
                self.assertAlmostEqual(
                    float(row["cumulative_hotspot_structural_coverage"]),
                    reduction / baseline if baseline else 0.0,
                    places=9,
                    msg=name,
                )
                self.assertAlmostEqual(
                    float(row["marginal_hotspot_structural_reduction_tco2"]),
                    reduction - previous,
                    places=9,
                    msg=name,
                )
                previous = reduction

    def test_hotspot_artifacts_verify_even_when_a_portfolio_is_empty(self):
        ranking = self.ranking.copy()
        # Make every upper-quartile node a direct hotspot so the mediated set can be empty.
        ranking["DLI"] = np.linspace(1.0, 0.1, len(ranking))
        result = hotspot.compute_hotspot_leverage(
            self.comparison, self.y1, self.linkage, self.node_result.frame, ranking,
            high_dli_quantile=0.99,
        )
        with tempfile.TemporaryDirectory() as directory:
            hashes = {"mrio": "a" * 64, "focal_demand": "b" * 64}
            meta = hotspot.write_hotspot_leverage_artifacts(
                directory,
                result,
                input_hashes=hashes,
                critic_evidence_cid="c" * 64,
                cdr_linkage_evidence_cid="d" * 64,
                node_sda_evidence_cid="e" * 64,
            )
            hotspot.bind_hotspot_leverage_metadata(directory, "f" * 64, "1" * 64)
            verified = hotspot.verify_hotspot_leverage_artifacts(directory, expected_input_hashes=hashes)
            self.assertEqual(verified["extension_id"], "v5.0.17-U16")
            self.assertIn("governance_mediated_portfolio", meta["artifacts"])

    def test_streamlit_modules_are_small_bridges_to_root_authorities(self):
        for filename in ("node_sda_engine.py", "hotspot_leverage.py"):
            bridge = (ROOT / "streamlit_app" / filename).read_text(encoding="utf-8")
            self.assertIn("Compatibility bridge to the single authoritative U16 module", bridge)
            self.assertIn(f"parent.parent / '{filename}'", bridge)
            self.assertLess(len(bridge), 1500)

    def test_streamlit_exposes_authoritative_node_sda_and_portfolio_workspaces(self):
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        node_ui = (ROOT / "streamlit_app" / "node_sda_ui.py").read_text(encoding="utf-8")
        leverage_ui = (ROOT / "streamlit_app" / "hotspot_leverage_ui.py").read_text(encoding="utf-8")
        self.assertIn("render_node_sda_workspace", app)
        self.assertIn('"Hotspot-leverage portfolios"', app)
        self.assertIn("verify_node_sda_artifacts", node_ui)
        self.assertIn("verify_hotspot_leverage_artifacts", leverage_ui)
        self.assertIn("not predicted or guaranteed", leverage_ui)

    def test_llm_reads_only_verified_u14_evidence_and_preserves_authority(self):
        assistant = (ROOT / "strategic_assistant.py").read_text(encoding="utf-8")
        self.assertIn("verify_node_sda_artifacts", assistant)
        self.assertIn("verify_hotspot_leverage_artifacts", assistant)
        self.assertIn("Node-wise SDA", assistant)
        self.assertIn("not predicted or guaranteed abatement", assistant)
        self.assertIn("do not enter DLI", assistant)


if __name__ == "__main__":
    unittest.main(verbosity=2)
