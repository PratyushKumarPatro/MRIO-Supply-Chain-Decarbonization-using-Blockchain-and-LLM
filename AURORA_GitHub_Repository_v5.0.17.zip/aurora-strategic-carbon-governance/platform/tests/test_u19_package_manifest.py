"""Completeness and integrity checks for the current deployable-file manifest."""
from __future__ import annotations

import hashlib
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
MANIFEST = ROOT / "BUILD_MANIFEST_SHA256.txt"
EXCLUDED_DIRECTORY_NAMES = {
    ".git",
    ".mypy_cache",
    ".pytest_cache",
    ".venv",
    "__pycache__",
    "content_store",
    "node_modules",
    "runtime",
}
EXCLUDED_FILE_NAMES = {
    "BUILD_MANIFEST_SHA256.txt",
    "deployment.json",
    "Focal_Company_Demand_Converted.xlsx",
    "input_mrio_completed.xlsx",
}


def _deployable_files() -> set[str]:
    files: set[str] = set()
    for path in ROOT.rglob("*"):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        if any(part in EXCLUDED_DIRECTORY_NAMES for part in relative.parts):
            continue
        if relative.name in EXCLUDED_FILE_NAMES or relative.suffix == ".pyc":
            continue
        files.add(relative.as_posix())
    return files


def _manifest_entries() -> dict[str, str]:
    entries: dict[str, str] = {}
    for line_number, raw in enumerate(
        MANIFEST.read_text(encoding="utf-8").splitlines(), start=1
    ):
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        digest, relative = line.split(maxsplit=1)
        relative = relative.strip().replace("\\", "/")
        if relative in entries:
            raise AssertionError(
                f"Duplicate manifest path on line {line_number}: {relative}"
            )
        entries[relative] = digest.lower()
    return entries


class CurrentPackageManifestTests(unittest.TestCase):
    def test_manifest_is_complete_and_every_hash_matches(self):
        self.assertTrue(MANIFEST.is_file())
        entries = _manifest_entries()
        self.assertEqual(set(entries), _deployable_files())
        for relative, expected in entries.items():
            body = (ROOT / relative).read_bytes()
            self.assertEqual(hashlib.sha256(body).hexdigest(), expected, relative)


if __name__ == "__main__":
    unittest.main(verbosity=2)
