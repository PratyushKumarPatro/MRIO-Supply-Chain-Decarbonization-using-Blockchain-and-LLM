"""Focused tests for the safe post-AURORA intervention recovery path."""
from __future__ import annotations

import sys
import threading
import types
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest import mock

try:  # The packaged environment installs NetworkX; the lean build runner may not.
    import networkx  # noqa: F401
except ModuleNotFoundError:  # pragma: no cover - build-environment compatibility
    sys.modules["networkx"] = types.ModuleType("networkx")

import data_orchestrator as orchestrator_module
import intervention_governance as governance
from data_orchestrator import DataOrchestrator, OrchestratorResponse
from orchestrator_client import OrchestratorClient
from orchestrator_server import OrchestratorApplication


ROOT = Path(__file__).resolve().parents[1]


def _response(operation: str = "intervention_governance_evidence_materialization"):
    return OrchestratorResponse(
        operation=operation,
        content_hash="e" * 64,
        payload={},
        auxiliary={},
        request_context={},
        generated_at_utc="2026-09-05T00:00:00+00:00",
    )


class U19InterventionMaterializationRecoveryTests(unittest.TestCase):
    def setUp(self):
        self.hashes = {"mrio": "1" * 64, "focal_demand": "2" * 64}
        self.network_cid = "a" * 64
        self.aurora_cid = "b" * 64
        self.metadata = {
            "source_network_result_cid": self.network_cid,
            "source_aurora_result_cid": self.aurora_cid,
            "intervention_governance_evidence_cid": "c" * 64,
            "candidate_pair_count": 17,
            "governance_ready_option_count": 3,
        }
        self.orchestrator = DataOrchestrator.__new__(DataOrchestrator)
        self.orchestrator._intervention_governance_lock = threading.Lock()
        self.orchestrator.deployment = {
            "active_input_hashes": self.hashes,
            "active_results": {
                "network": {"2017": {"content_hash": self.network_cid}},
                "aurora": {"2017": {"content_hash": self.aurora_cid}},
            },
        }

    @contextmanager
    def _patched_prerequisites(self):
        with (
            mock.patch.object(orchestrator_module, "active_input_hashes", return_value=self.hashes),
            mock.patch.object(
                orchestrator_module,
                "_verified_active_network_2017_payload",
                return_value={"year": 2017},
            ),
            mock.patch.object(
                orchestrator_module,
                "_verified_active_aurora_cid",
                return_value=self.aurora_cid,
            ),
        ):
            yield

    def test_retry_is_idempotent_when_exact_artifacts_already_verify(self):
        response = _response()
        with (
            self._patched_prerequisites(),
            mock.patch.object(
                governance,
                "verify_intervention_governance_artifacts",
                return_value=self.metadata,
            ),
            mock.patch.object(
                self.orchestrator,
                "_materialize_post_aurora_intervention_artifacts",
            ) as materialize,
            mock.patch.object(self.orchestrator, "_response", return_value=response) as build_response,
            mock.patch.object(orchestrator_module, "record_active_result"),
        ):
            observed = self.orchestrator.materialize_post_aurora_intervention_governance(
                self.network_cid,
                self.aurora_cid,
            )
        self.assertIs(observed, response)
        materialize.assert_not_called()
        payload = build_response.call_args.args[1]
        self.assertEqual(payload["status"], "already-materialized")
        self.assertEqual(payload["intervention_governance_evidence_cid"], "c" * 64)
        self.assertFalse(payload["analytical_recomputation"])

    def test_retry_after_missing_artifacts_materializes_and_reverifies_exact_binding(self):
        response = _response()
        with (
            self._patched_prerequisites(),
            mock.patch.object(
                governance,
                "verify_intervention_governance_artifacts",
                side_effect=[FileNotFoundError("missing"), self.metadata],
            ) as verify,
            mock.patch.object(
                self.orchestrator,
                "_materialize_post_aurora_intervention_artifacts",
                return_value=self.metadata,
            ) as materialize,
            mock.patch.object(self.orchestrator, "_response", return_value=response) as build_response,
            mock.patch.object(orchestrator_module, "record_active_result"),
        ):
            self.orchestrator.materialize_post_aurora_intervention_governance(
                self.network_cid,
                self.aurora_cid,
            )
        materialize.assert_called_once_with(
            self.network_cid,
            self.aurora_cid,
            self.hashes,
        )
        self.assertEqual(verify.call_count, 2)
        for call in verify.call_args_list:
            self.assertEqual(
                call.kwargs["expected_source_network_result_cid"],
                self.network_cid,
            )
            self.assertEqual(
                call.kwargs["expected_source_aurora_result_cid"],
                self.aurora_cid,
            )
        payload = build_response.call_args.args[1]
        self.assertEqual(payload["status"], "materialized-on-demand")
        self.assertEqual(payload["candidate_pair_count"], 17)
        self.assertEqual(payload["governance_ready_option_count"], 3)

    def test_invalid_or_unfulfilled_bindings_never_invoke_materializer(self):
        cases = (
            ("indexed AURORA mismatch", {"active_aurora": "d" * 64}),
            ("unfulfilled network", {"fulfilled_network": "d" * 64}),
            ("unfulfilled AURORA", {"fulfilled_aurora": "d" * 64}),
            ("stale lifecycle inputs", {"deployment_hashes": {"mrio": "9" * 64}}),
        )
        for label, change in cases:
            with self.subTest(label=label):
                self.orchestrator.deployment["active_input_hashes"] = change.get(
                    "deployment_hashes", self.hashes
                )
                self.orchestrator.deployment["active_results"]["network"]["2017"][
                    "content_hash"
                ] = change.get("fulfilled_network", self.network_cid)
                self.orchestrator.deployment["active_results"]["aurora"]["2017"][
                    "content_hash"
                ] = change.get("fulfilled_aurora", self.aurora_cid)
                with (
                    mock.patch.object(
                        orchestrator_module,
                        "active_input_hashes",
                        return_value=self.hashes,
                    ),
                    mock.patch.object(
                        orchestrator_module,
                        "_verified_active_network_2017_payload",
                        return_value={"year": 2017},
                    ),
                    mock.patch.object(
                        orchestrator_module,
                        "_verified_active_aurora_cid",
                        return_value=change.get("active_aurora", self.aurora_cid),
                    ),
                    mock.patch.object(
                        self.orchestrator,
                        "_materialize_post_aurora_intervention_artifacts",
                    ) as materialize,
                ):
                    with self.assertRaises(RuntimeError):
                        self.orchestrator.materialize_post_aurora_intervention_governance(
                            self.network_cid,
                            self.aurora_cid,
                        )
                materialize.assert_not_called()

    def test_explicit_retry_failure_surfaces_without_mutating_aurora_state(self):
        deployment_before = repr(self.orchestrator.deployment["active_results"]["aurora"])
        with (
            self._patched_prerequisites(),
            mock.patch.object(
                governance,
                "verify_intervention_governance_artifacts",
                side_effect=FileNotFoundError("missing"),
            ),
            mock.patch.object(
                self.orchestrator,
                "_materialize_post_aurora_intervention_artifacts",
                side_effect=OSError("simulated workbook failure"),
            ),
            mock.patch.object(orchestrator_module, "record_active_result") as record,
        ):
            with self.assertRaisesRegex(OSError, "simulated workbook failure"):
                self.orchestrator.materialize_post_aurora_intervention_governance(
                    self.network_cid,
                    self.aurora_cid,
                )
        self.assertEqual(
            repr(self.orchestrator.deployment["active_results"]["aurora"]),
            deployment_before,
        )
        record.assert_not_called()

    def test_server_dispatch_and_client_use_exact_recovery_operation(self):
        response = _response()
        application = OrchestratorApplication.__new__(OrchestratorApplication)
        application.orchestrator = mock.Mock()
        application.orchestrator.materialize_post_aurora_intervention_governance.return_value = response
        application._refresh_deployment = mock.Mock()
        context = {"source": "test"}
        observed = application.dispatch(
            "/v1/governance/intervention-materialize",
            {
                "network_result_hash": self.network_cid,
                "aurora_result_hash": self.aurora_cid,
                "request_context": context,
            },
        )
        self.assertTrue(observed["ok"])
        application.orchestrator.materialize_post_aurora_intervention_governance.assert_called_once_with(
            self.network_cid,
            self.aurora_cid,
            request_context=context,
        )

        client = OrchestratorClient(base_url="http://example.invalid")
        with mock.patch.object(client, "post", return_value={"payload": {}}) as post:
            client.materialize_intervention_governance(
                self.network_cid.upper(),
                self.aurora_cid.upper(),
                request_context=context,
            )
            post.assert_called_once_with(
                "/v1/governance/intervention-materialize",
                {
                    "network_result_hash": self.network_cid,
                    "aurora_result_hash": self.aurora_cid,
                    "request_context": context,
                },
            )
        with mock.patch.object(client, "post") as post:
            with self.assertRaises(ValueError):
                client.materialize_intervention_governance("bad", self.aurora_cid)
            with self.assertRaises(ValueError):
                client.materialize_intervention_governance(self.network_cid, "bad")
            post.assert_not_called()

    def test_blockchain_ui_exposes_explicit_compute_only_with_both_fulfilled_cids(self):
        source = (ROOT / "streamlit_app" / "intervention_control_ui.py").read_text(
            encoding="utf-8"
        )
        sidebar = (ROOT / "streamlit_app" / "intervention_governance_ui.py").read_text(
            encoding="utf-8"
        )
        self.assertIn("if not network_cid or not aurora_cid:", source)
        self.assertIn(
            "Compute intervention evidence and candidate mappings",
            source,
        )
        self.assertIn("materialize_intervention_governance(", source)
        self.assertIn('"control_plane": "blockchain_page"', source)
        self.assertIn("Read-only results workspace", sidebar)
        self.assertNotIn("materialize_intervention_governance(", sidebar)
        self.assertNotIn("OrchestratorClient", sidebar)


if __name__ == "__main__":
    unittest.main(verbosity=2)
