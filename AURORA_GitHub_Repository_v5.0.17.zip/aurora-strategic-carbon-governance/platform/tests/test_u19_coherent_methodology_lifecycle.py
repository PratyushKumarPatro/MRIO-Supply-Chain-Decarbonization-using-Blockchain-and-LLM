"""U19 regressions for the coherent governed methodology lifecycle."""
from __future__ import annotations

import ast
import hashlib
import json
import re
import unittest
from pathlib import Path

import aurora_lifecycle_policy as policy
import release_identity


ROOT = Path(__file__).resolve().parents[1]
SOLIDITY_SOURCE = ROOT / "contracts" / "StrategicCarbonIntelligenceSystem.sol"
HISTORICAL_CONTRACT_BASELINE = (
    ROOT / "CONTRACT_LOGIC_COMPATIBILITY_BASELINE_v5_0_16.json"
)
U19_CONTRACT_DELTA = ROOT / "U19_CONTRACT_LOGIC_DELTA_SHA256.json"


def _strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    return re.sub(r"//.*", "", text)


def _canonical(text: str) -> str:
    return " ".join(text.split())


def _contract_body(source: str, name: str) -> str:
    match = re.search(
        rf"\b(?:contract|abstract\s+contract)\s+{re.escape(name)}\b[^{{]*{{",
        source,
    )
    if match is None:
        raise AssertionError(f"Contract {name} was not found")
    start = match.end() - 1
    depth = 0
    for index in range(start, len(source)):
        if source[index] == "{":
            depth += 1
        elif source[index] == "}":
            depth -= 1
            if depth == 0:
                return source[start + 1 : index]
    raise AssertionError(f"Contract {name} is not closed")


def _solidity_function(body: str, name: str) -> str:
    clean = _strip_comments(body)
    match = re.search(rf"\bfunction\s+{re.escape(name)}\s*\(", clean)
    if match is None:
        raise AssertionError(f"Function {name} was not found")
    cursor = match.end()
    parentheses = 1
    while cursor < len(clean) and parentheses:
        if clean[cursor] == "(":
            parentheses += 1
        elif clean[cursor] == ")":
            parentheses -= 1
        cursor += 1
    while cursor < len(clean) and clean[cursor] not in "{;":
        cursor += 1
    if cursor >= len(clean) or clean[cursor] != "{":
        raise AssertionError(f"Function {name} has no implementation body")
    depth = 0
    for end in range(cursor, len(clean)):
        if clean[end] == "{":
            depth += 1
        elif clean[end] == "}":
            depth -= 1
            if depth == 0:
                return clean[match.start() : end + 1]
    raise AssertionError(f"Function {name} is not closed")


def _function_hashes(body: str) -> dict[str, str]:
    """Use the historical compatibility test's normalization and hashing."""

    import hashlib

    clean = _strip_comments(body)
    result: dict[str, str] = {}
    position = 0
    pattern = re.compile(r"\bfunction\s+(\w+)\s*\(")
    while True:
        match = pattern.search(clean, position)
        if match is None:
            break
        cursor = match.end()
        parentheses = 1
        while cursor < len(clean) and parentheses:
            if clean[cursor] == "(":
                parentheses += 1
            elif clean[cursor] == ")":
                parentheses -= 1
            cursor += 1
        while cursor < len(clean) and clean[cursor] not in "{;":
            cursor += 1
        if cursor >= len(clean):
            raise AssertionError(f"Malformed function {match.group(1)}")
        if clean[cursor] == ";":
            end = cursor + 1
        else:
            depth = 0
            end = None
            for index in range(cursor, len(clean)):
                if clean[index] == "{":
                    depth += 1
                elif clean[index] == "}":
                    depth -= 1
                    if depth == 0:
                        end = index + 1
                        break
            if end is None:
                raise AssertionError(f"Function {match.group(1)} is not closed")
        snippet = _canonical(clean[match.start() : end])
        logic = re.sub(r'"(?:\\.|[^"\\])*"', '"<TEXT>"', snippet)
        header = logic.split("{", 1)[0].rstrip().rstrip(";").strip()
        result[header] = hashlib.sha256(logic.encode("utf-8")).hexdigest()
        position = end
    return result


def _python_function_source(path: Path, name: str) -> str:
    source = path.read_text(encoding="utf-8")
    tree = ast.parse(source)
    for node in tree.body:
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == name:
            segment = ast.get_source_segment(source, node)
            if segment is None:
                break
            return segment
    raise AssertionError(f"Python function {name} was not found in {path.name}")


def _eligibility(status: str) -> dict[str, str]:
    return {
        "mechanism_mapping_status": policy.MAPPED_MECHANISM_STATUS,
        "linkage_gate_status": policy.PASSED_LINKAGE_STATUS,
        "assessment_status": status,
    }


class U19CoherentMethodologyLifecycleTests(unittest.TestCase):
    def test_release_identity_exposes_u23_without_relabelling_preserved_methods(self):
        identity = release_identity.RELEASE_IDENTITY
        self.assertEqual(
            identity["release_patch"],
            "u23-evidence-bound-abatement-decision",
        )
        self.assertIn(
            "_U23_EVIDENCE_BOUND_ABATEMENT_DECISION_",
            identity["package_name"],
        )
        self.assertEqual(
            identity["blockchain_control_plane_extension_id"], "v5.0.17-U22"
        )
        self.assertEqual(identity["abatement_decision_gate_extension_id"], "v5.0.17-U23")
        self.assertEqual(identity["abatement_scenario_extension_id"], "v5.0.17-U21")
        self.assertEqual(identity["performance_monitoring_extension_id"], "v5.0.17-U21")
        self.assertEqual(identity["governance_interface_extension_id"], "v5.0.17-U20")
        self.assertEqual(identity["aurora_lifecycle_extension_id"], "v5.0.17-U18")
        self.assertEqual(identity["methodology_lifecycle_extension_id"], "v5.0.17-U19")
        self.assertEqual(
            policy.AURORA_LIFECYCLE_EXTENSION_ID,
            identity["aurora_lifecycle_extension_id"],
        )
        self.assertEqual(
            policy.METHODOLOGY_LIFECYCLE_EXTENSION_ID,
            identity["methodology_lifecycle_extension_id"],
        )
        self.assertEqual(identity["spa_reporting_extension_id"], "v5.0.17-U17")
        self.assertEqual(identity["integrated_methodology_extension_id"], "v5.0.17-U17")
        self.assertEqual(identity["intervention_governance_extension_id"], "v5.0.17-U16")

        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8-sig")
        self.assertIn('RELEASE_IDENTITY["aurora_lifecycle_extension_id"]', server)
        self.assertIn(
            'Get-RqVersionValue -Key "aurora_lifecycle_extension_id"', launcher
        )
        self.assertIn(
            "$candidate.aurora_lifecycle_extension -eq $ExpectedAuroraLifecycle",
            launcher,
        )
        self.assertIn(
            "$candidate.methodology_lifecycle_extension -eq $ExpectedMethodologyLifecycle",
            launcher,
        )
        self.assertIn(
            "$candidate.governance_interface_extension -eq $ExpectedGovernanceInterface",
            launcher,
        )
        self.assertIn(
            'RELEASE_IDENTITY["blockchain_control_plane_extension_id"]', server
        )
        self.assertIn(
            'Get-RqVersionValue -Key "blockchain_control_plane_extension_id"',
            launcher,
        )
        self.assertIn(
            "$candidate.blockchain_control_plane_extension -eq $ExpectedBlockchainControlPlane",
            launcher,
        )

    def test_aurora_readiness_is_only_the_post_temporal_dli_gate(self):
        truth_table = [
            (False, False, False),
            (False, True, False),
            (True, False, False),
            (True, True, True),
        ]
        for governance_deployed, temporal_dli_complete, expected in truth_table:
            with self.subTest(
                governance_deployed=governance_deployed,
                temporal_dli_complete=temporal_dli_complete,
            ):
                self.assertEqual(
                    policy.aurora_request_ready(
                        governance_deployed=governance_deployed,
                        temporal_dli_complete=temporal_dli_complete,
                    ),
                    expected,
                )

    def test_intervention_workspace_follows_aurora(self):
        self.assertFalse(policy.intervention_workspace_ready(aurora_complete=False))
        self.assertTrue(policy.intervention_workspace_ready(aurora_complete=True))

    def test_query_management_requires_resolved_intervention_governance(self):
        cases = [
            (False, False, False, False),
            (False, True, True, False),
            (True, False, True, False),
            (True, True, False, False),
            (True, True, True, True),
        ]
        for temporal, aurora, resolved, expected in cases:
            with self.subTest(temporal=temporal, aurora=aurora, resolved=resolved):
                self.assertEqual(
                    policy.query_management_ready(
                        temporal_dli_complete=temporal,
                        aurora_complete=aurora,
                        intervention_governance_resolved=resolved,
                    ),
                    expected,
                )

    def test_unresolved_intervention_status_blocks_final_support(self):
        unresolved = policy.evaluate_intervention_governance(
            [_eligibility("Verified actionable")],
            governance_ready_option_count=1,
            selected_intervention_count=1,
            all_selected_interventions_decided=False,
            evidence_verified=True,
        )
        self.assertFalse(unresolved["intervention_governance_resolved"])
        self.assertFalse(
            policy.query_management_ready(
                temporal_dli_complete=True,
                aurora_complete=True,
                intervention_governance_resolved=unresolved["intervention_governance_resolved"],
            )
        )

    def test_solidity_matches_the_reviewed_u19_logic_delta(self):
        source_bytes = (
            ROOT / "assurance_history" / "release_documents" / "U19_StrategicCarbonIntelligenceSystem.sol"
        ).read_bytes()
        source = source_bytes.decode("utf-8")
        baseline = json.loads(HISTORICAL_CONTRACT_BASELINE.read_text(encoding="utf-8"))
        delta = json.loads(U19_CONTRACT_DELTA.read_text(encoding="utf-8"))
        self.assertEqual(delta["changed_contract"], "HotspotsManagementAndGovernance")
        self.assertEqual(
            hashlib.sha256(source_bytes).hexdigest(),
            delta["u19_solidity_source_sha256"],
        )
        compiler_source = hashlib.sha256()
        compiler_source.update(SOLIDITY_SOURCE.name.encode("utf-8"))
        compiler_source.update(b"\0")
        compiler_source.update(source_bytes)
        compiler_source.update(b"\0")
        self.assertEqual(
            compiler_source.hexdigest(), delta["u19_compiler_source_hash"]
        )
        actual_by_contract = {
            name: _function_hashes(_contract_body(source, name))
            for name in baseline["contracts"]
        }
        changed: dict[str, dict[str, tuple[str | None, str | None]]] = {}
        for contract_name, contract_baseline in baseline["contracts"].items():
            expected = contract_baseline["function_hashes"]
            actual = actual_by_contract[contract_name]
            differences = {
                header: (expected.get(header), actual.get(header))
                for header in set(expected) | set(actual)
                if expected.get(header) != actual.get(header)
            }
            if differences:
                changed[contract_name] = differences

        self.assertEqual(set(changed), {"HotspotsManagementAndGovernance"})
        expected_deltas = delta["changed_functions"]
        expected_additions = delta["added_functions"]
        self.assertEqual(
            set(changed["HotspotsManagementAndGovernance"]),
            set(expected_deltas) | set(expected_additions),
        )
        for header, hashes in expected_deltas.items():
            old_hash, new_hash = changed["HotspotsManagementAndGovernance"][header]
            self.assertEqual(old_hash, hashes["baseline_logic_sha256"])
            self.assertEqual(new_hash, hashes["u19_logic_sha256"])
        for header, hashes in expected_additions.items():
            old_hash, new_hash = changed["HotspotsManagementAndGovernance"][header]
            self.assertIsNone(old_hash)
            self.assertEqual(new_hash, hashes["u19_logic_sha256"])
        self.assertEqual(delta["allowed_logic_delta_count"], len(expected_deltas))
        self.assertEqual(
            delta["allowed_added_function_count"], len(expected_additions)
        )

    def test_solidity_aurora_requires_network_evidence_not_intervention_state(self):
        body = _contract_body(
            SOLIDITY_SOURCE.read_text(encoding="utf-8"),
            "HotspotsManagementAndGovernance",
        )
        function = _solidity_function(
            body, "performRegionalSourcingOpportunityAnalysis"
        )
        for retained_guard in (
            "networkRequest.requester != address(0)",
            "networkRequest.status == RequestStatus.Fulfilled",
            "year == 2017",
            "networkRequest.year == year",
            "bytes(networkRequest.resultHash).length > 0",
            "temporalBaselineForDecisionRequestPlusOne[networkRequestId]",
            "baselineRequest.status == RequestStatus.Fulfilled",
            "RequestStatus.Failed",
        ):
            self.assertIn(retained_guard, function)
        for removed_dependency in (
            "_portfolioStatus",
            "selected > 0",
            "allDecided",
            "select at least one intervention before AURORA",
            "selected interventions require governance decisions",
        ):
            self.assertNotIn(removed_dependency, function)

    def test_solidity_requires_fulfilled_aurora_before_intervention_selection(self):
        body = _contract_body(
            SOLIDITY_SOURCE.read_text(encoding="utf-8"),
            "HotspotsManagementAndGovernance",
        )
        function = _solidity_function(body, "requestInterventionProposal")
        self.assertIn("sourcingForNetworkRequestPlusOne", function)
        self.assertIn("complete AURORA before intervention governance", function)
        self.assertIn("AURORA request is not fulfilled", function)
        self.assertIn("keccak256(abi.encode(nodeCode, optionCID))", function)
        for retained_guard in (
            "source.status == RequestStatus.Fulfilled",
            "source.year == 2017",
            "bytes(source.resultHash).length > 0",
            "!interventionOptionRequestedForNetworkRequest",
        ):
            self.assertIn(retained_guard, function)

    def test_solidity_enforces_temporal_network_order_and_reuses_node_hotspots(self):
        body = _contract_body(
            SOLIDITY_SOURCE.read_text(encoding="utf-8"),
            "HotspotsManagementAndGovernance",
        )
        network = _solidity_function(body, "performNetworkAnalysis")
        register = _solidity_function(body, "_registerSelectedHotspot")
        create = _solidity_function(body, "_createSelectedIntervention")
        self.assertIn("year == 2014 || year == 2017", network)
        self.assertIn("complete 2014 Network/DLI before 2017", network)
        self.assertIn("temporalBaselineForDecisionRequestPlusOne", network)
        self.assertIn("existingPlusOne", register)
        self.assertIn("return existingPlusOne - 1", register)
        self.assertIn("interventionForHotspotPlusOne[hotspotId] == 0", create)

    def test_lifecycle_binds_review_evidence_to_active_2017_network_and_inputs(self):
        lifecycle = (ROOT / "dapp_lifecycle.py").read_text(encoding="utf-8")
        self.assertIn("verify_intervention_governance_artifacts", lifecycle)
        self.assertIn("expected_input_hashes=expected_hashes", lifecycle)
        self.assertIn("network_cid = str(network_2017.get(\"content_hash\", \"\"))", lifecycle)
        self.assertIn("expected_source_network_result_cid=network_cid", lifecycle)
        self.assertIn("expected_source_aurora_result_cid=aurora_cid", lifecycle)
        self.assertIn(
            'active_aurora_2017 = active_results["aurora"].get("2017")',
            lifecycle,
        )
        self.assertIn(
            'active_network_2017 = active_results["network"].get("2017")',
            lifecycle,
        )
        self.assertIn("evidence_verified=False", lifecycle)

    def test_sidebar_exposes_intervention_results_only_after_verified_evidence(self):
        function = _python_function_source(
            ROOT / "dapp_lifecycle.py", "available_sidebar_sections"
        )
        self.assertIn('if lifecycle.get("aurora_complete"):', function)
        self.assertIn(
            'if lifecycle.get("intervention_governance_evidence_verified"):',
            function,
        )
        self.assertIn('sections.append("Intervention Governance")', function)
        self.assertNotIn('if lifecycle.get("intervention_workspace_ready"):', function)

    def test_streamlit_navigation_fails_closed_when_live_refresh_is_unavailable(self):
        source = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        discover = source.split("def _discover_progressive_state():", 1)[1].split(
            "UI_DEPLOYMENT_PATH", 1
        )[0]
        self.assertIn("if not w3.is_connected():", discover)
        self.assertIn("deployment = refresh_lifecycle(deployment_path)", discover)
        self.assertIn("return deployment_path, {}, searched", discover)
        self.assertNotIn("if w3.is_connected() and", discover)

    def test_ui_orders_aurora_then_intervention_and_gates_final_support(self):
        source = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(
            encoding="utf-8"
        )
        self.assertEqual(
            source.count("performRegionalSourcingOpportunityAnalysis("), 1
        )
        self.assertEqual(source.count("requestInterventionProposal("), 1)
        self.assertIn("Network/DLI, then AURORA, then intervention governance", source)
        self.assertIn(
            "does not depend on selecting, verifying, approving or rejecting an intervention",
            source,
        )
        self.assertLess(
            source.index("### Stage 11 — AURORA"),
            source.index("### Stage 12 — Intervention"),
        )
        self.assertIn("render_intervention_control_plane(deployment, ROOT_DIR)", source)
        self.assertLess(
            source.index("render_intervention_control_plane(deployment, ROOT_DIR)"),
            source.index("### Governance-ready 2017 intervention options"),
        )
        self.assertLess(
            source.index("requestInterventionProposal("),
            source.index("### Selected on-chain intervention proposals"),
        )
        self.assertIn("final decision support remains locked", source)
        self.assertIn("resolve Stage 12", source)
        self.assertNotIn("do not block QueryManagement", source)
        for stale_text in (
            "parallel branch",
            "Select at least one generated option before AURORA can be requested",
            "AURORA unlocks after at least one deterministic intervention",
            "cannot add interventions after AURORA is requested",
            "intervention-selection portfolio is closed because AURORA",
            "Locked until Network/DLI, intervention decision and AURORA are complete",
        ):
            self.assertNotIn(stale_text, source)

    def test_query_deployment_requires_resolved_intervention_governance(self):
        function = _python_function_source(
            ROOT / "dapp_lifecycle.py", "deploy_functional_contract"
        )
        self.assertIn("intervention_governance_resolved", function)
        self.assertIn(
            "resolved intervention governance decision or verified no-option outcome",
            function,
        )
        self.assertIn("aurora_2017_complete", function)
        self.assertIn("temporal_dli_complete", function)

    def test_query_submission_pauses_when_current_evidence_is_invalidated(self):
        source = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        self.assertIn("elif not query_management_prerequisites_complete:", source)
        self.assertIn("Query submission is paused", source)
        sidebar = _python_function_source(ROOT / "dapp_lifecycle.py", "available_sidebar_sections")
        self.assertIn('lifecycle.get("query_management_ready")', sidebar)

    def test_aurora_orchestrator_and_llm_use_verified_governed_evidence(self):
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        assistant = (ROOT / "strategic_assistant.py").read_text(encoding="utf-8")
        self.assertIn("Stored content failed its SHA-256 CID check", orchestrator)
        self.assertIn("AURORA must use the active 2017 Network/DLI result", orchestrator)
        self.assertIn("authoritative pooled Pearson-CRITIC result", orchestrator)
        self.assertIn("ranking failed its SHA-256 check", orchestrator)
        tool = _python_function_source(ROOT / "strategic_assistant.py", "tool_sourcing_opportunity_analysis")
        self.assertIn("fulfilled, hash-verified AURORA result", tool)
        self.assertIn("governed_result_cid", tool)
        self.assertNotIn("aurora.analyse", tool)


if __name__ == "__main__":
    unittest.main(verbosity=2)
