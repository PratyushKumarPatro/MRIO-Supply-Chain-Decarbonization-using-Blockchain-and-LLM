"""Regression coverage for the Blockchain-page intervention control plane."""
from __future__ import annotations

import ast
import unittest
from pathlib import Path

import release_identity


ROOT = Path(__file__).resolve().parents[1]


class BlockchainControlPlaneTests(unittest.TestCase):
    def test_release_identifies_the_control_plane_extension(self):
        identity = release_identity.RELEASE_IDENTITY
        self.assertEqual(
            identity["architecture_version"],
            "5.0.17-u23-evidence-bound-abatement-decision",
        )
        self.assertEqual(
            identity["release_patch"],
            "u23-evidence-bound-abatement-decision",
        )
        self.assertEqual(identity["blockchain_control_plane_extension_id"], "v5.0.17-U22")
        self.assertEqual(
            identity["stage_12_action_authority"],
            "blockchain-and-llm-based-system-page",
        )
        self.assertEqual(
            identity["intervention_governance_sidebar_role"],
            "read-only-results-provenance-and-downloads",
        )

    def test_blockchain_page_owns_the_complete_intervention_sequence(self):
        page = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        controls = (ROOT / "streamlit_app" / "intervention_control_ui.py").read_text(
            encoding="utf-8"
        )
        self.assertIn("from intervention_control_ui import render_intervention_control_plane", page)
        ordered_tokens = (
            '"### Stage 12 — Intervention evidence and formal governance"',
            "render_intervention_control_plane(deployment, ROOT_DIR)",
            '"### Governance-ready 2017 intervention options"',
            "requestInterventionProposal(",
            '"### Selected on-chain intervention proposals"',
            "decideIntervention(",
            '"##### Record post-deployment observed performance"',
            "recordInterventionPerformance(",
        )
        positions = [page.index(token) for token in ordered_tokens]
        self.assertEqual(positions, sorted(positions))

        for token in (
            '"Compute intervention evidence and candidate mappings"',
            '"Producer hotspot"',
            '"Linked leverage/intervention node"',
            '"Inspect driver evidence and deterministic intervention mapping"',
            '"##### AURORA regional-opportunity context"',
            '"Record evidence and generate governance-ready options"',
        ):
            self.assertIn(token, controls)

    def test_sidebar_is_a_strictly_read_only_results_workspace(self):
        sidebar = (ROOT / "streamlit_app" / "intervention_governance_ui.py").read_text(
            encoding="utf-8"
        )
        self.assertIn("Read-only results workspace", sidebar)
        self.assertNotIn("OrchestratorClient", sidebar)
        self.assertNotIn("st.form(", sidebar)
        self.assertNotIn("st.form_submit_button(", sidebar)
        self.assertNotIn("st.button(", sidebar)
        self.assertNotIn("materialize_intervention_governance", sidebar)
        self.assertNotIn("record_intervention_actionability", sidebar)
        self.assertNotIn("record_intervention_performance", sidebar)
        self.assertIn("st.download_button(", sidebar)

    def test_controls_fail_closed_and_do_not_invent_feasibility_or_abatement(self):
        controls = (ROOT / "streamlit_app" / "intervention_control_ui.py").read_text(
            encoding="utf-8"
        )
        self.assertIn('text = _clean_text(value) or "Not assessed"', controls)
        self.assertIn('options.index("Not assessed")', controls)
        self.assertIn(
            '"Include a conservative/expected/ambitious reduction scenario"', controls
        )
        self.assertIn(
            '{field: None for field in governance_method.SCENARIO_NUMERIC_FIELDS}',
            controls,
        )
        self.assertIn("deterministically maps", controls)
        self.assertIn("does not manually override", controls)
        self.assertIn("not an automatic supplier change", controls)

    def test_aurora_completion_does_not_silently_run_stage_12(self):
        source = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        compute = source.split("def compute_sourcing_opportunities(", 1)[1].split(
            "def process_query(", 1
        )[0]
        explicit = source.split(
            "def materialize_post_aurora_intervention_governance(", 1
        )[1].split("def record_intervention_actionability(", 1)[0]
        self.assertNotIn("_materialize_post_aurora_intervention_artifacts(", compute)
        self.assertIn("pending-user-initiated-stage-12-computation", compute)
        self.assertIn("_materialize_post_aurora_intervention_artifacts(", explicit)
        self.assertIn('status = "materialized-on-demand"', explicit)

    def test_query_deployment_and_execution_require_stage_12_resolution(self):
        lifecycle = (ROOT / "dapp_lifecycle.py").read_text(encoding="utf-8")
        deployment_gate = lifecycle.split("def deploy_functional_contract(", 1)[1].split(
            "def available_sidebar_sections(", 1
        )[0]
        self.assertIn('"intervention_governance_resolved"', deployment_gate)
        self.assertIn(
            'lifecycle.get("intervention_governance_evidence_verified")', lifecycle
        )
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        query_gate = orchestrator.split("def _require_current_query_methodology_gate(", 1)[1].split(
            "def materialize_post_aurora_intervention_governance(", 1
        )[0]
        self.assertIn('lifecycle.get("intervention_governance_resolved")', query_gate)

    def test_assessments_freeze_and_monitoring_is_exactly_bound(self):
        source = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        assessment = source.split("def record_intervention_actionability(", 1)[1].split(
            "def prepare_intervention_proposal(", 1
        )[0]
        monitoring = source.split("def record_intervention_performance_evidence(", 1)[1].split(
            "def compute_sourcing_opportunities(", 1
        )[0]
        self.assertIn("assessment register is frozen", assessment)
        self.assertIn('int(item.get("status", -1)) in {0, 1}', assessment)
        self.assertIn('item.get("intervention_id", -1)', monitoring)
        self.assertIn('item.get("option_cid", "")', monitoring)
        self.assertIn('item.get("network_result_hash", "")', monitoring)
        self.assertIn("only for an approved intervention", monitoring)
        self.assertIn("datetime.fromisoformat", monitoring)
        self.assertIn("monitoring_period_start must not be later", monitoring)

    def test_new_ui_has_no_visible_internal_release_codes(self):
        source_path = ROOT / "streamlit_app" / "intervention_control_ui.py"
        tree = ast.parse(source_path.read_text(encoding="utf-8"), filename=str(source_path))
        rendered = {
            "button", "caption", "error", "expander", "info", "markdown",
            "metric", "selectbox", "success", "warning", "write",
        }
        for call in (node for node in ast.walk(tree) if isinstance(node, ast.Call)):
            if not isinstance(call.func, ast.Attribute) or call.func.attr not in rendered:
                continue
            text = " ".join(
                node.value
                for node in ast.walk(call)
                if isinstance(node, ast.Constant) and isinstance(node.value, str)
            )
            for code in ("U16", "U17", "U18", "U19", "U20", "U21", "U22"):
                self.assertNotIn(code, text, text)


if __name__ == "__main__":
    unittest.main(verbosity=2)
