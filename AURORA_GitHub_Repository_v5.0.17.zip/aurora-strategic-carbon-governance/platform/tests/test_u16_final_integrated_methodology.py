"""U16 final integrated methodology, decision-control, and release tests."""
from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import pandas as pd

import cdr_producer_linkage as cdr_linkage
import hotspot_leverage as hotspot
import intervention_governance as governance
import node_sda_engine as node_sda
import release_identity
from critic_dli_core import CRITERIA
from spa_sda_pathway_bridge import (
    ModelAdapter,
    build_path_panel,
    classify_signed_driver_effects,
)
from tests.test_u14_node_sda_hotspot_leverage import (
    _fixture,
    _joint_counterfactual_hotspot_reduction,
)

ROOT = Path(__file__).resolve().parents[1]


def _evidence():
    base, y0, comparison, y1, ranking = _fixture()
    node_result = node_sda.compute_node_wise_sda(
        base, y0, comparison, y1, hotspot_threshold=0.80
    )
    linkage = cdr_linkage.compute_cdr_producer_linkage(comparison, y1)
    hotspot_result = hotspot.compute_hotspot_leverage(
        comparison,
        y1,
        linkage,
        node_result.frame,
        ranking,
        hotspot_threshold=0.80,
        high_dli_quantile=0.75,
        target_coverage=0.80,
    )
    return base, y0, comparison, y1, ranking, node_result, linkage, hotspot_result


def _verified_assessment(reference: str = "DOC-U16") -> dict[str, str]:
    record = {field: "Yes" for field in governance.ACTIONABILITY_FIELDS}
    record.update(
        {
            "assessor_name": "Named accountable sustainability manager",
            "assessor_role": "Focal-company intervention owner",
            "evidence_reference": reference,
            "assessment_notes": "Documented U16 validation evidence.",
            "scenario_quantification_decision": "Proceed without quantification",
            "scenario_non_quantification_reason": "Legacy methodology test has no empirical scenario inputs.",
            "scenario_assessor_name": "Named accountable sustainability manager",
            "scenario_assessor_role": "Focal-company intervention owner",
            "scenario_evidence_reference": reference,
        }
    )
    return record


def _content_store():
    stored: dict[str, dict[str, Any]] = {}

    def store(payload: Any, namespace: str) -> str:
        body = json.dumps(
            {"namespace": namespace, "payload": payload},
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
        cid = hashlib.sha256(body).hexdigest()
        stored[cid] = {"namespace": namespace, "payload": payload}
        return cid

    return stored, store


class U16FinalIntegratedMethodologyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        (
            cls.base,
            cls.y0,
            cls.comparison,
            cls.y1,
            cls.ranking,
            cls.node_result,
            cls.linkage,
            cls.hotspot_result,
        ) = _evidence()
        cls.hashes = {"mrio": "a" * 64, "focal_demand": "b" * 64}

    def _initial(self, pair_evidence: pd.DataFrame | None = None):
        return governance.compute_intervention_governance(
            self.comparison,
            self.y1,
            self.hotspot_result.pair_evidence if pair_evidence is None else pair_evidence,
            target_coverage=0.80,
            source_network_result_cid="c" * 64,
            input_hashes=self.hashes,
        )

    def test_dli_authority_remains_bc_pr_cdr_ic_only(self):
        self.assertEqual(tuple(CRITERIA), ("BC", "PR", "CDR", "IC"))
        critic_source = (ROOT / "critic_dli_core.py").read_text(encoding="utf-8")
        for forbidden in ("node_delta_intensity", "primary_adverse_driver", "actionability", "path_identity_status"):
            self.assertNotIn(forbidden, critic_source)

    def test_signed_driver_logic_separates_absolute_adverse_and_beneficial(self):
        result = classify_signed_driver_effects(
            {"intensity": -70.0, "technology": 50.0, "composition": 15.0, "scale": 10.0},
            1e-12,
        )
        self.assertEqual(result["dominant_driver"], "intensity")
        self.assertEqual(result["primary_adverse_driver"], "technology")
        self.assertEqual(result["primary_adverse_effect_tco2"], 50.0)
        self.assertEqual(result["primary_beneficial_driver"], "intensity")
        self.assertEqual(result["primary_beneficial_effect_tco2"], -70.0)
        self.assertIn("composition", result["secondary_adverse_drivers"])
        self.assertEqual(result["driver_pattern"], "offsetting adverse and beneficial drivers")

    def test_node_sda_reconciles_and_retains_signed_priority_fields(self):
        frame = self.node_result.frame
        np.testing.assert_allclose(
            frame[[f"node_delta_{name}" for name in node_sda.FACTOR_NAMES]].sum(axis=1),
            frame["node_footprint_change_tco2"],
            rtol=1e-10,
            atol=1e-10,
        )
        required = {
            "node_dominant_driver",
            "node_primary_adverse_driver",
            "node_primary_adverse_effect_tco2",
            "node_secondary_adverse_drivers",
            "node_primary_beneficial_driver",
            "node_primary_beneficial_effect_tco2",
            "node_driver_pattern",
        }
        self.assertTrue(required.issubset(frame.columns))
        self.assertLessEqual(self.node_result.maximum_row_residual, 1e-9)
        self.assertLessEqual(self.node_result.maximum_column_residual, 1e-9)

    def test_common_node_can_follow_different_exact_paths_across_years(self):
        codes = ["ARE-cns", "ARE-nmm", "ROW-nmm", "ARE-ely"]
        a0 = np.zeros((4, 4), dtype=float)
        a1 = np.zeros((4, 4), dtype=float)
        # 2014 route: ARE-cns <- ARE-nmm <- ARE-ely
        a0[1, 0] = 0.5
        a0[3, 1] = 0.4
        # 2017 route: ARE-cns <- ROW-nmm <- ARE-ely
        a1[2, 0] = 0.6
        a1[3, 2] = 0.5
        # One persistent direct route to prove exact-identity handling.
        a0[3, 0] = 0.05
        a1[3, 0] = 0.06
        f0 = np.array([0.0, 0.0, 0.0, 2.0])
        f1 = np.array([0.0, 0.0, 0.0, 2.2])
        y0 = np.array([100.0, 0.0, 0.0, 0.0])
        y1 = np.array([120.0, 0.0, 0.0, 0.0])
        base = ModelAdapter(2014, a0, f0, y0, codes)
        comparison = ModelAdapter(2017, a1, f1, y1, codes)
        old_path = ("ARE-cns", "ARE-nmm", "ARE-ely")
        new_path = ("ARE-cns", "ROW-nmm", "ARE-ely")
        persistent = ("ARE-cns", "ARE-ely")
        panel = build_path_panel(
            {old_path, new_path, persistent},
            base,
            comparison,
            materiality_tolerance=1e-12,
            base_selected_paths={old_path, persistent},
            comparison_selected_paths={new_path, persistent},
        ).set_index("path_id")
        old_id = " <- ".join(old_path)
        new_id = " <- ".join(new_path)
        persistent_id = " <- ".join(persistent)
        self.assertEqual(panel.loc[old_id, "path_identity_status"], "disappearing exact path")
        self.assertEqual(panel.loc[new_id, "path_identity_status"], "emerging exact path")
        self.assertEqual(panel.loc[persistent_id, "path_identity_status"], "persistent exact path")
        self.assertEqual(panel.loc[old_id, "route_reconfiguration_status"], "outgoing member of reconfigured route")
        self.assertEqual(panel.loc[new_id, "route_reconfiguration_status"], "incoming member of reconfigured route")
        self.assertEqual(panel.loc[old_id, "demand_gateway_node"], "ARE-cns")
        self.assertEqual(panel.loc[new_id, "terminal_emitter_node"], "ARE-ely")
        self.assertEqual(panel.loc[old_id, "bounded_spa_selection_status"], "selected in baseline bounded SPA only")
        self.assertEqual(panel.loc[new_id, "bounded_spa_selection_status"], "selected in comparison bounded SPA only")
        self.assertAlmostEqual(
            float(panel.loc[old_id, ["delta_intensity", "delta_technology", "delta_composition", "delta_scale"]].sum()),
            float(panel.loc[old_id, "delta_path_contribution"]),
            places=10,
        )
        self.assertAlmostEqual(
            float(panel.loc[new_id, ["delta_intensity", "delta_technology", "delta_composition", "delta_scale"]].sum()),
            float(panel.loc[new_id, "delta_path_contribution"]),
            places=10,
        )

    def test_beam_selection_omission_is_not_automatically_a_physical_zero(self):
        codes = ["A-x", "B-y"]
        a0 = np.array([[0.0, 0.0], [0.2, 0.0]])
        a1 = np.array([[0.0, 0.0], [0.3, 0.0]])
        path = ("A-x", "B-y")
        panel = build_path_panel(
            {path},
            ModelAdapter(2014, a0, np.array([0.0, 1.0]), np.array([10.0, 0.0]), codes),
            ModelAdapter(2017, a1, np.array([0.0, 1.0]), np.array([10.0, 0.0]), codes),
            base_selected_paths={path},
            comparison_selected_paths=set(),
        ).iloc[0]
        self.assertTrue(bool(panel["path_present_in_comparison"]))
        self.assertFalse(bool(panel["selected_in_comparison_bounded_spa"]))
        self.assertEqual(panel["path_identity_status"], "persistent exact path")

    def test_hotspot_linkage_is_cdr_decomposition_and_dual_coverage_is_reported(self):
        hotspot_codes = self.hotspot_result.hotspot_nodes["node_code"].astype(str).tolist()
        code_to_index = {str(code): i for i, code in enumerate(self.linkage.node_codes)}
        indices = [code_to_index[code] for code in hotspot_codes]
        expected = self.linkage.avoided_producer_footprint[:, indices].sum(axis=1)
        observed = self.hotspot_result.node_summary.set_index("intervention_node").loc[
            self.linkage.node_codes, "hotspot_structural_influence_tco2"
        ].to_numpy()
        np.testing.assert_allclose(observed, expected, rtol=1e-12, atol=1e-12)
        for portfolio in self.hotspot_result.portfolios.values():
            if portfolio.frame.empty:
                continue
            self.assertIn("cumulative_hotspot_structural_coverage", portfolio.frame.columns)
            self.assertIn("cumulative_company_structural_coverage", portfolio.frame.columns)
            last = portfolio.frame.iloc[-1]
            self.assertLessEqual(float(last["cumulative_company_structural_coverage"]), 1.0 + 1e-10)
            self.assertLessEqual(float(last["cumulative_hotspot_structural_coverage"]), 1.0 + 1e-10)

    def test_single_funnel_maps_mechanism_without_tautological_compatibility_portfolio(self):
        result = self._initial()
        self.assertEqual(set(result.portfolios), {"governance_ready"})
        self.assertTrue(result.portfolio.frame.empty)
        self.assertTrue(result.governance_options.empty)
        self.assertNotIn("driver_compatibility_status", result.candidates.columns)
        self.assertNotIn("driver_compatible", result.portfolios)
        self.assertTrue(
            result.candidates["mechanism_mapping_status"].isin(
                ["Mapped from primary adverse node-SDA driver", "No mapped adverse-driver mechanism"]
            ).all()
        )
        for row in result.candidates.itertuples():
            if row.hotspot_primary_adverse_driver:
                expected = governance.MECHANISM_LIBRARY[row.hotspot_primary_adverse_driver]
                self.assertEqual(row.mechanism_code, expected["mechanism_code"])

    def test_initial_state_is_fail_closed_until_actionability_is_attested(self):
        result = self._initial()
        self.assertTrue(result.assessments["assessment_status"].eq("Not yet assessed").all())
        self.assertTrue(result.eligibility["governance_eligibility_status"].eq("Not yet eligible").all())
        self.assertTrue(result.portfolio.frame.empty)
        self.assertTrue(result.governance_options.empty)

    def test_node_actionability_propagates_but_pair_feasibility_does_not(self):
        initial = self._initial()
        grouped = initial.candidates.groupby("intervention_node")
        node = next(name for name, group in grouped if len(group) >= 2)
        group = initial.candidates.loc[initial.candidates["intervention_node"].eq(node)]
        first_id = str(group.iloc[0]["candidate_id"])
        second_id = str(group.iloc[1]["candidate_id"])
        assessments = governance.upsert_actionability_assessment(
            initial.candidates,
            initial.assessments,
            first_id,
            _verified_assessment("NODE-PAIR-EVIDENCE"),
        ).set_index("candidate_id")
        for field in governance.NODE_ACTIONABILITY_FIELDS:
            self.assertEqual(assessments.loc[first_id, field], "Yes")
            self.assertEqual(assessments.loc[second_id, field], "Yes")
        self.assertEqual(assessments.loc[first_id, "technical_feasibility_confirmed"], "Yes")
        self.assertEqual(assessments.loc[second_id, "technical_feasibility_confirmed"], "Not assessed")
        self.assertEqual(assessments.loc[first_id, "assessment_status"], "Verified actionable")
        self.assertEqual(assessments.loc[second_id, "assessment_status"], "Conditionally actionable")

    def test_verified_pair_enters_one_exact_joint_portfolio(self):
        initial = self._initial()
        candidate = initial.candidates.iloc[0]
        assessments = governance.upsert_actionability_assessment(
            initial.candidates,
            initial.assessments,
            str(candidate["candidate_id"]),
            _verified_assessment(),
        )
        result = governance.compute_intervention_governance(
            self.comparison,
            self.y1,
            self.hotspot_result.pair_evidence,
            assessments=assessments,
            source_network_result_cid="c" * 64,
            input_hashes=self.hashes,
        )
        self.assertEqual(
            int(result.eligibility["governance_eligibility_status"].eq(governance.ELIGIBLE_STATUS).sum()),
            1,
        )
        self.assertFalse(result.portfolio.frame.empty)
        hotspot_codes = self.hotspot_result.hotspot_nodes["node_code"].astype(str).tolist()
        selected: list[str] = []
        for _, row in result.portfolio.frame.iterrows():
            selected.append(str(row["intervention_node"]))
            reduction, baseline = _joint_counterfactual_hotspot_reduction(
                self.comparison, self.y1, selected, hotspot_codes
            )
            self.assertAlmostEqual(
                float(row["cumulative_full_hotspot_structural_reduction_tco2"]),
                reduction,
                places=9,
            )
            self.assertAlmostEqual(
                float(row["cumulative_full_hotspot_structural_coverage"]),
                reduction / baseline if baseline else 0.0,
                places=9,
            )

    def test_governance_options_are_grouped_by_node_and_mechanism(self):
        pair = self.hotspot_result.pair_evidence.copy()
        hotspots = list(dict.fromkeys(pair["hotspot_producer_node"].astype(str)))
        self.assertGreaterEqual(len(hotspots), 2)
        # Give two hotspot producers distinct adverse mechanisms.
        pair.loc[pair["hotspot_producer_node"].eq(hotspots[0]), "hotspot_primary_adverse_driver"] = "intensity"
        pair.loc[pair["hotspot_producer_node"].eq(hotspots[0]), "hotspot_primary_adverse_effect_tco2"] = 2.0
        pair.loc[pair["hotspot_producer_node"].eq(hotspots[1]), "hotspot_primary_adverse_driver"] = "technology"
        pair.loc[pair["hotspot_producer_node"].eq(hotspots[1]), "hotspot_primary_adverse_effect_tco2"] = 3.0
        initial = self._initial(pair)
        node = next(
            name for name, group in initial.candidates.groupby("intervention_node")
            if group["mechanism_code"].nunique() >= 2
        )
        assessments = initial.assessments
        for index, row in initial.candidates.loc[initial.candidates["intervention_node"].eq(node)].iterrows():
            assessments = governance.upsert_actionability_assessment(
                initial.candidates,
                assessments,
                str(row["candidate_id"]),
                _verified_assessment(f"MECH-{index}"),
            )
        stored, store = _content_store()
        result = governance.compute_intervention_governance(
            self.comparison,
            self.y1,
            pair,
            assessments=assessments,
            source_network_result_cid="c" * 64,
            input_hashes=self.hashes,
            store_content_fn=store,
        )
        options = result.governance_options.loc[result.governance_options["node_code"].eq(node)]
        self.assertGreaterEqual(options["mechanism_code"].nunique(), 2)
        self.assertEqual(len(options), len(options[["node_code", "mechanism_code"]].drop_duplicates()))
        for row in options.itertuples():
            self.assertEqual(len(str(row.option_cid)), 64)
            payload = stored[str(row.option_cid)]["payload"]
            self.assertEqual(payload["extension_id"], "v5.0.17-U16")

    def test_empty_candidate_universe_is_safe(self):
        pair = self.hotspot_result.pair_evidence.copy()
        pair["avoided_hotspot_footprint_tco2"] = 0.0
        result = self._initial(pair)
        self.assertTrue(result.candidates.empty)
        self.assertTrue(result.eligibility.empty)
        self.assertTrue(result.portfolio.frame.empty)
        self.assertTrue(result.governance_options.empty)

    def test_governance_artifacts_are_hash_verified_and_tamper_evident(self):
        initial = self._initial()
        with tempfile.TemporaryDirectory() as directory:
            stored, store = _content_store()
            metadata = governance.write_intervention_governance_artifacts(
                directory,
                initial,
                input_hashes=self.hashes,
                source_network_result_cid="c" * 64,
                hotspot_leverage_evidence_cid="d" * 64,
                node_sda_evidence_cid="e" * 64,
                critic_evidence_cid="f" * 64,
                store_content_fn=store,
            )
            verified = governance.verify_intervention_governance_artifacts(
                directory,
                expected_input_hashes=self.hashes,
                expected_source_network_result_cid="c" * 64,
            )
            self.assertEqual(verified["extension_id"], "v5.0.17-U16")
            target = Path(directory) / metadata["artifacts"]["eligibility"]["filename"]
            target.write_text(target.read_text(encoding="utf-8") + "\n", encoding="utf-8")
            with self.assertRaises(RuntimeError):
                governance.verify_intervention_governance_artifacts(
                    directory, expected_input_hashes=self.hashes
                )

    def test_release_identity_and_launcher_read_u16_authorities_from_version_file(self):
        identity = release_identity.RELEASE_IDENTITY
        self.assertEqual(identity["integrated_methodology_extension_id"], "v5.0.17-U17")
        self.assertEqual(identity["path_alignment_extension_id"], "v5.0.17-U16")
        self.assertEqual(identity["path_driver_extension_id"], "v5.0.17-U16")
        self.assertEqual(identity["intervention_governance_extension_id"], "v5.0.17-U16")
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8-sig")
        self.assertIn('RELEASE_IDENTITY["path_alignment_extension_id"]', server)
        self.assertIn('Get-RqVersionValue -Key "path_alignment_extension_id"', launcher)
        self.assertIn('$candidate.path_alignment_extension -eq $ExpectedPathAlignment', launcher)

    def test_pre_u16_top_dli_intervention_authority_is_retired(self):
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        legacy = (ROOT / "intervention_rules.py").read_text(encoding="utf-8")
        self.assertNotIn("generate_interventions(", orchestrator)
        self.assertIn("LEGACY_FORMAL_AUTHORITY = False", legacy)
        with self.assertRaises(RuntimeError):
            import intervention_rules
            intervention_rules.generate_interventions(pd.DataFrame())

    def test_aurora_is_ordered_after_temporal_dli_and_import_time_patching_is_inert(self):
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8")
        self.assertIn(
            "aurora_role=post-temporal-dli-regional-sourcing-intelligence-with-no-intervention-dependency",
            version,
        )
        for filename in ("aurora_reporting.py", "sourcing_opportunity_engine.py"):
            source = (ROOT / filename).read_text(encoding="utf-8")
            self.assertNotIn("install_evidence_patch(", source)
        hooks = (ROOT / "final_methodology_hooks.py").read_text(encoding="utf-8")
        self.assertIn("No-op compatibility function", hooks)

    def test_streamlit_core_modules_are_bridges_not_duplicate_implementations(self):
        for filename in (
            "analytics_engine.py",
            "network_engine.py",
            "node_sda_engine.py",
            "hotspot_leverage.py",
            "intervention_governance.py",
            "strategic_assistant.py",
        ):
            source = (ROOT / "streamlit_app" / filename).read_text(encoding="utf-8")
            self.assertIn("Compatibility bridge to the single authoritative U16 module", source)
            self.assertLess(len(source.splitlines()), 20)

    def test_knowledge_and_llm_boundaries_expose_u16_final_method(self):
        domain = json.loads((ROOT / "domain_knowledge.json").read_text(encoding="utf-8"))
        system = json.loads((ROOT / "system_knowledge.json").read_text(encoding="utf-8"))
        rag = json.loads((ROOT / "rag_documents.json").read_text(encoding="utf-8"))
        self.assertEqual(domain["version"], "5.0.17-U23")
        self.assertEqual(system["version"], "5.0.17-U23")
        self.assertIn("method_u16_union_exact_path_sda", {row["doc_id"] for row in rag})
        assistant = (ROOT / "strategic_assistant.py").read_text(encoding="utf-8")
        self.assertIn("not predicted or guaranteed abatement", assistant)
        self.assertIn("do not enter DLI", assistant)


if __name__ == "__main__":
    unittest.main(verbosity=2)
