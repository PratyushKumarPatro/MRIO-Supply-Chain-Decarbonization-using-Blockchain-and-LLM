"""Focused U19 regression tests for post-AURORA intervention provenance."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import pandas as pd

import cdr_producer_linkage as cdr_linkage
import hotspot_leverage as hotspot_engine
import intervention_governance as governance
import node_sda_engine as node_sda
from tests.test_u14_node_sda_hotspot_leverage import _fixture


ROOT = Path(__file__).resolve().parents[1]


def _assessment() -> dict[str, str]:
    result = {field: "Yes" for field in governance.ACTIONABILITY_FIELDS}
    result.update(
        {
            "assessor_name": "Named intervention owner",
            "assessor_role": "Focal-company intervention owner",
            "evidence_reference": "U19-POST-AURORA-EVIDENCE",
            "assessment_notes": "Verified for the focused U19 provenance test.",
            "scenario_quantification_decision": "Proceed without quantification",
            "scenario_non_quantification_reason": "No empirical scenario inputs are used in this provenance test.",
            "scenario_assessor_name": "Named intervention owner",
            "scenario_assessor_role": "Focal-company intervention owner",
            "scenario_evidence_reference": "U19-POST-AURORA-EVIDENCE",
        }
    )
    return result


def _content_store():
    stored: dict[str, dict] = {}

    def store(payload, namespace: str) -> str:
        envelope = {"namespace": namespace, "payload": payload}
        body = json.dumps(
            envelope,
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
        import hashlib

        cid = hashlib.sha256(body).hexdigest()
        stored[cid] = envelope
        return cid

    return stored, store


class U19PostAuroraInterventionBindingTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        base, base_demand, cls.model, cls.demand, ranking = _fixture()
        node_result = node_sda.compute_node_wise_sda(
            base,
            base_demand,
            cls.model,
            cls.demand,
            hotspot_threshold=0.80,
        )
        linkage = cdr_linkage.compute_cdr_producer_linkage(cls.model, cls.demand)
        cls.hotspot = hotspot_engine.compute_hotspot_leverage(
            cls.model,
            cls.demand,
            linkage,
            node_result.frame,
            ranking,
            hotspot_threshold=0.80,
            high_dli_quantile=0.75,
            target_coverage=0.80,
        )
        cls.hashes = {"mrio": "a" * 64, "focal_demand": "b" * 64}
        cls.network_cid = "c" * 64
        cls.aurora_cid = "d" * 64

    def test_aurora_binding_does_not_change_u16_candidate_or_mechanism_universe(self):
        before = governance.compute_intervention_governance(
            self.model,
            self.demand,
            self.hotspot.pair_evidence,
            source_network_result_cid=self.network_cid,
            input_hashes=self.hashes,
        )
        after = governance.compute_intervention_governance(
            self.model,
            self.demand,
            self.hotspot.pair_evidence,
            source_network_result_cid=self.network_cid,
            source_aurora_result_cid=self.aurora_cid,
            input_hashes=self.hashes,
        )
        pd.testing.assert_frame_equal(before.candidates, after.candidates)
        self.assertEqual(
            set(after.candidates["mechanism_code"].astype(str)),
            set(before.candidates["mechanism_code"].astype(str)),
        )

    def test_option_and_artifact_metadata_are_bound_to_exact_aurora_cid(self):
        initial = governance.compute_intervention_governance(
            self.model,
            self.demand,
            self.hotspot.pair_evidence,
            source_network_result_cid=self.network_cid,
            source_aurora_result_cid=self.aurora_cid,
            input_hashes=self.hashes,
        )
        candidate_id = str(initial.candidates.iloc[0]["candidate_id"])
        assessments = governance.upsert_actionability_assessment(
            initial.candidates,
            initial.assessments,
            candidate_id,
            _assessment(),
        )
        stored, store = _content_store()
        result = governance.compute_intervention_governance(
            self.model,
            self.demand,
            self.hotspot.pair_evidence,
            assessments=assessments,
            source_network_result_cid=self.network_cid,
            source_aurora_result_cid=self.aurora_cid,
            input_hashes=self.hashes,
            store_content_fn=store,
        )
        self.assertFalse(result.governance_options.empty)
        option_cid = str(result.governance_options.iloc[0]["option_cid"])
        self.assertEqual(
            stored[option_cid]["payload"]["source_aurora_result_cid"],
            self.aurora_cid,
        )

        with tempfile.TemporaryDirectory() as directory:
            governance.write_intervention_governance_artifacts(
                directory,
                result,
                input_hashes=self.hashes,
                source_network_result_cid=self.network_cid,
                source_aurora_result_cid=self.aurora_cid,
                hotspot_leverage_evidence_cid="e" * 64,
                node_sda_evidence_cid="f" * 64,
                critic_evidence_cid="1" * 64,
                store_content_fn=store,
            )
            verified = governance.verify_intervention_governance_artifacts(
                directory,
                expected_input_hashes=self.hashes,
                expected_source_network_result_cid=self.network_cid,
                expected_source_aurora_result_cid=self.aurora_cid,
            )
            self.assertEqual(verified["source_aurora_result_cid"], self.aurora_cid)
            with self.assertRaisesRegex(RuntimeError, "different fulfilled AURORA"):
                governance.verify_intervention_governance_artifacts(
                    directory,
                    expected_source_aurora_result_cid="2" * 64,
                )

    def test_actionability_and_proposal_verifiers_require_active_aurora_binding(self):
        source = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        helper_start = source.index("def _verified_active_aurora_cid(")
        client_start = source.index("def make_client(")
        helper = source[helper_start:client_start]
        self.assertIn('active_index["results"]["aurora:2017"]', helper)
        self.assertIn('load_content(aurora_cid)', helper)
        self.assertIn('"regional_sourcing_opportunity_analysis"', helper)
        self.assertIn('payload.get("network_result_hash"', helper)

        action_start = source.index("    def record_intervention_actionability(")
        proposal_start = source.index("    def prepare_intervention_proposal(")
        aurora_start = source.index("    def compute_sourcing_opportunities(")
        action = source[action_start:proposal_start]
        proposal = source[proposal_start:aurora_start]
        for function_source in (action, proposal):
            self.assertIn("_verified_active_aurora_cid(", function_source)
            self.assertIn("expected_source_aurora_result_cid=aurora_result_cid", function_source)

    def test_network_and_aurora_defer_until_explicit_stage12_materialization(self):
        source = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        network_start = source.index("    def compute_network(")
        robustness_start = source.index("    def compute_dli_weight_robustness(")
        network_source = source[network_start:robustness_start]
        aurora_start = source.index("    def compute_sourcing_opportunities(")
        query_start = source.index("    def process_query(")
        aurora_source = source[aurora_start:query_start]
        self.assertIn('"status": "deferred-until-fulfilled-aurora"', network_source)
        self.assertNotIn("write_intervention_governance_artifacts(", network_source)
        self.assertNotIn(
            "self._materialize_post_aurora_intervention_artifacts(", aurora_source
        )
        self.assertIn(
            '"status": "pending-user-initiated-stage-12-computation"',
            aurora_source,
        )
        self.assertIn('"intervention_governance_evidence_cid": ""', aurora_source)

        materialize_start = source.index(
            "    def materialize_post_aurora_intervention_governance("
        )
        actionability_start = source.index("    def record_intervention_actionability(")
        materialize_source = source[materialize_start:actionability_start]
        self.assertIn(
            "self._materialize_post_aurora_intervention_artifacts(",
            materialize_source,
        )
        self.assertIn('status = "materialized-on-demand"', materialize_source)
        self.assertIn(
            '"intervention_governance_evidence_materialization"',
            materialize_source,
        )

    def test_explicit_materialization_failure_preserves_aurora_but_blocks_governance(self):
        def fail_materialization():
            raise OSError("simulated downstream workbook failure")

        outcome = governance.capture_post_aurora_materialization(
            fail_materialization
        )
        self.assertFalse(outcome["available"])
        self.assertEqual(
            outcome["status"],
            "post-aurora-materialization-failed-governance-unresolved",
        )
        self.assertEqual(outcome["metadata"], {})
        self.assertIn("AURORA remains valid", outcome["authority_boundary"])

        source = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        aurora_start = source.index("    def compute_sourcing_opportunities(")
        query_start = source.index("    def process_query(")
        aurora_source = source[aurora_start:query_start]
        self.assertNotIn("capture_post_aurora_materialization(", aurora_source)
        self.assertIn(
            '"status": "pending-user-initiated-stage-12-computation"',
            aurora_source,
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
