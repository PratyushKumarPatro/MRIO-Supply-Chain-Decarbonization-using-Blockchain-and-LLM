from __future__ import annotations
import unittest
import numpy as np
import pandas as pd
from critic_dli_core import critic_weights, score_and_rank
from spa_sda_pathway_bridge import exact_product_shapley, cluster_baseline_paths, allocate_to_nodes

class U10FinalMethodologyTests(unittest.TestCase):
    def test_critic_weights_are_objective_and_sum_to_one(self):
        df=pd.DataFrame({"BC":[0,1,2,4],"PR":[0,2,3,8],"CDR":[0,1,4,5],"IC":[1,1.5,2,7],"year":[2014]*2+[2017]*2,"node_code":["a","b","a","b"]})
        r=critic_weights(df,scope="pooled-2014-2017")
        self.assertAlmostEqual(sum(r.weights.values()),1.0,12)
        self.assertTrue(all(v>0 for v in r.weights.values()))
        scored=score_and_rank(df,r)
        self.assertTrue((scored["dli_weighting_method"]=="CRITIC").all())
        with self.assertRaisesRegex(ValueError, "pooled Pearson-CRITIC"):
            critic_weights(df, correlation_method="spearman")
    def test_path_shapley_exact_reconciliation(self):
        v0=[2.0,0.2,0.3,10.0]; v1=[1.5,0.4,0.3,12.0]
        e=exact_product_shapley(v0,v1)
        self.assertAlmostEqual(sum(e.values()),np.prod(v1)-np.prod(v0),12)
    def test_structural_class_is_independent_of_driver_effects(self):
        rows=[]
        for i in range(20):
            rows.append({"path_id":str(i),"path_nodes":["ARE-a","ROW-b"],"depth":1 if i<10 else 5,"baseline_footprint_share":0.01+i*1e-5,"baseline_terminal_intensity":0.1 if i<10 else 2.0,"baseline_geometric_mean_coefficient":0.2,"external_node_share":0.2 if i<10 else 0.9,"baseline_contribution":1.0,"comparison_contribution":1.1,"delta_path_contribution":0.1,"delta_intensity":1000*i,"delta_technology":-1000*i,"delta_composition":0,"delta_scale":0,"dominant_driver":"intensity","driver_dominance_share":0.5,"driver_direction":"deterioration","baseline_edge_coefficients":[0.2],"comparison_edge_coefficients":[0.21]})
        out,diag,info=cluster_baseline_paths(pd.DataFrame(rows),k_min=2,k_max=2)
        self.assertEqual(info["selected_k"],2)
        self.assertEqual(out["structural_path_class"].nunique(),2)
    def test_node_attribution_reconciles_path_effects(self):
        df=pd.DataFrame([{"path_nodes":["ARE-a","ROW-b"],"delta_intensity":1.0,"delta_technology":2.0,"delta_composition":3.0,"delta_scale":4.0,"baseline_edge_coefficients":[0.2],"comparison_edge_coefficients":[0.3]}])
        nodes=allocate_to_nodes(df)
        for d,total in [("intensity",1.0),("technology",2.0),("composition",3.0),("scale",4.0)]:
            self.assertAlmostEqual(nodes[f"node_delta_{d}"].sum(),total,12)

if __name__=='__main__': unittest.main()
