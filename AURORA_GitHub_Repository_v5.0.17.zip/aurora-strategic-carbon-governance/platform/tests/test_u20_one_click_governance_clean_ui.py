"""Regression tests for the U20 governance-interface and clean-UI extension."""
from __future__ import annotations

import ast
import json
import math
import tempfile
import unittest
from dataclasses import asdict, is_dataclass
from pathlib import Path

import numpy as np
import pandas as pd

import intervention_governance as governance
import release_identity
from plot_style import style_plotly_axes


ROOT = Path(__file__).resolve().parents[1]


def _load_jsonable_without_runtime_services():
    """Load only the serializer function without importing service dependencies."""

    source = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
    tree = ast.parse(source)
    function = next(
        node
        for node in tree.body
        if isinstance(node, ast.FunctionDef) and node.name == "_jsonable"
    )
    module = ast.Module(body=[function], type_ignores=[])
    namespace = {
        "asdict": asdict,
        "is_dataclass": is_dataclass,
        "math": math,
        "np": np,
        "pd": pd,
        "Path": Path,
        "Any": object,
    }
    exec(compile(module, "<data_orchestrator._jsonable>", "exec"), namespace)
    return namespace["_jsonable"]


class _AxisFigure:
    def __init__(self) -> None:
        self.xaxis: dict = {}
        self.yaxis: dict = {}
        self.layout: dict = {}
        self.traces: dict = {}

    def update_layout(self, **kwargs) -> None:
        self.layout = kwargs

    def update_xaxes(self, **kwargs) -> None:
        self.xaxis = kwargs

    def update_yaxes(self, **kwargs) -> None:
        self.yaxis = kwargs

    def update_traces(self, **kwargs) -> None:
        self.traces = kwargs


class U20OneClickGovernanceCleanUITests(unittest.TestCase):
    def test_release_identity_preserves_u20_u21_and_adds_u22_control_plane(self):
        identity = release_identity.RELEASE_IDENTITY
        self.assertEqual(
            identity["release_patch"],
            "u23-evidence-bound-abatement-decision",
        )
        self.assertEqual(identity["governance_interface_extension_id"], "v5.0.17-U20")
        self.assertEqual(
            identity["architecture_version"],
            "5.0.17-u23-evidence-bound-abatement-decision",
        )
        self.assertEqual(identity["methodology_lifecycle_extension_id"], "v5.0.17-U19")
        self.assertEqual(identity["intervention_governance_extension_id"], "v5.0.17-U16")
        self.assertEqual(identity["abatement_scenario_extension_id"], "v5.0.17-U21")
        self.assertEqual(identity["performance_monitoring_extension_id"], "v5.0.17-U21")
        self.assertEqual(
            identity["blockchain_control_plane_extension_id"], "v5.0.17-U22"
        )
        self.assertEqual(identity["abatement_decision_gate_extension_id"], "v5.0.17-U23")

    def test_csv_missing_values_cannot_break_assessment_fingerprinting(self):
        candidates = pd.DataFrame(
            [
                {
                    "candidate_id": "a" * 64,
                    "intervention_node": "ARE-cns",
                    "hotspot_producer_node": "ARE-nmm",
                    "mechanism_code": "INTENSITY_DECARBONIZATION",
                },
                {
                    "candidate_id": "b" * 64,
                    "intervention_node": "ARE-cns",
                    "hotspot_producer_node": "ROW-ely",
                    "mechanism_code": "PRODUCTION_STRUCTURE_REDESIGN",
                },
            ]
        )
        initial = governance.empty_assessments(candidates)
        with tempfile.TemporaryDirectory() as temporary:
            csv_path = Path(temporary) / "assessments.csv"
            initial.to_csv(csv_path, index=False)
            # The historical failure came from a normal pandas CSV reload,
            # which converted blank sibling text fields into float NaN values.
            csv_reloaded = pd.read_csv(csv_path)

        assessment = {
            "direct_or_contractual_relationship": "Yes",
            "specification_or_procurement_control": "No",
            "supplier_selection_or_substitution_authority": "Yes",
            "emissions_disclosure_right": "Yes",
            "audit_or_verification_right": "Yes",
            "implementation_owner_identified": "Yes",
            "resource_or_budget_path_identified": "Yes",
            "technical_feasibility_confirmed": "Yes",
            "assessor_name": "Accountable company manager",
            "assessor_role": "Construction Procurement Manager",
            "evidence_reference": "GOV-DOC-2017-001",
            "assessment_notes": "Evidence reviewed for the selected hotspot/mechanism pair.",
        }
        updated = governance.upsert_actionability_assessment(
            candidates,
            csv_reloaded,
            "a" * 64,
            assessment,
        )
        strict_payload = json.loads(governance._canonical_json(updated.to_dict(orient="records")))
        self.assertEqual(len(strict_payload), 2)
        self.assertTrue(all(isinstance(row["assessment_notes"], str) for row in strict_payload))
        sibling = next(row for row in strict_payload if row["candidate_id"] == "b" * 64)
        self.assertEqual(sibling["assessment_notes"], "")
        self.assertEqual(sibling["technical_feasibility_confirmed"], "Not assessed")

    def test_strict_json_sanitizes_all_nonfinite_scalars(self):
        encoded = governance._canonical_json(
            {"nan": np.nan, "positive_infinity": np.inf, "pandas_missing": pd.NA}
        )
        self.assertEqual(
            json.loads(encoded),
            {"nan": None, "pandas_missing": None, "positive_infinity": None},
        )
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        self.assertIn("_jsonable(payload)", server)
        self.assertIn("allow_nan=False", server)

    def test_node_evidence_is_reused_for_a_new_pair_but_feasibility_is_not(self):
        original_candidates = pd.DataFrame(
            [
                {
                    "candidate_id": "c" * 64,
                    "intervention_node": "ARE-cns",
                    "hotspot_producer_node": "ARE-nmm",
                    "mechanism_code": "INTENSITY_DECARBONIZATION",
                }
            ]
        )
        assessment = {
            **{field: "Yes" for field in governance.ACTIONABILITY_FIELDS},
            "assessor_name": "Accountable company manager",
            "assessor_role": "Construction Procurement Manager",
            "evidence_reference": "GOV-DOC-2017-002",
            "assessment_notes": "Feasibility applies to the original pair only.",
        }
        prior = governance.upsert_actionability_assessment(
            original_candidates,
            None,
            "c" * 64,
            assessment,
        )
        rebuilt_candidates = pd.concat(
            [
                original_candidates,
                pd.DataFrame(
                    [
                        {
                            "candidate_id": "d" * 64,
                            "intervention_node": "ARE-cns",
                            "hotspot_producer_node": "ROW-ely",
                            "mechanism_code": "PRODUCTION_STRUCTURE_REDESIGN",
                        }
                    ]
                ),
            ],
            ignore_index=True,
        )
        merged = governance._merge_existing_assessments(rebuilt_candidates, prior)
        new_pair = merged.loc[merged["candidate_id"].eq("d" * 64)].iloc[0]
        for field in governance.NODE_ACTIONABILITY_FIELDS:
            self.assertEqual(new_pair[field], "Yes")
        self.assertEqual(new_pair["assessor_name"], "Accountable company manager")
        self.assertEqual(new_pair["technical_feasibility_confirmed"], "Not assessed")
        self.assertEqual(new_pair["assessment_notes"], "")
        self.assertEqual(new_pair["assessment_submitted_at_utc"], "")
        status, _basis = governance.assess_actionability(new_pair.to_dict())
        self.assertEqual(status, "Conditionally actionable")

    def test_missing_value_text_tokens_cannot_count_as_documentary_evidence(self):
        assessment = {
            **{field: "Yes" for field in governance.ACTIONABILITY_FIELDS},
            "assessor_name": "nan",
            "assessor_role": "None",
            "evidence_reference": "<NA>",
            "assessment_notes": "null",
        }
        status, _basis = governance.assess_actionability(assessment)
        self.assertNotEqual(status, "Verified actionable")
        for placeholder in (
            "nan",
            "None",
            "<NA>",
            "N/A",
            "NA",
            "Not assessed",
            "unknown",
            "-",
            "TBD",
        ):
            self.assertEqual(governance._safe_text(placeholder), "")
        self.assertIsNone(_load_jsonable_without_runtime_services()(pd.NA))

    def test_blockchain_ui_uses_selection_then_separate_human_decision(self):
        source = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        self.assertIn('selected_label = st.selectbox(', source)
        self.assertIn('"Select intervention and submit for verification"', source)
        self.assertIn('"Approve and record on-chain"', source)
        self.assertIn('"Reject and record on-chain"', source)
        self.assertIn('start_oracle("governance")', source)
        self.assertIn("already_requested", source)
        self.assertNotIn('selected = st.multiselect(\n                        "Governance-ready interventions"', source)
        request = source.index("requestInterventionProposal(")
        oracle_result = source.index("getInterventionProposalRequest(", request)
        decision = source.index("decideIntervention(", oracle_result)
        self.assertLess(request, oracle_result)
        self.assertLess(oracle_result, decision)
        contract = (ROOT / "contracts" / "StrategicCarbonIntelligenceSystem.sol").read_text(
            encoding="utf-8"
        )
        decision_start = contract.index("function decideIntervention(")
        self.assertIn("onlyGovernor", contract[decision_start : decision_start + 500])

        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        for function_name, next_name in (
            ("record_intervention_actionability", "prepare_intervention_proposal"),
            ("prepare_intervention_proposal", "compute_sourcing_opportunities"),
        ):
            body = orchestrator.split(f"def {function_name}(", 1)[1].split(
                f"def {next_name}(", 1
            )[0]
            self.assertIn("_verified_active_network_2017_payload", body)
        actionability_body = orchestrator.split(
            "def record_intervention_actionability(", 1
        )[1].split("def prepare_intervention_proposal(", 1)[0]
        self.assertIn(
            "with self._intervention_governance_lock, _RESULT_INDEX_LOCK:",
            actionability_body,
        )
        self.assertIn("@_with_result_index_lock\n    def prepare_intervention_proposal", orchestrator)

    def test_shared_plot_style_is_publication_readable_across_all_plots(self):
        figure = _AxisFigure()
        self.assertIs(style_plotly_axes(figure), figure)
        for axis in (figure.xaxis, figure.yaxis):
            self.assertEqual(axis["title_font"]["size"], 20)
            self.assertEqual(axis["tickfont"]["size"], 17)
            self.assertIn("Arial Black", axis["title_font"]["family"])
            self.assertIn("Arial Black", axis["tickfont"]["family"])
            self.assertTrue(axis["automargin"])
        self.assertEqual(figure.layout["title_font"]["size"], 24)
        self.assertEqual(figure.layout["font"]["size"], 17)
        self.assertEqual(figure.layout["legend"]["font"]["size"], 17)
        self.assertEqual(
            figure.layout["legend"]["title"]["font"]["size"],
            18,
        )
        self.assertEqual(figure.traces["textfont"]["size"], 17)

        chart_sources = [
            ROOT / "streamlit_app" / "app.py",
            ROOT / "final_methodology_ui.py",
            ROOT / "streamlit_app" / "node_sda_ui.py",
            ROOT / "streamlit_app" / "hotspot_leverage_ui.py",
            ROOT / "streamlit_app" / "cdr_linkage_ui.py",
            ROOT / "streamlit_app" / "intervention_governance_ui.py",
        ]
        style_calls = sum(
            path.read_text(encoding="utf-8").count("style_plotly_axes(")
            for path in chart_sources
        )
        # Every rendered Plotly figure, including the domestic/imported donut,
        # uses the shared publication-readable typography.
        self.assertEqual(style_calls, 21)

    def test_rendered_ui_labels_do_not_expose_internal_release_codes(self):
        rendered_methods = {
            "button",
            "caption",
            "download_button",
            "error",
            "expander",
            "info",
            "markdown",
            "multiselect",
            "selectbox",
            "subheader",
            "success",
            "tabs",
            "title",
            "warning",
            "write",
        }
        ui_sources = [
            ROOT / "streamlit_app" / "app.py",
            ROOT / "streamlit_app" / "blockchain_page.py",
            ROOT / "streamlit_app" / "cdr_linkage_ui.py",
            ROOT / "streamlit_app" / "hotspot_leverage_ui.py",
            ROOT / "streamlit_app" / "intervention_governance_ui.py",
            ROOT / "streamlit_app" / "intervention_control_ui.py",
            ROOT / "streamlit_app" / "node_sda_ui.py",
            ROOT / "final_methodology_ui.py",
        ]
        for path in ui_sources:
            tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
            for call in (node for node in ast.walk(tree) if isinstance(node, ast.Call)):
                if not isinstance(call.func, ast.Attribute) or call.func.attr not in rendered_methods:
                    continue
                rendered_text = " ".join(
                    node.value
                    for node in ast.walk(call)
                    if isinstance(node, ast.Constant) and isinstance(node.value, str)
                )
                for release_code in ("U16", "U17", "U19", "U20", "U21", "U22"):
                    self.assertNotIn(release_code, rendered_text, f"{path.name}: {rendered_text}")


if __name__ == "__main__":
    unittest.main(verbosity=2)
