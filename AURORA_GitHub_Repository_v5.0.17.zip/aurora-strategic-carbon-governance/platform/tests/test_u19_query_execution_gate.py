"""Fail-closed execution checks for the current QueryManagement evidence gate."""
from __future__ import annotations

import sys
import types
import unittest
from pathlib import Path
from unittest import mock

try:  # The packaged installation provides NetworkX; the lean build runner may not.
    import networkx  # noqa: F401
except ModuleNotFoundError:  # pragma: no cover - build-environment compatibility
    sys.modules["networkx"] = types.ModuleType("networkx")

import data_orchestrator as module
from data_orchestrator import DataOrchestrator


class U19QueryExecutionGateTests(unittest.TestCase):
    def setUp(self):
        self.hashes = {"mrio": "1" * 64, "focal_demand": "2" * 64}
        self.network_2014 = "a" * 64
        self.network_2017 = "b" * 64
        self.aurora_2017 = "c" * 64
        self.service = DataOrchestrator.__new__(DataOrchestrator)
        self.service.deployment_path = Path("__test_deployment_does_not_exist__.json")
        self.service.deployment = {
            "architecture_version": "5.0.17-u23-evidence-bound-abatement-decision",
            "contracts": {"QueryManagement": {"address": "0x1"}},
            "active_input_hashes": dict(self.hashes),
            "active_results": {
                "network": {
                    "2014": {"content_hash": self.network_2014},
                    "2017": {"content_hash": self.network_2017},
                },
                "aurora": {"2017": {"content_hash": self.aurora_2017}},
            },
            "lifecycle": {"intervention_governance_resolved": True},
        }

    def _patch_verified_chain(self):
        return [
            mock.patch.object(module, "active_input_hashes", return_value=self.hashes),
            mock.patch.object(
                module,
                "_verified_active_network_payload",
                return_value={"year": 2014},
            ),
            mock.patch.object(
                module,
                "_verified_active_network_2017_payload",
                return_value={
                    "year": 2017,
                    "pooled_critic_ready": True,
                    "temporal_dli_authority": {
                        "baseline_evidence_network_result_cid": self.network_2014
                    },
                },
            ),
            mock.patch.object(
                module,
                "_verified_active_aurora_cid",
                return_value=self.aurora_2017,
            ),
        ]

    def test_complete_chain_passes_with_resolved_intervention_governance(self):
        patches = self._patch_verified_chain()
        with patches[0], patches[1] as base, patches[2] as decision, patches[3] as aurora:
            gate = self.service._require_current_query_methodology_gate()
        self.assertEqual(gate["network_2014_cid"], self.network_2014)
        self.assertEqual(gate["network_2017_cid"], self.network_2017)
        self.assertEqual(gate["aurora_2017_cid"], self.aurora_2017)
        self.assertEqual(gate["intervention_governance_dependency"], "resolved")
        base.assert_called_once_with(self.network_2014, self.hashes, 2014)
        decision.assert_called_once_with(self.network_2017, self.hashes)
        aurora.assert_called_once_with(self.network_2017, self.hashes)

    def test_changed_inputs_fail_before_content_verification(self):
        self.service.deployment["active_input_hashes"] = {
            "mrio": "9" * 64,
            "focal_demand": self.hashes["focal_demand"],
        }
        with (
            mock.patch.object(module, "active_input_hashes", return_value=self.hashes),
            mock.patch.object(module, "_verified_active_network_payload") as verify,
        ):
            with self.assertRaisesRegex(RuntimeError, "stale for the active inputs"):
                self.service._require_current_query_methodology_gate()
        verify.assert_not_called()

    def test_unresolved_intervention_governance_fails_closed(self):
        self.service.deployment["lifecycle"]["intervention_governance_resolved"] = False
        with self.assertRaisesRegex(RuntimeError, "intervention governance"):
            self.service._require_current_query_methodology_gate()

    def test_unfulfilled_or_mismatched_aurora_fails_closed(self):
        patches = self._patch_verified_chain()
        patches[3] = mock.patch.object(
            module,
            "_verified_active_aurora_cid",
            return_value="d" * 64,
        )
        with patches[0], patches[1], patches[2], patches[3]:
            with self.assertRaisesRegex(RuntimeError, "fulfilled active 2017"):
                self.service._require_current_query_methodology_gate()

    def test_mismatched_temporal_baseline_cid_fails_closed(self):
        patches = self._patch_verified_chain()
        patches[2] = mock.patch.object(
            module,
            "_verified_active_network_2017_payload",
            return_value={
                "year": 2017,
                "pooled_critic_ready": True,
                "temporal_dli_authority": {
                    "baseline_evidence_network_result_cid": "e" * 64
                },
            },
        )
        with patches[0], patches[1], patches[2], patches[3]:
            with self.assertRaisesRegex(RuntimeError, "active 2014 baseline CID"):
                self.service._require_current_query_methodology_gate()

    def test_query_execution_rechecks_gate_before_committing(self):
        with open(module.__file__, encoding="utf-8") as source_file:
            source = source_file.read()
        process_source = source[source.index("    def process_query(") : source.index("    def record_error(")]
        self.assertGreaterEqual(
            process_source.count("self._require_current_query_methodology_gate()"),
            2,
        )
        self.assertNotIn("intervention_governance_resolved", process_source)
        self.assertNotIn("selected_intervention", process_source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
