"""Focused authority tests for the U19 pooled temporal DLI lifecycle."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

import pandas as pd

try:  # The deployable installs NetworkX; the lean build runner may not.
    import networkx  # noqa: F401
except ModuleNotFoundError:  # pragma: no cover - build-environment compatibility
    sys.modules["networkx"] = types.ModuleType("networkx")

import strategic_assistant as assistant
import data_orchestrator as orchestrator


def _rows(year: int) -> list[dict]:
    output = []
    for rank, (code, score) in enumerate((("AA-a", 0.8), ("BB-b", 0.2)), 1):
        row = {
            "year": year,
            "node_code": code,
            "region": code[:2],
            "sector": code[-1],
            "DLI": score + (0.05 if year == 2017 and code == "AA-a" else 0.0),
            "dli_rank": rank,
        }
        for criterion in assistant.net.CRITERIA:
            row[criterion] = score
            row[f"{criterion}_critic_weight_contribution"] = row["DLI"] / 4.0
        output.append(row)
    return output


class U19TemporalDLIAuthorityTests(unittest.TestCase):
    def _fixture(self, root: Path, *, include_both_slices: bool = True):
        mrio = root / "input_mrio_completed.xlsx"
        demand = root / "Focal_Company_Demand_Converted.xlsx"
        mrio.write_bytes(b"mrio")
        demand.write_bytes(b"demand")
        hashes = {
            "mrio": hashlib.sha256(b"mrio").hexdigest(),
            "focal_demand": hashlib.sha256(b"demand").hexdigest(),
        }
        slices = {"2017": _rows(2017)}
        if include_both_slices:
            slices["2014"] = _rows(2014)
        payload = {
            "year": 2017,
            "pooled_critic_ready": True,
            "input_hashes": hashes,
            "dli_weighting": {
                "method": "pooled Pearson-CRITIC",
                "weights": {criterion: 0.25 for criterion in assistant.net.CRITERIA},
            },
            "authoritative_dli_slices": slices,
            "temporal_dli_authority": {
                "method": "one pooled two-year Pearson-CRITIC calculation",
                "years": [2014, 2017],
                "baseline_evidence_network_result_cid": "a" * 64,
            },
        }
        envelope = {
            "namespace": "network_and_critic_dli_analysis",
            "payload": {
                "operation": "network_and_critic_dli_analysis",
                "payload": payload,
            },
        }
        body = json.dumps(envelope, sort_keys=True).encode()
        cid = hashlib.sha256(body).hexdigest()
        (root / "content_store").mkdir()
        (root / "content_store" / f"{cid}.json").write_bytes(body)
        (root / "runtime").mkdir()
        (root / "runtime" / "result_index.json").write_text(
            json.dumps(
                {
                    "results": {
                        "network:2014": {
                            "content_hash": "a" * 64,
                            "input_hashes": hashes,
                        },
                        "network:2017": {
                            "content_hash": cid,
                            "input_hashes": hashes,
                        },
                    }
                }
            ),
            encoding="utf-8",
        )
        return mrio, demand, hashes, cid, payload

    def _paths(self, root: Path, mrio: Path, demand: Path):
        return (
            mock.patch.object(assistant, "BASE_DIR", root),
            mock.patch.object(assistant, "MRIO_PATH", mrio),
            mock.patch.object(assistant, "COMPANY_PATH", demand),
        )

    def test_both_years_resolve_from_one_active_2017_cid(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mrio, demand, _hashes, _cid, _payload = self._fixture(root)
            patches = self._paths(root, mrio, demand)
            with patches[0], patches[1], patches[2]:
                base = assistant._authoritative_pooled_dli_slice(2014)
                decision = assistant._authoritative_pooled_dli_slice(2017)
            self.assertEqual(set(base["year"]), {2014})
            self.assertEqual(set(decision["year"]), {2017})
            self.assertEqual(base["node_code"].tolist(), decision["node_code"].tolist())

    def test_provisional_2014_is_not_used_when_pooled_pair_is_incomplete(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mrio, demand, _hashes, _cid, _payload = self._fixture(
                root, include_both_slices=False
            )
            patches = self._paths(root, mrio, demand)
            with patches[0], patches[1], patches[2]:
                with self.assertRaisesRegex(RuntimeError, "2014 is unavailable"):
                    assistant._authoritative_pooled_dli_slice(2014)

    def test_temporal_tool_uses_current_network_engine_schema(self):
        frames = {year: pd.DataFrame(_rows(year)) for year in (2014, 2017)}
        with mock.patch.object(
            assistant, "_load_dli", side_effect=lambda year: frames[int(year)]
        ):
            result = assistant.tool_temporal_dli(top_n=2)
        row = result["current_2017_priorities_with_trajectory"][0]
        self.assertIn("dli_rank_2014", row)
        self.assertIn("dli_rank_2017", row)
        self.assertIn("delta_DLI", row)
        self.assertIn("two_period_status", row)
        self.assertNotIn("annual_rank_2017", row)
        self.assertNotIn("delta_DLI_pooled", row)

    def test_spa_mirror_must_match_index_cid_and_immutable_paths(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mrio = root / "input_mrio_completed.xlsx"
            demand = root / "Focal_Company_Demand_Converted.xlsx"
            mrio.write_bytes(b"mrio")
            demand.write_bytes(b"demand")
            hashes = {
                "mrio": hashlib.sha256(b"mrio").hexdigest(),
                "focal_demand": hashlib.sha256(b"demand").hexdigest(),
            }
            rows = [{"path_rank": 1, "path_codes": "AA-a -> BB-b", "contribution": 3.0}]
            envelope = {
                "namespace": "structural_path_analysis",
                "payload": {
                    "operation": "structural_path_analysis",
                    "payload": {"year": 2017, "input_hashes": hashes, "paths": rows},
                },
            }
            body = json.dumps(envelope, sort_keys=True).encode()
            cid = hashlib.sha256(body).hexdigest()
            content = root / "content_store"
            content.mkdir()
            (content / f"{cid}.json").write_bytes(body)
            runtime = root / "runtime"
            active = runtime / "active_analytics"
            active.mkdir(parents=True)
            (runtime / "result_index.json").write_text(
                json.dumps({"results": {"spa:2017": {"content_hash": cid, "input_hashes": hashes}}}),
                encoding="utf-8",
            )
            csv_path = active / "spa_2017.csv"
            pd.DataFrame(rows).to_csv(csv_path, index=False)
            meta_path = active / "spa_2017.json"
            meta_path.write_text(
                json.dumps(
                    {
                        "input_hashes": hashes,
                        "source_result_cid": cid,
                        "frame_sha256": assistant._sha256_file(csv_path),
                    }
                ),
                encoding="utf-8",
            )
            patches = self._paths(root, mrio, demand)
            with patches[0], patches[1], patches[2]:
                self.assertIsNotNone(assistant._runtime_frame("spa", 2017))
                # Rewriting both mutable files cannot change immutable authority.
                pd.DataFrame([{**rows[0], "contribution": 999.0}]).to_csv(csv_path, index=False)
                meta = json.loads(meta_path.read_text(encoding="utf-8"))
                meta["frame_sha256"] = assistant._sha256_file(csv_path)
                meta_path.write_text(json.dumps(meta), encoding="utf-8")
                self.assertIsNone(assistant._runtime_frame("spa", 2017))

    def test_2017_network_persists_both_pooled_slices_under_one_result_cid(self):
        def raw(year: int, shift: float) -> pd.DataFrame:
            return pd.DataFrame(
                {
                    "year": [year] * 4,
                    "node_code": ["AA-a", "BB-b", "CC-c", "DD-d"],
                    "region": ["AA", "BB", "CC", "DD"],
                    "sector": ["a", "b", "c", "d"],
                    "BC": [0.1 + shift, 0.8, 0.4, 0.2],
                    "PR": [0.7, 0.2 + shift, 0.5, 0.1],
                    "CDR": [0.3, 0.1, 0.9 - shift, 0.6],
                    "IC": [0.5, 0.4, 0.2, 0.8 + shift],
                }
            )

        raw14 = raw(2014, 0.0)
        raw17 = raw(2017, 0.05)
        hashes = {"mrio": "1" * 64, "focal_demand": "2" * 64}
        response_cid = "f" * 64
        hotspot_result = type(
            "HotspotResult",
            (),
            {
                "hotspot_count": 1,
                "hotspot_total_footprint": 8.0,
                "company_total_footprint": 10.0,
                "high_dli_threshold": 0.5,
            },
        )()
        service = orchestrator.DataOrchestrator.__new__(orchestrator.DataOrchestrator)
        service._query_lock = None
        service._intervention_governance_lock = None
        with tempfile.TemporaryDirectory() as directory:
            index_path = Path(directory) / "result_index.json"
            index_path.write_text(
                json.dumps(
                    {
                        "results": {
                            "network:2014": {
                                "content_hash": "a" * 64,
                                "input_hashes": hashes,
                            }
                        }
                    }
                ),
                encoding="utf-8",
            )
            with (
                mock.patch.object(orchestrator, "RESULT_INDEX_PATH", index_path),
                mock.patch.object(orchestrator, "active_input_hashes", return_value=hashes),
                mock.patch.object(orchestrator.ae, "load_year", return_value=object()),
                mock.patch.object(orchestrator.ae, "load_company_Y", return_value=object()),
                mock.patch.object(
                    orchestrator.net,
                    "compute_raw_metrics_with_cdr_linkage",
                    return_value=(raw17, object()),
                ),
                mock.patch.object(
                    orchestrator,
                    "load_verified_active_frame",
                    return_value=(raw14, {}),
                ),
                mock.patch.object(
                    orchestrator.cdr_link,
                    "write_cdr_producer_linkage_artifacts",
                    return_value={},
                ),
                mock.patch.object(orchestrator.critic_core, "write_authoritative_artifacts", return_value={}),
                mock.patch.object(orchestrator.node_sda, "verify_node_sda_artifacts", return_value={}),
                mock.patch.object(orchestrator.pd, "read_csv", return_value=pd.DataFrame()),
                mock.patch.object(orchestrator.hotspot_link, "compute_hotspot_leverage", return_value=hotspot_result),
                mock.patch.object(orchestrator.hotspot_link, "write_hotspot_leverage_artifacts", return_value={}),
                mock.patch.object(
                    orchestrator.final_methodology,
                    "run_integrated_methodology",
                    return_value={"integrated_evidence_cid": "e" * 64, "summary": {}},
                ),
                mock.patch.object(
                    orchestrator,
                    "store_content",
                    side_effect=["b" * 64, "c" * 64, "d" * 64, response_cid],
                ),
                mock.patch.object(orchestrator, "write_active_frame_artifact"),
                mock.patch.object(orchestrator, "store_active_analytics_frame") as store_frame,
                mock.patch.object(orchestrator, "record_active_result"),
                mock.patch.object(orchestrator.cdr_link, "bind_cdr_linkage_metadata_to_network_result"),
                mock.patch.object(orchestrator.hotspot_link, "bind_hotspot_leverage_metadata"),
                mock.patch.object(service, "compute_dli_weight_robustness"),
            ):
                response = service.compute_network(2017)

        self.assertEqual(response.content_hash, response_cid)
        self.assertEqual(set(response.payload["authoritative_dli_slices"]), {"2014", "2017"})
        self.assertEqual(len(response.payload["temporal_dli_comparison"]), 4)
        dli_calls = [
            call for call in store_frame.call_args_list if call.args and call.args[0] == "dli"
        ]
        self.assertEqual([call.args[1] for call in dli_calls], [2014, 2017])
        self.assertTrue(
            all(call.kwargs["source_result_cid"] == response_cid for call in dli_calls)
        )


if __name__ == "__main__":
    unittest.main()
