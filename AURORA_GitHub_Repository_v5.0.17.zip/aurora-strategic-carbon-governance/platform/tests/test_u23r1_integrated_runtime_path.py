"""Regression checks for the U23R1 integrated-workspace runtime-path fix."""
from __future__ import annotations

import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]


class IntegratedRuntimePathFixTests(unittest.TestCase):
    def test_root_ui_uses_package_local_runtime(self):
        source = (ROOT / "final_methodology_ui.py").read_text(encoding="utf-8")
        self.assertIn('Path(__file__).resolve().parent / "runtime"', source)
        self.assertNotIn('Path(__file__).resolve().parent.parent / "runtime"', source)

    def test_launcher_binds_shared_runtime_directory(self):
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        self.assertIn('$env:SCIG_RUNTIME_DIR = $runtimeDirectory', launcher)


if __name__ == "__main__":
    unittest.main(verbosity=2)
