"""Aggregate independent expert scores exported by validate_live_llm.py."""
from __future__ import annotations

import argparse
import csv
import json
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Any


SCORE_FIELDS = (
    "strategic_relevance_1_to_5",
    "actionability_1_to_5",
    "groundedness_1_to_5",
    "limitations_1_to_5",
)
CLAIM_COUNT_FIELDS = (
    "verifiable_project_claim_count",
    "supported_project_claim_count",
    "unsupported_critical_project_claim_count",
)
KEY_FIELDS = ("case_id", "run_index", "stage")


def _safe_mean(values: list[float]) -> float | None:
    return round(statistics.mean(values), 6) if values else None


def _normalise_binary(value: str) -> int | None:
    text = str(value or "").strip().casefold()
    if text in {"yes", "y", "true", "1", "aligned"}:
        return 1
    if text in {"no", "n", "false", "0", "misaligned"}:
        return 0
    return None


def _score(value: str, field: str, row_number: int) -> float | None:
    if not str(value or "").strip():
        return None
    try:
        parsed = float(value)
    except ValueError as exc:
        raise ValueError(f"Row {row_number}: {field} must be a number from 1 to 5.") from exc
    if not 1.0 <= parsed <= 5.0:
        raise ValueError(f"Row {row_number}: {field} must be between 1 and 5.")
    return parsed


def _count(value: str, field: str, row_number: int) -> int | None:
    if not str(value or "").strip():
        return None
    try:
        parsed = int(value)
    except ValueError as exc:
        raise ValueError(f"Row {row_number}: {field} must be a non-negative integer.") from exc
    if parsed < 0:
        raise ValueError(f"Row {row_number}: {field} must be non-negative.")
    return parsed


def load_reviews(path: Path) -> list[dict[str, Any]]:
    with path.open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        required = set(KEY_FIELDS) | {"reviewer_id", "aligned_yes_no"} | set(SCORE_FIELDS) | set(CLAIM_COUNT_FIELDS)
        missing = required - set(reader.fieldnames or [])
        if missing:
            raise ValueError(f"The review file is missing columns: {sorted(missing)}")
        rows: list[dict[str, Any]] = []
        for row_number, row in enumerate(reader, start=2):
            if not any(str(value or "").strip() for value in row.values()):
                continue
            if not all(str(row.get(field, "")).strip() for field in (*KEY_FIELDS, "reviewer_id")):
                raise ValueError(f"Row {row_number}: case_id, run_index, stage and reviewer_id are required.")
            parsed = {
                field: _score(row.get(field, ""), field, row_number)
                for field in SCORE_FIELDS
            }
            parsed.update(
                {
                    field: _count(row.get(field, ""), field, row_number)
                    for field in CLAIM_COUNT_FIELDS
                }
            )
            parsed.update(
                {
                    "case_id": str(row["case_id"]).strip(),
                    "run_index": str(row["run_index"]).strip(),
                    "stage": str(row["stage"]).strip(),
                    "reviewer_id": str(row["reviewer_id"]).strip(),
                    "aligned": _normalise_binary(row.get("aligned_yes_no", "")),
                }
            )
            rows.append(parsed)
    if not rows:
        raise ValueError("No completed review rows were found.")
    return rows


def _cohens_kappa(pairs: list[tuple[int, int]]) -> float | None:
    if not pairs:
        return None
    observed = sum(left == right for left, right in pairs) / len(pairs)
    left_rates = {value: sum(left == value for left, _ in pairs) / len(pairs) for value in (0, 1)}
    right_rates = {value: sum(right == value for _, right in pairs) / len(pairs) for value in (0, 1)}
    expected = sum(left_rates[value] * right_rates[value] for value in (0, 1))
    if expected == 1.0:
        return 1.0 if observed == 1.0 else None
    return round((observed - expected) / (1.0 - expected), 6)


def score_reviews(rows: list[dict[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {"review_count": len(rows), "metrics": {}, "agreement": {}}
    for field in SCORE_FIELDS:
        values = [float(row[field]) for row in rows if row[field] is not None]
        result["metrics"][field] = {
            "mean": _safe_mean(values),
            "n": len(values),
            "proportion_at_least_4": (
                round(sum(value >= 4.0 for value in values) / len(values), 6) if values else None
            ),
        }
    aligned = [row["aligned"] for row in rows if row["aligned"] is not None]
    result["metrics"]["aligned_yes_no"] = {
        "proportion_aligned": round(sum(aligned) / len(aligned), 6) if aligned else None,
        "n": len(aligned),
    }
    reviewed_claim_rows = [
        row
        for row in rows
        if row["verifiable_project_claim_count"] is not None
        and row["supported_project_claim_count"] is not None
    ]
    total_verifiable = sum(int(row["verifiable_project_claim_count"]) for row in reviewed_claim_rows)
    total_supported = sum(int(row["supported_project_claim_count"]) for row in reviewed_claim_rows)
    total_critical_unsupported = sum(
        int(row["unsupported_critical_project_claim_count"])
        for row in rows
        if row["unsupported_critical_project_claim_count"] is not None
    )
    result["metrics"]["expert_grounded_claim_precision"] = {
        "supported_claims": total_supported,
        "verifiable_claims": total_verifiable,
        "precision": round(total_supported / total_verifiable, 6) if total_verifiable else None,
        "reviewed_rows": len(reviewed_claim_rows),
        "unsupported_critical_project_claim_count": total_critical_unsupported,
    }
    by_case: dict[tuple[str, str, str], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        by_case[tuple(row[field] for field in KEY_FIELDS)].append(row)
    pairs: list[tuple[int, int]] = []
    for reviews in by_case.values():
        by_reviewer = {row["reviewer_id"]: row for row in reviews if row["aligned"] is not None}
        if len(by_reviewer) != 2:
            continue
        first, second = sorted(by_reviewer)
        pairs.append((by_reviewer[first]["aligned"], by_reviewer[second]["aligned"]))
    result["agreement"] = {
        "paired_case_count": len(pairs),
        "cohens_kappa_aligned_yes_no": _cohens_kappa(pairs),
        "note": "Kappa is reported only where exactly two reviewers independently scored the same case/run/stage.",
    }
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description="Aggregate independent human review scores for live LLM evaluation.")
    parser.add_argument("reviews", type=Path, help="Completed human_review_template.csv file.")
    parser.add_argument(
        "--output",
        type=Path,
        default=None,
        help="JSON report path. Defaults beside the input as human_review_summary.json.",
    )
    args = parser.parse_args()
    result = score_reviews(load_reviews(args.reviews))
    output = args.output or args.reviews.with_name("human_review_summary.json")
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Human-review summary written to {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
