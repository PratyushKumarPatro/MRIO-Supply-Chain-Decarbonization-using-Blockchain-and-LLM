'use strict';

const crypto = require('crypto');
const fs = require('fs');
const path = require('path');
const solc = require('solc');

const root = __dirname;
const contractsDir = path.join(root, 'contracts');
const buildDir = path.join(contractsDir, 'build');
const sourceFiles = fs.readdirSync(contractsDir)
  .filter((name) => name.endsWith('.sol'))
  .sort();

if (sourceFiles.length !== 1 || sourceFiles[0] !== 'StrategicCarbonIntelligenceSystem.sol') {
  throw new Error(
    `Expected exactly one Solidity source file, contracts/StrategicCarbonIntelligenceSystem.sol; found: ${sourceFiles.join(', ')}`
  );
}

const sources = {};
const sourceHasher = crypto.createHash('sha256');
for (const filename of sourceFiles) {
  const content = fs.readFileSync(path.join(contractsDir, filename), 'utf8');
  sources[`contracts/${filename}`] = { content };
  sourceHasher.update(filename, 'utf8');
  sourceHasher.update('\0', 'utf8');
  sourceHasher.update(content, 'utf8');
  sourceHasher.update('\0', 'utf8');
}
const sourceHash = sourceHasher.digest('hex');

const compilerVersion = solc.version();
if (!compilerVersion.startsWith('0.8.19+')) {
  throw new Error(
    `This package is pinned to solc 0.8.19, but npm loaded ${compilerVersion}. ` +
    'Delete node_modules and run npm ci again.'
  );
}

const input = {
  language: 'Solidity',
  sources,
  settings: {
    optimizer: { enabled: true, runs: 200 },
    evmVersion: 'paris',
    outputSelection: {
      '*': {
        '*': ['abi', 'evm.bytecode.object', 'evm.deployedBytecode.object'],
      },
    },
  },
};

const output = JSON.parse(solc.compile(JSON.stringify(input)));
const messages = output.errors || [];
for (const item of messages) {
  const line = item.formattedMessage || item.message;
  if (item.severity === 'error') {
    console.error(line);
  } else {
    console.warn(line);
  }
}
if (messages.some((item) => item.severity === 'error')) {
  process.exit(1);
}

fs.mkdirSync(buildDir, { recursive: true });
for (const directory of [root, buildDir]) {
  for (const filename of fs.readdirSync(directory)) {
    if (/^[A-Za-z0-9]+_sol_[A-Za-z0-9]+\.(abi|bin)$/.test(filename)) {
      fs.rmSync(path.join(directory, filename));
    }
  }
}

const generated = [];
for (const [sourceName, contracts] of Object.entries(output.contracts || {})) {
  const sourceBase = path.basename(sourceName, '.sol');
  for (const [contractName, artifact] of Object.entries(contracts)) {
    const stem = `${sourceBase}_sol_${contractName}`;
    const abiText = JSON.stringify(artifact.abi, null, 2);
    const bytecode = artifact.evm.bytecode.object || '';
    for (const directory of [root, buildDir]) {
      fs.writeFileSync(path.join(directory, `${stem}.abi`), abiText);
      fs.writeFileSync(path.join(directory, `${stem}.bin`), bytecode);
    }
    generated.push({
      source: sourceName,
      contract: contractName,
      abi: `${stem}.abi`,
      bin: `${stem}.bin`,
      bytecodeBytes: bytecode.length / 2,
    });
  }
}

let generatedAt = new Date().toISOString();
const previousBuildPath = path.join(root, 'contract_build.json');
if (fs.existsSync(previousBuildPath)) {
  try {
    const previousBuild = JSON.parse(fs.readFileSync(previousBuildPath, 'utf8'));
    if (
      previousBuild.sourceHash === sourceHash &&
      previousBuild.compiler === compilerVersion &&
      typeof previousBuild.generatedAt === 'string' &&
      previousBuild.generatedAt.length > 0
    ) {
      // Preserve the original build timestamp when identical source is
      // recompiled, so the checked-in build metadata remains reproducible.
      generatedAt = previousBuild.generatedAt;
    }
  } catch (_error) {
    // A malformed prior build record is replaced by a fresh, valid record.
  }
}

const buildInfo = {
  architectureVersion: '5.0.17-u23-evidence-bound-abatement-decision',
  sourceLayout: 'single-solidity-source-four-independent-deployments',
  compiler: compilerVersion,
  generatedAt,
  sourceHash,
  optimizer: input.settings.optimizer,
  evmVersion: input.settings.evmVersion,
  artifacts: generated,
};
for (const directory of [root, buildDir]) {
  fs.writeFileSync(
    path.join(directory, 'contract_build.json'),
    JSON.stringify(buildInfo, null, 2),
  );
}
console.log(
  `Compiled ${generated.length} contract/interface artifacts with ${compilerVersion}; source hash ${sourceHash}.`
);
