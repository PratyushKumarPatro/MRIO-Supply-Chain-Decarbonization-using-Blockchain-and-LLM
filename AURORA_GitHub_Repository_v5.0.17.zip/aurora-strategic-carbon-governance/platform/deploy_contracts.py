"""Shared Solidity artifact and bootstrap-evidence helpers.

In the progressive v5.0.17 deployment, this module no longer submits the four
constructor transactions as one command-line operation. ``dapp_lifecycle.py``
imports its source-hash, artifact and evidence helpers, while the responsible
stakeholder deploys each contract from the Streamlit Blockchain page after the
preceding business stage is complete.
"""
from __future__ import annotations

import hashlib
import json
import os
import shutil
import subprocess
from pathlib import Path
from typing import Any

from web3 import Web3

BASE_DIR = Path(__file__).resolve().parent
RPC_URL = os.environ.get("RPC_URL", "http://127.0.0.1:8545")
ARTIFACT_DIR = Path(os.environ.get("ARTIFACT_DIR", str(BASE_DIR)))
CONTENT_STORE = BASE_DIR / "content_store"
RUNTIME_DIR = BASE_DIR / "runtime"

ROLE_CODES = {
    "RegulatoryAuthority": 1,
    "MRIODataProvider": 2,
    "FocalCompany": 3,
    "RegistrationOracle": 4,
    "UpstreamAnalyticsOracle": 5,
    "GovernanceOracle": 6,
    "QueryOracle": 7,
}


def contract_source_hash() -> str:
    """Return the deterministic SHA-256 used by compile_contracts.js."""
    hasher = hashlib.sha256()
    contracts_dir = BASE_DIR / "contracts"
    for source_path in sorted(contracts_dir.glob("*.sol"), key=lambda item: item.name):
        hasher.update(source_path.name.encode("utf-8"))
        hasher.update(b"\0")
        hasher.update(source_path.read_bytes())
        hasher.update(b"\0")
    return hasher.hexdigest()


def _artifacts_valid(required: list[Path]) -> bool:
    build_info_path = ARTIFACT_DIR / "contract_build.json"
    if not all(path.exists() and path.stat().st_size > 0 for path in required):
        return False
    if not build_info_path.exists():
        return False
    try:
        build_info = json.loads(build_info_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False
    return (
        str(build_info.get("compiler", "")).startswith("0.8.19+")
        and build_info.get("sourceHash") == contract_source_hash()
        and build_info.get("architectureVersion")
        == "5.0.17-u23-evidence-bound-abatement-decision"
    )


def ensure_artifacts() -> None:
    required = [
        ARTIFACT_DIR / "StrategicCarbonIntelligenceSystem_sol_Registration.abi",
        ARTIFACT_DIR / "StrategicCarbonIntelligenceSystem_sol_Registration.bin",
        ARTIFACT_DIR / "StrategicCarbonIntelligenceSystem_sol_UpstreamCarbonEmissionsAnalysis.abi",
        ARTIFACT_DIR / "StrategicCarbonIntelligenceSystem_sol_UpstreamCarbonEmissionsAnalysis.bin",
        ARTIFACT_DIR / "StrategicCarbonIntelligenceSystem_sol_HotspotsManagementAndGovernance.abi",
        ARTIFACT_DIR / "StrategicCarbonIntelligenceSystem_sol_HotspotsManagementAndGovernance.bin",
        ARTIFACT_DIR / "StrategicCarbonIntelligenceSystem_sol_QueryManagement.abi",
        ARTIFACT_DIR / "StrategicCarbonIntelligenceSystem_sol_QueryManagement.bin",
    ]
    if _artifacts_valid(required):
        return

    print(
        "Contract artifacts are missing or stale; compiling the current Solidity "
        "sources with the npm-pinned solc 0.8.19 compiler..."
    )
    npm_command = "npm.cmd" if os.name == "nt" else "npm"
    subprocess.run([npm_command, "run", "compile"], cwd=BASE_DIR, check=True)

    if not _artifacts_valid(required):
        missing = [
            str(path.name)
            for path in required
            if not path.exists() or path.stat().st_size == 0
        ]
        raise RuntimeError(
            "Solidity compilation did not create a source-matched build. "
            f"Missing artifacts: {missing}; expected source hash: {contract_source_hash()}"
        )


def load_artifact(name: str):
    with (ARTIFACT_DIR / f"{name}.abi").open(encoding="utf-8") as handle:
        abi = json.load(handle)
    bytecode = "0x" + (ARTIFACT_DIR / f"{name}.bin").read_text(encoding="utf-8").strip()
    return abi, bytecode


def deploy(w3: Web3, abi, bytecode: str, from_addr: str, *constructor_args):
    contract_type = w3.eth.contract(abi=abi, bytecode=bytecode)
    tx_hash = contract_type.constructor(*constructor_args).transact({"from": from_addr})
    receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
    return receipt.contractAddress, receipt


def store_bootstrap_evidence(label: str, address: str, role_code: int) -> str:
    CONTENT_STORE.mkdir(parents=True, exist_ok=True)
    payload = {
        "type": "reference-deployment-registration-evidence",
        "label": label,
        "address": address,
        "requested_role": role_code,
        "notice": (
            "This local deployment evidence is verified by the Registration Oracle against "
            "deployment.json. Replace with governed credentials in production."
        ),
    }
    body = json.dumps(payload, sort_keys=True, indent=2).encode("utf-8")
    content_hash = hashlib.sha256(body).hexdigest()
    (CONTENT_STORE / f"{content_hash}.json").write_bytes(body)
    (CONTENT_STORE / content_hash).write_bytes(body)
    return content_hash


def clean_runtime() -> None:
    if RUNTIME_DIR.exists():
        shutil.rmtree(RUNTIME_DIR)
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)


def main() -> None:
    """Validate/compile artifacts for the guided platform deployment.

    Contract constructor transactions are intentionally not submitted here.
    They are executed one stage at a time from the Streamlit Blockchain page by
    the responsible stakeholder account.
    """
    ensure_artifacts()
    print("Solidity artifacts are source-matched and ready.")
    print("This progressive build does not deploy contracts from deploy_contracts.py.")
    print("Start Ganache, run start_dapp_lifecycle.ps1, then deploy each contract from Streamlit -> Governance & Audit Control.")


if __name__ == "__main__":
    main()
