"""
spa_engine.py -- Structural Path Analysis.

The exact SPA tier totals are calculated separately by matrix powers in the
Data Orchestrator.  This module provides a bounded, screened ranking of
individual country-sector paths for explanation and decision support.

A dense 455-node MRIO network cannot be exhaustively materialized through
multiple upstream tiers: the number of path records grows combinatorially.
The implementation therefore applies two complementary controls:

* a local supplier screen retains branches with the greatest embodied-carbon
  continuation potential at each expansion; and
* a global beam applies the same carbon-potential priority to partial paths at
  each depth.

Repeated-node walks are retained within the finite depth bound because exact
matrix-power tier totals include cyclic production requirements. Low- or
zero-direct-emission intermediaries remain expandable when they transmit
important upstream embodied emissions.

The screen is explanatory rather than authoritative for total coverage.  The
result package always reports the actual screened-path coverage and the exact
matrix-power coverage separately.  U17 reports the smallest contribution-ranked
set reaching at least 87% of the complete focal-company footprint.  There is no
additional fixed row cap inside the already bounded screened universe.  U19
adds bounded adaptive expansion: if the initial screen is insufficient, wider
and deeper screens are tried deterministically.  A caller still receives the
best bounded attempt when the target is unreachable so it can diagnose the
shortfall, but the orchestrator must not commit or fulfil that attempt as a
governed SPA result.
"""

from __future__ import annotations

from dataclasses import dataclass
import heapq
from typing import Iterable

import numpy as np
import pandas as pd

from analytics_engine import MRIOYear


SPA_COVERAGE_TOLERANCE = 1e-10


@dataclass(frozen=True)
class SPAConfig:
    """Controls for screened individual-path enumeration.

    ``max_depth`` is the deepest individual path reported.  ``exact_max_tier``
    controls the exact matrix-power convergence calculation.  Exact tier totals
    are not truncated by the beam; they are computed by matrix powers in the
    orchestrator.  ``beam_width`` bounds the number of partial paths carried
    between depths. ``max_reported_paths`` is an optional emergency serialization
    cap; U17 disables it by default so the empirical path count is determined by
    the 87%-of-total-footprint stopping rule.
    """

    max_depth: int = 5
    exact_max_tier: int = 30
    top_k_per_hop: int = 22
    beam_width: int = 5_000
    max_reported_paths: int | None = None
    min_coefficient: float = 1e-5
    cumulative_target: float = 0.87


def adaptive_coverage_configs(
    base: SPAConfig,
    node_count: int,
) -> tuple[SPAConfig, ...]:
    """Return a deterministic, resource-bounded SPA expansion schedule.

    The first item is always ``base``. Later attempts expand the local branch
    screen, global beam and depth while lowering the coefficient floor. The
    schedule intentionally stops at three attempts; failure after the final
    attempt is an explicit analytical failure, not permission to publish a
    below-target result.
    """

    nodes = int(node_count)
    if nodes <= 0:
        raise ValueError("SPA node_count must be positive.")
    attempts = [base]
    schedules = (
        (1, 2, 2, 0.1),
        (2, 4, 3, 0.01),
    )
    for depth_increment, beam_multiplier, hop_multiplier, coefficient_multiplier in schedules:
        attempts.append(
            SPAConfig(
                max_depth=max(
                    int(base.max_depth),
                    min(max(int(base.max_depth) + depth_increment, 0), 8),
                ),
                exact_max_tier=int(base.exact_max_tier),
                top_k_per_hop=min(
                    nodes,
                    max(int(base.top_k_per_hop) * hop_multiplier, int(base.top_k_per_hop)),
                ),
                beam_width=min(
                    max(int(base.beam_width) * beam_multiplier, int(base.beam_width)),
                    max(int(base.beam_width), 20_000),
                ),
                max_reported_paths=base.max_reported_paths,
                min_coefficient=max(
                    0.0, float(base.min_coefficient) * coefficient_multiplier
                ),
                cumulative_target=float(base.cumulative_target),
            )
        )
    # Tiny/custom configurations can collapse to the same effective attempt.
    # Preserve order while avoiding redundant recomputation.
    return tuple(dict.fromkeys(attempts))


# (chain, coefficient_product, contribution)
_PathState = tuple[tuple[int, ...], float, float]


def _technical_coefficients(mrio_year: MRIOYear) -> np.ndarray:
    """Return A while avoiding invalid divisions for zero-output columns."""

    A = np.zeros_like(mrio_year.Z, dtype=float)
    positive = np.asarray(mrio_year.X, dtype=float) > 0
    A[:, positive] = mrio_year.Z[:, positive] / mrio_year.X[positive][np.newaxis, :]
    return A


def _row_from_state(mrio_year: MRIOYear, state: _PathState) -> dict:
    chain, coefficient_product, contribution = state
    return {
        "depth": len(chain) - 1,
        "path_nodes": tuple(int(node) for node in chain),
        "path_codes": " <- ".join(str(mrio_year.node_codes[node]) for node in chain),
        "flow_reaching_emitting_node": float(coefficient_product),
        "contribution": float(contribution),
    }


def _top_states(
    states: Iterable[_PathState],
    limit: int,
    embodied_intensity: np.ndarray,
) -> list[_PathState]:
    """Return states with the largest remaining embodied-carbon potential.

    Ranking a partial path only by the direct intensity of its current node can
    incorrectly discard a low-emitting intermediary that leads to an important
    upstream emitter.  ``flow * embodied_intensity[current_node]`` measures the
    complete Leontief carbon potential carried by the partial branch and is the
    appropriate screening priority.
    """

    if limit <= 0:
        return []
    return heapq.nlargest(
        limit,
        states,
        key=lambda item: (
            float(item[1] * embodied_intensity[item[0][-1]]),
            float(item[2]),
            tuple(-node for node in item[0]),
        ),
    )


def trace_paths(
    mrio_year: MRIOYear,
    Y: np.ndarray,
    cfg: SPAConfig = SPAConfig(),
) -> tuple[pd.DataFrame, float]:
    """Return a bounded ranking of screened individual SPA paths.

    The contribution of a path ending at upstream node ``i`` is
    ``f_i * product(A links) * y_j``. Every depth-zero demand node is carried
    forward; subsequent depths are expanded from a global beam ranked by the
    complete embodied-carbon potential remaining on each partial path. The
    returned DataFrame is therefore bounded by approximately
    ``nonzero(Y) + max_depth*beam_width`` before coverage selection.
    """

    Y = np.asarray(Y, dtype=float).reshape(-1)
    if len(Y) != len(mrio_year.node_codes):
        raise ValueError(
            f"SPA demand vector has {len(Y)} elements; expected {len(mrio_year.node_codes)}."
        )
    if not np.isfinite(Y).all() or (Y < 0).any():
        raise ValueError("SPA demand vector must contain finite, non-negative values.")

    A = _technical_coefficients(mrio_year)
    leontief = getattr(mrio_year, "L", None)
    if leontief is None:
        leontief = getattr(mrio_year, "_L", None)
    if leontief is None:
        leontief = np.linalg.inv(np.eye(A.shape[0], dtype=float) - A)
    embodied_intensity = np.asarray(mrio_year.fE, dtype=float) @ np.asarray(
        leontief, dtype=float
    )
    total_footprint = float(mrio_year.footprint(Y))
    if total_footprint < 0:
        raise ValueError("SPA total footprint must be non-negative.")

    demand_nodes = np.flatnonzero(Y > 0)
    current: list[_PathState] = []
    retained_records: list[dict] = []

    for j in demand_nodes:
        flow = float(Y[j])
        contribution = float(mrio_year.fE[j] * flow)
        state: _PathState = ((int(j),), flow, contribution)
        current.append(state)
        if contribution > 0.0:
            retained_records.append(_row_from_state(mrio_year, state))

    # Carry every depth-zero demand node into the first expansion.  From depth
    # one onward, the global beam bounds memory and runtime deterministically.
    current = _top_states(
        current, max(cfg.beam_width, len(current)), embodied_intensity
    )

    for _depth in range(1, cfg.max_depth + 1):
        next_candidates: list[_PathState] = []
        for chain, flow, _contribution in current:
            current_node = chain[-1]
            column = A[:, current_node]
            candidates = np.flatnonzero(column > cfg.min_coefficient)
            if candidates.size == 0:
                continue

            # Rank local suppliers by full embodied-carbon continuation
            # potential, then immediate path emissions and node index.
            ordered = sorted(
                (int(index) for index in candidates),
                key=lambda index: (
                    -float(flow * column[index] * embodied_intensity[index]),
                    -float(flow * column[index] * mrio_year.fE[index]),
                    index,
                ),
            )[: cfg.top_k_per_hop]

            for supplier in ordered:
                new_flow = float(flow * column[supplier])
                new_contribution = float(mrio_year.fE[supplier] * new_flow)
                if (
                    not np.isfinite(new_flow)
                    or new_flow <= 0.0
                    or not np.isfinite(new_contribution)
                    or new_contribution < 0.0
                ):
                    continue
                next_candidates.append(
                    (chain + (supplier,), new_flow, new_contribution)
                )

        if not next_candidates:
            break

        current = _top_states(next_candidates, cfg.beam_width, embodied_intensity)
        retained_records.extend(
            _row_from_state(mrio_year, state)
            for state in current
            if state[2] > 0.0
        )

    columns = [
        "depth",
        "path_nodes",
        "path_codes",
        "flow_reaching_emitting_node",
        "contribution",
        "path_rank",
        "terminal_emitter_index",
        "terminal_emitter_node",
        "terminal_emitter_hotspot_rank",
        "terminal_emitter_in_top15",
        "individual_share_of_company_footprint",
        "cumulative_contribution",
        "cumulative_share",
    ]
    if not retained_records:
        return pd.DataFrame(columns=columns), total_footprint

    frame = pd.DataFrame(retained_records)
    frame = frame.sort_values(
        ["contribution", "depth", "path_codes"],
        ascending=[False, True, True],
        kind="mergesort",
    ).reset_index(drop=True)
    frame["path_rank"] = np.arange(1, len(frame) + 1, dtype=int)
    frame["terminal_emitter_index"] = frame["path_nodes"].map(
        lambda nodes: int(nodes[-1])
    )
    frame["terminal_emitter_node"] = frame["terminal_emitter_index"].map(
        lambda index: str(mrio_year.node_codes[index])
    )
    node_footprints = np.asarray(mrio_year.footprint_by_node(Y), dtype=float)
    hotspot_order = sorted(
        range(len(node_footprints)),
        key=lambda index: (
            -float(node_footprints[index]),
            str(mrio_year.node_codes[index]),
        ),
    )
    hotspot_rank = {node_index: rank for rank, node_index in enumerate(hotspot_order, start=1)}
    frame["terminal_emitter_hotspot_rank"] = frame["terminal_emitter_index"].map(
        hotspot_rank
    )
    frame["terminal_emitter_in_top15"] = (
        frame["terminal_emitter_hotspot_rank"] <= min(15, len(hotspot_order))
    )
    if total_footprint > 0:
        frame["individual_share_of_company_footprint"] = (
            frame["contribution"] / total_footprint
        )
        frame["cumulative_contribution"] = frame["contribution"].cumsum()
        frame["cumulative_share"] = frame["contribution"].cumsum() / total_footprint
    else:
        frame["individual_share_of_company_footprint"] = 0.0
        frame["cumulative_contribution"] = 0.0
        frame["cumulative_share"] = 0.0
    return frame, total_footprint


def top_paths_to_threshold(
    df: pd.DataFrame,
    cfg: SPAConfig = SPAConfig(),
    total_footprint: float | None = None,
) -> tuple[pd.DataFrame, bool]:
    """Return the minimum complete-path set reaching the configured target.

    When ``total_footprint`` is supplied, contributions are validated, ranked
    deterministically, and cumulative share is recomputed against that complete
    footprint.  The final path is retained intact, so achieved coverage may
    slightly exceed the target.  When the bounded screened universe cannot
    reach the target, all screened rows are returned unless an explicit
    emergency cap is configured.
    """

    if df.empty:
        return df.head(0).copy(), False

    target = float(cfg.cumulative_target)
    if not np.isfinite(target) or not 0.0 < target <= 1.0:
        raise ValueError("SPA cumulative_target must be finite and in the interval (0, 1].")
    ranked = df.copy()
    if total_footprint is not None:
        total = float(total_footprint)
        if not np.isfinite(total) or total < 0.0:
            raise ValueError("SPA total_footprint must be finite and non-negative.")
        if "contribution" not in ranked.columns:
            raise ValueError("SPA path rows must include contribution.")
        contributions = pd.to_numeric(ranked["contribution"], errors="coerce")
        if contributions.isna().any() or not np.isfinite(contributions.to_numpy(dtype=float)).all():
            raise ValueError("SPA path contribution must contain finite numeric values.")
        if (contributions < 0.0).any():
            raise ValueError("SPA path contribution must be non-negative.")
        if "path_codes" in ranked.columns and ranked["path_codes"].astype(str).duplicated().any():
            raise ValueError("SPA path_codes must be unique within the screened universe.")
        sort_columns = ["contribution"]
        ascending = [False]
        if "depth" in ranked.columns:
            sort_columns.append("depth")
            ascending.append(True)
        if "path_codes" in ranked.columns:
            sort_columns.append("path_codes")
            ascending.append(True)
        ranked = ranked.sort_values(
            sort_columns, ascending=ascending, kind="mergesort"
        ).reset_index(drop=True)
        ranked["path_rank"] = np.arange(1, len(ranked) + 1, dtype=int)
        if total > 0.0:
            ranked["individual_share_of_company_footprint"] = (
                pd.to_numeric(ranked["contribution"], errors="raise") / total
            )
            ranked["cumulative_contribution"] = pd.to_numeric(
                ranked["contribution"], errors="raise"
            ).cumsum()
            ranked["cumulative_share"] = (
                pd.to_numeric(ranked["contribution"], errors="raise").cumsum() / total
            )
        else:
            ranked["individual_share_of_company_footprint"] = 0.0
            ranked["cumulative_contribution"] = 0.0
            ranked["cumulative_share"] = 0.0
    elif "cumulative_share" not in ranked.columns:
        raise ValueError("SPA path rows must include cumulative_share when total_footprint is omitted.")

    cumulative = pd.to_numeric(ranked["cumulative_share"], errors="coerce")
    if cumulative.isna().any() or not np.isfinite(cumulative.to_numpy(dtype=float)).all():
        raise ValueError("SPA cumulative_share must contain finite numeric values.")
    if (cumulative.diff().dropna() < -1e-12).any():
        raise ValueError("SPA cumulative_share must be monotonically non-decreasing.")

    reached = cumulative >= target
    if bool(reached.any()):
        cutoff = int(np.flatnonzero(reached.to_numpy())[0]) + 1
        if cfg.max_reported_paths is not None:
            if int(cfg.max_reported_paths) <= 0:
                raise ValueError("SPA max_reported_paths must be positive when configured.")
            cutoff = min(cutoff, int(cfg.max_reported_paths))
        subset = ranked.iloc[:cutoff].copy()
        threshold_reached = bool(
            float(subset["cumulative_share"].iloc[-1]) >= target
        )
        return subset, threshold_reached

    if cfg.max_reported_paths is None:
        return ranked.copy(), False
    if int(cfg.max_reported_paths) <= 0:
        raise ValueError("SPA max_reported_paths must be positive when configured.")
    return ranked.head(int(cfg.max_reported_paths)).copy(), False


def trace_paths_to_threshold_adaptive(
    mrio_year: MRIOYear,
    Y: np.ndarray,
    cfg: SPAConfig = SPAConfig(),
) -> tuple[pd.DataFrame, pd.DataFrame, float, SPAConfig, list[dict[str, float | int | bool]]]:
    """Trace paths with bounded expansion until the coverage target is met.

    Returns the screened universe, minimum whole-path prefix, complete footprint,
    selected configuration and an audit record for every attempt. If no bounded
    attempt reaches the target, the last (widest) attempt is returned with its
    audit record marked ``threshold_reached=False``. Governed callers are
    expected to fail closed in that case.
    """

    attempts: list[dict[str, float | int | bool]] = []
    final_screened = pd.DataFrame()
    final_reported = pd.DataFrame()
    final_total = 0.0
    selected_config = cfg

    for attempt_number, attempt_config in enumerate(
        adaptive_coverage_configs(cfg, len(mrio_year.node_codes)), start=1
    ):
        screened, total = trace_paths(mrio_year, Y, attempt_config)
        reported, reached = top_paths_to_threshold(screened, attempt_config, total)
        screened_share = (
            float(screened["cumulative_share"].iloc[-1])
            if not screened.empty
            else 0.0
        )
        reported_share = (
            float(reported["cumulative_share"].iloc[-1])
            if not reported.empty
            else 0.0
        )
        # Recheck the returned prefix rather than relying only on the selector's
        # flag. This is the boundary consumed by the orchestrator.
        reached = bool(
            reached
            and reported_share + SPA_COVERAGE_TOLERANCE
            >= float(attempt_config.cumulative_target)
        )
        attempts.append(
            {
                "attempt": attempt_number,
                "max_depth": int(attempt_config.max_depth),
                "top_k_per_hop": int(attempt_config.top_k_per_hop),
                "beam_width": int(attempt_config.beam_width),
                "min_coefficient": float(attempt_config.min_coefficient),
                "screened_path_count": int(len(screened)),
                "reported_path_count": int(len(reported)),
                "screened_cumulative_share": screened_share,
                "reported_cumulative_share": reported_share,
                "threshold_reached": reached,
            }
        )
        final_screened = screened
        final_reported = reported
        final_total = float(total)
        selected_config = attempt_config
        if reached:
            break

    return final_screened, final_reported, final_total, selected_config, attempts


if __name__ == "__main__":
    from analytics_engine import load_company_Y, load_year

    config = SPAConfig()
    for reference_year in (2014, 2017):
        mrio = load_year("input_mrio_completed.xlsx", reference_year)
        company_demand = load_company_Y(
            "Focal_Company_Demand_Converted.xlsx", reference_year
        )
        all_screened, total = trace_paths(mrio, company_demand, config)
        reported, reached = top_paths_to_threshold(all_screened, config, total)
        screened_coverage = (
            float(all_screened["cumulative_share"].iloc[-1])
            if not all_screened.empty
            else 0.0
        )
        reported_coverage = (
            float(reported["cumulative_share"].iloc[-1])
            if not reported.empty
            else 0.0
        )
        print(f"\n=== {reference_year} ===")
        print(f"Screened paths retained before report cap: {len(all_screened):,}")
        print(f"Paths serialized: {len(reported):,}")
        print(f"Screened coverage: {screened_coverage:.2%}")
        print(f"Reported coverage: {reported_coverage:.2%}")
        print(f"Target reached: {reached}")
        print(f"Total footprint: {total:.6f}")
