"""Regression tests for the U9 AURORA Otsu calibration and decision-trace exports."""
from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from io import BytesIO
from pathlib import Path

from openpyxl import load_workbook

import aurora_reporting as reporting

ROOT = Path(__file__).resolve().parent
SOLIDITY_SHA256 = json.loads(
    (ROOT / "U19_CONTRACT_LOGIC_DELTA_SHA256.json").read_text(encoding="utf-8")
)["u19_solidity_source_sha256"]


def _candidate(
    node: str,
    *,
    sector: str = "nmm",
    production: float = 0.9,
    market: float = 0.9,
    reduction: float = 0.2,
    linkage_code: int = 1,
    pareto: bool = True,
    recommended: bool = True,
    uae_share: float = 0.1,
) -> dict:
    return {
        "sector": sector,
        "current_nodes": [f"ARE-{sector}"],
        "node_code": node,
        "region": node.split("-", 1)[0],
        "sector_demand": 1000.0,
        "baseline_embodied_multiplier": 0.001,
        "candidate_embodied_multiplier": 0.001 * (1.0 - reduction),
        "relative_multiplier_reduction": reduction,
        "modelled_full_reallocation_opportunity": max(0.0, 1000.0 * 0.001 * reduction),
        "opportunity_share_of_company_footprint": 0.01,
        "production_sector_similarity": production,
        "production_region_similarity": 0.5,
        "market_sector_similarity": market,
        "market_region_similarity": 0.5,
        "direct_flow_to_focal_region_construction": 1.0 if linkage_code == 1 else 0.0,
        "focal_consumer_intermediate_sales_share": 0.01,
        "intermediate_sales_to_focal_region": 10.0 if linkage_code <= 2 else 0.0,
        "focal_region_intermediate_sales_share": uae_share,
        "gcc_intermediate_sales_share": 0.2,
        "observed_linkage_tier": {
            1: "observed direct flow to focal-region construction",
            2: "observed flow to other focal-region industries",
            3: "observed GCC intermediate-market flow",
            4: "positive sector output but no observed relevant intermediate flow",
        }[linkage_code],
        "observed_linkage_code": linkage_code,
        "structural_analogue": production >= 0.8 and market >= 0.7,
        "lower_carbon_multiplier": reduction > 0.0,
        "pareto_efficient": pareto,
        "eligible_for_regional_investigation": production >= 0.8 and market >= 0.7 and reduction > 0.0 and linkage_code <= 3,
        "recommended_for_investigation": recommended,
        "DLI": 0.25,
        "dli_rank": 12,
        "BC_norm": 0.1,
        "PR_norm": 0.2,
        "CDR_norm": 0.3,
        "IC_norm": 0.4,
        "dominant_dli_component": "intervention criticality",
        "dli_governance_lens": "Synthetic governance evidence.",
        "recommendation": "Priority regional procurement investigation" if recommended else "Additional candidate",
    }


class AuroraDecisionTraceReportingTests(unittest.TestCase):
    def setUp(self):
        self.primary = {
            "method": "AURORA",
            "method_name": "Analogue-based Upstream Regional Opportunity and Resilience Assessment",
            "year": 2017,
            "configuration": {
                "production_similarity_threshold": 0.75,
                "market_similarity_threshold": 0.745,
                "similarity_threshold_method": "exact_bin_free_otsu",
                "similarity_threshold_calibration_year": 2014,
                "minimum_carbon_improvement": 0.0,
                "top_candidates_per_sector": 1,
            },
            "threshold_calibration": {
                "method": "exact_bin_free_otsu",
                "calibration_year": 2014,
                "candidate_universe_count": 5,
                "production": {
                    "threshold": 0.75,
                    "sample_count": 5,
                    "lower_class_count": 2,
                    "upper_class_count": 3,
                    "lower_class_mean": 0.4,
                    "upper_class_mean": 0.9,
                    "lower_boundary_value": 0.6,
                    "upper_boundary_value": 0.9,
                    "between_class_variance": 0.1,
                },
                "market": {
                    "threshold": 0.745,
                    "sample_count": 5,
                    "lower_class_count": 1,
                    "upper_class_count": 4,
                    "lower_class_mean": 0.4,
                    "upper_class_mean": 0.9,
                    "lower_boundary_value": 0.59,
                    "upper_boundary_value": 0.9,
                    "between_class_variance": 0.08,
                },
            },
            "company_footprint": 100.0,
            "demanded_sector_count": 1,
            "current_mix": [],
            "all_candidates": [
                _candidate("BHR-nmm", recommended=True, pareto=True, uae_share=0.2),
                _candidate("QAT-nmm", recommended=False, pareto=True, uae_share=0.15),
                _candidate("SAU-nmm", recommended=False, pareto=False, uae_share=0.1),
                _candidate("OMN-nmm", production=0.5, recommended=False, pareto=False),
                _candidate("ROW-nmm", reduction=-0.1, recommended=False, pareto=False),
            ],
            "sector_summaries": [],
            "claim_boundary": "Supplier-level due diligence remains required.",
            "dli_rule": "DLI is a governance lens only.",
            "input_hashes": {"mrio": "a" * 64, "focal_demand": "b" * 64},
            "network_result_hash": "c" * 64,
        }
        self.comparison = {
            "year": 2014,
            "all_candidates": [
                _candidate("BHR-nmm", recommended=False, pareto=True, uae_share=0.18),
                _candidate("QAT-nmm", market=0.4, recommended=False, pareto=False, uae_share=0.14),
            ],
        }

    def test_enrichment_exposes_complete_gate_propagation(self):
        result = reporting.enrich_aurora_result(self.primary, self.comparison)
        self.assertEqual(result["reporting_schema_version"], "1.1")
        self.assertEqual(result["decision_funnel_summary"]["same_sector_candidates"], 5)
        self.assertEqual(result["decision_funnel_summary"]["all_eligibility_gates_passed"], 3)
        self.assertEqual(result["decision_funnel_summary"]["pareto_efficient_candidates"], 2)
        self.assertEqual(result["decision_funnel_summary"]["displayed_recommendations"], 1)
        self.assertEqual(result["decision_funnel_summary"]["stable_displayed_recommendations"], 1)
        first = result["recommended_opportunities"][0]
        self.assertTrue(first["production_similarity_gate_passed"])
        self.assertTrue(first["market_similarity_gate_passed"])
        self.assertTrue(first["carbon_improvement_gate_passed"])
        self.assertTrue(first["linkage_gate_passed"])
        self.assertTrue(first["pareto_efficient"])
        self.assertTrue(first["selected_within_display_cap"])
        self.assertTrue(first["stable_reference_year_signal"])
        self.assertEqual(first["comparison_observed_linkage_code"], 1)
        self.assertIn("Pareto efficient=pass", first["decision_trace"])

    def test_decision_status_distinguishes_cap_dominance_and_gate_failure(self):
        result = reporting.enrich_aurora_result(self.primary, self.comparison)
        lookup = {row["node_code"]: row for row in result["all_candidates"]}
        self.assertEqual(lookup["QAT-nmm"]["decision_status"], "Pareto efficient — outside display cap")
        self.assertEqual(lookup["SAU-nmm"]["decision_status"], "Eligible — Pareto dominated")
        self.assertEqual(lookup["OMN-nmm"]["decision_status"], "Ineligible — production similarity")
        self.assertEqual(lookup["ROW-nmm"]["decision_status"], "Ineligible — no carbon improvement")

    def test_workbook_contains_complete_result_sheets_and_formats(self):
        result = reporting.enrich_aurora_result(self.primary, self.comparison)
        body = reporting.build_excel_workbook_bytes(result, source_result_cid="d" * 64)
        workbook = load_workbook(BytesIO(body), data_only=False)
        expected = {
            "AURORA_Summary",
            "Threshold_Calibration",
            "Decision_Funnel",
            "Sector_Funnel",
            "Recommended",
            "Pareto_Candidates",
            "Eligible_Candidates",
            "Decision_Trace",
            "All_Candidates",
            "Cross_Year_Evidence",
            "Current_Mix",
            "Configuration",
            "Data_Dictionary",
            "Provenance_Notes",
        }
        self.assertEqual(set(workbook.sheetnames), expected)
        ws = workbook["Recommended"]
        headers = [cell.value for cell in ws[1]]
        self.assertIn("pareto_efficient", headers)
        self.assertIn("focal_region_intermediate_sales_share", headers)
        self.assertIn("baseline_embodied_multiplier", headers)
        self.assertEqual(ws.freeze_panes, "A2")
        pct_col = headers.index("relative_multiplier_reduction") + 1
        self.assertEqual(ws.cell(2, pct_col).number_format, "0.00%")
        dictionary = workbook["Data_Dictionary"]
        dictionary_headers = [cell.value for cell in dictionary[1]]
        self.assertEqual(dictionary_headers, ["field", "definition", "unit_or_scale", "decision_role"])
        self.assertIn("pareto_efficient", [dictionary.cell(row=row, column=1).value for row in range(2, dictionary.max_row + 1)])

    def test_runtime_exports_are_cid_bound_and_complete(self):
        result = reporting.enrich_aurora_result(self.primary, self.comparison)
        with tempfile.TemporaryDirectory() as tmp:
            manifest = reporting.write_runtime_exports(
                result,
                tmp,
                year=2017,
                source_result_cid="e" * 64,
            )
            self.assertEqual(manifest["source_result_cid"], "e" * 64)
            for key in [
                "workbook",
                "threshold_calibration",
                "recommended",
                "pareto_candidates",
                "decision_funnel",
                "all_candidates",
                "cross_year_evidence",
                "data_dictionary",
                "provenance_notes",
            ]:
                path = Path(manifest["files"][key]["path"])
                self.assertTrue(path.is_file())
                self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), manifest["files"][key]["sha256"])
            saved = json.loads(Path(manifest["manifest_path"]).read_text(encoding="utf-8"))
            self.assertEqual(saved["source_result_cid"], "e" * 64)

    def test_u9_aurora_threshold_logic_and_reviewed_u19_solidity_boundary(self):
        root_engine = (ROOT / "sourcing_opportunity_engine.py").read_text(encoding="utf-8")
        streamlit_engine = (ROOT / "streamlit_app" / "sourcing_opportunity_engine.py").read_text(encoding="utf-8")
        self.assertIn("Compatibility bridge to the single authoritative U16 module", streamlit_engine)
        self.assertIn("parent.parent / 'sourcing_opportunity_engine.py'", streamlit_engine)
        self.assertIn("def exact_bin_free_otsu", root_engine)
        self.assertIn("def calibrate_exact_otsu_config", root_engine)
        self.assertIn('similarity_threshold_method="exact_bin_free_otsu"', root_engine)
        self.assertEqual(
            hashlib.sha256((ROOT / "assurance_history" / "release_documents" / "U19_StrategicCarbonIntelligenceSystem.sol").read_bytes()).hexdigest(),
            SOLIDITY_SHA256,
        )

    def test_ui_and_orchestrator_expose_decision_trace_and_exports(self):
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        assistant = (ROOT / "strategic_assistant.py").read_text(encoding="utf-8")
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        for marker in [
            "Candidate decision funnel",
            "Pareto-efficient candidates",
            "Candidate-level gate propagation",
            "Download complete AURORA workbook",
            "Download complete candidate table (CSV)",
            "UAE intermediate-sales share (%)",
        ]:
            self.assertIn(marker, app)
        self.assertIn("aurora_report.enrich_aurora_result(result, comparison)", orchestrator)
        self.assertIn("aurora_report.write_runtime_exports", orchestrator)
        self.assertIn('"pareto_efficient_candidates": result.get', assistant)
        for key in (
            "integrated_methodology_extension_id",
            "aurora_similarity_threshold_extension_id",
            "dli_in_app_execution_extension_id",
            "node_wise_sda_extension_id",
            "hotspot_leverage_extension_id",
            "intervention_governance_extension_id",
        ):
            self.assertIn(f'RELEASE_IDENTITY["{key}"]', server)
        self.assertIn('elif path == "/v1/governance/dli-robustness"', server)
        self.assertIn('$ExpectedIntegratedMethodology = Get-RqVersionValue -Key "integrated_methodology_extension_id"', launcher)
        self.assertIn('$ExpectedAuroraThreshold = Get-RqVersionValue -Key "aurora_similarity_threshold_extension_id"', launcher)
        self.assertIn('$ExpectedDliExecution = Get-RqVersionValue -Key "dli_in_app_execution_extension_id"', launcher)
        self.assertIn('$ExpectedNodeSda = Get-RqVersionValue -Key "node_wise_sda_extension_id"', launcher)
        self.assertIn('$ExpectedHotspotLeverage = Get-RqVersionValue -Key "hotspot_leverage_extension_id"', launcher)
        self.assertIn('$ExpectedInterventionGovernance = Get-RqVersionValue -Key "intervention_governance_extension_id"', launcher)



if __name__ == "__main__":
    unittest.main(verbosity=2)
