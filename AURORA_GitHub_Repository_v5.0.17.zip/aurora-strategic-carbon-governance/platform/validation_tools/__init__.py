"""Validation-only utilities for the U19 deployment package."""
