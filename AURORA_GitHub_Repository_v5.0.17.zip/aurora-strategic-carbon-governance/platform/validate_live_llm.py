"""Live-model evaluation harness for the Strategic Carbon Intelligence platform.

This program complements the mocked regression tests. It evaluates the
configured local Ollama model without executing MRIO, SPA, SDA, DLI, scenario,
or other deterministic analytical modules. Planner cases capture the raw model
plan before platform guards modify it. Synthesis cases provide frozen gold plans
and frozen evidence bundles, so model performance is not confounded with
retrieval or analytical-engine behaviour.

The input corpus is JSONL. See LLM_LIVE_MODEL_VALIDATION_GUIDE.txt and
llm_validation_cases.template.jsonl before using this evaluator with research
or production-like data.
"""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import math
import os
import re
import statistics
import sys
import time
from collections import Counter, defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable


ROOT = Path(__file__).resolve().parent
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

# Loading the package modules imports the analytical stack. Keeping that import
# lazy lets --dry-run validate a JSONL corpus even in a source-only environment
# where deployment requirements have not yet been installed.
lfo: Any = None
sa: Any = None
sma: Any = None


VALID_STAGES = ("planner", "raw_synthesis", "controlled_synthesis")
PLAN_BOOLEAN_FIELDS = (
    "project_context",
    "system_context",
    "requires_exact_project_values",
    "needs_current_information",
    "use_conversation_context",
)
NODE_PATTERN = re.compile(r"\b[A-Z]{3}[-_][A-Za-z0-9]+\b")


def _load_platform() -> None:
    global lfo, sa, sma
    if lfo is not None:
        return
    import llm_first_orchestrator as lfo_module
    import strategic_assistant as sa_module
    import system_meta_assistant as sma_module

    lfo = lfo_module
    sa = sa_module
    sma = sma_module


class RecordingClient:
    """Proxy that preserves production calls while retaining evaluation traces."""

    def __init__(self, client: Any):
        self._client = client
        self.calls: list[dict[str, Any]] = []

    @property
    def model(self) -> str:
        return str(getattr(self._client, "model", ""))

    def chat_json(
        self,
        system: str,
        user: str,
        schema: dict[str, Any],
        model: str | None = None,
        num_predict: int = 512,
        temperature: float = 0.0,
    ) -> dict[str, Any]:
        started = time.perf_counter()
        record: dict[str, Any] = {
            "model": model or self.model,
            "temperature": temperature,
            "num_predict": num_predict,
            "schema_required": list(schema.get("required", [])),
            "started_at_utc": datetime.now(timezone.utc).isoformat(),
        }
        try:
            response = self._client.chat_json(
                system,
                user,
                schema,
                model=model,
                num_predict=num_predict,
                temperature=temperature,
            )
            record["response"] = response
            return response
        except Exception as exc:
            record["error"] = str(exc)
            raise
        finally:
            record["latency_ms"] = round((time.perf_counter() - started) * 1000, 3)
            self.calls.append(record)

    def __getattr__(self, name: str) -> Any:
        return getattr(self._client, name)


def _json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, default=str)


def _write_json(path: Path, value: Any) -> None:
    path.write_text(_json_text(value) + "\n", encoding="utf-8")


def _safe_div(numerator: float, denominator: float) -> float | None:
    return numerator / denominator if denominator else None


def _rate_with_ci(successes: int, total: int) -> dict[str, float | int | None]:
    rate = _safe_div(successes, total)
    if not total:
        return {"successes": successes, "total": total, "rate": None, "ci95_low": None, "ci95_high": None}
    z = 1.959963984540054
    centre = (rate + z * z / (2 * total)) / (1 + z * z / total)
    margin = z * math.sqrt((rate * (1 - rate) + z * z / (4 * total)) / total) / (1 + z * z / total)
    return {
        "successes": successes,
        "total": total,
        "rate": round(float(rate), 6),
        "ci95_low": round(max(0.0, centre - margin), 6),
        "ci95_high": round(min(1.0, centre + margin), 6),
    }


def _percentile(values: Iterable[float], percentile: float) -> float | None:
    ordered = sorted(float(value) for value in values)
    if not ordered:
        return None
    if len(ordered) == 1:
        return round(ordered[0], 3)
    position = (len(ordered) - 1) * percentile
    low = math.floor(position)
    high = math.ceil(position)
    if low == high:
        return round(ordered[low], 3)
    return round(ordered[low] + (ordered[high] - ordered[low]) * (position - low), 3)


def _mean(values: Iterable[float]) -> float | None:
    prepared = [float(value) for value in values]
    return round(statistics.mean(prepared), 6) if prepared else None


def _truthy_env(value: str | None) -> bool:
    return str(value or "1").strip().casefold() not in {"0", "false", "no", "off"}


def _normalise_tool_set(items: Any) -> set[str]:
    if not isinstance(items, list):
        return set()
    return {
        str(item.get("tool", "")).strip()
        for item in items
        if isinstance(item, dict) and str(item.get("tool", "")).strip()
    }


def _task_plan_schema_valid(raw: Any) -> bool:
    """Strict schema check; the production normalizer deliberately coerces values."""

    if not isinstance(raw, dict):
        return False
    schema = lfo.TASK_PLAN_SCHEMA
    required = set(schema["required"])
    properties = schema["properties"]
    if set(raw) != required:
        return False
    if raw.get("task_kind") not in properties["task_kind"]["enum"]:
        return False
    if raw.get("evidence_policy") not in properties["evidence_policy"]["enum"]:
        return False
    if raw.get("answer_format") not in properties["answer_format"]["enum"]:
        return False
    if type(raw.get("requested_count")) is not int or not 0 <= raw["requested_count"] <= 20:
        return False
    if type(raw.get("confidence")) not in {int, float} or not 0.0 <= float(raw["confidence"]) <= 1.0:
        return False
    if any(type(raw.get(field)) is not bool for field in PLAN_BOOLEAN_FIELDS):
        return False
    if not isinstance(raw.get("user_goal"), str) or not isinstance(raw.get("tool_requests"), list):
        return False
    if len(raw["tool_requests"]) > 6:
        return False
    for request in raw["tool_requests"]:
        if not isinstance(request, dict) or set(request) != {"tool", "purpose"}:
            return False
        if request.get("tool") not in lfo.TOOL_CATALOG or not isinstance(request.get("purpose"), str):
            return False
    return True


def load_cases(path: Path) -> list[dict[str, Any]]:
    cases: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        text = line.strip()
        if not text or text.startswith("#"):
            continue
        try:
            item = json.loads(text)
        except json.JSONDecodeError as exc:
            raise ValueError(f"{path.name}:{line_number} is not valid JSON: {exc}") from exc
        if not isinstance(item, dict):
            raise ValueError(f"{path.name}:{line_number} must be a JSON object.")
        case_id = str(item.get("case_id", "")).strip()
        question = str(item.get("question", "")).strip()
        if not case_id or not question:
            raise ValueError(f"{path.name}:{line_number} needs non-empty case_id and question.")
        if case_id in seen_ids:
            raise ValueError(f"Duplicate case_id '{case_id}'.")
        if not isinstance(item.get("gold_plan"), dict):
            raise ValueError(f"{case_id} needs a gold_plan object.")
        path_name = str(item.get("synthesis_path", "standard")).strip().casefold()
        if path_name not in {"standard", "system_meta"}:
            raise ValueError(f"{case_id} has unsupported synthesis_path '{path_name}'.")
        if path_name == "standard" and not isinstance(item.get("frozen_evidence", []), list):
            raise ValueError(f"{case_id} frozen_evidence must be a list.")
        if path_name == "system_meta" and not isinstance(item.get("frozen_system_retrieval"), dict):
            raise ValueError(f"{case_id} needs frozen_system_retrieval for system_meta synthesis.")
        expected_numbers = item.get("expected_numeric_tokens", [])
        if not isinstance(expected_numbers, list) or any(not isinstance(token, str) or not token.strip() for token in expected_numbers):
            raise ValueError(f"{case_id} expected_numeric_tokens must be a list of non-empty strings.")
        if str(item["gold_plan"].get("task_kind", "")) == "project_exact" and not expected_numbers:
            raise ValueError(f"{case_id} is an exact-result case and needs expected_numeric_tokens.")
        prohibited = item.get("prohibited_claim_patterns", [])
        if not isinstance(prohibited, list) or any(not isinstance(pattern, str) or not pattern.strip() for pattern in prohibited):
            raise ValueError(f"{case_id} prohibited_claim_patterns must be a list of non-empty strings.")
        seen_ids.add(case_id)
        cases.append(item)
    if not cases:
        raise ValueError("The evaluation corpus did not contain any cases.")
    return cases


def _gold_plan(case: dict[str, Any]) -> dict[str, Any]:
    """Complete a labelled plan without invoking any platform planner."""

    question = str(case["question"])
    source = dict(case["gold_plan"])
    output_contract = dict(lfo.extract_output_contract(question))
    output_contract.update(source.get("output_contract", {}))
    plan: dict[str, Any] = {
        "task_kind": "direct_answer",
        "project_context": False,
        "system_context": False,
        "evidence_policy": "none",
        "tool_requests": [],
        "answer_format": output_contract["answer_format"],
        "requested_count": output_contract["requested_count"],
        "requires_exact_project_values": False,
        "needs_current_information": False,
        "use_conversation_context": False,
        "user_goal": "Answer the labelled evaluation task.",
        "confidence": 1.0,
        "source": "gold_evaluation_label",
    }
    for key in tuple(plan):
        if key in source:
            plan[key] = source[key]
    plan["tool_requests"] = [
        {"tool": str(item["tool"]), "purpose": str(item.get("purpose", ""))}
        for item in plan.get("tool_requests", [])
        if isinstance(item, dict) and str(item.get("tool", "")) in lfo.TOOL_CATALOG
    ]
    plan["output_contract"] = output_contract
    plan["explicit_follow_up"] = bool(
        source.get("explicit_follow_up", plan.get("use_conversation_context", False))
    )
    plan["hard_evidence_guard"] = {
        "policy": str(source.get("hard_evidence_policy", plan.get("evidence_policy", "none"))),
        "reason": "Frozen evaluation label; no deterministic tool is executed by this harness.",
    }
    return plan


def _plan_metrics(
    raw: Any,
    gold: dict[str, Any],
    *,
    normalized_plan: dict[str, Any] | None = None,
    effective_tools: bool = False,
) -> dict[str, Any]:
    normalized = normalized_plan if normalized_plan is not None else lfo._normalise_model_plan(raw)
    if normalized is None:
        return {
            "schema_valid": False,
            "normalizable": False,
            "task_kind_correct": False,
            "evidence_policy_correct": False,
            "compute_required": gold["evidence_policy"] == "compute",
            "compute_predicted": False,
            "tool_tp": 0,
            "tool_fp": 0,
            "tool_fn": len(_normalise_tool_set(gold["tool_requests"])),
            "tool_exact": False,
            "answer_format_correct": False,
            "requested_count_correct": False,
            "follow_up_correct": False,
            "current_information_correct": False,
            "exact_plan_correct": False,
            "confidence": None,
        }
    tool_source = normalized.get("validated_tool_calls", []) if effective_tools else normalized.get("tool_requests", [])
    predicted_tools = _normalise_tool_set(tool_source)
    gold_tools = _normalise_tool_set(gold.get("tool_requests", []))
    task_kind_correct = normalized.get("task_kind") == gold.get("task_kind")
    policy_correct = normalized.get("evidence_policy") == gold.get("evidence_policy")
    format_correct = normalized.get("answer_format") == gold.get("answer_format")
    count_correct = int(normalized.get("requested_count", 0)) == int(gold.get("requested_count", 0))
    follow_up_correct = bool(normalized.get("use_conversation_context")) == bool(gold.get("use_conversation_context"))
    current_correct = bool(normalized.get("needs_current_information")) == bool(gold.get("needs_current_information"))
    safety_flags_correct = all(
        bool(normalized.get(field)) == bool(gold.get(field))
        for field in ("project_context", "system_context", "requires_exact_project_values")
    )
    exact = all(
        (
            task_kind_correct,
            policy_correct,
            predicted_tools == gold_tools,
            format_correct,
            count_correct,
            follow_up_correct,
            current_correct,
            safety_flags_correct,
        )
    )
    return {
        "schema_valid": _task_plan_schema_valid(raw),
        "normalizable": True,
        "task_kind_correct": task_kind_correct,
        "evidence_policy_correct": policy_correct,
        "compute_required": gold["evidence_policy"] == "compute",
        "compute_predicted": normalized.get("evidence_policy") == "compute",
        "tool_tp": len(predicted_tools & gold_tools),
        "tool_fp": len(predicted_tools - gold_tools),
        "tool_fn": len(gold_tools - predicted_tools),
        "tool_exact": predicted_tools == gold_tools,
        "answer_format_correct": format_correct,
        "requested_count_correct": count_correct,
        "follow_up_correct": follow_up_correct,
        "current_information_correct": current_correct,
        "safety_flags_correct": safety_flags_correct,
        "exact_plan_correct": exact,
        "confidence": float(normalized.get("confidence", 0.0)),
    }


def _run_planner(case: dict[str, Any], client: Any) -> dict[str, Any]:
    recorder = RecordingClient(client)
    question = str(case["question"])
    history = case.get("conversation_history", [])
    if not isinstance(history, list):
        history = []
    try:
        guarded_plan = lfo.plan_question(
            recorder,
            question,
            mode=str(case.get("requested_mode", "auto")),
            history=history,
            state=case.get("conversation_state") if isinstance(case.get("conversation_state"), dict) else {},
        )
    except Exception as exc:
        guarded_plan = {"source": "evaluation_exception", "planner_error": str(exc)}
    raw = recorder.calls[0].get("response") if recorder.calls else None
    return {
        "raw_model_plan": raw,
        "guarded_plan": guarded_plan,
        "calls": recorder.calls,
        "metrics": _plan_metrics(raw, _gold_plan(case)),
        "guarded_metrics": _plan_metrics(raw, _gold_plan(case), normalized_plan=guarded_plan, effective_tools=True),
    }


def _allowed_node_codes(question: str, evidence: list[dict[str, Any]], draft: str) -> set[str]:
    # Questions are untrusted input, not an evidence source.
    allowed_text = _json_text(evidence) + " " + str(draft)
    return {
        code.replace("_", "-").casefold()
        for code in NODE_PATTERN.findall(allowed_text)
    }


def _output_contract_pass(answer: str, plan: dict[str, Any]) -> bool:
    text = str(answer or "").strip()
    count = int(plan.get("requested_count", 0) or 0)
    answer_format = str(plan.get("answer_format", "paragraphs"))
    numbered = lfo._numbered_items(text)
    bullets = lfo._bullet_items(text)
    if count and len(numbered) != count:
        return False
    if not count and answer_format == "numbered_list" and not numbered:
        return False
    if not count and answer_format == "bullet_list" and not bullets:
        return False
    if answer_format == "table" and "|" not in text:
        return False
    code_fence = chr(96) * 3
    if answer_format == "code" and code_fence not in text and not re.search(r"\b(def|class|SELECT|function|const|let|var)\b", text):
        return False
    if plan.get("output_contract", {}).get("recommendation"):
        if not lfo._contains(
            [
                r"\bshould\b", r"\brecommend", r"\bprioriti[sz]", r"\bimplement",
                r"\badopt", r"\bdevelop", r"\bengage", r"\breduce", r"\brequire",
                r"\bestablish", r"\bintegrate",
            ],
            text,
        ):
            return False
    return bool(text)


def _claim_metrics(
    answer: str,
    case: dict[str, Any],
    plan: dict[str, Any],
    evidence: list[dict[str, Any]],
    deterministic_draft: str,
    validation: dict[str, Any],
) -> dict[str, Any]:
    text = str(answer or "").strip()
    required_claims = [str(item) for item in case.get("required_claims", []) if str(item).strip()]
    covered_claims = [claim for claim in required_claims if claim.casefold() in text.casefold()]
    expected_numbers = [str(item) for item in case.get("expected_numeric_tokens", []) if str(item).strip()]
    present_numbers = [token for token in expected_numbers if token in text]
    allowed_text = _json_text(evidence) + " " + str(deterministic_draft)
    unsupported_numbers: list[str] = []
    unsupported_codes: list[str] = []
    if plan.get("project_context"):
        unsupported_numbers = sorted(lfo._claim_numbers(text) - lfo._claim_numbers(allowed_text))
        allowed_codes = _allowed_node_codes(str(case["question"]), evidence, deterministic_draft)
        answer_codes = {
            code.replace("_", "-").casefold()
            for code in NODE_PATTERN.findall(text)
        }
        unsupported_codes = sorted(answer_codes - allowed_codes)
    prohibited_matches = list(validation.get("prohibited_claim_matches", [])) if isinstance(validation, dict) else []
    alignment = validation.get("alignment", {}) if isinstance(validation, dict) else {}
    return {
        "answer_present": bool(text),
        "validation_valid": bool(validation.get("valid")) if isinstance(validation, dict) else False,
        "output_contract_pass": _output_contract_pass(text, plan),
        "required_claim_count": len(required_claims),
        "covered_claim_count": len(covered_claims),
        "claim_coverage": _safe_div(len(covered_claims), len(required_claims)),
        "expected_numeric_count": len(expected_numbers),
        "numerical_fidelity": _safe_div(len(present_numbers), len(expected_numbers)),
        "unsupported_numeric_claims": unsupported_numbers,
        "unsupported_node_codes": unsupported_codes,
        "critical_grounding_pass": not unsupported_numbers and not unsupported_codes and not prohibited_matches,
        "prohibited_claim_matches": prohibited_matches,
        "alignment_score": alignment.get("score"),
        "alignment_reasons": alignment.get("reasons", []),
    }


def _standard_raw_synthesis(case: dict[str, Any], client: Any) -> dict[str, Any]:
    plan = _gold_plan(case)
    evidence = list(case.get("frozen_evidence", []))
    deterministic_draft = str(case.get("deterministic_draft", ""))
    history = case.get("conversation_history", [])
    history = history if isinstance(history, list) else []
    recorder = RecordingClient(client)
    model = os.getenv("OLLAMA_ANSWER_MODEL", recorder.model)
    output: Any = None
    error = ""
    try:
        output = recorder.chat_json(
            lfo._answer_system_prompt(),
            _json_text(lfo._answer_payload(str(case["question"]), plan, evidence, deterministic_draft, history)),
            lfo.FINAL_ANSWER_SCHEMA,
            model=model or None,
            num_predict=1800,
            temperature=0.2,
        )
    except Exception as exc:
        error = str(exc)
    answer = str(output.get("answer", "")).strip() if isinstance(output, dict) else ""
    validation = lfo.validate_answer(
        str(case["question"]), answer, plan, evidence, deterministic_draft,
        case.get("prohibited_claim_patterns", []),
    )
    return {
        "raw_output": output,
        "raw_answer": answer,
        "final_answer": answer,
        "model_status": "ok" if validation.get("valid") else ("unavailable" if error else "rejected"),
        "model_metrics": {"status": "raw_only", "error": error, "validation": validation},
        "calls": recorder.calls,
        "metrics": _claim_metrics(answer, case, plan, evidence, deterministic_draft, validation),
    }


def _controlled_standard_synthesis(case: dict[str, Any], client: Any) -> dict[str, Any]:
    plan = _gold_plan(case)
    evidence = list(case.get("frozen_evidence", []))
    deterministic_draft = str(case.get("deterministic_draft", ""))
    history = case.get("conversation_history", [])
    history = history if isinstance(history, list) else []
    recorder = RecordingClient(client)
    final_answer, model_metrics = lfo._generate_answer(
        recorder,
        str(case["question"]),
        plan,
        evidence,
        deterministic_draft,
        history,
        prohibited_claim_patterns=case.get("prohibited_claim_patterns", []),
    )
    raw_output = recorder.calls[0].get("response") if recorder.calls else None
    raw_answer = str(raw_output.get("answer", "")).strip() if isinstance(raw_output, dict) else ""
    raw_validation = lfo.validate_answer(
        str(case["question"]), raw_answer, plan, evidence, deterministic_draft,
        case.get("prohibited_claim_patterns", []),
    )
    final_validation = lfo.validate_answer(
        str(case["question"]), final_answer, plan, evidence, deterministic_draft,
        case.get("prohibited_claim_patterns", []),
    )
    return {
        "raw_output": raw_output,
        "raw_answer": raw_answer,
        "final_answer": final_answer,
        "model_status": str(model_metrics.get("status", "")),
        "model_metrics": model_metrics,
        "calls": recorder.calls,
        "metrics": {
            **_claim_metrics(final_answer, case, plan, evidence, deterministic_draft, final_validation),
            "raw_validation_valid": bool(raw_validation.get("valid")),
            "final_validation_valid": bool(final_validation.get("valid")),
        },
    }


def _system_synthesis(case: dict[str, Any], client: Any) -> dict[str, Any]:
    """Evaluate the separate system-meta LLM path with frozen retrieval."""

    retrieval = dict(case["frozen_system_retrieval"])
    recorder = RecordingClient(client)
    answer, alignment, model_metrics = sma.synthesize_system_answer(
        recorder,
        str(case["question"]),
        retrieval,
        history=case.get("conversation_history") if isinstance(case.get("conversation_history"), list) else [],
    )
    raw_output = recorder.calls[0].get("response") if recorder.calls else None
    raw_answer = str(raw_output.get("narrative_answer", "")).strip() if isinstance(raw_output, dict) else ""
    draft = sma.deterministic_system_narrative(str(case["question"]), retrieval)
    raw_valid, raw_alignment = sma._valid_model_answer(raw_output or {}, str(case["question"]), retrieval, draft)
    final_valid, final_alignment = sma._valid_model_answer(
        {
            "answer_type": "system_meta",
            "narrative_answer": answer,
            "covered_record_ids": model_metrics.get("covered_record_ids", []),
            "material_limitations_included": True,
        },
        str(case["question"]),
        retrieval,
        draft,
    )
    raw_prohibited = lfo._matching_prohibited_claim_patterns(
        raw_answer, [*lfo.GLOBAL_PROHIBITED_CLAIM_PATTERNS, *case.get("prohibited_claim_patterns", [])]
    )
    final_prohibited = lfo._matching_prohibited_claim_patterns(
        answer, [*lfo.GLOBAL_PROHIBITED_CLAIM_PATTERNS, *case.get("prohibited_claim_patterns", [])]
    )
    raw_valid = bool(raw_valid) and not raw_prohibited
    final_valid = bool(final_valid) and not final_prohibited
    base_plan = _gold_plan(case)
    validation = {
        "valid": bool(final_valid), "alignment": final_alignment,
        "prohibited_claim_matches": final_prohibited,
    }
    metrics = _claim_metrics(
        answer,
        case,
        base_plan,
        [{"tool": "system_knowledge", "data": retrieval}],
        draft,
        validation,
    )
    metrics.update(
        {
            "raw_validation_valid": bool(raw_valid),
            "final_validation_valid": bool(final_valid),
            "raw_alignment": raw_alignment,
        }
    )
    return {
        "raw_output": raw_output,
        "raw_answer": raw_answer,
        "final_answer": answer,
        "model_status": str(model_metrics.get("status", "")),
        "model_metrics": model_metrics,
        "calls": recorder.calls,
        "metrics": metrics,
    }


def _run_synthesis(case: dict[str, Any], client: Any, stage: str) -> dict[str, Any]:
    path_name = str(case.get("synthesis_path", "standard")).casefold()
    if path_name == "system_meta":
        return _system_synthesis(case, client)
    if stage == "raw_synthesis":
        return _standard_raw_synthesis(case, client)
    return _controlled_standard_synthesis(case, client)


def _macro_f1(pairs: list[tuple[str, str]]) -> float | None:
    if not pairs:
        return None
    labels = sorted({item for pair in pairs for item in pair})
    scores: list[float] = []
    for label in labels:
        tp = sum(1 for truth, predicted in pairs if truth == label and predicted == label)
        fp = sum(1 for truth, predicted in pairs if truth != label and predicted == label)
        fn = sum(1 for truth, predicted in pairs if truth == label and predicted != label)
        denominator = 2 * tp + fp + fn
        scores.append((2 * tp / denominator) if denominator else 0.0)
    return round(statistics.mean(scores), 6)


def _calibration(confidences: list[float], outcomes: list[bool], bins: int = 10) -> dict[str, float | None]:
    if not confidences:
        return {"brier_score": None, "expected_calibration_error": None}
    brier = statistics.mean((confidence - float(outcome)) ** 2 for confidence, outcome in zip(confidences, outcomes))
    ece = 0.0
    total = len(confidences)
    for bin_index in range(bins):
        lower = bin_index / bins
        upper = (bin_index + 1) / bins
        indices = [
            index
            for index, confidence in enumerate(confidences)
            if lower <= confidence < upper or (bin_index == bins - 1 and confidence == 1.0)
        ]
        if not indices:
            continue
        average_confidence = statistics.mean(confidences[index] for index in indices)
        accuracy = statistics.mean(float(outcomes[index]) for index in indices)
        ece += len(indices) / total * abs(accuracy - average_confidence)
    return {
        "brier_score": round(float(brier), 6),
        "expected_calibration_error": round(float(ece), 6),
    }


def _planner_summary(records: list[dict[str, Any]]) -> dict[str, Any]:
    rows = [item for item in records if item["stage"] == "planner"]
    if not rows:
        return {}
    # Primary measures describe the governed plan that actually controls the
    # application. Raw-model measures are retained below as diagnostics.
    metrics = [item["result"]["guarded_metrics"] for item in rows]
    truth_task = [str(item["gold_plan"]["task_kind"]) for item in rows]
    guarded_plans = [item["result"].get("guarded_plan") for item in rows]
    normalized_plans = [plan if isinstance(plan, dict) else None for plan in guarded_plans]
    pred_task = [str(plan.get("task_kind", "__invalid__")) if plan else "__invalid__" for plan in normalized_plans]
    truth_policy = [str(item["gold_plan"]["evidence_policy"]) for item in rows]
    pred_policy = [str(plan.get("evidence_policy", "__invalid__")) if plan else "__invalid__" for plan in normalized_plans]
    tool_tp = sum(int(item["tool_tp"]) for item in metrics)
    tool_fp = sum(int(item["tool_fp"]) for item in metrics)
    tool_fn = sum(int(item["tool_fn"]) for item in metrics)
    tool_precision = _safe_div(tool_tp, tool_tp + tool_fp)
    tool_recall = _safe_div(tool_tp, tool_tp + tool_fn)
    tool_f1 = (
        2 * tool_precision * tool_recall / (tool_precision + tool_recall)
        if tool_precision is not None and tool_recall is not None and tool_precision + tool_recall
        else None
    )
    compute_rows = [item for item in metrics if item["compute_required"]]
    non_compute_rows = [item for item in metrics if not item["compute_required"]]
    confidences = [float(item["confidence"]) for item in metrics if item["confidence"] is not None]
    confidence_outcomes = [bool(item["exact_plan_correct"]) for item in metrics if item["confidence"] is not None]
    latencies = [
        call["latency_ms"]
        for item in rows
        for call in item["result"].get("calls", [])
        if call.get("latency_ms") is not None
    ]
    raw_metrics = [item["result"]["metrics"] for item in rows]
    raw_plans = [item["result"].get("raw_model_plan") for item in rows]
    raw_normalized = [lfo._normalise_model_plan(raw) for raw in raw_plans]
    raw_task = [str(plan.get("task_kind", "__invalid__")) if plan else "__invalid__" for plan in raw_normalized]
    return {
        "cases_x_runs": len(rows),
        "schema_validity": _rate_with_ci(sum(bool(item["schema_valid"]) for item in metrics), len(metrics)),
        "task_kind_macro_f1": _macro_f1(list(zip(truth_task, pred_task))),
        "evidence_policy_macro_f1": _macro_f1(list(zip(truth_policy, pred_policy))),
        "compute_recall": _rate_with_ci(sum(bool(item["compute_predicted"]) for item in compute_rows), len(compute_rows)),
        "unnecessary_compute_rate": _rate_with_ci(sum(bool(item["compute_predicted"]) for item in non_compute_rows), len(non_compute_rows)),
        "tool_selection": {
            "true_positive": tool_tp,
            "false_positive": tool_fp,
            "false_negative": tool_fn,
            "precision": round(tool_precision, 6) if tool_precision is not None else None,
            "recall": round(tool_recall, 6) if tool_recall is not None else None,
            "f1": round(tool_f1, 6) if tool_f1 is not None else None,
            "exact_set_match": _rate_with_ci(sum(bool(item["tool_exact"]) for item in metrics), len(metrics)),
        },
        "output_contract": {
            "answer_format_accuracy": _rate_with_ci(sum(bool(item["answer_format_correct"]) for item in metrics), len(metrics)),
            "requested_count_accuracy": _rate_with_ci(sum(bool(item["requested_count_correct"]) for item in metrics), len(metrics)),
        },
        "follow_up_accuracy": _rate_with_ci(sum(bool(item["follow_up_correct"]) for item in metrics), len(metrics)),
        "current_information_accuracy": _rate_with_ci(sum(bool(item["current_information_correct"]) for item in metrics), len(metrics)),
        "exact_plan_accuracy": _rate_with_ci(sum(bool(item["exact_plan_correct"]) for item in metrics), len(metrics)),
        "calibration": _calibration(confidences, confidence_outcomes),
        "latency_ms": {"p50": _percentile(latencies, 0.50), "p95": _percentile(latencies, 0.95)},
        "raw_model_diagnostic": {
            "task_kind_macro_f1": _macro_f1(list(zip(truth_task, raw_task))),
            "schema_validity": _rate_with_ci(sum(bool(item["schema_valid"]) for item in raw_metrics), len(raw_metrics)),
            "note": "Diagnostic only: this is the ungoverned model proposal, not the plan used for tool execution.",
        },
    }


def _synthesis_summary(records: list[dict[str, Any]], stage: str) -> dict[str, Any]:
    rows = [item for item in records if item["stage"] == stage]
    if not rows:
        return {}
    metrics = [item["result"]["metrics"] for item in rows]
    statuses = Counter(str(item["result"].get("model_status", "")) for item in rows)
    validity_key = "final_validation_valid" if stage == "controlled_synthesis" else "validation_valid"
    passes = [bool(item.get(validity_key, item.get("validation_valid"))) for item in metrics]
    required_coverage = [float(item["claim_coverage"]) for item in metrics if item.get("claim_coverage") is not None]
    numerical = [float(item["numerical_fidelity"]) for item in metrics if item.get("numerical_fidelity") is not None]
    alignment = [float(item["alignment_score"]) for item in metrics if item.get("alignment_score") is not None]
    latencies = [
        call["latency_ms"]
        for item in rows
        for call in item["result"].get("calls", [])
        if call.get("latency_ms") is not None
    ]
    groups: dict[str, list[bool]] = defaultdict(list)
    for item, passed in zip(rows, passes):
        groups[str(item["case_id"])].append(passed)
    initial_failures = [
        item
        for item in rows
        if not bool(item["result"]["metrics"].get("raw_validation_valid", item["result"]["metrics"].get("validation_valid")))
    ]
    repair_recovered = [
        item
        for item in rows
        if item["result"].get("model_status") == "repaired"
        and bool(item["result"]["metrics"].get("final_validation_valid"))
    ]
    return {
        "cases_x_runs": len(rows),
        "validation_pass_rate": _rate_with_ci(sum(passes), len(passes)),
        "output_contract_pass_rate": _rate_with_ci(sum(bool(item["output_contract_pass"]) for item in metrics), len(metrics)),
        "critical_grounding_pass_rate": _rate_with_ci(sum(bool(item["critical_grounding_pass"]) for item in metrics), len(metrics)),
        "unsupported_numeric_claim_count": sum(len(item["unsupported_numeric_claims"]) for item in metrics),
        "unsupported_node_code_count": sum(len(item["unsupported_node_codes"]) for item in metrics),
        "prohibited_claim_match_count": sum(len(item["prohibited_claim_matches"]) for item in metrics),
        "mean_required_claim_coverage": _mean(required_coverage),
        "mean_numerical_fidelity": _mean(numerical),
        "mean_internal_alignment_score": _mean(alignment),
        "model_status_counts": dict(statuses),
        "model_call_unavailable_count": sum(
            1 for item in rows
            if item["result"].get("model_status") in {"unavailable", "safe_fallback_unavailable"}
        ),
        "unavailable_response_count": sum(
            1 for item in rows if item["result"].get("model_status") == "unavailable"
        ),
        "safe_fallback_due_to_unavailability_count": sum(
            1 for item in rows if item["result"].get("model_status") == "safe_fallback_unavailable"
        ),
        "all_critical_controls_pass_rate": _rate_with_ci(
            sum(
                bool(item.get(validity_key, item.get("validation_valid")))
                and bool(item["critical_grounding_pass"])
                and bool(item["output_contract_pass"])
                for item in metrics
            ),
            len(metrics),
        ),
        "per_case_all_runs_pass_rate": _rate_with_ci(sum(all(values) for values in groups.values()), len(groups)),
        "latency_ms": {"p50": _percentile(latencies, 0.50), "p95": _percentile(latencies, 0.95)},
        "repair_recovery_rate": _rate_with_ci(len(repair_recovered), len(initial_failures)) if stage == "controlled_synthesis" else None,
    }


def summarise(records: list[dict[str, Any]], metadata: dict[str, Any]) -> dict[str, Any]:
    return {
        "metadata": metadata,
        "planner": _planner_summary(records),
        "raw_synthesis": _synthesis_summary(records, "raw_synthesis"),
        "controlled_synthesis": _synthesis_summary(records, "controlled_synthesis"),
        "interpretation_note": (
            "The internal alignment score is a platform gate, not independent evidence of LLM quality. "
            "Use the generated human-review template for independent expert assessment."
        ),
    }


def _human_review_template(records: list[dict[str, Any]], path: Path) -> None:
    fields = [
        "case_id", "run_index", "stage", "answer_key", "reviewer_id",
        "strategic_relevance_1_to_5", "actionability_1_to_5",
        "groundedness_1_to_5", "limitations_1_to_5", "aligned_yes_no",
        "verifiable_project_claim_count", "supported_project_claim_count",
        "unsupported_critical_project_claim_count", "comments",
    ]
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        for item in records:
            if item["stage"] not in {"raw_synthesis", "controlled_synthesis"}:
                continue
            answer_key = "raw_answer" if item["stage"] == "raw_synthesis" else "final_answer"
            writer.writerow(
                {
                    "case_id": item["case_id"],
                    "run_index": item["run_index"],
                    "stage": item["stage"],
                    "answer_key": answer_key,
                }
            )


def _markdown_report(summary: dict[str, Any]) -> str:
    lines = [
        "# Live LLM validation report",
        "",
        "This report is generated from the configured local model and frozen evaluation cases. It does not validate MRIO, SPA, SDA, DLI, scenario, retrieval, blockchain, or tool-execution accuracy.",
        "",
        "## Run metadata",
        "",
        "~~~json",
        _json_text(summary["metadata"]),
        "~~~",
        "",
        "## Planner",
        "",
        "~~~json",
        _json_text(summary.get("planner", {})),
        "~~~",
        "",
        "## Raw synthesis",
        "",
        "~~~json",
        _json_text(summary.get("raw_synthesis", {})),
        "~~~",
        "",
        "## Controlled synthesis",
        "",
        "~~~json",
        _json_text(summary.get("controlled_synthesis", {})),
        "~~~",
        "",
        "## Interpretation",
        "",
        summary["interpretation_note"],
        "",
        "A zero observed critical-error count is not proof of zero risk. Report the Wilson confidence interval and retain the held-out cases, raw model responses, model configuration, and expert-review results.",
    ]
    return "\n".join(lines) + "\n"


def run_evaluation(
    cases: list[dict[str, Any]],
    client: Any,
    *,
    stages: Iterable[str] = VALID_STAGES,
    runs: int = 1,
) -> list[dict[str, Any]]:
    _load_platform()
    selected_stages = tuple(stages)
    invalid_stages = set(selected_stages) - set(VALID_STAGES)
    if invalid_stages:
        raise ValueError(f"Unsupported stages: {sorted(invalid_stages)}")
    if runs < 1:
        raise ValueError("runs must be at least one.")
    records: list[dict[str, Any]] = []
    for run_index in range(1, runs + 1):
        for case in cases:
            case_id = str(case["case_id"])
            gold = _gold_plan(case)
            if "planner" in selected_stages:
                result = _run_planner(case, client)
                records.append(
                    {
                        "case_id": case_id,
                        "category": case.get("category", ""),
                        "run_index": run_index,
                        "stage": "planner",
                        "question": case["question"],
                        "gold_plan": gold,
                        "result": result,
                    }
                )
            for stage in ("raw_synthesis", "controlled_synthesis"):
                if stage not in selected_stages:
                    continue
                result = _run_synthesis(case, client, stage)
                records.append(
                    {
                        "case_id": case_id,
                        "category": case.get("category", ""),
                        "run_index": run_index,
                        "stage": stage,
                        "question": case["question"],
                        "gold_plan": gold,
                        "result": result,
                    }
                )
    return records


def _package_version() -> str:
    path = ROOT / "VERSION.txt"
    return path.read_text(encoding="utf-8").splitlines()[0].strip() if path.exists() else "unknown"


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Evaluate the live local Ollama model with frozen, labelled LLM validation cases."
    )
    parser.add_argument(
        "--cases",
        type=Path,
        default=ROOT / "llm_validation_cases.template.jsonl",
        help="JSONL corpus path. Start from the supplied template, then use a held-out labelled corpus for reporting.",
    )
    parser.add_argument("--runs", type=int, default=1, help="Repeated runs per case; use at least five for synthesis stability.")
    parser.add_argument(
        "--stages",
        nargs="+",
        choices=VALID_STAGES,
        default=list(VALID_STAGES),
        help="One or more evaluation stages.",
    )
    parser.add_argument("--model", default="", help="Ollama model passed to the client; dedicated OLLAMA variables still take precedence.")
    parser.add_argument("--base-url", default="", help="Ollama base URL; defaults to OLLAMA_BASE_URL.")
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=None,
        help="Directory for auditable result files. Defaults to llm_validation_results/<UTC timestamp>.",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate the JSONL corpus only; do not call Ollama or create result files.",
    )
    return parser.parse_args()


def main() -> int:
    args = _parse_args()
    cases = load_cases(args.cases)
    if args.dry_run:
        print(f"Validated {len(cases)} labelled cases in {args.cases}. No model call was made.")
        return 0
    if not _truthy_env(os.getenv("OLLAMA_LLM_FIRST_ENABLED", "1")):
        raise SystemExit("OLLAMA_LLM_FIRST_ENABLED is disabled. Enable it to run a live-model evaluation.")
    _load_platform()
    client = sa.make_client(base_url=args.base_url or None, model=args.model or None)
    started = datetime.now(timezone.utc)
    records = run_evaluation(cases, client, stages=args.stages, runs=args.runs)
    completed = datetime.now(timezone.utc)
    default_output = ROOT / "llm_validation_results" / started.strftime("%Y%m%dT%H%M%SZ")
    output_dir = (args.output_dir or default_output).resolve()
    output_dir.mkdir(parents=True, exist_ok=False)
    metadata = {
        "platform_version": _package_version(),
        "started_at_utc": started.isoformat(),
        "completed_at_utc": completed.isoformat(),
        "duration_seconds": round((completed - started).total_seconds(), 3),
        "case_file": str(args.cases.resolve()),
        "case_file_sha256": hashlib.sha256(args.cases.read_bytes()).hexdigest(),
        "case_count": len(cases),
        "runs_per_case": args.runs,
        "stages": list(args.stages),
        "client_model": getattr(client, "model", ""),
        "ollama_base_url": getattr(client, "base_url", ""),
        "planner_model_env": os.getenv("OLLAMA_ORCHESTRATOR_MODEL", ""),
        "answer_model_env": os.getenv("OLLAMA_ANSWER_MODEL", ""),
        "system_synthesis_model_env": os.getenv("OLLAMA_SYNTHESIS_MODEL", ""),
        "planner_temperature": 0.0,
        "answer_temperature": 0.2,
        "repair_temperature": 0.1,
    }
    summary = summarise(records, metadata)
    with (output_dir / "case_results.jsonl").open("w", encoding="utf-8") as handle:
        for record in records:
            handle.write(_json_text(record) + "\n")
    _write_json(output_dir / "summary.json", summary)
    (output_dir / "report.md").write_text(_markdown_report(summary), encoding="utf-8")
    _human_review_template(records, output_dir / "human_review_template.csv")
    print(f"Live LLM evaluation completed. Results: {output_dir}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
