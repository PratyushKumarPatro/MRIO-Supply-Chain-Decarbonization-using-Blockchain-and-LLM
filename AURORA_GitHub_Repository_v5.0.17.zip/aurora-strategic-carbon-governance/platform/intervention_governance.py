"""U16 integrated intervention governance and single authoritative decision funnel.

This downstream module does not alter MRIO, SPA, SDA, BC, PR, CDR, IC,
pooled Pearson-CRITIC, DLI, producer-resolved CDR linkage, or HSI.  It joins
those evidence streams for each hotspot-producer / intervention-node pair and
uses one transparent sequence:

    positive producer linkage
      -> hotspot primary adverse SDA driver
      -> deterministic mechanism mapping
      -> node-level actionability + pair-level technical feasibility
      -> one overlap-controlled governance-ready portfolio
      -> mechanism-specific formal governance options

Path-SDA is supporting mechanism evidence.  It can refine how an intervention
is delivered and reveal persistent, emerging, disappearing, or reconfigured
routes, but it is not a mandatory gate because bounded SPA does not represent
every dependency detected by the complete CDR counterfactual.

U19 preserves this substantive U16 funnel while publishing formal artifacts
only after AURORA, with every artifact and option bound to the exact 2017
Network/DLI CID and the exact AURORA CID.

All structural coverage is a complete-node-removal diagnostic.  It is not a
forecast or guarantee of realizable abatement.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import Any, Callable, Mapping

import numpy as np
import pandas as pd

INTERVENTION_GOVERNANCE_EXTENSION_ID = "v5.0.17-U16"
ABATEMENT_DECISION_GATE_EXTENSION_ID = "v5.0.17-U23"
PAIR_CANDIDATES_FILENAME = "u16_intervention_pair_candidates_2017.csv"
ACTIONABILITY_FILENAME = "u16_actionability_assessments_2017.csv"
NODE_ACTIONABILITY_FILENAME = "u16_node_actionability_2017.csv"
PAIR_FEASIBILITY_FILENAME = "u16_pair_feasibility_2017.csv"
ELIGIBILITY_FILENAME = "u16_intervention_eligibility_2017.csv"
GOVERNANCE_PORTFOLIO_FILENAME = "u16_governance_ready_portfolio_2017.csv"
GOVERNANCE_OPTIONS_FILENAME = "u16_governance_ready_options_2017.csv"
WORKBOOK_FILENAME = "U16_FINAL_INTEGRATED_INTERVENTION_GOVERNANCE_2017.xlsx"
METADATA_FILENAME = "u16_intervention_governance_2017.json"

# Compatibility aliases intentionally point to the one U16 portfolio.  They
# are not written as duplicate artifacts and are not exposed as competing
# analytical authorities.
ACTIONABLE_PORTFOLIO_FILENAME = GOVERNANCE_PORTFOLIO_FILENAME
STRUCTURAL_PORTFOLIO_FILENAME = GOVERNANCE_PORTFOLIO_FILENAME
DRIVER_PORTFOLIO_FILENAME = GOVERNANCE_PORTFOLIO_FILENAME

NODE_ACTIONABILITY_FIELDS = (
    "direct_or_contractual_relationship",
    "specification_or_procurement_control",
    "supplier_selection_or_substitution_authority",
    "emissions_disclosure_right",
    "audit_or_verification_right",
    "implementation_owner_identified",
    "resource_or_budget_path_identified",
)
PAIR_FEASIBILITY_FIELDS = ("technical_feasibility_confirmed",)
ACTIONABILITY_FIELDS = NODE_ACTIONABILITY_FIELDS + PAIR_FEASIBILITY_FIELDS
ASSESSMENT_TEXT_FIELDS = (
    "assessor_name",
    "assessor_role",
    "evidence_reference",
    "assessment_notes",
)
SCENARIO_NUMERIC_FIELDS = (
    "scenario_conservative_effectiveness_fraction",
    "scenario_expected_effectiveness_fraction",
    "scenario_ambitious_effectiveness_fraction",
    "scenario_implementation_coverage_fraction",
    "scenario_adoption_fraction",
)
SCENARIO_TEXT_FIELDS = (
    "scenario_quantification_decision",
    "scenario_non_quantification_reason",
    "scenario_assessor_name",
    "scenario_assessor_role",
    "scenario_evidence_reference",
    "scenario_confidence",
    "scenario_notes",
)
SCENARIO_DECISION_VALUES = (
    "Not decided",
    "Quantify reduction scenario",
    "Proceed without quantification",
)
SCENARIO_GOVERNANCE_READY_STATUSES = (
    "Quantified scenario",
    "Documented unquantified",
)
ASSESSMENT_VALUES = ("Yes", "No", "Not assessed")
ELIGIBLE_STATUS = "Eligible for formal governance"

MECHANISM_LIBRARY: dict[str, dict[str, str]] = {
    "intensity": {
        "mechanism_code": "INTENSITY_DECARBONIZATION",
        "category": "Carbon-intensity decarbonization",
        "direct_action": (
            "Reduce the producer hotspot's carbon intensity through renewable energy, "
            "fuel switching, process efficiency, or verified lower-carbon production technology."
        ),
        "mediated_action": (
            "Use the leverage node's procurement or governance relationship to require renewable energy, "
            "fuel switching, process-efficiency targets, and verified producer-intensity improvement at the linked hotspot."
        ),
        "channel": "energy, process, and supplier-intensity requirements",
    },
    "technology": {
        "mechanism_code": "PRODUCTION_STRUCTURE_REDESIGN",
        "category": "Production-structure intervention",
        "direct_action": (
            "Redesign the hotspot's input and production structure through lower-carbon inputs, "
            "material or process substitution, supplier reconfiguration, and technology-specific efficiency requirements."
        ),
        "mediated_action": (
            "Use the leverage node to redesign sourcing and input relationships affecting the hotspot, "
            "including supplier configuration, material substitution, and upstream technology requirements."
        ),
        "channel": "input structure, supplier configuration, and process redesign",
    },
    "composition": {
        "mechanism_code": "DEMAND_COMPOSITION_REDIRECTION",
        "category": "Demand-composition intervention",
        "direct_action": (
            "Shift focal procurement away from the hotspot-intensive demand category toward verified lower-carbon "
            "products, services, locations, suppliers, materials, or specifications."
        ),
        "mediated_action": (
            "Use the leverage node to redirect procurement composition toward lower-carbon categories, suppliers, "
            "locations, materials, or service specifications linked to the hotspot."
        ),
        "channel": "procurement-mix and specification redesign",
    },
    "scale": {
        "mechanism_code": "DEMAND_SCALE_MANAGEMENT",
        "category": "Demand-scale intervention",
        "direct_action": (
            "Reduce the demand scale inducing the hotspot through volume control, reuse, service-life extension, "
            "resource productivity, and avoidance of unnecessary procurement."
        ),
        "mediated_action": (
            "Use the leverage node to implement demand reduction, reuse, volume controls, service-life extension, "
            "and resource-productivity requirements affecting the linked hotspot."
        ),
        "channel": "demand management and circular-use requirements",
    },
}

PORTFOLIO_COLUMNS = (
    "portfolio_stage",
    "selection_step",
    "intervention_node",
    "intervention_region",
    "intervention_sector",
    "DLI",
    "dli_rank",
    "eligible_pair_count",
    "eligible_hotspot_count",
    "eligible_hotspots",
    "mechanism_families",
    "governance_supported_marginal_reduction_tco2",
    "cumulative_governance_supported_reduction_tco2",
    "cumulative_governance_supported_hotspot_coverage",
    "cumulative_governance_supported_company_coverage",
    "full_marginal_hotspot_structural_reduction_tco2",
    "cumulative_full_hotspot_structural_reduction_tco2",
    "cumulative_full_hotspot_structural_coverage",
    "cumulative_full_company_structural_coverage",
    "hotspot_set_share_of_company_footprint",
    "top_supported_marginal_hotspots",
    "selection_rule",
    "stop_boundary",
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _canonical_json(value: Any) -> str:
    return json.dumps(
        _json_safe(value),
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
        allow_nan=False,
        default=str,
    )


def _json_safe(value: Any) -> Any:
    """Normalize pandas/numpy missing values before strict JSON encoding."""

    if isinstance(value, Mapping):
        return {str(key): _json_safe(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_json_safe(item) for item in value]
    if isinstance(value, np.ndarray):
        return _json_safe(value.tolist())
    if isinstance(value, np.generic):
        return _json_safe(value.item())
    if value is None:
        return None
    if isinstance(value, float):
        return value if np.isfinite(value) else None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    return value


def _fingerprint(value: Any) -> str:
    return hashlib.sha256(_canonical_json(value).encode("utf-8")).hexdigest()


def _normalise_yes_no(value: Any) -> str:
    if value is None or (not isinstance(value, (str, bytes)) and pd.isna(value)):
        return "Not assessed"
    text = str(value).strip().lower()
    if text in {"yes", "y", "true", "1"}:
        return "Yes"
    if text in {"no", "n", "false", "0"}:
        return "No"
    if text in {"not assessed", "not_assessed", "unknown", "", "none", "nan"}:
        return "Not assessed"
    raise ValueError(f"Unsupported actionability value: {value!r}. Use Yes, No, or Not assessed.")


def _safe_text(value: Any, *, maximum: int = 4000) -> str:
    if value is None or (not isinstance(value, (str, bytes)) and pd.isna(value)):
        text = ""
    else:
        text = str(value).strip()
    if text.lower() in {
        "nan",
        "none",
        "null",
        "<na>",
        "n/a",
        "na",
        "not applicable",
        "not assessed",
        "unknown",
        "-",
        "--",
        "tbd",
    }:
        text = ""
    if len(text) > maximum:
        raise ValueError(f"Assessment text exceeds the {maximum}-character limit")
    return text


def _optional_fraction(value: Any) -> float | None:
    """Return a finite fraction in [0, 1], or None for an unassessed field."""

    if value is None or (isinstance(value, str) and not value.strip()):
        return None
    try:
        if pd.isna(value):
            return None
    except (TypeError, ValueError):
        pass
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Scenario parameter {value!r} is not numeric") from exc
    if not np.isfinite(number) or not 0.0 <= number <= 1.0:
        raise ValueError("Scenario parameters must be finite fractions between 0 and 1")
    return number


def _scenario_evidence(record: Mapping[str, Any]) -> dict[str, Any]:
    """Calculate an assumption-bound abatement range for one hotspot pair."""

    values = {field: _optional_fraction(record.get(field)) for field in SCENARIO_NUMERIC_FIELDS}
    texts = {field: _safe_text(record.get(field, "")) for field in SCENARIO_TEXT_FIELDS}
    supplied = [value is not None for value in values.values()]
    decision = texts["scenario_quantification_decision"]
    # Preserve compatibility with evidence packages produced before the explicit
    # decision field existed: supplied scenario evidence means quantify.
    if not decision and (any(supplied) or any(
        texts[field]
        for field in (
            "scenario_assessor_name",
            "scenario_assessor_role",
            "scenario_evidence_reference",
            "scenario_confidence",
            "scenario_notes",
        )
    )):
        decision = "Quantify reduction scenario"
    if decision and decision not in SCENARIO_DECISION_VALUES:
        raise ValueError(f"Unsupported scenario quantification decision: {decision}")
    baseline = max(0.0, _numeric(record, "baseline_hotspot_footprint_tco2"))
    structural = max(0.0, _numeric(record, "avoided_hotspot_footprint_tco2"))
    addressable = min(baseline, structural)
    output: dict[str, Any] = {
        "scenario_status": "Not quantified",
        "scenario_status_basis": (
            "No explicit quantification or documented non-quantification decision has been submitted."
        ),
        "scenario_addressable_footprint_tco2": addressable,
        "scenario_conservative_reduction_tco2": None,
        "scenario_expected_reduction_tco2": None,
        "scenario_ambitious_reduction_tco2": None,
        "scenario_claim_boundary": (
            "This is an assumption-bound comparative estimate, not guaranteed or observed abatement; "
            "the complete-node-removal linkage remains a separate structural diagnostic."
        ),
    }
    if not decision or decision == "Not decided":
        return output
    accountable_fields = (
        texts["scenario_assessor_name"],
        texts["scenario_assessor_role"],
        texts["scenario_evidence_reference"],
    )
    if decision == "Proceed without quantification":
        if any(supplied):
            output["scenario_status"] = "Incomplete scenario"
            output["scenario_status_basis"] = (
                "A documented non-quantification decision cannot also contain numerical scenario parameters."
            )
            return output
        if not texts["scenario_non_quantification_reason"] or not all(accountable_fields):
            output["scenario_status"] = "Incomplete scenario"
            output["scenario_status_basis"] = (
                "A reason, named assessor, assessor role, and evidence reference are required to proceed "
                "without quantification."
            )
            return output
        output["scenario_status"] = "Documented unquantified"
        output["scenario_status_basis"] = (
            "An accountable stakeholder explicitly documented why a defensible pre-decision abatement "
            "range is unavailable."
        )
        return output
    if not all(supplied):
        output["scenario_status"] = "Incomplete scenario"
        output["scenario_status_basis"] = "All effectiveness, implementation-coverage, and adoption parameters are required."
        return output
    low = float(values["scenario_conservative_effectiveness_fraction"])
    expected = float(values["scenario_expected_effectiveness_fraction"])
    high = float(values["scenario_ambitious_effectiveness_fraction"])
    if not low <= expected <= high:
        raise ValueError("Scenario effectiveness must satisfy conservative <= expected <= ambitious")
    if not all(accountable_fields):
        output["scenario_status"] = "Incomplete scenario"
        output["scenario_status_basis"] = "Named assessor, assessor role, and scenario evidence reference are required."
        return output
    multiplier = (
        float(values["scenario_implementation_coverage_fraction"])
        * float(values["scenario_adoption_fraction"])
    )
    output.update(
        {
            "scenario_status": "Quantified scenario",
            "scenario_status_basis": (
                "Evidence-backed comparative estimate: structurally associated footprint multiplied by "
                "scenario effectiveness, implementation coverage, and adoption."
            ),
            "scenario_conservative_reduction_tco2": addressable * low * multiplier,
            "scenario_expected_reduction_tco2": addressable * expected * multiplier,
            "scenario_ambitious_reduction_tco2": addressable * high * multiplier,
        }
    )
    return output


def _as_boolean_series(series: pd.Series) -> pd.Series:
    if pd.api.types.is_bool_dtype(series):
        return series.fillna(False).astype(bool)
    normalized = series.astype(str).str.strip().str.lower()
    allowed_true = {"true", "1", "yes", "y"}
    allowed_false = {"false", "0", "no", "n", "", "nan", "none", "<na>"}
    unsupported = sorted(set(normalized) - allowed_true - allowed_false)
    if unsupported:
        raise ValueError(f"Unsupported boolean values in hotspot pair evidence: {unsupported[:5]}")
    return normalized.isin(allowed_true)


def _numeric(record: Mapping[str, Any], key: str, default: float = 0.0) -> float:
    value = record.get(key, default)
    try:
        number = float(value)
    except (TypeError, ValueError):
        return float(default)
    return number if np.isfinite(number) else float(default)


def _primary_adverse_driver(record: Mapping[str, Any]) -> tuple[str, float, str]:
    explicit = str(record.get("hotspot_primary_adverse_driver", "") or "").strip().lower()
    explicit_value = _numeric(record, "hotspot_primary_adverse_effect_tco2", 0.0)
    if explicit in MECHANISM_LIBRARY and explicit_value > 0.0:
        return explicit, explicit_value, "authoritative node-SDA primary adverse driver"

    effects = {
        "intensity": _numeric(record, "hotspot_intensity_effect_tco2"),
        "technology": _numeric(record, "hotspot_technology_effect_tco2"),
        "composition": _numeric(record, "hotspot_composition_effect_tco2"),
        "scale": _numeric(record, "hotspot_scale_effect_tco2"),
    }
    positive = [(name, value) for name, value in effects.items() if value > 0.0]
    if not positive:
        return "", 0.0, "no positive node-SDA effect requiring emissions-reduction intervention"
    positive.sort(key=lambda item: (-item[1], item[0]))
    return positive[0][0], float(positive[0][1]), "derived from the largest positive signed node-SDA effect"


def _mechanism_for(
    driver: str,
    route: str,
    hotspot: str,
    leverage: str,
    *,
    beneficial_driver: str = "",
    path_driver: str = "",
    path_status: str = "",
) -> dict[str, str]:
    key = str(driver or "").strip().lower()
    library = MECHANISM_LIBRARY.get(key)
    if library is None:
        return {
            "mechanism_code": "NO_ADVERSE_DRIVER_MECHANISM",
            "intervention_category": "No reduction mechanism assigned",
            "recommended_action": (
                f"Do not advance a reduction intervention from {leverage} to {hotspot} until a positive "
                "hotspot node-SDA effect requiring action is identified."
            ),
            "delivery_channel": "evidence review",
            "mechanism_mapping_status": "No mapped adverse-driver mechanism",
            "mechanism_mapping_basis": "The hotspot has no recognized positive primary adverse node-SDA driver.",
            "pathway_mechanism_note": str(path_status or "No bounded path-SDA mechanism evidence supplied."),
        }

    direct = str(route) == "direct"
    action = library["direct_action"] if direct else library["mediated_action"]
    preserve = (
        f" Preserve or strengthen the beneficial {beneficial_driver} effect where operationally appropriate."
        if beneficial_driver in MECHANISM_LIBRARY
        else ""
    )
    path_note = ""
    if path_driver in MECHANISM_LIBRARY:
        if path_driver == key:
            path_note = (
                f"Represented path-SDA reinforces the {key} mechanism along the observed route(s)."
            )
        else:
            path_library = MECHANISM_LIBRARY[path_driver]
            path_note = (
                f"Represented path-SDA identifies {path_driver} as a complementary pathway-level adverse driver; "
                f"consider a secondary {path_library['category'].lower()} measure along the affected route(s)."
            )
    elif path_status:
        path_note = str(path_status)
    return {
        "mechanism_code": library["mechanism_code"],
        "intervention_category": library["category"],
        "recommended_action": action + preserve,
        "delivery_channel": library["channel"],
        "mechanism_mapping_status": "Mapped from primary adverse node-SDA driver",
        "mechanism_mapping_basis": (
            f"The deterministic mechanism acts on the hotspot's largest positive signed SDA effect ({key}); "
            f"route={route}, leverage_node={leverage}, hotspot={hotspot}."
        ),
        "pathway_mechanism_note": path_note,
    }


def build_pair_candidates(pair_evidence: pd.DataFrame) -> pd.DataFrame:
    """Create direct and governance-mediated hotspot/leverage candidates."""
    required = {
        "year",
        "intervention_node",
        "intervention_region",
        "intervention_sector",
        "intervention_DLI",
        "intervention_dli_rank",
        "intervention_is_high_dli",
        "hotspot_producer_node",
        "hotspot_producer_region",
        "hotspot_producer_sector",
        "hotspot_rank",
        "baseline_hotspot_footprint_tco2",
        "avoided_hotspot_footprint_tco2",
        "hotspot_intensity_effect_tco2",
        "hotspot_technology_effect_tco2",
        "hotspot_composition_effect_tco2",
        "hotspot_scale_effect_tco2",
        "hotspot_temporal_status",
    }
    missing = sorted(required.difference(pair_evidence.columns))
    if missing:
        raise ValueError(f"Hotspot pair evidence is missing required columns: {missing}")

    frame = pair_evidence.copy()
    for column in ("intervention_node", "hotspot_producer_node"):
        frame[column] = frame[column].astype(str)
    avoided = pd.to_numeric(frame["avoided_hotspot_footprint_tco2"], errors="raise")
    baseline_total = float(
        frame[["hotspot_producer_node", "baseline_hotspot_footprint_tco2"]]
        .drop_duplicates("hotspot_producer_node")["baseline_hotspot_footprint_tco2"]
        .sum()
    )
    tolerance = max(abs(baseline_total) * 1e-12, 1e-10)
    direct = frame["intervention_node"].eq(frame["hotspot_producer_node"])
    mediated = _as_boolean_series(frame["intervention_is_high_dli"]) & ~direct
    frame = frame.loc[(direct | mediated) & (avoided > tolerance)].copy()

    records: list[dict[str, Any]] = []
    for row in frame.to_dict(orient="records"):
        route = (
            "direct"
            if str(row["intervention_node"]) == str(row["hotspot_producer_node"])
            else "governance-mediated"
        )
        driver, driver_effect, driver_source = _primary_adverse_driver(row)
        beneficial_driver = str(row.get("hotspot_primary_beneficial_driver", "") or "").strip().lower()
        path_driver = str(row.get("represented_path_primary_adverse_driver", "") or "").strip().lower()
        path_status = str(row.get("represented_path_link_status", "") or "")
        mechanism = _mechanism_for(
            driver,
            route,
            str(row["hotspot_producer_node"]),
            str(row["intervention_node"]),
            beneficial_driver=beneficial_driver,
            path_driver=path_driver,
            path_status=path_status,
        )
        identity = {
            "extension_id": INTERVENTION_GOVERNANCE_EXTENSION_ID,
            "year": int(row["year"]),
            "intervention_node": str(row["intervention_node"]),
            "hotspot_producer_node": str(row["hotspot_producer_node"]),
            "route": route,
            "primary_adverse_driver": driver,
            "mechanism_code": mechanism["mechanism_code"],
        }
        records.append(
            {
                "candidate_id": _fingerprint(identity),
                "intervention_route": route,
                **row,
                "hotspot_primary_adverse_driver": driver,
                "hotspot_primary_adverse_effect_tco2": driver_effect,
                "hotspot_primary_adverse_driver_source": driver_source,
                **mechanism,
                "linkage_gate_status": "Pass",
                "linkage_gate_basis": (
                    "Positive producer-resolved complete-node-removal linkage to a dominant producer hotspot."
                ),
                "path_evidence_role": (
                    "supporting mechanism evidence; not a mandatory linkage gate"
                ),
                "structural_claim_boundary": (
                    "The linkage is a complete-node-removal structural diagnostic, not predicted or guaranteed abatement."
                ),
            }
        )
    if not records:
        return pd.DataFrame(
            columns=[
                "candidate_id",
                "intervention_route",
                *sorted(required),
                "hotspot_primary_adverse_driver",
                "hotspot_primary_adverse_effect_tco2",
                "mechanism_code",
                "intervention_category",
                "recommended_action",
                "delivery_channel",
                "mechanism_mapping_status",
                "mechanism_mapping_basis",
                "pathway_mechanism_note",
                "linkage_gate_status",
                "linkage_gate_basis",
                "structural_claim_boundary",
            ]
        )
    result = pd.DataFrame.from_records(records)
    if result["candidate_id"].duplicated().any():
        raise RuntimeError("Deterministic intervention candidate identifiers are not unique")
    return result.sort_values(
        ["intervention_dli_rank", "hotspot_rank", "intervention_node", "hotspot_producer_node"],
        kind="mergesort",
    ).reset_index(drop=True)


def empty_assessments(candidates: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "candidate_id",
        "intervention_node",
        "hotspot_producer_node",
        "mechanism_code",
        *ACTIONABILITY_FIELDS,
        *ASSESSMENT_TEXT_FIELDS,
        *SCENARIO_NUMERIC_FIELDS,
        *SCENARIO_TEXT_FIELDS,
        "scenario_status",
        "scenario_status_basis",
        "scenario_addressable_footprint_tco2",
        "scenario_conservative_reduction_tco2",
        "scenario_expected_reduction_tco2",
        "scenario_ambitious_reduction_tco2",
        "scenario_claim_boundary",
        "scenario_id",
        "scenario_submitted_at_utc",
        "assessment_status",
        "assessment_status_basis",
        "assessment_id",
        "assessment_submitted_at_utc",
    ]
    records: list[dict[str, Any]] = []
    for candidate in candidates.to_dict(orient="records"):
        record: dict[str, Any] = {
            "candidate_id": str(candidate["candidate_id"]),
            "intervention_node": str(candidate.get("intervention_node", "")),
            "hotspot_producer_node": str(candidate.get("hotspot_producer_node", "")),
            "mechanism_code": str(candidate.get("mechanism_code", "")),
        }
        record.update({field: "Not assessed" for field in ACTIONABILITY_FIELDS})
        record.update({field: "" for field in ASSESSMENT_TEXT_FIELDS})
        record.update({field: None for field in SCENARIO_NUMERIC_FIELDS})
        record.update({field: "" for field in SCENARIO_TEXT_FIELDS})
        record.update(_scenario_evidence({**candidate, **record}))
        record.update(
            {
                "assessment_status": "Not yet assessed",
                "assessment_status_basis": "No stakeholder actionability evidence has been submitted.",
                "assessment_id": "",
                "assessment_submitted_at_utc": "",
                "scenario_id": "",
                "scenario_submitted_at_utc": "",
            }
        )
        records.append(record)
    return pd.DataFrame.from_records(records, columns=columns)


def assess_actionability(assessment: Mapping[str, Any]) -> tuple[str, str]:
    values = {
        field: _normalise_yes_no(assessment.get(field, "Not assessed"))
        for field in ACTIONABILITY_FIELDS
    }
    texts = {
        field: _safe_text(assessment.get(field, ""))
        for field in ASSESSMENT_TEXT_FIELDS
    }
    if all(value == "Not assessed" for value in values.values()) and not any(texts.values()):
        return "Not yet assessed", "No stakeholder actionability evidence has been submitted."

    influence_fields = (
        "direct_or_contractual_relationship",
        "specification_or_procurement_control",
        "supplier_selection_or_substitution_authority",
    )
    assurance_fields = ("emissions_disclosure_right", "audit_or_verification_right")
    all_influence_no = all(values[field] == "No" for field in influence_fields)
    hard_no = any(
        values[field] == "No"
        for field in (
            "technical_feasibility_confirmed",
            "implementation_owner_identified",
            "resource_or_budget_path_identified",
        )
    )
    if all_influence_no or hard_no:
        return (
            "Not actionable",
            "A required implementation condition is explicitly No, or every recognized influence channel is No.",
        )

    verified = (
        values["technical_feasibility_confirmed"] == "Yes"
        and values["implementation_owner_identified"] == "Yes"
        and values["resource_or_budget_path_identified"] == "Yes"
        and any(values[field] == "Yes" for field in influence_fields)
        and any(values[field] == "Yes" for field in assurance_fields)
        and bool(texts["assessor_name"])
        and bool(texts["assessor_role"])
        and bool(texts["evidence_reference"])
    )
    if verified:
        return (
            "Verified actionable",
            "Required pair feasibility, node ownership/resources, influence, assurance, assessor, and evidence fields are documented.",
        )
    if any(value == "Yes" for value in values.values()):
        return (
            "Conditionally actionable",
            "Some actionability evidence is positive, but one or more required fields remain Not assessed or undocumented.",
        )
    return "Not yet assessed", "The submitted record does not establish a positive influence or implementation channel."


def _merge_existing_assessments(
    candidates: pd.DataFrame,
    existing: pd.DataFrame | None,
) -> pd.DataFrame:
    base = empty_assessments(candidates)
    if existing is None or existing.empty or base.empty:
        return base
    known = existing.copy()
    if "candidate_id" not in known.columns:
        return base
    node_evidence = known.copy()
    known["candidate_id"] = known["candidate_id"].astype(str)
    known = known.drop_duplicates("candidate_id", keep="last").set_index("candidate_id")
    base = base.set_index("candidate_id")
    shared = base.index.intersection(known.index)
    for column in known.columns:
        if column not in base.columns:
            base[column] = ""
        base.loc[shared, column] = known.loc[shared, column]
    base = base.reset_index()
    # Candidate identifiers include the hotspot/mechanism pair and may change
    # when the analytical candidate universe is rebuilt. Node-level evidence is
    # nevertheless a durable assertion about the leverage node, so reuse the
    # most recently submitted node record for both existing and newly linked
    # pairs. Pair feasibility and assessment notes remain pair-specific.
    if "intervention_node" in node_evidence.columns:
        node_evidence["intervention_node"] = node_evidence["intervention_node"].astype(str)
        if "assessment_submitted_at_utc" not in node_evidence.columns:
            node_evidence["assessment_submitted_at_utc"] = ""
        node_evidence = node_evidence.sort_values(
            ["intervention_node", "assessment_submitted_at_utc"],
            kind="mergesort",
        ).drop_duplicates("intervention_node", keep="last").set_index("intervention_node")
        reusable_node_fields = (
            *NODE_ACTIONABILITY_FIELDS,
            "assessor_name",
            "assessor_role",
            "evidence_reference",
        )
        for node_code in base["intervention_node"].astype(str).drop_duplicates():
            if node_code not in node_evidence.index:
                continue
            node_mask = base["intervention_node"].astype(str).eq(node_code)
            node_record = node_evidence.loc[node_code]
            for field in reusable_node_fields:
                if field in node_evidence.columns:
                    base.loc[node_mask, field] = node_record.get(field, "")
    # CSV round-trips represent blank strings as NaN by default.  Normalize the
    # complete register—not only the selected row—before sibling-node evidence
    # is propagated and fingerprinted.
    for field in ACTIONABILITY_FIELDS:
        base[field] = base[field].map(_normalise_yes_no)
    for field in ASSESSMENT_TEXT_FIELDS:
        base[field] = base[field].map(_safe_text)
    for field in SCENARIO_NUMERIC_FIELDS:
        if field not in base.columns:
            base[field] = None
        base[field] = base[field].map(_optional_fraction)
    for field in SCENARIO_TEXT_FIELDS:
        if field not in base.columns:
            base[field] = ""
        base[field] = base[field].map(_safe_text)
    for field in (
        "assessment_status",
        "assessment_status_basis",
        "assessment_id",
        "assessment_submitted_at_utc",
        "scenario_status",
        "scenario_status_basis",
        "scenario_id",
        "scenario_submitted_at_utc",
    ):
        if field in base.columns:
            base[field] = base[field].map(_safe_text)
    return base


def upsert_actionability_assessment(
    candidates: pd.DataFrame,
    existing: pd.DataFrame | None,
    candidate_id: str,
    assessment: Mapping[str, Any],
) -> pd.DataFrame:
    """Record one pair assessment while reusing node-level governance evidence.

    Node-level fields are propagated to every candidate sharing the same
    intervention node.  Technical feasibility remains pair/mechanism specific.
    This avoids re-entering the same contractual and governance evidence for
    every hotspot linked to one leverage node.
    """
    candidate_id = str(candidate_id).strip().lower()
    valid_ids = set(candidates.get("candidate_id", pd.Series(dtype=str)).astype(str))
    if candidate_id not in valid_ids:
        raise ValueError("The candidate_id is not present in the active intervention-candidate set")
    base = _merge_existing_assessments(candidates, existing)
    target = candidates.loc[candidates["candidate_id"].astype(str).eq(candidate_id)].iloc[0]
    intervention_node = str(target["intervention_node"])

    existing_target = base.loc[base["candidate_id"].astype(str).eq(candidate_id)].iloc[0]
    normalized_node = {
        field: _normalise_yes_no(assessment.get(field, existing_target.get(field, "Not assessed")))
        for field in NODE_ACTIONABILITY_FIELDS
    }
    normalized_pair = {
        field: _normalise_yes_no(assessment.get(field, existing_target.get(field, "Not assessed")))
        for field in PAIR_FEASIBILITY_FIELDS
    }
    normalized_text = {
        field: _safe_text(assessment.get(field, existing_target.get(field, "")))
        for field in ASSESSMENT_TEXT_FIELDS
    }
    normalized_scenario = {
        field: _optional_fraction(assessment.get(field, existing_target.get(field)))
        for field in SCENARIO_NUMERIC_FIELDS
    }
    normalized_scenario_text = {
        field: _safe_text(assessment.get(field, existing_target.get(field, "")))
        for field in SCENARIO_TEXT_FIELDS
    }
    submitted_at = _utc_now()

    node_mask = base["intervention_node"].astype(str).eq(intervention_node)
    target_mask = base["candidate_id"].astype(str).eq(candidate_id)
    for field, value in normalized_node.items():
        base.loc[node_mask, field] = value
    for field in ("assessor_name", "assessor_role", "evidence_reference"):
        base.loc[node_mask, field] = normalized_text[field]
    for field, value in normalized_pair.items():
        base.loc[target_mask, field] = value
    base.loc[target_mask, "assessment_notes"] = normalized_text["assessment_notes"]
    for field, value in normalized_scenario.items():
        base.loc[target_mask, field] = value
    for field, value in normalized_scenario_text.items():
        base.loc[target_mask, field] = value

    for index, record in base.iterrows():
        if not bool(node_mask.loc[index]) and not bool(target_mask.loc[index]):
            continue
        status, basis = assess_actionability(record.to_dict())
        candidate_record = candidates.loc[
            candidates["candidate_id"].astype(str).eq(str(record["candidate_id"]))
        ].iloc[0].to_dict()
        scenario = _scenario_evidence({**candidate_record, **record.to_dict()})
        identity = {
            "candidate_id": str(record["candidate_id"]),
            **{field: record.get(field, "") for field in ACTIONABILITY_FIELDS},
            **{field: record.get(field, "") for field in ASSESSMENT_TEXT_FIELDS},
            "assessment_status": status,
            "assessment_status_basis": basis,
            "assessment_submitted_at_utc": submitted_at,
        }
        base.at[index, "assessment_status"] = status
        base.at[index, "assessment_status_basis"] = basis
        base.at[index, "assessment_id"] = _fingerprint(identity)
        base.at[index, "assessment_submitted_at_utc"] = submitted_at
        for field, value in scenario.items():
            base.at[index, field] = value
        if bool(target_mask.loc[index]) and scenario["scenario_status"] != "Not quantified":
            scenario_identity = {
                "candidate_id": str(record["candidate_id"]),
                **{field: record.get(field) for field in SCENARIO_NUMERIC_FIELDS},
                **{field: record.get(field, "") for field in SCENARIO_TEXT_FIELDS},
                **scenario,
                "scenario_submitted_at_utc": submitted_at,
            }
            base.at[index, "scenario_id"] = _fingerprint(scenario_identity)
            base.at[index, "scenario_submitted_at_utc"] = submitted_at
    return base.sort_values("candidate_id", kind="mergesort").reset_index(drop=True)


def merge_actionability(
    candidates: pd.DataFrame,
    assessments: pd.DataFrame | None,
) -> pd.DataFrame:
    base = _merge_existing_assessments(candidates, assessments)
    statuses: list[str] = []
    bases: list[str] = []
    for record in base.to_dict(orient="records"):
        status, basis = assess_actionability(record)
        statuses.append(status)
        bases.append(basis)
    if not base.empty:
        base["assessment_status"] = statuses
        base["assessment_status_basis"] = bases
        candidate_lookup = candidates.set_index("candidate_id", drop=False)
        scenario_rows = [
            _scenario_evidence(
                {
                    **candidate_lookup.loc[str(record["candidate_id"])].to_dict(),
                    **record,
                }
            )
            for record in base.to_dict(orient="records")
        ]
        for field in scenario_rows[0] if scenario_rows else ():
            base[field] = [row[field] for row in scenario_rows]
    merge_columns = [
        column
        for column in base.columns
        if column not in {"intervention_node", "hotspot_producer_node", "mechanism_code"}
    ]
    result = candidates.merge(
        base[merge_columns],
        on="candidate_id",
        how="left",
        validate="one_to_one",
    )
    mapped = result["mechanism_mapping_status"].eq(
        "Mapped from primary adverse node-SDA driver"
    )
    linked = result["linkage_gate_status"].eq("Pass")
    scenario_ready = result["scenario_status"].isin(SCENARIO_GOVERNANCE_READY_STATUSES)
    result["governance_eligibility_status"] = np.select(
        [
            mapped & linked & result["assessment_status"].eq("Verified actionable") & scenario_ready,
            mapped & linked & result["assessment_status"].eq("Verified actionable") & ~scenario_ready,
            mapped & linked & result["assessment_status"].eq("Conditionally actionable"),
            ~mapped,
            result["assessment_status"].eq("Not actionable"),
        ],
        [
            ELIGIBLE_STATUS,
            "Conditionally eligible - scenario decision incomplete",
            "Conditionally eligible - actionability evidence incomplete",
            "Ineligible - no adverse-driver mechanism mapped",
            "Ineligible - not actionable",
        ],
        default="Not yet eligible",
    )
    result["governance_eligibility_basis"] = np.select(
        [
            result["governance_eligibility_status"].eq(ELIGIBLE_STATUS),
            result["governance_eligibility_status"].eq(
                "Conditionally eligible - scenario decision incomplete"
            ),
            result["governance_eligibility_status"].eq(
                "Conditionally eligible - actionability evidence incomplete"
            ),
            result["governance_eligibility_status"].str.startswith("Ineligible"),
        ],
        [
            "Positive linkage, a mechanism mapped from the hotspot's primary adverse node-SDA driver, verified node/pair actionability evidence, and an explicit quantified or documented-unquantified scenario decision.",
            "Actionability is verified, but the pre-decision scenario has neither been quantified nor explicitly waived with accountable evidence.",
            "Analytical evidence is sufficient, but actionability documentation is incomplete.",
            "One or more mandatory linkage, driver-mechanism, or actionability conditions failed.",
        ],
        default="Actionability has not yet been documented to the formal threshold.",
    )
    return result


@dataclass(frozen=True)
class PortfolioResult:
    stage: str
    frame: pd.DataFrame
    target_coverage: float
    achieved_hotspot_coverage: float
    achieved_company_coverage: float
    achieved_full_hotspot_coverage: float
    achieved_full_company_coverage: float
    reached_target: bool
    stop_reason: str

    # Historical attribute names retained as read-only aliases.
    @property
    def achieved_supported_coverage(self) -> float:
        return self.achieved_hotspot_coverage

    @property
    def achieved_full_coverage(self) -> float:
        return self.achieved_full_hotspot_coverage


@dataclass(frozen=True)
class InterventionGovernanceResult:
    year: int
    candidates: pd.DataFrame
    assessments: pd.DataFrame
    eligibility: pd.DataFrame
    portfolio: PortfolioResult
    governance_options: pd.DataFrame
    hotspot_total_footprint: float
    company_total_footprint: float
    hotspot_count: int

    @property
    def portfolios(self) -> dict[str, PortfolioResult]:
        # One authoritative U16 portfolio only.
        return {"governance_ready": self.portfolio}


def _portfolio_with_pair_gate(
    *,
    stage: str,
    model: Any,
    demand: np.ndarray,
    all_hotspot_codes: list[str],
    eligible_pairs: pd.DataFrame,
    target_coverage: float,
) -> PortfolioResult:
    node_codes = np.asarray(model.node_codes).astype(str)
    regions = np.asarray(model.regions).astype(str)
    sectors = np.asarray(model.sectors).astype(str)
    intensity = np.asarray(model.fE, dtype=float)
    demand = np.asarray(demand, dtype=float).reshape(-1)
    inverse = np.asarray(model.L, dtype=float).copy()
    if inverse.shape != (len(node_codes), len(node_codes)):
        raise ValueError("The model Leontief inverse does not match the node universe")
    code_to_index = {code: index for index, code in enumerate(node_codes)}
    missing_hotspots = [code for code in all_hotspot_codes if code not in code_to_index]
    if missing_hotspots:
        raise ValueError(f"Portfolio hotspot codes are absent from the MRIO model: {missing_hotspots[:5]}")
    hotspot_indices = np.asarray([code_to_index[code] for code in all_hotspot_codes], dtype=int)

    pair_map: dict[str, set[str]] = {}
    mechanism_map: dict[str, set[str]] = {}
    dli_lookup: dict[str, float] = {}
    rank_lookup: dict[str, int] = {}
    pair_count_lookup: dict[str, int] = {}
    for record in eligible_pairs.to_dict(orient="records"):
        node = str(record["intervention_node"])
        hotspot = str(record["hotspot_producer_node"])
        if node not in code_to_index or hotspot not in code_to_index:
            continue
        pair_map.setdefault(node, set()).add(hotspot)
        mechanism_map.setdefault(node, set()).add(str(record.get("mechanism_code", "")))
        dli_lookup[node] = float(record.get("intervention_DLI", 0.0))
        rank_lookup[node] = int(record.get("intervention_dli_rank", 0))
        pair_count_lookup[node] = pair_count_lookup.get(node, 0) + 1

    candidates = set(pair_map)
    active = np.arange(len(node_codes), dtype=int)
    output = inverse @ demand
    baseline_hotspot = float(sum(intensity[index] * output[index] for index in hotspot_indices))
    baseline_company = float(intensity @ output)
    tolerance = max(abs(baseline_hotspot) * 1e-12, 1e-10)
    cumulative_supported = 0.0
    records: list[dict[str, Any]] = []
    stop_reason = "candidate set exhausted"

    while candidates:
        position = {int(original): int(pos) for pos, original in enumerate(active)}
        current_hotspot = float(
            sum(intensity[index] * output[position[index]] for index in hotspot_indices if index in position)
        )
        current_company = float(
            sum(intensity[original] * output[pos] for pos, original in enumerate(active))
        )
        best: dict[str, Any] | None = None
        for node in sorted(candidates):
            node_index = code_to_index[node]
            if node_index not in position:
                continue
            p = position[node_index]
            pivot = float(inverse[p, p])
            if abs(pivot) <= np.finfo(float).eps:
                continue
            keep = np.ones(len(active), dtype=bool)
            keep[p] = False
            next_active = active[keep]
            next_output = output[keep] - inverse[keep, p] * output[p] / pivot
            next_position = {int(original): int(pos) for pos, original in enumerate(next_active)}
            marginals: dict[str, float] = {}
            for code, index in zip(all_hotspot_codes, hotspot_indices):
                before = intensity[index] * output[position[index]] if index in position else 0.0
                after = intensity[index] * next_output[next_position[index]] if index in next_position else 0.0
                marginals[code] = float(before - after)
            supported_codes = pair_map[node]
            supported_marginal = float(sum(marginals.get(code, 0.0) for code in supported_codes))
            full_marginal = float(sum(marginals.values()))
            next_company = float(
                sum(intensity[original] * next_output[pos] for pos, original in enumerate(next_active))
            )
            candidate = {
                "node": node,
                "node_index": node_index,
                "supported_marginal": supported_marginal,
                "full_marginal": full_marginal,
                "company_marginal": current_company - next_company,
                "marginals": marginals,
                "next_active": next_active,
                "next_output": next_output,
                "next_company": next_company,
                "dli": dli_lookup.get(node, 0.0),
                "rank": rank_lookup.get(node, 0),
            }
            if best is None:
                best = candidate
            elif supported_marginal > float(best["supported_marginal"]) + tolerance:
                best = candidate
            elif abs(supported_marginal - float(best["supported_marginal"])) <= tolerance:
                if candidate["dli"] > best["dli"] + 1e-15:
                    best = candidate
                elif abs(candidate["dli"] - best["dli"]) <= 1e-15 and node < best["node"]:
                    best = candidate
        if best is None or float(best["supported_marginal"]) <= tolerance:
            stop_reason = "no remaining eligible candidate provides a positive supported marginal hotspot reduction"
            break

        node = str(best["node"])
        node_index = int(best["node_index"])
        p = position[node_index]
        pivot = float(inverse[p, p])
        keep = np.ones(len(active), dtype=bool)
        keep[p] = False
        next_inverse = inverse[np.ix_(keep, keep)] - np.outer(
            inverse[keep, p], inverse[p, keep]
        ) / pivot
        cumulative_supported += float(best["supported_marginal"])
        next_position = {int(original): int(pos) for pos, original in enumerate(best["next_active"])}
        next_hotspot = float(
            sum(
                intensity[index] * best["next_output"][next_position[index]]
                for index in hotspot_indices
                if index in next_position
            )
        )
        cumulative_full = baseline_hotspot - next_hotspot
        cumulative_company = baseline_company - float(best["next_company"])
        supported_hotspot_coverage = cumulative_supported / baseline_hotspot if baseline_hotspot else 0.0
        supported_company_coverage = cumulative_supported / baseline_company if baseline_company else 0.0
        full_hotspot_coverage = cumulative_full / baseline_hotspot if baseline_hotspot else 0.0
        full_company_coverage = cumulative_company / baseline_company if baseline_company else 0.0
        supported_marginals = [
            (code, float(best["marginals"].get(code, 0.0)))
            for code in sorted(pair_map[node])
            if float(best["marginals"].get(code, 0.0)) > tolerance
        ]
        supported_marginals.sort(key=lambda item: (-item[1], item[0]))
        records.append(
            {
                "portfolio_stage": stage,
                "selection_step": len(records) + 1,
                "intervention_node": node,
                "intervention_region": str(regions[node_index]),
                "intervention_sector": str(sectors[node_index]),
                "DLI": float(best["dli"]),
                "dli_rank": int(best["rank"]),
                "eligible_pair_count": int(pair_count_lookup.get(node, 0)),
                "eligible_hotspot_count": int(len(pair_map[node])),
                "eligible_hotspots": "; ".join(sorted(pair_map[node])),
                "mechanism_families": "; ".join(sorted(mechanism_map.get(node, set()))),
                "governance_supported_marginal_reduction_tco2": float(best["supported_marginal"]),
                "cumulative_governance_supported_reduction_tco2": float(cumulative_supported),
                "cumulative_governance_supported_hotspot_coverage": float(supported_hotspot_coverage),
                "cumulative_governance_supported_company_coverage": float(supported_company_coverage),
                "full_marginal_hotspot_structural_reduction_tco2": float(best["full_marginal"]),
                "cumulative_full_hotspot_structural_reduction_tco2": float(cumulative_full),
                "cumulative_full_hotspot_structural_coverage": float(full_hotspot_coverage),
                "cumulative_full_company_structural_coverage": float(full_company_coverage),
                "hotspot_set_share_of_company_footprint": float(baseline_hotspot / baseline_company) if baseline_company else 0.0,
                "top_supported_marginal_hotspots": "; ".join(
                    f"{code}:{value:.6g}" for code, value in supported_marginals[:5]
                ),
                "selection_rule": (
                    "largest exact positive governance-supported marginal hotspot reduction; DLI is tie-break only"
                ),
                "stop_boundary": (
                    "joint complete-node-removal structural diagnostic; not predicted, feasible, or guaranteed abatement"
                ),
            }
        )
        candidates.remove(node)
        active = np.asarray(best["next_active"], dtype=int)
        output = np.asarray(best["next_output"], dtype=float)
        inverse = next_inverse
        if supported_hotspot_coverage + 1e-12 >= float(target_coverage):
            stop_reason = "target governance-supported hotspot-set structural coverage reached"
            break

    frame = pd.DataFrame.from_records(records, columns=list(PORTFOLIO_COLUMNS))
    def last(column: str) -> float:
        return float(frame[column].iloc[-1]) if not frame.empty else 0.0
    achieved_hotspot = last("cumulative_governance_supported_hotspot_coverage")
    return PortfolioResult(
        stage=stage,
        frame=frame,
        target_coverage=float(target_coverage),
        achieved_hotspot_coverage=achieved_hotspot,
        achieved_company_coverage=last("cumulative_governance_supported_company_coverage"),
        achieved_full_hotspot_coverage=last("cumulative_full_hotspot_structural_coverage"),
        achieved_full_company_coverage=last("cumulative_full_company_structural_coverage"),
        reached_target=bool(achieved_hotspot + 1e-12 >= float(target_coverage)),
        stop_reason=stop_reason,
    )


def _build_governance_options(
    eligibility: pd.DataFrame,
    portfolio: pd.DataFrame,
    *,
    source_network_result_cid: str,
    source_aurora_result_cid: str,
    input_hashes: Mapping[str, str],
    store_content_fn: Callable[[Any, str], str] | None,
    existing_options: pd.DataFrame | None = None,
) -> pd.DataFrame:
    columns = [
        "node_code",
        "region",
        "sector",
        "dli_rank",
        "dli_score",
        "dli_score_bps",
        "mechanism_code",
        "category",
        "action",
        "channel",
        "driven_by",
        "beneficial_drivers_to_preserve",
        "pathway_mechanism_evidence",
        "intervention_route",
        "hotspot_targets",
        "hotspot_target_count",
        "pair_candidate_ids",
        "actionability_assessment_ids",
        "actionability_evidence_references",
        "portfolio_selection_step",
        "target_baseline_hotspot_footprint_tco2",
        "structurally_associated_footprint_tco2",
        "governance_supported_marginal_reduction_tco2",
        "cumulative_governance_supported_hotspot_coverage",
        "cumulative_governance_supported_company_coverage",
        "abatement_scenario_status",
        "scenario_conservative_reduction_tco2",
        "scenario_expected_reduction_tco2",
        "scenario_ambitious_reduction_tco2",
        "scenario_assumption_summary",
        "scenario_evidence_references",
        "scenario_assessment_ids",
        "scenario_claim_boundary",
        "governance_eligibility_status",
        "option_fingerprint",
        "option_cid",
        "claim_boundary",
    ]
    if portfolio.empty:
        return pd.DataFrame(columns=columns)
    existing_map: dict[str, str] = {}
    if existing_options is not None and not existing_options.empty:
        for row in existing_options.to_dict(orient="records"):
            fingerprint = str(row.get("option_fingerprint", ""))
            cid = str(row.get("option_cid", ""))
            if fingerprint and cid:
                existing_map[fingerprint] = cid

    records: list[dict[str, Any]] = []
    for portfolio_row in portfolio.to_dict(orient="records"):
        node = str(portfolio_row["intervention_node"])
        eligible_pairs = eligibility.loc[
            eligibility["intervention_node"].astype(str).eq(node)
            & eligibility["governance_eligibility_status"].eq(ELIGIBLE_STATUS)
        ].copy()
        if eligible_pairs.empty:
            continue
        # Do not bundle unrelated intervention mechanisms merely because they
        # share one leverage node.
        for mechanism_code, pairs in eligible_pairs.groupby("mechanism_code", sort=True):
            pairs = pairs.sort_values(
                ["avoided_hotspot_footprint_tco2", "hotspot_rank", "hotspot_producer_node"],
                ascending=[False, True, True],
                kind="mergesort",
            )
            routes = sorted(set(pairs["intervention_route"].astype(str)))
            route = routes[0] if len(routes) == 1 else "hybrid"
            actions = list(dict.fromkeys(pairs["recommended_action"].astype(str).tolist()))
            path_notes = [
                value for value in dict.fromkeys(pairs.get("pathway_mechanism_note", pd.Series(dtype=str)).astype(str))
                if value and value.lower() != "nan"
            ]
            beneficial = [
                value for value in dict.fromkeys(pairs.get("hotspot_primary_beneficial_driver", pd.Series(dtype=str)).astype(str))
                if value and value.lower() != "nan"
            ]
            quantified = pairs.loc[pairs["scenario_status"].eq("Quantified scenario")].copy()
            documented_unquantified = pairs.loc[
                pairs["scenario_status"].eq("Documented unquantified")
            ].copy()
            if quantified.empty:
                scenario_status = "Documented unquantified"
            elif len(quantified) == len(pairs):
                scenario_status = "All target hotspots quantified"
            else:
                scenario_status = "Partially quantified"

            def scenario_sum(column: str) -> float | None:
                values = pd.to_numeric(quantified.get(column, pd.Series(dtype=float)), errors="coerce")
                return float(values.sum()) if not values.empty and values.notna().any() else None

            scenario_assumptions = []
            for pair in quantified.to_dict(orient="records"):
                scenario_assumptions.append(
                    f"{pair.get('hotspot_producer_node')}: effectiveness "
                    f"{_numeric(pair, 'scenario_conservative_effectiveness_fraction'):.1%}/"
                    f"{_numeric(pair, 'scenario_expected_effectiveness_fraction'):.1%}/"
                    f"{_numeric(pair, 'scenario_ambitious_effectiveness_fraction'):.1%}; "
                    f"coverage {_numeric(pair, 'scenario_implementation_coverage_fraction'):.1%}; "
                    f"adoption {_numeric(pair, 'scenario_adoption_fraction'):.1%}"
                )
            for pair in documented_unquantified.to_dict(orient="records"):
                scenario_assumptions.append(
                    f"{pair.get('hotspot_producer_node')}: not quantified - "
                    f"{_safe_text(pair.get('scenario_non_quantification_reason'))}"
                )
            option = {
                "node_code": node,
                "region": str(pairs.iloc[0]["intervention_region"]),
                "sector": str(pairs.iloc[0]["intervention_sector"]),
                "dli_rank": int(pairs.iloc[0]["intervention_dli_rank"]),
                "dli_score": float(pairs.iloc[0]["intervention_DLI"]),
                "dli_score_bps": int(round(float(pairs.iloc[0]["intervention_DLI"]) * 10000)),
                "mechanism_code": str(mechanism_code),
                "category": str(pairs.iloc[0]["intervention_category"]),
                "action": " | ".join(actions),
                "channel": "; ".join(dict.fromkeys(pairs["delivery_channel"].astype(str))),
                "driven_by": "; ".join(dict.fromkeys(pairs["hotspot_primary_adverse_driver"].astype(str))),
                "beneficial_drivers_to_preserve": "; ".join(beneficial),
                "pathway_mechanism_evidence": " | ".join(path_notes),
                "intervention_route": route,
                "hotspot_targets": "; ".join(pairs["hotspot_producer_node"].astype(str)),
                "hotspot_target_count": int(pairs["hotspot_producer_node"].nunique()),
                "pair_candidate_ids": "; ".join(pairs["candidate_id"].astype(str)),
                "actionability_assessment_ids": "; ".join(
                    identifier for identifier in pairs["assessment_id"].astype(str) if identifier
                ),
                "actionability_evidence_references": "; ".join(
                    value for value in dict.fromkeys(pairs["evidence_reference"].astype(str)) if value
                ),
                "portfolio_selection_step": int(portfolio_row["selection_step"]),
                "target_baseline_hotspot_footprint_tco2": float(
                    pd.to_numeric(pairs["baseline_hotspot_footprint_tco2"], errors="raise").sum()
                ),
                "structurally_associated_footprint_tco2": float(
                    pd.to_numeric(pairs["avoided_hotspot_footprint_tco2"], errors="raise").sum()
                ),
                "governance_supported_marginal_reduction_tco2": float(
                    portfolio_row["governance_supported_marginal_reduction_tco2"]
                ),
                "cumulative_governance_supported_hotspot_coverage": float(
                    portfolio_row["cumulative_governance_supported_hotspot_coverage"]
                ),
                "cumulative_governance_supported_company_coverage": float(
                    portfolio_row["cumulative_governance_supported_company_coverage"]
                ),
                "abatement_scenario_status": scenario_status,
                "scenario_conservative_reduction_tco2": scenario_sum(
                    "scenario_conservative_reduction_tco2"
                ),
                "scenario_expected_reduction_tco2": scenario_sum(
                    "scenario_expected_reduction_tco2"
                ),
                "scenario_ambitious_reduction_tco2": scenario_sum(
                    "scenario_ambitious_reduction_tco2"
                ),
                "scenario_assumption_summary": " | ".join(scenario_assumptions),
                "scenario_evidence_references": "; ".join(
                    value
                    for value in dict.fromkeys(pairs.get("scenario_evidence_reference", pd.Series(dtype=str)).astype(str))
                    if _safe_text(value)
                ),
                "scenario_assessment_ids": "; ".join(
                    value
                    for value in pairs.get("scenario_id", pd.Series(dtype=str)).astype(str)
                    if _safe_text(value)
                ),
                "scenario_claim_boundary": (
                    "The conservative, expected, and ambitious values are assumption-bound comparative estimates, "
                    "not guaranteed or observed abatement. Structural coverage remains a separate diagnostic."
                ),
                "governance_eligibility_status": ELIGIBLE_STATUS,
                "claim_boundary": (
                    "Governance eligibility confirms evidence completeness and organizational actionability; "
                    "structural coverage is not predicted or guaranteed real-world abatement."
                ),
            }
            fingerprint_payload = {
                "extension_id": INTERVENTION_GOVERNANCE_EXTENSION_ID,
                "abatement_decision_gate_extension_id": ABATEMENT_DECISION_GATE_EXTENSION_ID,
                "source_network_result_cid": str(source_network_result_cid),
                "source_aurora_result_cid": str(source_aurora_result_cid),
                "input_hashes": {str(k): str(v) for k, v in input_hashes.items()},
                **option,
            }
            option_fingerprint = _fingerprint(fingerprint_payload)
            option["option_fingerprint"] = option_fingerprint
            option_cid = existing_map.get(option_fingerprint, "")
            if not option_cid and store_content_fn is not None and source_network_result_cid:
                option_cid = str(
                    store_content_fn(
                        {
                            "extension_id": INTERVENTION_GOVERNANCE_EXTENSION_ID,
                            "abatement_decision_gate_extension_id": ABATEMENT_DECISION_GATE_EXTENSION_ID,
                            "source_network_result_cid": str(source_network_result_cid),
                            "source_aurora_result_cid": str(source_aurora_result_cid),
                            "input_hashes": {str(k): str(v) for k, v in input_hashes.items()},
                            "intervention": option,
                            "pair_evidence": pairs.to_dict(orient="records"),
                            "portfolio_evidence": portfolio_row,
                            "option_fingerprint": option_fingerprint,
                            "authority_boundary": (
                                "Deterministic analytics remain numerical authority. Actionability is a named "
                                "stakeholder attestation, not an LLM inference."
                            ),
                        },
                        "u16_governance_ready_intervention_option",
                    )
                )
            option["option_cid"] = option_cid
            records.append(option)
    if not records:
        return pd.DataFrame(columns=columns)
    return pd.DataFrame.from_records(records, columns=columns).sort_values(
        ["portfolio_selection_step", "dli_rank", "node_code", "mechanism_code"],
        kind="mergesort",
    ).reset_index(drop=True)


def compute_intervention_governance(
    model: Any,
    demand: np.ndarray,
    pair_evidence: pd.DataFrame,
    *,
    assessments: pd.DataFrame | None = None,
    target_coverage: float = 0.80,
    source_network_result_cid: str = "",
    source_aurora_result_cid: str = "",
    input_hashes: Mapping[str, str] | None = None,
    store_content_fn: Callable[[Any, str], str] | None = None,
    existing_options: pd.DataFrame | None = None,
) -> InterventionGovernanceResult:
    if int(model.year) != 2017:
        raise ValueError("Intervention governance is defined for the 2017 decision year")
    if not 0.0 < float(target_coverage) <= 1.0:
        raise ValueError("target_coverage must lie in (0, 1]")
    candidates = build_pair_candidates(pair_evidence)
    merged = merge_actionability(candidates, assessments)
    assessment_columns = [
        "candidate_id",
        "intervention_node",
        "hotspot_producer_node",
        "mechanism_code",
        *ACTIONABILITY_FIELDS,
        *ASSESSMENT_TEXT_FIELDS,
        *SCENARIO_NUMERIC_FIELDS,
        *SCENARIO_TEXT_FIELDS,
        "scenario_status",
        "scenario_status_basis",
        "scenario_addressable_footprint_tco2",
        "scenario_conservative_reduction_tco2",
        "scenario_expected_reduction_tco2",
        "scenario_ambitious_reduction_tco2",
        "scenario_id",
        "scenario_submitted_at_utc",
        "assessment_status",
        "assessment_status_basis",
        "assessment_id",
        "assessment_submitted_at_utc",
    ]
    assessment_frame = merged[
        [column for column in assessment_columns if column in merged.columns]
    ].copy()

    hotspot_reference = pair_evidence[
        ["hotspot_producer_node", "hotspot_rank", "baseline_hotspot_footprint_tco2"]
    ].drop_duplicates("hotspot_producer_node").sort_values(
        ["hotspot_rank", "hotspot_producer_node"], kind="mergesort"
    )
    all_hotspot_codes = hotspot_reference["hotspot_producer_node"].astype(str).tolist()
    hotspot_total = float(hotspot_reference["baseline_hotspot_footprint_tco2"].sum())
    model_output = np.asarray(model.L, dtype=float) @ np.asarray(demand, dtype=float)
    company_total = float(np.asarray(model.fE, dtype=float) @ model_output)

    eligible_pairs = merged.loc[
        merged["governance_eligibility_status"].eq(ELIGIBLE_STATUS)
    ].copy()
    portfolio = _portfolio_with_pair_gate(
        stage="governance_ready",
        model=model,
        demand=demand,
        all_hotspot_codes=all_hotspot_codes,
        eligible_pairs=eligible_pairs,
        target_coverage=target_coverage,
    )
    options = _build_governance_options(
        merged,
        portfolio.frame,
        source_network_result_cid=source_network_result_cid,
        source_aurora_result_cid=source_aurora_result_cid,
        input_hashes=input_hashes or {},
        store_content_fn=store_content_fn,
        existing_options=existing_options,
    )
    return InterventionGovernanceResult(
        year=2017,
        candidates=candidates,
        assessments=assessment_frame,
        eligibility=merged,
        portfolio=portfolio,
        governance_options=options,
        hotspot_total_footprint=hotspot_total,
        company_total_footprint=company_total,
        hotspot_count=len(all_hotspot_codes),
    )


def _format_workbook(path: Path) -> None:
    from openpyxl import load_workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    workbook = load_workbook(path)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    for worksheet in workbook.worksheets:
        worksheet.freeze_panes = "A2"
        worksheet.sheet_view.showGridLines = False
        if worksheet.max_row:
            for cell in worksheet[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            worksheet.auto_filter.ref = worksheet.dimensions
        for column_index, cells in enumerate(worksheet.columns, start=1):
            width = 10
            for cell in list(cells)[:300]:
                text = "" if cell.value is None else str(cell.value)
                width = max(width, min(52, len(text) + 2))
                if cell.row > 1:
                    cell.alignment = Alignment(vertical="top", wrap_text=True)
            worksheet.column_dimensions[get_column_letter(column_index)].width = width
    workbook.save(path)


def _artifact_record(path: Path) -> dict[str, Any]:
    record: dict[str, Any] = {"filename": path.name, "sha256": _sha256_file(path)}
    if path.suffix.lower() == ".csv":
        with path.open("r", encoding="utf-8") as handle:
            record["row_count"] = max(0, sum(1 for _ in handle) - 1)
    return record


def _node_actionability_view(assessments: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "intervention_node",
        *NODE_ACTIONABILITY_FIELDS,
        "assessor_name",
        "assessor_role",
        "evidence_reference",
        "assessment_submitted_at_utc",
    ]
    if assessments.empty:
        return pd.DataFrame(columns=columns)
    available = [column for column in columns if column in assessments.columns]
    return assessments[available].sort_values(
        ["intervention_node", "assessment_submitted_at_utc"], kind="mergesort"
    ).drop_duplicates("intervention_node", keep="last").reset_index(drop=True)


def _pair_feasibility_view(assessments: pd.DataFrame) -> pd.DataFrame:
    columns = [
        "candidate_id",
        "intervention_node",
        "hotspot_producer_node",
        "mechanism_code",
        *PAIR_FEASIBILITY_FIELDS,
        "assessment_notes",
        *SCENARIO_NUMERIC_FIELDS,
        *SCENARIO_TEXT_FIELDS,
        "scenario_status",
        "scenario_status_basis",
        "scenario_addressable_footprint_tco2",
        "scenario_conservative_reduction_tco2",
        "scenario_expected_reduction_tco2",
        "scenario_ambitious_reduction_tco2",
        "scenario_id",
        "scenario_submitted_at_utc",
        "assessment_status",
        "assessment_status_basis",
        "assessment_id",
        "assessment_submitted_at_utc",
    ]
    if assessments.empty:
        return pd.DataFrame(columns=columns)
    return assessments[[column for column in columns if column in assessments.columns]].copy()


def write_intervention_governance_artifacts(
    output_dir: str | Path,
    result: InterventionGovernanceResult,
    *,
    input_hashes: Mapping[str, str],
    source_network_result_cid: str,
    hotspot_leverage_evidence_cid: str,
    node_sda_evidence_cid: str,
    critic_evidence_cid: str,
    integrated_evidence_cid: str = "",
    source_aurora_result_cid: str = "",
    store_content_fn: Callable[[Any, str], str] | None = None,
) -> dict[str, Any]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    paths = {
        "pair_candidates": output / PAIR_CANDIDATES_FILENAME,
        "actionability_assessments": output / ACTIONABILITY_FILENAME,
        "node_actionability": output / NODE_ACTIONABILITY_FILENAME,
        "pair_feasibility": output / PAIR_FEASIBILITY_FILENAME,
        "eligibility": output / ELIGIBILITY_FILENAME,
        "governance_ready_portfolio": output / GOVERNANCE_PORTFOLIO_FILENAME,
        "governance_ready_options": output / GOVERNANCE_OPTIONS_FILENAME,
        "workbook": output / WORKBOOK_FILENAME,
    }
    node_actionability = _node_actionability_view(result.assessments)
    pair_feasibility = _pair_feasibility_view(result.assessments)
    result.candidates.to_csv(paths["pair_candidates"], index=False)
    result.assessments.to_csv(paths["actionability_assessments"], index=False)
    node_actionability.to_csv(paths["node_actionability"], index=False)
    pair_feasibility.to_csv(paths["pair_feasibility"], index=False)
    result.eligibility.to_csv(paths["eligibility"], index=False)
    result.portfolio.frame.to_csv(paths["governance_ready_portfolio"], index=False)
    result.governance_options.to_csv(paths["governance_ready_options"], index=False)

    portfolio_summary = {
        "portfolio_stage": result.portfolio.stage,
        "selected_node_count": int(len(result.portfolio.frame)),
        "target_hotspot_structural_coverage": result.portfolio.target_coverage,
        "achieved_governance_supported_hotspot_coverage": result.portfolio.achieved_hotspot_coverage,
        "achieved_governance_supported_company_coverage": result.portfolio.achieved_company_coverage,
        "achieved_full_joint_hotspot_coverage": result.portfolio.achieved_full_hotspot_coverage,
        "achieved_full_joint_company_coverage": result.portfolio.achieved_full_company_coverage,
        "reached_target": result.portfolio.reached_target,
        "stop_reason": result.portfolio.stop_reason,
    }
    notes = pd.DataFrame(
        [
            {
                "topic": "Single intervention funnel",
                "statement": "The current method writes one governance-ready portfolio. Earlier route portfolios remain diagnostic evidence only, and the duplicate structural/driver-compatible portfolio sequence is retired.",
            },
            {
                "topic": "Mechanism mapping",
                "statement": "The largest positive signed hotspot node-SDA effect is the primary adverse intervention driver. Mechanism assignment is a deterministic mapping, not a tautological compatibility gate; all signed effects remain visible and beneficial effects are preserved.",
            },
            {
                "topic": "Path-SDA role",
                "statement": "Union-based exact path identities classify persistent, emerging, disappearing, and reconfigured routes. Path-SDA refines mechanism design but does not replace authoritative node-SDA or complete CDR linkage.",
            },
            {
                "topic": "Actionability model",
                "statement": "Contractual, procurement, assurance, ownership and resource evidence is stored once per leverage node; technical feasibility remains hotspot/mechanism specific.",
            },
            {
                "topic": "Coverage denominators",
                "statement": "The portfolio reports both coverage of the approximately-80% hotspot set and coverage of the complete company footprint; the two percentages must not be conflated.",
            },
            {
                "topic": "Claim boundary",
                "statement": "Complete-node-removal structural coverage is not predicted, feasible, or guaranteed real-world abatement.",
            },
            {
                "topic": "Intervention-specific abatement scenarios",
                "statement": "Scenario ranges use a capped structurally associated footprint and documented effectiveness, implementation-coverage, and adoption assumptions. They are pre-decision comparative estimates, not achieved or guaranteed reductions.",
            },
        ]
    )
    with pd.ExcelWriter(paths["workbook"], engine="openpyxl") as writer:
        pd.DataFrame([portfolio_summary]).to_excel(writer, sheet_name="Portfolio_Summary", index=False)
        result.candidates.to_excel(writer, sheet_name="Pair_Candidates", index=False)
        node_actionability.to_excel(writer, sheet_name="Node_Actionability", index=False)
        pair_feasibility.to_excel(writer, sheet_name="Pair_Feasibility", index=False)
        result.eligibility.to_excel(writer, sheet_name="Eligibility", index=False)
        result.portfolio.frame.to_excel(writer, sheet_name="Governance_Portfolio", index=False)
        result.governance_options.to_excel(writer, sheet_name="Governance_Options", index=False)
        notes.to_excel(writer, sheet_name="Methodology_Notes", index=False)
    _format_workbook(paths["workbook"])

    artifacts = {name: _artifact_record(path) for name, path in paths.items()}
    assessment_counts = (
        result.eligibility["assessment_status"].value_counts(dropna=False).to_dict()
        if not result.eligibility.empty
        else {}
    )
    eligibility_counts = (
        result.eligibility["governance_eligibility_status"].value_counts(dropna=False).to_dict()
        if not result.eligibility.empty
        else {}
    )
    scenario_counts = (
        result.eligibility["scenario_status"].value_counts(dropna=False).to_dict()
        if not result.eligibility.empty and "scenario_status" in result.eligibility.columns
        else {}
    )
    metadata_basis = {
        "extension_id": INTERVENTION_GOVERNANCE_EXTENSION_ID,
        "abatement_decision_gate_extension_id": ABATEMENT_DECISION_GATE_EXTENSION_ID,
        "year": result.year,
        "source_network_result_cid": str(source_network_result_cid),
        "source_aurora_result_cid": str(source_aurora_result_cid),
        "input_hashes": {str(key): str(value) for key, value in input_hashes.items()},
        "hotspot_leverage_evidence_cid": str(hotspot_leverage_evidence_cid),
        "node_sda_evidence_cid": str(node_sda_evidence_cid),
        "critic_evidence_cid": str(critic_evidence_cid),
        "integrated_evidence_cid": str(integrated_evidence_cid),
        "candidate_pair_count": int(len(result.candidates)),
        "hotspot_count": int(result.hotspot_count),
        "hotspot_total_footprint_tco2": float(result.hotspot_total_footprint),
        "company_total_footprint_tco2": float(result.company_total_footprint),
        "hotspot_share_of_company_footprint": (
            result.hotspot_total_footprint / result.company_total_footprint
            if result.company_total_footprint
            else 0.0
        ),
        "assessment_status_counts": {str(k): int(v) for k, v in assessment_counts.items()},
        "eligibility_status_counts": {str(k): int(v) for k, v in eligibility_counts.items()},
        "abatement_scenario_status_counts": {str(k): int(v) for k, v in scenario_counts.items()},
        "governance_ready_option_count": int(len(result.governance_options)),
        "portfolio_summary": portfolio_summary,
        "intervention_funnel": (
            "positive linkage -> primary adverse node-SDA driver -> deterministic mechanism mapping -> "
            "regional opportunity -> node actionability + pair feasibility + optional evidence-backed abatement range -> "
            "one exact joint governance-ready portfolio -> human selection and decision"
        ),
        "methodology_sequence": (
            "temporal Network/DLI -> fulfilled AURORA evidence CID -> deterministic intervention evidence -> "
            "optional formal governance"
        ),
        "path_identity_rule": (
            "union of complete ordered 2014/2017 path identities; common nodes may follow different paths"
        ),
        "dli_boundary": (
            "node/path SDA, linkage, actionability and governance do not enter BC, PR, CDR, IC, "
            "pooled Pearson-CRITIC, DLI scores, or DLI ranks"
        ),
        "abatement_boundary": (
            "complete-node-removal structural coverage is not predicted abatement; scenario ranges are assumption-bound "
            "comparative estimates and remain distinct from post-deployment observed reductions"
        ),
        "artifacts": artifacts,
    }
    governance_evidence_cid = ""
    if store_content_fn is not None and source_network_result_cid:
        governance_evidence_cid = str(
            store_content_fn(metadata_basis, "u16_intervention_governance_evidence")
        )
    metadata = {
        **metadata_basis,
        "intervention_governance_evidence_cid": governance_evidence_cid,
        "generated_at_utc": _utc_now(),
    }
    metadata_path = output / METADATA_FILENAME
    temporary = metadata_path.with_name(f".{metadata_path.name}.tmp")
    temporary.write_text(
        json.dumps(_json_safe(metadata), indent=2, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )
    temporary.replace(metadata_path)
    return metadata


def verify_intervention_governance_artifacts(
    output_dir: str | Path,
    *,
    expected_input_hashes: Mapping[str, str] | None = None,
    expected_source_network_result_cid: str | None = None,
    expected_source_aurora_result_cid: str | None = None,
) -> dict[str, Any]:
    output = Path(output_dir)
    metadata_path = output / METADATA_FILENAME
    if not metadata_path.is_file():
        raise FileNotFoundError(
            "Intervention-governance evidence is unavailable. Complete node-wise SDA, both Network/DLI years, and the governed 2017 AURORA assessment."
        )
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    if metadata.get("extension_id") != INTERVENTION_GOVERNANCE_EXTENSION_ID:
        raise RuntimeError("Intervention-governance metadata has an unexpected extension identity")
    if metadata.get("abatement_decision_gate_extension_id") != ABATEMENT_DECISION_GATE_EXTENSION_ID:
        raise RuntimeError("Intervention-governance metadata predates the explicit abatement-decision gate")
    if expected_input_hashes is not None and metadata.get("input_hashes") != {
        str(key): str(value) for key, value in expected_input_hashes.items()
    }:
        raise RuntimeError("Intervention-governance evidence is stale for the active input workbooks")
    if expected_source_network_result_cid is not None and str(
        metadata.get("source_network_result_cid", "")
    ) != str(expected_source_network_result_cid):
        raise RuntimeError("Intervention-governance evidence is bound to a different 2017 Network/DLI result")
    if expected_source_aurora_result_cid is not None and str(
        metadata.get("source_aurora_result_cid", "")
    ) != str(expected_source_aurora_result_cid):
        raise RuntimeError("Intervention-governance evidence is bound to a different fulfilled AURORA result")
    for name, record in metadata.get("artifacts", {}).items():
        filename = str(record.get("filename", ""))
        if not filename or Path(filename).name != filename:
            raise RuntimeError(f"Unsafe intervention artifact filename for {name}")
        path = output / filename
        if not path.is_file():
            raise FileNotFoundError(f"Intervention artifact is missing: {filename}")
        if _sha256_file(path) != str(record.get("sha256", "")):
            raise RuntimeError(f"Intervention artifact failed SHA-256 verification: {filename}")
        if path.suffix.lower() == ".csv" and "row_count" in record:
            with path.open("r", encoding="utf-8") as handle:
                observed = max(0, sum(1 for _ in handle) - 1)
            if observed != int(record["row_count"]):
                raise RuntimeError(f"Intervention artifact failed row-count verification: {filename}")
    return metadata


def load_intervention_governance_frames(output_dir: str | Path) -> dict[str, pd.DataFrame]:
    output = Path(output_dir)
    return {
        "candidates": pd.read_csv(output / PAIR_CANDIDATES_FILENAME),
        "assessments": pd.read_csv(output / ACTIONABILITY_FILENAME, keep_default_na=False),
        "node_actionability": pd.read_csv(output / NODE_ACTIONABILITY_FILENAME, keep_default_na=False),
        "pair_feasibility": pd.read_csv(output / PAIR_FEASIBILITY_FILENAME, keep_default_na=False),
        "eligibility": pd.read_csv(output / ELIGIBILITY_FILENAME),
        "governance_ready": pd.read_csv(output / GOVERNANCE_PORTFOLIO_FILENAME),
        "governance_options": pd.read_csv(output / GOVERNANCE_OPTIONS_FILENAME, keep_default_na=False),
    }


def capture_post_aurora_materialization(
    materialize: Callable[[], Mapping[str, Any]],
) -> dict[str, Any]:
    """Capture post-AURORA artifact status without changing AURORA validity.

    Intervention evidence is downstream of AURORA.  A local workbook, CSV, or
    candidate-register failure must therefore leave the already computed and
    content-addressed AURORA result valid and returnable.  Formal intervention
    governance remains fail-closed until a later materialization succeeds.
    """

    try:
        metadata = materialize()
        if not isinstance(metadata, Mapping):
            raise TypeError("post-AURORA intervention materialization returned invalid metadata")
        materialized = dict(metadata)
        return {
            "available": True,
            "status": "materialized-on-demand",
            "metadata": materialized,
            "intervention_governance_evidence_cid": str(
                materialized.get("intervention_governance_evidence_cid", "")
            ),
        }
    except Exception as exc:
        return {
            "available": False,
            "status": "post-aurora-materialization-failed-governance-unresolved",
            "error_type": type(exc).__name__,
            "error": str(exc),
            "metadata": {},
            "intervention_governance_evidence_cid": "",
            "authority_boundary": (
                "AURORA remains valid. Formal intervention governance stays unavailable and fail-closed "
                "until its downstream evidence can be materialized and verified."
            ),
        }


__all__ = (
    "INTERVENTION_GOVERNANCE_EXTENSION_ID",
    "ABATEMENT_DECISION_GATE_EXTENSION_ID",
    "NODE_ACTIONABILITY_FIELDS",
    "PAIR_FEASIBILITY_FIELDS",
    "ACTIONABILITY_FIELDS",
    "ASSESSMENT_TEXT_FIELDS",
    "SCENARIO_NUMERIC_FIELDS",
    "SCENARIO_TEXT_FIELDS",
    "SCENARIO_DECISION_VALUES",
    "SCENARIO_GOVERNANCE_READY_STATUSES",
    "ASSESSMENT_VALUES",
    "ELIGIBLE_STATUS",
    "MECHANISM_LIBRARY",
    "PortfolioResult",
    "InterventionGovernanceResult",
    "build_pair_candidates",
    "empty_assessments",
    "assess_actionability",
    "upsert_actionability_assessment",
    "merge_actionability",
    "compute_intervention_governance",
    "write_intervention_governance_artifacts",
    "verify_intervention_governance_artifacts",
    "load_intervention_governance_frames",
    "capture_post_aurora_materialization",
    "PAIR_CANDIDATES_FILENAME",
    "ACTIONABILITY_FILENAME",
    "NODE_ACTIONABILITY_FILENAME",
    "PAIR_FEASIBILITY_FILENAME",
    "ELIGIBILITY_FILENAME",
    "GOVERNANCE_PORTFOLIO_FILENAME",
    "GOVERNANCE_OPTIONS_FILENAME",
    "WORKBOOK_FILENAME",
    "METADATA_FILENAME",
    "PORTFOLIO_COLUMNS",
)
