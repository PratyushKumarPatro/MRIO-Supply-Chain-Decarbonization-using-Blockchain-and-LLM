"""Regression tests for the final unit/UI and bounded-SPA correction."""
from __future__ import annotations

import json
import subprocess
import sys
import unittest
from pathlib import Path

import numpy as np

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

import spa_engine as spa  # noqa: E402


class _DummyMRIO:
    def __init__(self) -> None:
        n = 8
        self.Z = np.full((n, n), 0.03, dtype=float)
        np.fill_diagonal(self.Z, 0.0)
        self.X = np.ones(n, dtype=float)
        self.fE = np.linspace(0.1, 0.8, n)
        self.node_codes = np.array([f"N{i}" for i in range(n)])
        self._A = self.Z.copy()
        self._L = np.linalg.inv(np.eye(n) - self._A)

    def footprint(self, demand: np.ndarray) -> float:
        return float(self.fE @ (self._L @ demand))

    def footprint_by_node(self, demand: np.ndarray) -> np.ndarray:
        return self.fE * (self._L @ demand)


class FinalUnitAndSPATests(unittest.TestCase):
    def test_focal_company_labels_are_tonnes_everywhere_on_headline_page(self):
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        units = (ROOT / "streamlit_app" / "ui_units.py").read_text(encoding="utf-8")
        self.assertIn('FOCAL_EMISSIONS_UNIT = "t CO₂"', units)
        self.assertIn('2014 focal-company footprint ({FOCAL_EMISSIONS_UNIT})', app)
        self.assertIn('2017 focal-company footprint ({FOCAL_EMISSIONS_UNIT})', app)
        self.assertIn('Change, 2014–2017 ({FOCAL_EMISSIONS_UNIT})', app)
        self.assertIn('not million tonnes', app)
        self.assertNotIn('Share of economy-wide footprint (2017)', app)

    def test_bounded_beam_limits_retained_and_reported_paths(self):
        model = _DummyMRIO()
        demand = np.zeros(8, dtype=float)
        demand[[0, 1]] = [10.0, 5.0]
        cfg = spa.SPAConfig(
            max_depth=4,
            exact_max_tier=6,
            top_k_per_hop=7,
            beam_width=3,
            max_reported_paths=4,
            min_coefficient=0.0,
            cumulative_target=0.999999,
        )
        screened, total = spa.trace_paths(model, demand, cfg)
        reported, reached = spa.top_paths_to_threshold(screened, cfg)
        self.assertGreater(total, 0)
        self.assertLessEqual(len(screened), 2 + cfg.max_depth * cfg.beam_width)
        self.assertLessEqual(len(reported), cfg.max_reported_paths)
        self.assertFalse(reached)

    def test_u17_has_no_fixed_reporting_cap_inside_bounded_beam(self):
        source = (ROOT / "spa_engine.py").read_text(encoding="utf-8")
        self.assertIn('max_reported_paths: int | None = None', source)
        self.assertIn('cumulative_target: float = 0.87', source)
        self.assertIn('return ranked.copy(), False', source)
        self.assertIn('beam_width: int = 5_000', source)
        self.assertIn('exact_max_tier: int = 30', source)
        self.assertNotIn('max_reported_paths: int = 5_000', source)

    def test_launcher_restarts_stale_platform_ports_and_checks_release(self):
        source = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        self.assertIn('Stop-RqPortListener 8765', source)
        self.assertIn('Stop-RqPortListener 8501', source)
        self.assertIn("function Get-RqVersionValue", source)
        self.assertIn('$ExpectedReleasePatch = Get-RqVersionValue -Key "release_patch"', source)
        self.assertIn("$candidate.release_patch -eq $ExpectedReleasePatch", source)
        self.assertNotIn("final-unit-ui-bounded-spa-1", source)
        self.assertIn('$env:SCIG_FOCAL_EMISSIONS_UNIT = "t CO2"', source)

    def test_orchestrator_reports_screening_and_exact_tier_diagnostics(self):
        source = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        for marker in [
            '"reported_path_count"',
            '"screened_path_count"',
            '"screened_cumulative_share"',
            '"reported_cumulative_share"',
            'range(config.exact_max_tier + 1)',
            '"path_contribution": "t CO2"',
        ]:
            self.assertIn(marker, source)

    def test_legacy_top15_authority_is_retired_and_direct_intensity_sensitivity_is_optional(self):
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        legacy = (ROOT / "intervention_rules.py").read_text(encoding="utf-8")
        for marker in [
            'year = _select_available_year("mrio", "scenario_year")',
            '"Illustrative direct intensity sensitivity"',
            '"Literature-sourced direct intensity scenario"',
            'sce.counterfactual_footprint(',
            'sce.run_scenario_library(my, company_y, node_code)',
            'not a formal intervention recommendation',
            'DLI does not authorize this sensitivity as an intervention',
        ]:
            self.assertIn(marker, app)
        self.assertIn("intervention_records: list[dict[str, Any]] = []", orchestrator)
        self.assertIn('"interventions": intervention_records', orchestrator)
        self.assertIn('LEGACY_FORMAL_AUTHORITY = False', legacy)
        self.assertNotIn('ir.generate_interventions', app)
        self.assertNotIn('network_payload.get("interventions", [])', app)



if __name__ == "__main__":
    unittest.main(verbosity=2)
