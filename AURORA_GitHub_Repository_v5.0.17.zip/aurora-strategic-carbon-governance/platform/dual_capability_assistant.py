"""LLM-first conversational agent for the Strategic Carbon Intelligence & Governance deployment.

In Auto mode the local Ollama model is the primary task interpreter and
user-facing reasoner. It can answer ordinary, strategic, critical, explanatory,
hypothetical, comparative, recommendation, writing, and mixed questions without
forcing them into the deterministic research planner. Closed Strategic Carbon Intelligence & Governance tools are
invoked only when an exact project result is explicitly required or when validated
project evidence is deliberately selected as supporting context.

The internal routes remain ``research``, ``general``, ``hybrid``, and
``system_meta`` for audit and QueryManagement compatibility. Research-only and
General-chat overrides remain available. Project-specific numerical values,
rankings, scenarios, and country-sector node claims always remain under the
authority of strategic_assistant.py and its deterministic tools.
"""
from __future__ import annotations

import json
import re
from dataclasses import asdict, dataclass, field
from typing import Any

import strategic_assistant as sa
import query_intelligence as qi
import system_meta_assistant as sma
import llm_first_orchestrator as lfo


MODE_ALIASES = {
    "auto": "auto",
    "research": "research",
    "research only": "research",
    "general": "general",
    "general chat": "general",
}

RESEARCH_PATTERNS = [
    r"\bcarbon accounting\b",
    r"\bgreenhouse[- ]gas accounting\b",
    r"\bghg accounting\b",
    r"\bscope\s+[123]\b",
    r"\bconsumption[- ]based\b",
    r"\bembodied carbon\b",
    r"\bupstream emissions?\b",
    r"\bcarbon footprint\b",
    r"\bsupply[- ]chain emissions?\b",
    r"\bdecarboni[sz]ation leverage\b",
    r"\bdli\b",
    r"\bmrio\b",
    r"\bmulti[- ]regional input[- ]output\b",
    r"\bstructural path(?: analysis)?\b",
    r"\bspa\b",
    r"\bstructural decomposition(?: analysis)?\b",
    r"\bsda\b",
    r"\bemission hotspots?\b",
    r"\bnetwork centrality\b",
    r"\bpage\s*rank\b",
    r"\bbetweenness\b",
    r"\bdependency risk\b",
    r"\bintervention criticality\b",
    r"\bsourcing optimi[sz]ation\b",
    r"\bsupplier reallocation\b",
    r"\bdomestic(?:[- ]footprint)? share\b",
    r"\bsector demand\b",
    r"\bcountry[- ]sector\b",
    r"\bwhich node\b",
    r"\bnode profile\b",
    r"\bfocal[- ]company\b",
    r"\bour (?:2014|2017|company|footprint|hotspot|dli|supply chain)\b",
    r"\bthis (?:study|model|research)\b",
    r"\bintervention(?:s)?\b",
]

HYBRID_PATTERNS = [
    r"\bbroader\b",
    r"\bgeneral (?:context|background|perspective)\b",
    r"\bin (?:industry|business|management|procurement) practice\b",
    r"\bconventional (?:approach|practice|supplier|method)\b",
    r"\bbest practice\b",
    r"\breal[- ]world\b",
    r"\bmanagerial (?:importance|implication|meaning|relevance)\b",
    r"\bpolicy implication\b",
    r"\boutside (?:this|the) (?:study|model|framework)\b",
    r"\bcompare (?:our|this|the study)\b",
    r"\bhow does (?:our|this) .* compare\b",
    r"\bwhy (?:does|is) .* matter\b",
    r"\bcommunicat(?:e|ion)\b",
    r"\bwrite\b.*\b(?:email|memo|brief|summary|presentation|speech)\b",
    r"\bdraft\b.*\b(?:email|memo|brief|summary|presentation|speech)\b",
]

PERSONAL_GENERAL_PATTERNS = [
    r"\bat home\b",
    r"\bmy home\b",
    r"\bpersonal carbon\b",
    r"\bmy diet\b",
    r"\bmy travel\b",
    r"\bhousehold\b",
]

FOLLOW_UP_PATTERNS = [
    r"\bit\b",
    r"\bthat node\b",
    r"\bthis node\b",
    r"\bthat supplier\b",
    r"\bthis supplier\b",
    r"\bthe same node\b",
    r"\bwhat about\b",
    r"\bwhy\b",
    r"\bhow about\b",
    r"\band the intervention\b",
    r"\band its\b",
    r"\btell me more\b",
    r"\belaborate\b",
    r"\bexplain further\b",
    r"\band what\b",
]

EMPIRICAL_FOLLOW_UP_PATTERNS = [
    r"\bintervention\b",
    r"\brank\b",
    r"\bscore\b",
    r"\bhotspot\b",
    r"\bpath\b",
    r"\bfootprint\b",
    r"\bscenario\b",
    r"\bwhy\b",
    r"\bcompare\b",
    r"\bpriority\b",
    r"\bimportant\b",
]

GENERAL_SYSTEM_PROMPT = """You are the general conversational layer of a local
Strategic Carbon Intelligence application. Answer the user's ordinary question
helpfully, directly, and in a natural style. Prefer connected paragraphs over
disconnected fragments unless the user explicitly requests a list. You may handle general knowledge,
writing, explanation, brainstorming, and everyday tasks. You are running
locally through Ollama and do not have live web access unless a separate tool is
explicitly provided. Do not pretend that current facts have been verified. Do
not invent results from the application's MRIO, SPA, SDA, DLI, intervention,
scenario, sourcing, or blockchain modules. If a question asks for project-
specific analytical values, say those values must come from the validated
research route. For medical, legal, or financial decisions, provide only general
information and encourage appropriate professional verification."""

HYBRID_SYSTEM_PROMPT = """You are the broader-context layer of a dual-capability
Strategic Carbon Intelligence assistant. A validated deterministic research
answer will be displayed separately and is authoritative for every claim about
the focal company, the study, years, nodes, rankings, scenarios, and numerical
results. Add only the broader context requested by the user: managerial meaning,
comparison with conventional practice, communication support, implications, or
general explanation. Do not change, recompute, contradict, or invent any project-
specific result. Write one coherent paragraph that connects naturally to the
validated answer; do not repeat the full research answer. State uncertainty where
appropriate and do not claim live web verification."""


@dataclass
class ConversationState:
    active_year: str = ""
    active_node: str = ""
    last_route: str = ""
    last_research_question: str = ""
    last_tools: list[str] = field(default_factory=list)
    last_meta_aspects: list[str] = field(default_factory=list)
    turn_count: int = 0


@dataclass
class ConversationResult:
    question: str
    effective_question: str
    requested_mode: str
    route: str
    blockchain_route: str
    answer: str
    research_answer: str
    general_answer: str
    plan: dict[str, Any]
    evidence: list[dict[str, Any]]
    provenance: dict[str, Any]
    state: dict[str, Any]
    model_metrics: dict[str, Any]
    system_answer: str = ""


def state_from(value: ConversationState | dict[str, Any] | None) -> ConversationState:
    if isinstance(value, ConversationState):
        return ConversationState(**asdict(value))
    if isinstance(value, dict):
        allowed = {field.name for field in ConversationState.__dataclass_fields__.values()}
        payload = {key: value[key] for key in allowed if key in value}
        try:
            return ConversationState(**payload)
        except TypeError:
            return ConversationState()
    return ConversationState()


def normalise_mode(mode: str | None) -> str:
    return MODE_ALIASES.get(str(mode or "auto").strip().casefold(), "auto")


def _contains(patterns: list[str], text: str) -> bool:
    return any(re.search(pattern, text, flags=re.IGNORECASE) for pattern in patterns)


def _has_known_node(question: str) -> bool:
    try:
        return bool(sa._extract_node_code(question))
    except Exception:
        return bool(re.search(r"\b[A-Z]{3}[-_][A-Za-z0-9]+\b", question))


def _research_signal(question: str, state: ConversationState) -> bool:
    q = question.casefold()
    if _contains(PERSONAL_GENERAL_PATTERNS, q) and not _has_known_node(question):
        return False
    if _has_known_node(question) or _contains(RESEARCH_PATTERNS, q):
        return True
    if state.last_route in {"research", "hybrid"} and _contains(FOLLOW_UP_PATTERNS, q):
        return True
    return False


def _hybrid_signal(question: str) -> bool:
    return _contains(HYBRID_PATTERNS, question.casefold())


def classify_route(
    question: str,
    mode: str = "auto",
    state: ConversationState | dict[str, Any] | None = None,
    client: Any | None = None,
) -> tuple[str, dict[str, Any]]:
    """Select a guarded route with explicit support for system-level questions."""

    state_obj = state_from(state)
    requested = normalise_mode(mode)
    research_signal = _research_signal(question, state_obj)
    hybrid_signal = research_signal and _hybrid_signal(question)
    baseline = qi.deterministic_understanding(
        question,
        last_route=state_obj.last_route,
        research_signal=research_signal,
        hybrid_signal=hybrid_signal,
    )
    understanding = baseline

    if requested == "general":
        route = "general"
        reason = "General chat mode was selected by the user."
    else:
        if requested == "auto" and client is not None:
            understanding = qi.interpret_ambiguous_query(client, question, baseline)
        guarded = qi.guarded_route_from_understanding(understanding, baseline)
        if requested == "research":
            # Research-only mode excludes ordinary general chat, but a question
            # about the deployed architecture belongs in the validated
            # system-knowledge route rather than the analytical planner.
            route = "system_meta" if guarded == "system_meta" else "research"
        else:
            route = guarded

        reason = {
            "system_meta": (
                "The question concerns deployment, architecture, limitations, reliability, or improvement of the Strategic Carbon Intelligence & Governance system; analytical tools are not required."
            ),
            "hybrid": (
                "The question combines deployed analytical evidence with broader context or communication needs."
            ),
            "research": (
                "A deployed carbon-governance concept, method, entity, or analytical request was detected."
            ),
            "general": (
                "No validated project-analytical or system-architecture evidence is required, so the local general assistant is used."
            ),
        }.get(route, "The LLM-first orchestrator selected this route.")

    return route, {
        "requested_mode": requested,
        "research_signal": research_signal,
        "hybrid_signal": hybrid_signal,
        "system_meta_signal": baseline.get("route_hint") == "system_meta",
        "query_understanding": understanding,
        "reason": reason,
    }


def _explicit_year(question: str) -> bool:
    return bool(re.search(r"\b(?:2014|2017)\b", question))


def _needs_conversation_context(question: str, state: ConversationState) -> bool:
    """Return True only for a genuinely referential research follow-up.

    Earlier builds treated every short question as a follow-up. That could make
    a complete new question such as ``Compare DLI and an emissions hotspot``
    inherit the active node or year from an unrelated prior turn. Context is now
    added only when the wording contains an explicit anaphor, continuation cue,
    or elliptical follow-up command.
    """

    if state.last_route not in {"research", "hybrid"}:
        return False

    q = re.sub(r"\s+", " ", str(question or "").casefold()).strip()
    explicit_reference = _contains(
        [
            r"\bit\b",
            r"\b(?:that|this|the same) (?:node|supplier|result|ranking|recommendation|scenario|intervention)\b",
            r"\b(?:its|their) (?:rank|score|intervention|footprint|hotspot|path|dli)\b",
            r"\bthe (?:previous|above|recommended|selected) (?:node|result|ranking|scenario|intervention)\b",
        ],
        q,
    )
    elliptical = bool(
        re.fullmatch(
            r"(?:why|why is that|why does that matter|tell me more|elaborate|explain further)[?!.]*",
            q,
        )
    )
    continuation = bool(
        re.match(
            r"^(?:and|also|then|so|what about|how about)\b",
            q,
        )
    )
    return explicit_reference or elliptical or continuation


def enrich_research_question(question: str, state: ConversationState | dict[str, Any] | None) -> str:
    """Resolve safe research follow-ups using structured state, not hidden model memory."""

    state_obj = state_from(state)
    if not _needs_conversation_context(question, state_obj):
        return question

    context: list[str] = []
    if state_obj.active_node and not _has_known_node(question):
        context.append(f"The referenced country-sector node is {state_obj.active_node}.")
    if (
        state_obj.active_year in {"2014", "2017"}
        and not _explicit_year(question)
        and _contains(EMPIRICAL_FOLLOW_UP_PATTERNS, question.casefold())
    ):
        context.append(f"Use {state_obj.active_year} as the active analytical year.")

    if not context:
        return question
    return question.rstrip() + "\n\nConversation context: " + " ".join(context)


def _history_for_ollama(
    history: list[dict[str, Any]] | None,
    max_messages: int = 12,
    max_characters: int = 24000,
) -> list[dict[str, str]]:
    """Return recent chat history within a conservative local-model budget."""

    reversed_prepared: list[dict[str, str]] = []
    used = 0
    for item in reversed((history or [])[-max_messages:]):
        role = str(item.get("role", "")).strip().lower()
        if role not in {"user", "assistant"}:
            continue
        content = str(item.get("content", "")).strip()
        if not content:
            continue
        remaining = max_characters - used
        if remaining <= 0:
            break
        clipped = content[-min(12000, remaining):]
        reversed_prepared.append({"role": role, "content": clipped})
        used += len(clipped)
    return list(reversed(reversed_prepared))


def _general_unavailable(client: Any) -> str:
    model = getattr(client, "model", "the selected model")
    return (
        "The validated research assistant is available, but general conversation requires "
        "a reachable local Ollama model. Start the Ollama Desktop application, confirm the "
        "server is available at `http://127.0.0.1:11434`, and ensure the selected model "
        f"`{model}` is installed. You can also switch to **Research only** mode for questions "
        "about the deployed Strategic Carbon Intelligence & Governance framework."
    )


def _run_general_chat(
    client: Any,
    question: str,
    history: list[dict[str, Any]] | None,
) -> tuple[str, dict[str, Any]]:
    messages = _history_for_ollama(history)
    messages.append({"role": "user", "content": question})
    try:
        response = client.chat_messages(
            messages,
            system=GENERAL_SYSTEM_PROMPT,
            num_predict=1400,
            temperature=0.35,
        )
        content = str(response.get("content", "")).strip()
        if not content:
            raise RuntimeError("Ollama returned an empty general-chat response.")
        return content, {
            "status": "ok",
            "model": response.get("model", getattr(client, "model", "")),
            **(response.get("metrics", {}) or {}),
        }
    except Exception as exc:
        return _general_unavailable(client), {
            "status": "unavailable",
            "model": getattr(client, "model", ""),
            "error": str(exc),
        }


def _run_hybrid_context(
    client: Any,
    question: str,
    research_answer: str,
    history: list[dict[str, Any]] | None,
) -> tuple[str, dict[str, Any]]:
    messages = _history_for_ollama(history, max_messages=8)
    messages.append(
        {
            "role": "user",
            "content": (
                f"Original user question:\n{question}\n\n"
                "Authoritative validated research answer (do not alter):\n"
                f"{research_answer}\n\n"
                "Provide only the broader context, comparison, communication support, or "
                "managerial interpretation requested by the user."
            ),
        }
    )
    try:
        response = client.chat_messages(
            messages,
            system=HYBRID_SYSTEM_PROMPT,
            num_predict=1200,
            temperature=0.25,
        )
        content = str(response.get("content", "")).strip()
        if not content:
            raise RuntimeError("Ollama returned an empty hybrid-context response.")
        return content, {
            "status": "ok",
            "model": response.get("model", getattr(client, "model", "")),
            **(response.get("metrics", {}) or {}),
        }
    except Exception as exc:
        return (
            "Broader local-model context was unavailable for this turn. The validated "
            "research answer above remains complete and authoritative for the deployed analysis.",
            {
                "status": "unavailable",
                "model": getattr(client, "model", ""),
                "error": str(exc),
            },
        )


def _extract_state_from_research(
    previous: ConversationState,
    result: sa.AssistantResult,
    route: str,
) -> ConversationState:
    state = state_from(previous)
    state.turn_count += 1
    state.last_route = route
    state.last_research_question = result.question
    state.last_tools = [str(item.get("tool", "")) for item in result.evidence if item.get("tool")]

    for call in result.plan.get("tool_calls", []) or []:
        year = str(call.get("year", ""))
        if year in {"2014", "2017"}:
            state.active_year = year
        node = str(call.get("node_code", "")).strip()
        if node:
            state.active_node = node

    for item in result.evidence:
        data = item.get("data") if isinstance(item, dict) else None
        if not isinstance(data, dict):
            continue
        recommended = data.get("recommended_node")
        if isinstance(recommended, dict) and recommended.get("node_code"):
            state.active_node = str(recommended["node_code"])
        if data.get("node_code"):
            state.active_node = str(data["node_code"])
        year = str(data.get("year", ""))
        if year in {"2014", "2017"}:
            state.active_year = year
    return state


def _general_state(previous: ConversationState, route: str) -> ConversationState:
    state = state_from(previous)
    state.turn_count += 1
    state.last_route = route
    return state


def _system_meta_state(
    previous: ConversationState,
    aspects: list[str],
) -> ConversationState:
    state = state_from(previous)
    state.turn_count += 1
    state.last_route = "system_meta"
    state.last_meta_aspects = list(aspects)
    state.last_tools = ["system_knowledge"]
    return state



def _state_from_llm_first(
    previous: ConversationState,
    result: lfo.LlmFirstResult,
    original_question: str,
) -> ConversationState:
    """Update structured state without leaking an unrelated prior research entity."""

    state = state_from(previous)
    state.turn_count += 1
    state.last_route = result.route
    state.last_tools = [
        str(item.get("tool", ""))
        for item in result.evidence
        if isinstance(item, dict) and item.get("tool")
    ]
    if result.route in {"research", "hybrid"}:
        state.last_research_question = original_question
    if result.route == "system_meta":
        aspects: list[str] = []
        for item in result.evidence:
            data = item.get("data") if isinstance(item, dict) else None
            if isinstance(data, dict):
                aspects.extend(str(value) for value in data.get("aspects", []) if value)
        state.last_meta_aspects = list(dict.fromkeys(aspects))

    for call in result.plan.get("validated_tool_calls", []) or []:
        year = str(call.get("year", ""))
        if year in {"2014", "2017"}:
            state.active_year = year
        node = str(call.get("node_code", "")).strip()
        if node:
            state.active_node = node

    for item in result.evidence:
        data = item.get("data") if isinstance(item, dict) else None
        if not isinstance(data, dict):
            continue
        recommended = data.get("recommended_node")
        if isinstance(recommended, dict) and recommended.get("node_code"):
            state.active_node = str(recommended["node_code"])
        if data.get("node_code"):
            state.active_node = str(data["node_code"])
        year = str(data.get("year", ""))
        if year in {"2014", "2017"}:
            state.active_year = year
    return state

def answer_turn(
    client: Any,
    question: str,
    mode: str = "auto",
    history: list[dict[str, Any]] | None = None,
    state: ConversationState | dict[str, Any] | None = None,
) -> ConversationResult:
    """Answer one conversational turn through the validated dual-capability router."""

    original = str(question or "").strip()
    if not original:
        raise ValueError("A non-empty question is required.")

    prior_state = state_from(state)
    requested_mode = normalise_mode(mode)

    # V5.0.17: Auto and Research-only questions are interpreted by the local
    # model first. Deterministic tools are closed evidence services and are not
    # selected merely because the question contains carbon-domain vocabulary.
    if requested_mode in {"auto", "research"}:
        primary = lfo.answer_question(
            client,
            original,
            mode=requested_mode,
            history=history,
            state=asdict(prior_state),
        )
        new_state = _state_from_llm_first(prior_state, primary, original)
        return ConversationResult(
            question=original,
            effective_question=original,
            requested_mode=requested_mode,
            route=primary.route,
            blockchain_route=primary.blockchain_route,
            answer=primary.answer,
            research_answer=primary.research_answer,
            general_answer=primary.general_answer,
            plan=primary.plan,
            evidence=primary.evidence,
            provenance=primary.provenance,
            state=asdict(new_state),
            model_metrics=primary.model_metrics,
            system_answer=primary.system_answer,
        )

    selected_route, router = classify_route(
        original,
        mode=requested_mode,
        state=prior_state,
        client=client,
    )
    requested_mode = router["requested_mode"]

    if selected_route == "system_meta":
        system_result = sma.answer_system_question(
            client,
            original,
            history=history,
        )
        new_state = _system_meta_state(prior_state, system_result.aspects)
        model_used = system_result.model_metrics.get("status") == "ok"
        blockchain_route = "composite" if model_used else "retrieval"
        plan = {
            "scope": "system_meta",
            "response_mode": "system_meta",
            "intent": "deployment and architecture reasoning",
            "tool_calls": [
                {
                    "tool": "system_knowledge",
                    "query": original,
                    "top_n": 7,
                    "aspects": system_result.aspects,
                }
            ],
            "conversation_router": router,
            "answer_alignment": system_result.alignment,
        }
        provenance = {
            "route": "system_meta",
            "validated_research_evidence_used": False,
            "validated_system_evidence_used": True,
            "general_model_context_used": model_used,
            "quantitative_tools_executed": False,
            "notice": (
                "This answer is grounded in curated evidence about the packaged Strategic Carbon Intelligence & Governance architecture and deployment. No MRIO, SPA, SDA, DLI, AURORA, scenario, or intervention calculation was executed for this question."
            ),
        }
        metrics = dict(system_result.model_metrics)
        metrics["semantic_router"] = router.get("query_understanding", {}).get("model_status", "deterministic")
        return ConversationResult(
            question=original,
            effective_question=original,
            requested_mode=requested_mode,
            route="system_meta",
            blockchain_route=blockchain_route,
            answer=system_result.answer,
            research_answer="",
            general_answer="",
            plan=plan,
            evidence=system_result.evidence,
            provenance=provenance,
            state=asdict(new_state),
            model_metrics=metrics,
            system_answer=system_result.answer,
        )

    if selected_route == "general":
        general_answer, metrics = _run_general_chat(client, original, history)
        new_state = _general_state(prior_state, "general")
        plan = {
            "scope": "general",
            "response_mode": "general",
            "intent": "general local Ollama conversation",
            "tool_calls": [],
            "conversation_router": router,
        }
        provenance = {
            "route": "general",
            "validated_research_evidence_used": False,
            "general_model_context_used": metrics.get("status") == "ok",
            "notice": (
                "This is a local Ollama response. It is not a computed Strategic Carbon Intelligence & Governance research result "
                "and has not been verified against live web sources."
            ),
        }
        return ConversationResult(
            question=original,
            effective_question=original,
            requested_mode=requested_mode,
            route="general",
            blockchain_route="general",
            answer=general_answer,
            research_answer="",
            general_answer=general_answer,
            plan=plan,
            evidence=[],
            provenance=provenance,
            state=asdict(new_state),
            model_metrics={
                **metrics,
                "semantic_router": router.get("query_understanding", {}).get("model_status", "deterministic"),
            },
        )

    effective = enrich_research_question(original, prior_state)

    # Hybrid questions use the deterministic research client for the research
    # block and reserve the single Ollama call for broader context. This avoids
    # three sequential local-model calls on modest laptops while preserving the
    # exact same quantitative research tools and evidence controls.
    research_client = sa.make_deterministic_client() if selected_route == "hybrid" else client
    research_result = sa.answer_question(research_client, effective)
    new_state = _extract_state_from_research(prior_state, research_result, selected_route)

    if selected_route == "research":
        plan = dict(research_result.plan)
        plan["conversation_router"] = router
        provenance = {
            "route": "research",
            "validated_research_evidence_used": True,
            "general_model_context_used": False,
            "research_route": research_result.route,
            "notice": (
                "Study-specific concepts, methods, and quantitative claims are grounded in the "
                "curated knowledge layer and deterministic analytical modules."
            ),
        }
        return ConversationResult(
            question=original,
            effective_question=effective,
            requested_mode=requested_mode,
            route="research",
            blockchain_route=research_result.route,
            answer=research_result.answer,
            research_answer=research_result.answer,
            general_answer="",
            plan=plan,
            evidence=research_result.evidence,
            provenance=provenance,
            state=asdict(new_state),
            model_metrics={
                "status": research_result.plan.get("synthesis_validation", {}).get(
                    "status",
                    research_result.plan.get("planner_validation", {}).get("llm_status", "not_used"),
                ),
                "model": getattr(client, "model", ""),
                "planner": research_result.plan.get("planner_validation", {}),
                "synthesis": research_result.plan.get("synthesis_validation", {}),
                "semantic_router": router.get("query_understanding", {}).get("model_status", "deterministic"),
            },
        )

    broader, metrics = _run_hybrid_context(client, original, research_result.answer, history)
    answer = f"{research_result.answer}\n\n{broader}"
    plan = dict(research_result.plan)
    plan["conversation_router"] = router
    plan["hybrid_general_context"] = {
        "status": metrics.get("status"),
        "model": metrics.get("model", getattr(client, "model", "")),
    }
    provenance = {
        "route": "hybrid",
        "validated_research_evidence_used": True,
        "general_model_context_used": metrics.get("status") == "ok",
        "research_route": research_result.route,
        "notice": (
            "The first section is grounded in deployed research evidence. The second section is "
            "general Ollama context and is not an additional computed research result."
        ),
    }
    return ConversationResult(
        question=original,
        effective_question=effective,
        requested_mode=requested_mode,
        route="hybrid",
        blockchain_route="composite",
        answer=answer,
        research_answer=research_result.answer,
        general_answer=broader,
        plan=plan,
        evidence=research_result.evidence,
        provenance=provenance,
        state=asdict(new_state),
        model_metrics={
            **metrics,
            "semantic_router": router.get("query_understanding", {}).get("model_status", "deterministic"),
        },
    )


def serialise_result(result: ConversationResult) -> dict[str, Any]:
    """Convenience helper for Streamlit session state and blockchain storage."""

    return json.loads(json.dumps(asdict(result), default=str))
