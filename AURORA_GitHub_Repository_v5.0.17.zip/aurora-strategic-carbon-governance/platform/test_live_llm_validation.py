"""Offline tests for the live-model evaluation harness.

These use a scripted client and never contact Ollama. The separate evaluator is
the only component that should run live local models.
"""
from __future__ import annotations

import importlib.util
import os
import sys
import types
import unittest

if importlib.util.find_spec("networkx") is None:
    # The evaluator never executes network analysis. A minimal type stub lets
    # this source-level unit test import the deployment orchestration module in
    # stripped CI images that have not installed the full runtime requirements.
    networkx_stub = types.ModuleType("networkx")
    class _NetworkXTestGraph:
        def __init__(self):
            self._nodes = set()

        def add_nodes_from(self, nodes):
            self._nodes.update(nodes)

        def add_edge(self, left, right, **_attributes):
            self._nodes.update((left, right))

        def number_of_nodes(self):
            return len(self._nodes)

    networkx_stub.DiGraph = _NetworkXTestGraph
    networkx_stub.betweenness_centrality = lambda graph, **_kwargs: {
        node: 0.0 for node in sorted(graph._nodes)
    }
    networkx_stub.pagerank = lambda graph, **_kwargs: {
        node: (1.0 / len(graph._nodes) if graph._nodes else 0.0)
        for node in sorted(graph._nodes)
    }
    sys.modules["networkx"] = networkx_stub

import validate_live_llm as live


class ScriptedClient:
    model = "scripted-live-evaluation-test-model"

    def chat_json(self, system, user, schema, model=None, num_predict=512, temperature=0.0):
        properties = schema.get("properties", {})
        if "task_kind" in properties:
            return {
                "task_kind": "project_exact",
                "project_context": True,
                "system_context": False,
                "evidence_policy": "compute",
                "tool_requests": [{"tool": "dli", "purpose": "Return exact fixture evidence."}],
                "answer_format": "paragraphs",
                "requested_count": 0,
                "requires_exact_project_values": True,
                "needs_current_information": False,
                "use_conversation_context": False,
                "user_goal": "State the exact frozen result.",
                "confidence": 0.95,
            }
        if "answer" in properties:
            return {
                "answer": (
                    "TST-nmm has a 2017 DLI of 0.449321 and rank 1 in the supplied "
                    "synthetic validation fixture. The value is a governance-screening "
                    "signal rather than proof that an intervention is feasible."
                ),
                "evidence_used": ["dli"],
                "material_uncertainties": ["This is a synthetic test fixture."],
            }
        raise AssertionError("Unexpected schema.")


class ProhibitedClaimClient:
    model = "prohibited-claim-test-model"

    def chat_json(self, system, user, schema, model=None, num_predict=512, temperature=0.0):
        return {
            "answer": "The platform is certified for production.",
            "evidence_used": [],
            "material_uncertainties": [],
        }


class UnavailableClient:
    model = "unavailable-test-model"

    def chat_json(self, *args, **kwargs):
        raise RuntimeError("simulated local-model transport failure")


def exact_fixture() -> dict:
    return {
        "case_id": "TEST-EXACT-001",
        "category": "test",
        "question": "What is the DLI of TST-nmm in 2017?",
        "gold_plan": {
            "task_kind": "project_exact",
            "project_context": True,
            "system_context": False,
            "evidence_policy": "compute",
            "tool_requests": [{"tool": "dli", "purpose": "Return exact fixture evidence."}],
            "answer_format": "paragraphs",
            "requested_count": 0,
            "requires_exact_project_values": True,
            "needs_current_information": False,
            "use_conversation_context": False,
        },
        "frozen_evidence": [
            {
                "tool": "dli",
                "parameters": {"year": 2017, "node_code": "TST-nmm"},
                "source": "synthetic test fixture",
                "data": {"year": 2017, "node_code": "TST-nmm", "DLI": 0.449321, "rank": 1},
            }
        ],
        "deterministic_draft": "TST-nmm has a 2017 DLI of 0.449321 and rank 1.",
        "required_claims": ["TST-nmm", "2017", "0.449321"],
        "expected_numeric_tokens": ["2017", "0.449321"],
    }


class LiveLlmValidationTests(unittest.TestCase):
    def test_evaluator_separates_planner_raw_and_controlled_metrics(self):
        records = live.run_evaluation(
            [exact_fixture()],
            ScriptedClient(),
            stages=live.VALID_STAGES,
            runs=2,
        )
        self.assertEqual(len(records), 6)
        planner = [record for record in records if record["stage"] == "planner"]
        raw = [record for record in records if record["stage"] == "raw_synthesis"]
        controlled = [record for record in records if record["stage"] == "controlled_synthesis"]
        self.assertTrue(all(item["result"]["metrics"]["schema_valid"] for item in planner))
        self.assertTrue(all(item["result"]["metrics"]["exact_plan_correct"] for item in planner))
        self.assertTrue(all(item["result"]["metrics"]["critical_grounding_pass"] for item in raw))
        self.assertTrue(all(item["result"]["metrics"]["final_validation_valid"] for item in controlled))

    def test_summary_contains_live_model_measures(self):
        records = live.run_evaluation([exact_fixture()], ScriptedClient(), runs=1)
        summary = live.summarise(records, {"case_count": 1})
        self.assertEqual(summary["planner"]["compute_recall"]["rate"], 1.0)
        self.assertEqual(summary["raw_synthesis"]["critical_grounding_pass_rate"]["rate"], 1.0)
        self.assertEqual(summary["controlled_synthesis"]["validation_pass_rate"]["rate"], 1.0)

    def test_deterministic_routes_control_ambiguous_local_model_plan(self):
        live._load_platform()
        prior = os.environ.get("OLLAMA_LLM_FIRST_ENABLED")
        os.environ["OLLAMA_LLM_FIRST_ENABLED"] = "1"
        try:
            plan = live.lfo.plan_question(
                ScriptedClient(),
                "Give five practical ways a procurement team can encourage supplier decarbonization.",
            )
        finally:
            if prior is None:
                os.environ.pop("OLLAMA_LLM_FIRST_ENABLED", None)
            else:
                os.environ["OLLAMA_LLM_FIRST_ENABLED"] = prior
        self.assertEqual(plan["task_kind"], "recommendation")
        self.assertEqual(plan["evidence_policy"], "none")
        self.assertEqual(plan["validated_tool_calls"], [])

    def test_safe_fallback_preserves_requested_recommendation_count(self):
        plan = live._gold_plan({
            "question": "Give three recommendations.",
            "gold_plan": {
                "task_kind": "recommendation", "project_context": False,
                "system_context": False, "evidence_policy": "none", "tool_requests": [],
                "answer_format": "numbered_list", "requested_count": 3,
                "requires_exact_project_values": False, "needs_current_information": False,
                "use_conversation_context": False,
                "output_contract": {"recommendation": True, "requested_count": 3, "answer_format": "numbered_list"},
            },
        })
        answer = live.lfo._safe_answer_fallback("Give three recommendations.", plan, "")
        self.assertEqual(len(live.lfo._numbered_items(answer)), 3)
        self.assertTrue(live.lfo.validate_answer("Give three recommendations.", answer, plan, [], "")["valid"])

    def test_lowercase_hyphenated_terms_are_not_project_node_codes(self):
        live._load_platform()
        plan = {"project_context": True, "answer_format": "paragraphs", "requested_count": 0, "output_contract": {}}
        answer = "Use a low-carbon and non-deterministic screening process before making a claim."
        result = live.lfo.validate_answer("Explain the approach.", answer, plan, [], "")
        self.assertNotIn("Unsupported project node codes", " ".join(result["reasons"]))

    def test_prohibited_claim_is_blocking_and_uses_safe_fallback(self):
        live._load_platform()
        fixture = exact_fixture()
        plan = live._gold_plan(fixture)
        answer, metrics = live.lfo._generate_answer(
            ProhibitedClaimClient(), fixture["question"], plan, fixture["frozen_evidence"],
            fixture["deterministic_draft"], [],
            prohibited_claim_patterns=[r"\b(?:is|are)\s+certified for production\b"],
        )
        self.assertEqual(metrics["status"], "safe_fallback")
        self.assertNotIn("certified for production", answer.casefold())
        self.assertTrue(metrics["validation"]["valid"])

    def test_unavailable_model_call_returns_validated_safe_fallback(self):
        live._load_platform()
        fixture = exact_fixture()
        plan = live._gold_plan(fixture)
        answer, metrics = live.lfo._generate_answer(
            UnavailableClient(), fixture["question"], plan, fixture["frozen_evidence"],
            fixture["deterministic_draft"], [],
        )
        self.assertEqual(metrics["status"], "safe_fallback_unavailable")
        self.assertIn("0.449321", answer)
        self.assertTrue(metrics["validation"]["valid"])

    def test_bounded_follow_up_reuses_active_node_and_year_only(self):
        live._load_platform()
        plan = live.lfo.plan_question(
            ScriptedClient(),
            "Explain that DLI result.",
            state={"active_node": "TST-nmm", "active_year": "2017", "last_route": "research"},
        )
        self.assertEqual(plan["evidence_policy"], "support")
        self.assertTrue(plan["use_conversation_context"])
        self.assertEqual(plan["validated_tool_calls"][0]["tool"], "dli")
        self.assertEqual(plan["validated_tool_calls"][0]["node_code"], "TST-nmm")
        self.assertEqual(str(plan["validated_tool_calls"][0]["year"]), "2017")


if __name__ == "__main__":
    unittest.main()
