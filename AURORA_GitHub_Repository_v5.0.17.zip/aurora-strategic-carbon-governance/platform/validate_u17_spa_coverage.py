"""Validate the U17 dynamic 87%-of-total SPA reporting contract."""
from __future__ import annotations

import argparse
import hashlib
import json
import math
from pathlib import Path
from typing import Any

import numpy as np

import analytics_engine as ae
import spa_engine as spa


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def validate_year(mrio_path: Path, demand_path: Path, year: int) -> dict[str, Any]:
    model = ae.load_year(str(mrio_path), int(year))
    demand = ae.load_company_Y(str(demand_path), int(year))
    config = spa.SPAConfig()
    screened, selected, total, config, attempts = (
        spa.trace_paths_to_threshold_adaptive(model, demand, config)
    )
    reached = bool(
        attempts
        and attempts[-1].get("threshold_reached") is True
    )

    selected_mass = float(selected["contribution"].sum()) if not selected.empty else 0.0
    selected_share = selected_mass / total if total else 0.0
    screened_mass = float(screened["contribution"].sum()) if not screened.empty else 0.0
    screened_share = screened_mass / total if total else 0.0
    prior_share = (
        float(selected["cumulative_share"].iloc[-2]) if len(selected) > 1 else 0.0
    )

    A = np.zeros_like(model.Z, dtype=float)
    positive = np.asarray(model.X, dtype=float) > 0
    A[:, positive] = model.Z[:, positive] / model.X[positive][np.newaxis, :]
    tier_vector = np.asarray(demand, dtype=float).copy()
    exact_cumulative = 0.0
    exact_shares: list[float] = []
    for depth in range(config.exact_max_tier + 1):
        if depth > 0:
            tier_vector = A @ tier_vector
        exact_cumulative += float(model.fE @ tier_vector)
        exact_shares.append(exact_cumulative / total if total else 0.0)

    exact_at_path_depth = float(exact_shares[config.max_depth]) if exact_shares else 0.0
    screening_residual = max(0.0, exact_at_path_depth * total - screened_mass)
    depth_tail = max(0.0, total - exact_at_path_depth * total)
    unreported_screened = max(0.0, screened_mass - selected_mass)
    reconciliation_residual = total - (
        selected_mass + unreported_screened + screening_residual + depth_tail
    )
    target_amount = config.cumulative_target * total
    overshoot = max(0.0, selected_mass - target_amount)
    shortfall = max(0.0, target_amount - selected_mass)

    result = {
        "year": int(year),
        "coverage_target": float(config.cumulative_target),
        "coverage_denominator": "complete focal-company footprint",
        "total_footprint_tco2": total,
        "top15_hotspot_share": float(model.hotspots(demand, top=15)["share_of_total"].sum()),
        "screened_path_count": int(len(screened)),
        "screened_path_footprint_tco2": screened_mass,
        "screened_share": screened_share,
        "selected_path_count": int(len(selected)),
        "selected_path_footprint_tco2": selected_mass,
        "selected_share": selected_share,
        "prior_path_share": prior_share,
        "target_reached": bool(reached),
        "target_shortfall_tco2": shortfall,
        "whole_path_overshoot_tco2": overshoot,
        "adaptive_expansion_attempts": attempts,
        "selected_configuration": {
            "max_depth": int(config.max_depth),
            "top_k_per_hop": int(config.top_k_per_hop),
            "beam_width": int(config.beam_width),
            "min_coefficient": float(config.min_coefficient),
        },
        "exact_share_through_max_path_depth": exact_at_path_depth,
        "exact_share_through_tier_30": float(exact_shares[-1]) if exact_shares else 0.0,
        "repeated_node_path_count": int(
            screened["path_nodes"].map(lambda nodes: len(set(nodes)) < len(nodes)).sum()
        ) if not screened.empty else 0,
        "reconciliation_residual_tco2": reconciliation_residual,
        "minimum_prefix_valid": bool(
            (not reached)
            or (
                selected_share >= config.cumulative_target
                and (len(selected) <= 1 or prior_share < config.cumulative_target)
            )
        ),
    }
    if total > 0.0 and not reached:
        raise RuntimeError(
            f"{year} explicit SPA coverage is {selected_share:.6%}, below the required "
            f"{config.cumulative_target:.2%}."
        )
    if not result["minimum_prefix_valid"]:
        raise RuntimeError(f"{year} selected path set is not the minimum target-reaching prefix.")
    if not math.isclose(reconciliation_residual, 0.0, abs_tol=1e-8, rel_tol=1e-10):
        raise RuntimeError(
            f"{year} SPA coverage reconciliation residual is {reconciliation_residual:.3e} t CO2."
        )
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--mrio", type=Path, default=Path("input_mrio_completed.xlsx"))
    parser.add_argument(
        "--demand", type=Path, default=Path("Focal_Company_Demand_Converted.xlsx")
    )
    parser.add_argument("--years", type=int, nargs="+", default=[2014, 2017])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    report = {
        "validation": "U17 dynamic 87%-of-total SPA coverage",
        "input_sha256": {
            "mrio": _sha256(args.mrio),
            "focal_demand": _sha256(args.demand),
        },
        "years": [validate_year(args.mrio, args.demand, year) for year in args.years],
        "status": "pass",
    }
    rendered = json.dumps(report, indent=2, sort_keys=True)
    if args.output:
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
