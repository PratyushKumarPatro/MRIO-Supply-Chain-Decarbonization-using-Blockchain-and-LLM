"""Offline validation of the v5.0.17 professional identity and U9 AURORA method."""
from __future__ import annotations

import ast
import hashlib
import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
PLATFORM_NAME = "Strategic Carbon Intelligence & Governance Platform"
AURORA_NAME = "Analogue-based Upstream Regional Opportunity and Resilience Assessment"
SOURCE_NAME = "StrategicCarbonIntelligenceSystem.sol"
ARCHITECTURE = "5.0.17-u23-evidence-bound-abatement-decision"


class ProfessionalIdentityAuroraTests(unittest.TestCase):
    def test_release_identity_is_consistent(self):
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8")
        package = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
        readme = (ROOT / "README_START_HERE.txt").read_text(encoding="utf-8")
        self.assertIn("5.0.17", version)
        self.assertIn("STRATEGIC_CARBON_INTELLIGENCE_GOVERNANCE_PLATFORM", version)
        self.assertIn(ARCHITECTURE, version)
        self.assertEqual(package["version"], "5.0.17")
        self.assertEqual(package["name"], "strategic-carbon-intelligence-governance-platform")
        self.assertIn(PLATFORM_NAME, readme)
        self.assertIn(AURORA_NAME, readme)

    def test_professional_interface_titles_and_navigation(self):
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        lifecycle = (ROOT / "dapp_lifecycle.py").read_text(encoding="utf-8")
        blockchain = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        notification = (ROOT / "streamlit_app" / "stakeholder_notification_ui.py").read_text(encoding="utf-8")
        transaction = (ROOT / "streamlit_app" / "transaction_ui.py").read_text(encoding="utf-8")
        expected = [
            "Carbon Footprint Intelligence",
            "Emissions Hotspot Intelligence",
            "Structural Pathway Intelligence",
            "Carbon-Change Decomposition",
            "Network Leverage & DLI",
            "Intervention Governance",
            "Strategic Scenario Analysis",
            "AURORA Opportunity Intelligence",
            "AI Decision Intelligence",
            "Governance & Audit Control",
        ]
        for label in expected:
            self.assertIn(label, app + lifecycle)
        self.assertIn("Blockchain and LLM-based low-carbon supply chain governance and decision support", blockchain)
        self.assertIn('"Governance & Audit Control": "Blockchain and LLM-based System"', app)
        self.assertIn("Stakeholder Event & Assurance Center", notification)
        self.assertIn("Blockchain Audit & Transaction Explorer", transaction)
        self.assertIn(PLATFORM_NAME, app)

    def test_deprecated_research_stage_labels_are_absent_from_public_identity(self):
        public_files = [
            ROOT / "README_START_HERE.txt",
            ROOT / "PLATFORM_DEPLOYMENT_COMMANDS.txt",
            ROOT / "PLATFORM_IDENTITY_AND_AURORA_GUIDE.txt",
            ROOT / "STAKEHOLDER_EVENT_NOTIFICATION_GUIDE.txt",
            ROOT / "LLM_FIRST_ORCHESTRATION_GUIDE.txt",
            ROOT / "QUERY_RESULT_AUDIT_GUIDE.txt",
            ROOT / "QUERY_SEMANTIC_INTELLIGENCE_GUIDE.txt",
            ROOT / "TRANSACTION_EXPLORER_GUIDE.txt",
            ROOT / "UPLOAD_INPUTS_GUIDE.txt",
            ROOT / "INTERVENTION_PORTFOLIO_GUIDE.txt",
            ROOT / "streamlit_app" / "app.py",
            ROOT / "streamlit_app" / "blockchain_page.py",
            ROOT / "streamlit_app" / "stakeholder_notification_ui.py",
            ROOT / "streamlit_app" / "transaction_ui.py",
            ROOT / "domain_knowledge.json",
            ROOT / "rag_documents.json",
            ROOT / "system_knowledge.json",
            ROOT / "contracts" / SOURCE_NAME,
        ]
        text = "\n".join(path.read_text(encoding="utf-8") for path in public_files)
        legacy_project_pattern = "R" + r"Q3\s*[/_-]?\s*R" + "Q4"
        legacy_method = "SARS" + "OA"
        informal_words = ("de" + "mo", "demon" + "stration")
        self.assertIsNone(re.search(legacy_project_pattern, text, flags=re.I))
        self.assertNotIn(legacy_method, text)
        self.assertIsNone(
            re.search(r"\b(?:" + "|".join(informal_words) + r")\b", text, flags=re.I)
        )
        self.assertNotIn("Carbon governance " + informal_words[0], text)

    def test_aurora_method_identity_and_runtime_keys_are_consistent(self):
        method_source = (ROOT / "sourcing_opportunity_engine.py").read_text(encoding="utf-8")
        lifecycle = (ROOT / "dapp_lifecycle.py").read_text(encoding="utf-8")
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        oracle = (ROOT / "oracle_service.py").read_text(encoding="utf-8")
        domain = json.loads((ROOT / "domain_knowledge.json").read_text(encoding="utf-8"))
        aurora_records = [item for item in domain["concepts"] if item.get("id") == "aurora"]
        self.assertEqual(len(aurora_records), 1)
        self.assertEqual(aurora_records[0]["term"], f"{AURORA_NAME} (AURORA)")
        self.assertIn("class AURORAConfig", method_source)
        self.assertIn('"method": "AURORA"', method_source)
        self.assertIn(f'"method_name": "{AURORA_NAME}"', method_source)
        self.assertIn("aurora_complete", lifecycle)
        self.assertIn('record_active_result("aurora"', orchestrator)
        self.assertIn('"request_scope": "aurora"', oracle)


    def test_aurora_u9_retains_core_logic_and_adds_exact_otsu_calibration(self):
        source = (ROOT / "sourcing_opportunity_engine.py").read_text(encoding="utf-8")
        self.assertIn("Production behaviour is derived from columns of A", source)
        self.assertIn("Market/output-distribution behaviour is derived from rows of Z", source)
        self.assertIn("def exact_bin_free_otsu", source)
        self.assertIn("def calibrate_exact_otsu_config", source)
        self.assertIn("candidate_indices = np.where((my.sectors == sector) & (my.X > EPS))[0]", source)
        self.assertIn("if int(index) in set(int(i) for i in current_indices)", source)
        self.assertIn("relative_reduction > cfg.minimum_carbon_improvement + EPS", source)
        self.assertIn("pareto_efficient", source)
        self.assertIn('similarity_threshold_method="exact_bin_free_otsu"', source)
        self.assertIn("DEFAULT_THRESHOLD_CALIBRATION_YEAR = 2014", source)

    def test_unified_source_and_streamlit_copies_use_professional_identity(self):
        solidity_files = sorted((ROOT / "contracts").glob("*.sol"))
        self.assertEqual([path.name for path in solidity_files], [SOURCE_NAME])
        compile_script = (ROOT / "compile_contracts.js").read_text(encoding="utf-8")
        deploy = (ROOT / "deploy_contracts.py").read_text(encoding="utf-8")
        self.assertIn(SOURCE_NAME, compile_script)
        self.assertIn("StrategicCarbonIntelligenceSystem_sol_Registration", deploy)
        parity_files = [
            "analytics_engine.py",
            "network_engine.py",
            "spa_engine.py",
            "sda_engine.py",
            "scenario_engine.py",
            "sourcing_opportunity_engine.py",
            "strategic_assistant.py",
            "dual_capability_assistant.py",
            "llm_first_orchestrator.py",
            "query_intelligence.py",
            "system_meta_assistant.py",
        ]
        for name in parity_files:
            with self.subTest(file=name):
                root_source = (ROOT / name).read_text(encoding="utf-8")
                bridge = (ROOT / "streamlit_app" / name).read_text(encoding="utf-8")
                self.assertTrue(root_source.strip())
                bridge_release = "U17" if name == "spa_engine.py" else "U16"
                self.assertIn(
                    f"Compatibility bridge to the single authoritative {bridge_release} module",
                    bridge,
                )
                self.assertIn(f"parent.parent / '{name}'", bridge)
                self.assertLess(len(bridge), 1500)



if __name__ == "__main__":
    unittest.main(verbosity=2)
