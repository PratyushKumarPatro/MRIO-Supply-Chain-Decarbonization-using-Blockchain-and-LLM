"""
scenario_engine.py -- comparative-static counterfactual scenarios.

Answers "would this decarbonization strategy actually work" without the
overreach of generating a synthetic future MRIO table. The method agreed
on directly: hold L and y exactly as validated for the real reference
year, vary only f for the targeted node, and recompute

    F'(y) = f'^T L y

This is exact given the assumption (footprint is linear in f), not a
simulation, and it inherits none of the circularity risk of projecting a
future table: nothing here is a forecast, it's "if this specific,
published reduction were achieved today, on the real 2017 structure,
what would the number do."

Every reduction percentage below is sourced to a real, checked paper, not
invented. Where the literature is scattered rather than convergent (fleet
electrification, heavily grid-dependent), that's stated explicitly, and
a conservative, construction-specific figure is used rather than an
optimistic aggregate one. Nodes without solid sourced literature (found
during research) are deliberately left out rather than filled in with a
plausible-sounding guess -- see NOT_YET_SOURCED below.

SDG 9.4.1 note: this module's per-node f is normalized by gross output
(GTAP X), not value added. The official SDG 9.4.1 indicator, CO2
emissions per unit of value added, is a related but numerically distinct
quantity (value added excludes intermediate inputs, gross output doesn't).
f is reported here as an SDG 9.4.1 *analogue*, useful for the same
interpretive purpose, not claimed as a statistical match.
"""

from dataclasses import dataclass
import numpy as np
from analytics_engine import MRIOYear


@dataclass
class Scenario:
    label: str
    reduction_pct: float  # fraction, e.g. 0.30 = 30% cut to this node's own intensity
    citation: str


SCENARIO_LIBRARY: dict[str, list[Scenario]] = {
    "ARE-nmm": [
        Scenario("30% GGBS/fly-ash clinker substitution", 0.30,
                 "Thongsanitgarn et al.-style LCA range; UNSDSN (2022) low-carbon concrete "
                 "whitepaper: fly ash substitution ~27% reduction"),
        Scenario("50% GGBS substitution", 0.47,
                 "Cement production LCA+TOPSIS study (2025): 50% GGBS substitution -> 47.1% "
                 "reduction (906 -> 906*0.529 kg CO2eq)"),
        Scenario("65% GGBS substitution (mass concrete)", 0.61,
                 "Thailand cradle-to-gate mass-concrete LCA: 65% GGBS -> 61% GWP reduction"),
    ],
    "ARE-mvh": [
        Scenario("Grid-powered electrification of fleet/equipment", 0.25,
                 "Construction-machinery-specific LCA (21-tonne hydraulic excavator, "
                 "grid-powered): 25.3% lifecycle reduction. NOTE: literature for this "
                 "category is far more scattered than cement (14.7%-93% depending on "
                 "vehicle class, grid mix, and study), this is the most conservative, "
                 "most construction-relevant figure found, not a central estimate -- "
                 "treat with more caution than the ARE-nmm scenarios above."),
    ],
}

NOT_YET_SOURCED = [
    "ARE-p_c (fuel switching) -- no node-specific published reduction figure found during "
    "research; do not substitute a generic or assumed number here without doing the same "
    "literature check as the two nodes above.",
    "ROW-trd, ROW-cns, and other supplier-engagement-channel nodes -- these are not "
    "intensity-reduction interventions at all (see the dashboard's own 'structural rather "
    "than direct-intensity driven' framing for ROW-trd); a scenario framed as an f-cut "
    "doesn't apply to them, a different mechanism (disclosure, engagement) would need a "
    "different kind of counterfactual, not built here.",
]


def counterfactual_footprint(my: MRIOYear, Y: np.ndarray, node_code: str, reduction_pct: float) -> dict:
    """F'(y) with node_code's own fE cut by reduction_pct, L and Y held
    exactly as-is. Exact, not simulated: footprint is linear in f, so this
    is the same computation footprint() does, just with one entry of f
    replaced first."""
    idx_matches = np.where(my.node_codes == node_code)[0]
    if len(idx_matches) == 0:
        raise KeyError(f"no node {node_code!r} in this MRIO year")
    idx = int(idx_matches[0])

    f_prime = my.fE.copy()
    f_prime[idx] = f_prime[idx] * (1 - reduction_pct)

    Ly = my.L @ Y  # already-required output per node; doesn't depend on f at all
    baseline_footprint = float(my.fE @ Ly)
    scenario_footprint = float(f_prime @ Ly)

    return {
        "node_code": node_code,
        "reduction_pct": reduction_pct,
        "baseline_footprint": baseline_footprint,
        "scenario_footprint": scenario_footprint,
        "absolute_saving": baseline_footprint - scenario_footprint,
        "pct_of_total_footprint_saved": (baseline_footprint - scenario_footprint) / baseline_footprint,
        "node_own_baseline_contribution": float(my.fE[idx] * Ly[idx]),
        "node_own_scenario_contribution": float(f_prime[idx] * Ly[idx]),
    }


def run_scenario_library(my: MRIOYear, Y: np.ndarray, node_code: str) -> list[dict]:
    """Run every sourced scenario for a node. Returns [] for nodes not in
    SCENARIO_LIBRARY -- deliberately, rather than falling back to a guess."""
    scenarios = SCENARIO_LIBRARY.get(node_code, [])
    results = []
    for s in scenarios:
        r = counterfactual_footprint(my, Y, node_code, s.reduction_pct)
        r["label"] = s.label
        r["citation"] = s.citation
        results.append(r)
    return results


if __name__ == "__main__":
    from analytics_engine import load_year, load_company_Y

    my17 = load_year("input_mrio_completed.xlsx", 2017)
    Yc17 = load_company_Y("Focal_Company_Demand_Converted.xlsx", 2017)

    for node_code in SCENARIO_LIBRARY:
        print(f"\n{'='*70}\n{node_code}\n{'='*70}")
        for r in run_scenario_library(my17, Yc17, node_code):
            print(f"  {r['label']}")
            print(f"    baseline footprint:  {r['baseline_footprint']:.6f}")
            print(f"    scenario footprint:  {r['scenario_footprint']:.6f}")
            print(f"    saving:              {r['absolute_saving']:.6f}  "
                  f"({r['pct_of_total_footprint_saved']:.2%} of total)")
            print(f"    source: {r['citation']}")

    print(f"\n{'='*70}\nNOT YET SOURCED (deliberately excluded)\n{'='*70}")
    for note in NOT_YET_SOURCED:
        print(f"  - {note}")
