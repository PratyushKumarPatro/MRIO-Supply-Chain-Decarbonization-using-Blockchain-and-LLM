"""Producer-specific decomposition of the established CDR node-removal test.

This module does not change Carbon Dependency Risk (CDR), Intervention
Criticality (IC), CRITIC weighting, or DLI.  It retains the exact CDR
counterfactual already used by ``network_engine`` and decomposes the total
footprint change by the node where emissions are produced.

For intervention/removal node ``k`` and emissions-producing node ``j``:

    C_j              = f_j (L y)_j
    C_j^(-k)         = f_j (L^(-k) y^(-k))_j
    Delta C_{j|-k}   = C_j - C_j^(-k)

The row identity is:

    sum_j Delta C_{j|-k} = F - F^(-k) = CDR(k) * F.

The result is a structural full-node-removal diagnostic.  It is not a causal
forecast of what happens when only the direct carbon intensity ``f_k`` is
reduced while the technical coefficients and final demand remain fixed.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

FOOTPRINT_UNIT = "t CO2"
PAIRWISE_FILENAME_TEMPLATE = "cdr_producer_linkage_{year}.csv.gz"
INTERVENTION_SUMMARY_FILENAME_TEMPLATE = "cdr_intervention_summary_{year}.csv"
PRODUCER_BASELINE_FILENAME_TEMPLATE = "cdr_producer_baseline_{year}.csv"
METADATA_FILENAME_TEMPLATE = "cdr_producer_linkage_{year}.json"
PAIRWISE_FIELDS = (
    "year",
    "intervention_node",
    "intervention_region",
    "intervention_sector",
    "producer_node",
    "producer_region",
    "producer_sector",
    "baseline_producer_footprint_tco2",
    "counterfactual_producer_footprint_tco2",
    "avoided_producer_footprint_tco2",
    "producer_reduction_fraction",
    "share_of_intervention_total_reduction",
    "share_of_baseline_company_footprint",
)
EVIDENCE_BASIS_FIELDS = (
    "extension_id",
    "year",
    "node_count",
    "pair_count",
    "footprint_unit",
    "baseline_company_footprint_tco2",
    "maximum_absolute_reconciliation_residual_tco2",
    "formula",
    "row_identity",
    "counterfactual_definition",
    "dli_authority_boundary",
    "interpretation_boundary",
    "input_hashes",
    "artifacts",
    "pairwise_fields",
    "preferred_pair",
)


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _atomic_replace(source: Path, destination: Path) -> None:
    destination.parent.mkdir(parents=True, exist_ok=True)
    source.replace(destination)


def _safe_fraction(numerator: np.ndarray, denominator: np.ndarray) -> np.ndarray:
    numerator = np.asarray(numerator, dtype=float)
    denominator = np.asarray(denominator, dtype=float)
    result = np.zeros(np.broadcast_shapes(numerator.shape, denominator.shape), dtype=float)
    np.divide(numerator, denominator, out=result, where=np.abs(denominator) > 0.0)
    return result


@dataclass(frozen=True)
class CDRProducerLinkageResult:
    """Complete producer-specific decomposition of all CDR node removals."""

    year: int
    node_codes: np.ndarray
    regions: np.ndarray
    sectors: np.ndarray
    baseline_total_footprint: float
    baseline_producer_footprint: np.ndarray
    counterfactual_total_footprint: np.ndarray
    cdr: np.ndarray
    avoided_producer_footprint: np.ndarray
    reconciliation_residual: np.ndarray

    def __post_init__(self) -> None:
        n = len(self.node_codes)
        vectors = {
            "regions": self.regions,
            "sectors": self.sectors,
            "baseline_producer_footprint": self.baseline_producer_footprint,
            "counterfactual_total_footprint": self.counterfactual_total_footprint,
            "cdr": self.cdr,
            "reconciliation_residual": self.reconciliation_residual,
        }
        for name, values in vectors.items():
            if len(values) != n:
                raise ValueError(f"{name} has length {len(values)}; expected {n}")
        if np.asarray(self.avoided_producer_footprint).shape != (n, n):
            raise ValueError(
                "avoided_producer_footprint must have shape "
                f"({n}, {n}), got {np.asarray(self.avoided_producer_footprint).shape}"
            )

    @property
    def node_count(self) -> int:
        return int(len(self.node_codes))

    @property
    def total_reduction(self) -> np.ndarray:
        return float(self.baseline_total_footprint) - np.asarray(
            self.counterfactual_total_footprint, dtype=float
        )

    def node_position(self, node_code: str) -> int:
        target = str(node_code)
        matches = np.where(np.asarray(self.node_codes).astype(str) == target)[0]
        if len(matches) != 1:
            raise KeyError(
                f"Expected exactly one occurrence of node_code={target!r}; found {len(matches)}"
            )
        return int(matches[0])

    def pair_record(self, intervention_node: str, producer_node: str) -> dict[str, Any]:
        k = self.node_position(intervention_node)
        j = self.node_position(producer_node)
        baseline = float(self.baseline_producer_footprint[j])
        avoided = float(self.avoided_producer_footprint[k, j])
        counterfactual = baseline - avoided
        total_reduction = float(self.total_reduction[k])
        return {
            "year": int(self.year),
            "intervention_node": str(self.node_codes[k]),
            "intervention_region": str(self.regions[k]),
            "intervention_sector": str(self.sectors[k]),
            "producer_node": str(self.node_codes[j]),
            "producer_region": str(self.regions[j]),
            "producer_sector": str(self.sectors[j]),
            "baseline_producer_footprint_tco2": baseline,
            "counterfactual_producer_footprint_tco2": counterfactual,
            "avoided_producer_footprint_tco2": avoided,
            "producer_reduction_fraction": avoided / baseline if baseline else 0.0,
            "share_of_intervention_total_reduction": (
                avoided / total_reduction if total_reduction else 0.0
            ),
            "share_of_baseline_company_footprint": (
                avoided / float(self.baseline_total_footprint)
                if self.baseline_total_footprint
                else 0.0
            ),
            "intervention_total_footprint_reduction_tco2": total_reduction,
            "intervention_cdr": float(self.cdr[k]),
            "reconciliation_residual_tco2": float(self.reconciliation_residual[k]),
            "interpretation_boundary": (
                "Full node-removal decomposition of the established CDR counterfactual; "
                "not an intensity-only causal decarbonization forecast."
            ),
        }

    def producer_baseline_frame(self) -> pd.DataFrame:
        baseline = np.asarray(self.baseline_producer_footprint, dtype=float)
        total = float(self.baseline_total_footprint)
        return pd.DataFrame(
            {
                "year": int(self.year),
                "producer_node": np.asarray(self.node_codes).astype(str),
                "producer_region": np.asarray(self.regions).astype(str),
                "producer_sector": np.asarray(self.sectors).astype(str),
                "baseline_producer_footprint_tco2": baseline,
                "share_of_baseline_company_footprint": (
                    baseline / total if total else np.zeros_like(baseline)
                ),
            }
        ).sort_values(
            ["baseline_producer_footprint_tco2", "producer_node"],
            ascending=[False, True],
            kind="mergesort",
        ).reset_index(drop=True)

    def intervention_summary_frame(self) -> pd.DataFrame:
        total_reduction = np.asarray(self.total_reduction, dtype=float)
        avoided = np.asarray(self.avoided_producer_footprint, dtype=float)
        top_index = np.argmax(avoided, axis=1)
        row_index = np.arange(self.node_count)
        top_values = avoided[row_index, top_index]
        top_share = _safe_fraction(top_values, total_reduction)
        return pd.DataFrame(
            {
                "year": int(self.year),
                "intervention_node": np.asarray(self.node_codes).astype(str),
                "intervention_region": np.asarray(self.regions).astype(str),
                "intervention_sector": np.asarray(self.sectors).astype(str),
                "baseline_company_footprint_tco2": float(self.baseline_total_footprint),
                "counterfactual_company_footprint_tco2": np.asarray(
                    self.counterfactual_total_footprint, dtype=float
                ),
                "total_footprint_reduction_tco2": total_reduction,
                "CDR": np.asarray(self.cdr, dtype=float),
                "producer_decomposition_sum_tco2": avoided.sum(axis=1),
                "reconciliation_residual_tco2": np.asarray(
                    self.reconciliation_residual, dtype=float
                ),
                "top_affected_producer_node": np.asarray(self.node_codes).astype(str)[top_index],
                "top_affected_producer_reduction_tco2": top_values,
                "top_affected_share_of_total_reduction": top_share,
            }
        ).sort_values(
            ["CDR", "intervention_node"], ascending=[False, True], kind="mergesort"
        ).reset_index(drop=True)

    def pairwise_frame(self) -> pd.DataFrame:
        n = self.node_count
        intervention_index = np.repeat(np.arange(n), n)
        producer_index = np.tile(np.arange(n), n)
        node_codes = np.asarray(self.node_codes).astype(str)
        regions = np.asarray(self.regions).astype(str)
        sectors = np.asarray(self.sectors).astype(str)
        avoided = np.asarray(self.avoided_producer_footprint, dtype=float).reshape(-1)
        baseline = np.asarray(self.baseline_producer_footprint, dtype=float)[producer_index]
        counterfactual = baseline - avoided
        total_reduction = np.asarray(self.total_reduction, dtype=float)[intervention_index]
        company_total = float(self.baseline_total_footprint)
        return pd.DataFrame(
            {
                "year": int(self.year),
                "intervention_node": node_codes[intervention_index],
                "intervention_region": regions[intervention_index],
                "intervention_sector": sectors[intervention_index],
                "producer_node": node_codes[producer_index],
                "producer_region": regions[producer_index],
                "producer_sector": sectors[producer_index],
                "baseline_producer_footprint_tco2": baseline,
                "counterfactual_producer_footprint_tco2": counterfactual,
                "avoided_producer_footprint_tco2": avoided,
                "producer_reduction_fraction": _safe_fraction(avoided, baseline),
                "share_of_intervention_total_reduction": _safe_fraction(
                    avoided, total_reduction
                ),
                "share_of_baseline_company_footprint": (
                    avoided / company_total if company_total else np.zeros_like(avoided)
                ),
            }
        )

    def assert_reconciled(self, *, absolute_tolerance: float = 1e-8) -> None:
        arrays = (
            np.asarray(self.baseline_producer_footprint, dtype=float),
            np.asarray(self.counterfactual_total_footprint, dtype=float),
            np.asarray(self.cdr, dtype=float),
            np.asarray(self.avoided_producer_footprint, dtype=float),
            np.asarray(self.reconciliation_residual, dtype=float),
        )
        if not all(np.isfinite(values).all() for values in arrays):
            raise RuntimeError("CDR producer-linkage result contains non-finite values")
        tolerance = max(
            float(absolute_tolerance),
            abs(float(self.baseline_total_footprint)) * 1e-10,
        )
        max_residual = float(np.max(np.abs(self.reconciliation_residual)))
        if max_residual > tolerance:
            raise RuntimeError(
                "CDR producer-linkage decomposition does not reconcile: "
                f"max residual {max_residual:.12g} exceeds tolerance {tolerance:.12g}"
            )
        expected = np.asarray(self.cdr, dtype=float) * float(self.baseline_total_footprint)
        observed = np.asarray(self.total_reduction, dtype=float)
        if not np.allclose(observed, expected, atol=tolerance, rtol=1e-10):
            raise RuntimeError("CDR times baseline footprint does not match total node-removal reduction")


def compute_cdr_producer_linkage(my: Any, demand: np.ndarray) -> CDRProducerLinkageResult:
    """Compute CDR and decompose each node-removal footprint change by producer.

    The matrix construction and removal operation intentionally reproduce the
    pre-existing ``network_engine.carbon_dependency_risk`` implementation:
    row ``k`` and column ``k`` of ``A`` are zeroed and final demand ``y_k`` is
    set to zero before recomputing the Leontief inverse.
    """
    demand = np.asarray(demand, dtype=float).reshape(-1)
    n = len(demand)
    node_codes = np.asarray(my.node_codes).astype(str)
    regions = np.asarray(my.regions).astype(str)
    sectors = np.asarray(my.sectors).astype(str)
    if not (len(node_codes) == len(regions) == len(sectors) == n):
        raise ValueError("MRIO metadata and focal-demand dimensions do not agree")

    z = np.asarray(my.Z, dtype=float)
    x = np.asarray(my.X, dtype=float).reshape(-1)
    f = np.asarray(my.fE, dtype=float).reshape(-1)
    leontief_base = np.asarray(my.L, dtype=float)
    if z.shape != (n, n) or leontief_base.shape != (n, n) or len(x) != n or len(f) != n:
        raise ValueError("MRIO matrices do not match the focal-demand node count")

    base_output = leontief_base @ demand
    baseline_by_producer = f * base_output
    base_footprint = float(my.footprint(demand))

    a = np.zeros_like(z, dtype=float)
    positive = x > 0
    a[:, positive] = z[:, positive] / x[positive][np.newaxis, :]

    cdr = np.zeros(n, dtype=float)
    counterfactual_total = np.full(n, base_footprint, dtype=float)
    avoided = np.zeros((n, n), dtype=float)
    residual = np.zeros(n, dtype=float)
    identity = np.eye(n)

    for k in range(n):
        if demand[k] == 0 and a[:, k].sum() == 0 and a[k, :].sum() == 0:
            continue
        candidate = a.copy()
        candidate[k, :] = 0.0
        candidate[:, k] = 0.0
        try:
            leontief_reduced = np.linalg.inv(identity - candidate)
        except np.linalg.LinAlgError:
            cdr[k] = np.nan
            counterfactual_total[k] = np.nan
            avoided[k, :] = np.nan
            residual[k] = np.nan
            continue

        reduced_demand = demand.copy()
        reduced_demand[k] = 0.0
        reduced_output = leontief_reduced @ reduced_demand
        reduced_by_producer = f * reduced_output
        reduced_footprint = float(f @ reduced_output)

        counterfactual_total[k] = reduced_footprint
        cdr[k] = (
            (base_footprint - reduced_footprint) / base_footprint
            if base_footprint
            else 0.0
        )
        avoided[k, :] = baseline_by_producer - reduced_by_producer
        residual[k] = float(
            avoided[k, :].sum() - (base_footprint - reduced_footprint)
        )

    result = CDRProducerLinkageResult(
        year=int(my.year),
        node_codes=node_codes,
        regions=regions,
        sectors=sectors,
        baseline_total_footprint=base_footprint,
        baseline_producer_footprint=baseline_by_producer,
        counterfactual_total_footprint=counterfactual_total,
        cdr=cdr,
        avoided_producer_footprint=avoided,
        reconciliation_residual=residual,
    )
    result.assert_reconciled()
    return result


def write_cdr_producer_linkage_artifacts(
    output_dir: str | Path,
    result: CDRProducerLinkageResult,
    *,
    input_hashes: dict[str, str],
    source_result_cid: str = "",
    preferred_pair: tuple[str, str] = ("ARE-cns", "ARE-ely"),
) -> dict[str, Any]:
    """Write auditable CSV artifacts and return their metadata and hashes."""
    result.assert_reconciled()
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    year = int(result.year)

    pairwise_path = output / PAIRWISE_FILENAME_TEMPLATE.format(year=year)
    intervention_path = output / INTERVENTION_SUMMARY_FILENAME_TEMPLATE.format(year=year)
    producer_path = output / PRODUCER_BASELINE_FILENAME_TEMPLATE.format(year=year)
    metadata_path = output / METADATA_FILENAME_TEMPLATE.format(year=year)

    pairwise_tmp = pairwise_path.with_name(f".{pairwise_path.name}.tmp.gz")
    intervention_tmp = intervention_path.with_name(f".{intervention_path.name}.tmp")
    producer_tmp = producer_path.with_name(f".{producer_path.name}.tmp")

    result.pairwise_frame().to_csv(
        pairwise_tmp,
        index=False,
        compression={"method": "gzip", "compresslevel": 6, "mtime": 0},
    )
    result.intervention_summary_frame().to_csv(intervention_tmp, index=False)
    result.producer_baseline_frame().to_csv(producer_tmp, index=False)
    _atomic_replace(pairwise_tmp, pairwise_path)
    _atomic_replace(intervention_tmp, intervention_path)
    _atomic_replace(producer_tmp, producer_path)

    artifacts = {
        "pairwise": {
            "filename": pairwise_path.name,
            "sha256": _sha256_file(pairwise_path),
            "row_count": int(result.node_count * result.node_count),
            "compression": "gzip",
        },
        "intervention_summary": {
            "filename": intervention_path.name,
            "sha256": _sha256_file(intervention_path),
            "row_count": int(result.node_count),
        },
        "producer_baseline": {
            "filename": producer_path.name,
            "sha256": _sha256_file(producer_path),
            "row_count": int(result.node_count),
        },
    }

    node_set = set(np.asarray(result.node_codes).astype(str))
    preferred_record = None
    if preferred_pair[0] in node_set and preferred_pair[1] in node_set:
        preferred_record = result.pair_record(*preferred_pair)

    metadata: dict[str, Any] = {
        "extension_id": "v5.0.17-U13",
        "year": year,
        "node_count": int(result.node_count),
        "pair_count": int(result.node_count * result.node_count),
        "footprint_unit": FOOTPRINT_UNIT,
        "baseline_company_footprint_tco2": float(result.baseline_total_footprint),
        "maximum_absolute_reconciliation_residual_tco2": float(
            np.max(np.abs(result.reconciliation_residual))
        ),
        "formula": "Delta C_{j|-k} = C_j - C_j^(-k)",
        "row_identity": "sum_j Delta C_{j|-k} = F - F^(-k) = CDR(k) * F",
        "counterfactual_definition": (
            "For each k, zero row k and column k of A and set focal final demand y_k to zero, "
            "then recompute (I-A^(-k))^-1."
        ),
        "dli_authority_boundary": (
            "The decomposition is explanatory evidence only. It does not enter BC, PR, CDR, IC, "
            "pooled Pearson-CRITIC weights, DLI scores, DLI ranks, or intervention rules."
        ),
        "interpretation_boundary": (
            "This is a full node-removal structural counterfactual. It is not the predicted impact "
            "of reducing only the direct carbon intensity of the intervention node."
        ),
        "input_hashes": {str(k): str(v) for k, v in input_hashes.items()},
        "source_network_result_cid": str(source_result_cid),
        "artifacts": artifacts,
        "pairwise_fields": list(PAIRWISE_FIELDS),
        "preferred_pair": preferred_record,
    }
    metadata_tmp = metadata_path.with_name(f".{metadata_path.name}.tmp")
    metadata_tmp.write_text(
        json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )
    _atomic_replace(metadata_tmp, metadata_path)
    return metadata


def bind_cdr_linkage_metadata_to_network_result(
    output_dir: str | Path,
    year: int,
    source_result_cid: str,
    evidence_cid: str = "",
) -> dict[str, Any]:
    """Bind linkage metadata to its Network/DLI result and evidence CIDs."""
    output = Path(output_dir)
    metadata_path = output / METADATA_FILENAME_TEMPLATE.format(year=int(year))
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata["source_network_result_cid"] = str(source_result_cid)
    metadata["linkage_evidence_cid"] = str(evidence_cid)
    temporary = metadata_path.with_name(f".{metadata_path.name}.tmp")
    temporary.write_text(
        json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False),
        encoding="utf-8",
    )
    _atomic_replace(temporary, metadata_path)
    return metadata


def verify_cdr_linkage_artifacts(
    output_dir: str | Path,
    year: int,
    *,
    expected_input_hashes: dict[str, str] | None = None,
    expected_source_result_cid: str | None = None,
    expected_evidence_cid: str | None = None,
    expected_evidence_basis: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Verify linkage metadata, hashes, inputs, result binding, and file policy.

    When ``expected_evidence_basis`` is supplied from the content-addressed
    Network/DLI response, the artifact hashes and all methodological metadata
    must also match that immutable response. This prevents coordinated edits to
    a runtime CSV and its adjacent metadata JSON from being accepted.
    """
    output = Path(output_dir)
    metadata_path = output / METADATA_FILENAME_TEMPLATE.format(year=int(year))
    if not metadata_path.is_file():
        raise FileNotFoundError(f"CDR producer-linkage metadata is unavailable for {year}")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    if metadata.get("extension_id") != "v5.0.17-U13":
        raise RuntimeError("CDR producer-linkage metadata has an unexpected extension identity")
    if int(metadata.get("year", -1)) != int(year):
        raise RuntimeError("CDR producer-linkage metadata year does not match the requested year")
    node_count = int(metadata.get("node_count", 0))
    pair_count = int(metadata.get("pair_count", 0))
    if node_count <= 0 or pair_count != node_count * node_count:
        raise RuntimeError("CDR producer-linkage metadata contains an invalid node/pair count")
    if expected_input_hashes is not None and metadata.get("input_hashes") != {
        str(k): str(v) for k, v in expected_input_hashes.items()
    }:
        raise RuntimeError("CDR producer-linkage artifacts do not match the active input hashes")
    if expected_source_result_cid is not None and str(
        metadata.get("source_network_result_cid", "")
    ) != str(expected_source_result_cid):
        raise RuntimeError("CDR producer-linkage artifacts are bound to a different Network/DLI result")
    if expected_evidence_cid is not None and str(
        metadata.get("linkage_evidence_cid", "")
    ) != str(expected_evidence_cid):
        raise RuntimeError("CDR producer-linkage metadata is bound to different evidence")
    if expected_evidence_basis is not None:
        expected_basis = {
            field: expected_evidence_basis.get(field) for field in EVIDENCE_BASIS_FIELDS
        }
        observed_basis = {field: metadata.get(field) for field in EVIDENCE_BASIS_FIELDS}
        if json.dumps(observed_basis, sort_keys=True, allow_nan=False) != json.dumps(
            expected_basis, sort_keys=True, allow_nan=False
        ):
            raise RuntimeError(
                "CDR producer-linkage metadata does not match the immutable "
                "Network/DLI evidence basis"
            )

    expected_records = {
        "pairwise": pair_count,
        "intervention_summary": node_count,
        "producer_baseline": node_count,
    }
    artifacts = metadata.get("artifacts", {})
    if set(artifacts) != set(expected_records):
        raise RuntimeError("CDR producer-linkage metadata has an incomplete artifact set")
    for key, expected_rows in expected_records.items():
        record = artifacts[key]
        filename = str(record.get("filename", ""))
        if not filename or Path(filename).name != filename:
            raise RuntimeError("CDR producer-linkage metadata contains an unsafe artifact filename")
        if int(record.get("row_count", -1)) != int(expected_rows):
            raise RuntimeError(f"CDR producer-linkage metadata has a wrong row count for {key}")
        path = output / filename
        if not path.is_file():
            raise FileNotFoundError(f"CDR producer-linkage artifact is missing: {path.name}")
        if _sha256_file(path) != str(record.get("sha256", "")):
            raise RuntimeError(f"CDR producer-linkage artifact failed SHA-256 verification: {path.name}")
    return metadata


def validate_cdr_linkage_frames(
    metadata: dict[str, Any],
    pairwise: pd.DataFrame,
    intervention_summary: pd.DataFrame,
    producer_baseline: pd.DataFrame,
) -> None:
    """Validate loaded linkage tables against metadata and accounting identities.

    This is deliberately separate from the file-hash check so Streamlit can read
    each large artifact once, then validate the in-memory frames it displays.
    """
    required_pairwise = set(PAIRWISE_FIELDS)
    required_intervention = {
        "year",
        "intervention_node",
        "baseline_company_footprint_tco2",
        "counterfactual_company_footprint_tco2",
        "total_footprint_reduction_tco2",
        "CDR",
        "producer_decomposition_sum_tco2",
        "reconciliation_residual_tco2",
    }
    required_producer = {
        "year",
        "producer_node",
        "baseline_producer_footprint_tco2",
        "share_of_baseline_company_footprint",
    }
    for label, frame, required in (
        ("pairwise", pairwise, required_pairwise),
        ("intervention summary", intervention_summary, required_intervention),
        ("producer baseline", producer_baseline, required_producer),
    ):
        missing = sorted(required.difference(frame.columns))
        if missing:
            raise RuntimeError(f"CDR producer-linkage {label} is missing columns: {missing}")

    year = int(metadata["year"])
    node_count = int(metadata["node_count"])
    pair_count = int(metadata["pair_count"])
    if len(pairwise) != pair_count:
        raise RuntimeError(f"Pairwise linkage table has {len(pairwise)} rows; expected {pair_count}")
    if len(intervention_summary) != node_count:
        raise RuntimeError(
            f"Intervention summary has {len(intervention_summary)} rows; expected {node_count}"
        )
    if len(producer_baseline) != node_count:
        raise RuntimeError(
            f"Producer baseline has {len(producer_baseline)} rows; expected {node_count}"
        )
    for label, frame in (
        ("pairwise", pairwise),
        ("intervention summary", intervention_summary),
        ("producer baseline", producer_baseline),
    ):
        years = set(pd.to_numeric(frame["year"], errors="raise").astype(int).tolist())
        if years != {year}:
            raise RuntimeError(f"CDR producer-linkage {label} contains an unexpected year")

    pair_keys = pairwise[["intervention_node", "producer_node"]].astype(str)
    if len(pair_keys.drop_duplicates()) != pair_count:
        raise RuntimeError("Pairwise linkage table does not contain one unique row per node pair")
    intervention_nodes = set(intervention_summary["intervention_node"].astype(str))
    producer_nodes = set(producer_baseline["producer_node"].astype(str))
    if len(intervention_nodes) != node_count or len(producer_nodes) != node_count:
        raise RuntimeError("CDR producer-linkage node sets are incomplete")
    if set(pair_keys["intervention_node"]) != intervention_nodes:
        raise RuntimeError("Pairwise intervention-node universe does not match the summary")
    if set(pair_keys["producer_node"]) != producer_nodes:
        raise RuntimeError("Pairwise producer-node universe does not match the baseline")

    numeric_pair_columns = [
        "baseline_producer_footprint_tco2",
        "counterfactual_producer_footprint_tco2",
        "avoided_producer_footprint_tco2",
        "producer_reduction_fraction",
        "share_of_intervention_total_reduction",
        "share_of_baseline_company_footprint",
    ]
    numeric_intervention_columns = [
        "baseline_company_footprint_tco2",
        "counterfactual_company_footprint_tco2",
        "total_footprint_reduction_tco2",
        "CDR",
        "producer_decomposition_sum_tco2",
        "reconciliation_residual_tco2",
    ]
    numeric_producer_columns = [
        "baseline_producer_footprint_tco2",
        "share_of_baseline_company_footprint",
    ]
    for frame, columns in (
        (pairwise, numeric_pair_columns),
        (intervention_summary, numeric_intervention_columns),
        (producer_baseline, numeric_producer_columns),
    ):
        values = frame[columns].apply(pd.to_numeric, errors="raise").to_numpy(dtype=float)
        if not np.isfinite(values).all():
            raise RuntimeError("CDR producer-linkage tables contain non-finite numerical values")

    pair_values = pairwise[
        [
            "baseline_producer_footprint_tco2",
            "counterfactual_producer_footprint_tco2",
            "avoided_producer_footprint_tco2",
        ]
    ].to_numpy(dtype=float)
    baseline = pair_values[:, 0]
    counterfactual = pair_values[:, 1]
    avoided = pair_values[:, 2]
    baseline_total = float(metadata.get("baseline_company_footprint_tco2", 0.0))
    tolerance = max(abs(baseline_total) * 1e-9, 1e-8)
    if not np.allclose(baseline - counterfactual, avoided, atol=tolerance, rtol=1e-10):
        raise RuntimeError("Pairwise linkage rows do not satisfy Delta C = C - C^(-k)")

    grouped = (
        pairwise.assign(
            avoided_producer_footprint_tco2=pd.to_numeric(
                pairwise["avoided_producer_footprint_tco2"], errors="raise"
            )
        )
        .groupby("intervention_node", as_index=False, sort=False)[
            "avoided_producer_footprint_tco2"
        ]
        .sum()
        .rename(columns={"avoided_producer_footprint_tco2": "pairwise_sum"})
    )
    check = intervention_summary.merge(grouped, on="intervention_node", how="left", validate="one_to_one")
    total_reduction = check["total_footprint_reduction_tco2"].to_numpy(dtype=float)
    cdr_reduction = (
        check["CDR"].to_numpy(dtype=float)
        * check["baseline_company_footprint_tco2"].to_numpy(dtype=float)
    )
    decomposition_sum = check["producer_decomposition_sum_tco2"].to_numpy(dtype=float)
    pairwise_sum = check["pairwise_sum"].to_numpy(dtype=float)
    if not (
        np.allclose(pairwise_sum, total_reduction, atol=tolerance, rtol=1e-9)
        and np.allclose(decomposition_sum, total_reduction, atol=tolerance, rtol=1e-9)
        and np.allclose(cdr_reduction, total_reduction, atol=tolerance, rtol=1e-9)
    ):
        raise RuntimeError("Producer-specific linkage tables do not reconcile to CDR(k) * F")

    baseline_lookup = producer_baseline.set_index(
        producer_baseline["producer_node"].astype(str)
    )["baseline_producer_footprint_tco2"].astype(float)
    expected_baseline = pairwise["producer_node"].astype(str).map(baseline_lookup).to_numpy(dtype=float)
    if not np.allclose(baseline, expected_baseline, atol=tolerance, rtol=1e-10):
        raise RuntimeError("Pairwise producer baselines do not match the producer baseline artifact")


__all__ = (
    "CDRProducerLinkageResult",
    "compute_cdr_producer_linkage",
    "write_cdr_producer_linkage_artifacts",
    "bind_cdr_linkage_metadata_to_network_result",
    "verify_cdr_linkage_artifacts",
    "validate_cdr_linkage_frames",
    "PAIRWISE_FILENAME_TEMPLATE",
    "INTERVENTION_SUMMARY_FILENAME_TEMPLATE",
    "PRODUCER_BASELINE_FILENAME_TEMPLATE",
    "METADATA_FILENAME_TEMPLATE",
    "PAIRWISE_FIELDS",
    "EVIDENCE_BASIS_FIELDS",
)
