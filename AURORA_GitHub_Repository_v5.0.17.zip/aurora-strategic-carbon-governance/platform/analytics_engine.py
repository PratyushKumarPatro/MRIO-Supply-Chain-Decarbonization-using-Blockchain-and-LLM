"""
analytics_engine.py -- MRIO carbon-accounting core.

This is the first of the four Strategic Carbon Intelligence Engine stages
(MRIO carbon accounting -> SPA -> SDA -> Network/DLI). It builds the
Leontief inverse for a given year's MRIO table and computes consumption-
based (embodied) carbon footprints for any final-demand vector -- the
economy-wide vector already in the workbook, or the focal-company vector
produced separately.

Everything downstream (SPA path tracing, SDA driver decomposition, network
centrality) is built on the objects this module returns, so its correctness
is validated here directly against the workbook's own documented totals
rather than assumed.

Input conventions, taken from input_mrio_original.xlsx's own README sheet:
    N              = 455
    START_ROW      = 2      (0-indexed; Excel row 3)
    START_COL      = 2      (0-indexed; Excel column C)
    Y_COL_OFFSET   = N + 3  (add to START_COL to reach the Y column)
"""

from dataclasses import dataclass, field
from functools import lru_cache
from pathlib import Path
import os
import numpy as np
import pandas as pd

N = 455
START_ROW = 2
START_COL = 2
Y_COL_OFFSET = N + 3
X_ROW = START_ROW + N + 1   # one blank spacer row separates Z from X
FE_ROW = X_ROW + 1


@dataclass
class MRIOYear:
    """Everything needed to compute footprints for one year's MRIO table."""
    year: int
    Z: np.ndarray                  # N x N, row = supplying node, col = using node
    X: np.ndarray                  # N, total output (model-ready, epsilon-adjusted)
    fE: np.ndarray                 # N, direct carbon intensity = emissions / output
    Y_economy: np.ndarray          # N, economy-wide final demand
    node_codes: np.ndarray
    regions: np.ndarray
    sectors: np.ndarray
    L: np.ndarray = field(init=False, repr=False)   # Leontief inverse

    def __post_init__(self):
        A = self.Z / self.X[np.newaxis, :]
        self.L = np.linalg.inv(np.eye(N) - A)

    def node_index(self, region: str, sector: str) -> int:
        matches = np.where((self.regions == region) & (self.sectors == sector))[0]
        if len(matches) == 0:
            raise KeyError(f"no node for region={region!r} sector={sector!r}")
        return int(matches[0])

    def footprint(self, Y: np.ndarray) -> float:
        """Total embodied-carbon footprint of a final-demand vector Y."""
        return float(self.fE @ (self.L @ Y))

    def footprint_by_node(self, Y: np.ndarray) -> np.ndarray:
        """Per-node contribution to footprint(Y). Sums to footprint(Y)."""
        output_required = self.L @ Y
        return self.fE * output_required

    def hotspots(self, Y: np.ndarray, top: int = 15) -> pd.DataFrame:
        """Rank nodes by their contribution to the footprint of Y."""
        contrib = self.footprint_by_node(Y)
        total = contrib.sum()
        df = pd.DataFrame({
            "node_code": self.node_codes,
            "region": self.regions,
            "sector": self.sectors,
            "footprint_contribution": contrib,
            "share_of_total": contrib / total if total else np.zeros_like(contrib),
        })
        return df.sort_values("footprint_contribution", ascending=False).head(top).reset_index(drop=True)


def _file_signature(path: str | os.PathLike[str]) -> tuple[str, int, int]:
    """Return a deterministic cache key that invalidates when a workbook changes.

    The active-input governance layer already verifies SHA-256 values.  This
    lightweight stat signature prevents repeated workbook parsing and repeated
    Leontief inversion inside one deployment process while still invalidating
    immediately when the promoted file is replaced.
    """
    source = Path(path).expanduser().resolve()
    stat = source.stat()
    return str(source), int(stat.st_size), int(stat.st_mtime_ns)


@lru_cache(maxsize=8)
def _load_year_cached(path_text: str, year: int, _size: int, _mtime_ns: int) -> MRIOYear:
    raw = pd.read_excel(path_text, sheet_name=str(year), header=None)
    Z = raw.iloc[START_ROW:START_ROW + N, START_COL:START_COL + N].to_numpy(dtype=float)
    X = raw.iloc[X_ROW, START_COL:START_COL + N].to_numpy(dtype=float)
    fE = raw.iloc[FE_ROW, START_COL:START_COL + N].to_numpy(dtype=float)
    y_col = START_COL + Y_COL_OFFSET
    Y_economy = raw.iloc[START_ROW:START_ROW + N, y_col].to_numpy(dtype=float)

    meta = pd.read_excel(path_text, sheet_name="Metadata")
    if len(meta) != N:
        raise ValueError(f"Metadata sheet has {len(meta)} rows, expected {N}")

    return MRIOYear(
        year=int(year), Z=Z, X=X, fE=fE, Y_economy=Y_economy,
        node_codes=meta["Node_Code"].to_numpy(),
        regions=meta["Region_Code"].to_numpy(),
        sectors=meta["Sector_Code"].to_numpy(),
    )


def load_year(mrio_xlsx_path: str, year: int) -> MRIOYear:
    """Load one MRIO year with process-local, file-change-aware caching.

    The returned model is immutable by convention.  All counterfactual modules
    copy matrices before alteration, so sharing one cached Leontief inverse is
    safe and removes repeated inversions across MRIO, SPA, SDA, DLI and the
    integrated decision workspace.
    """
    path_text, size, mtime_ns = _file_signature(mrio_xlsx_path)
    return _load_year_cached(path_text, int(year), size, mtime_ns)


@lru_cache(maxsize=8)
def _load_company_y_cached(path_text: str, year: int, _size: int, _mtime_ns: int) -> tuple[float, ...]:
    df = pd.read_excel(path_text, sheet_name="Converted_Demand")
    col = f"Company_{year}_USD"
    if col not in df.columns:
        raise KeyError(f"{col} not found; available columns: {list(df.columns)}")
    if len(df) != N:
        raise ValueError(f"Converted_Demand has {len(df)} rows, expected {N}")
    values = df[col].to_numpy(dtype=float)
    if not np.isfinite(values).all() or (values < 0).any():
        raise ValueError(f"{col} must contain {N} finite, non-negative values")
    return tuple(float(value) for value in values)


def load_company_Y(converted_xlsx_path: str, year: int) -> np.ndarray:
    """Load focal-company demand using the same file-aware cache.

    A new NumPy array is returned on each call so callers cannot mutate the
    cached authoritative demand vector.
    """
    path_text, size, mtime_ns = _file_signature(converted_xlsx_path)
    return np.asarray(
        _load_company_y_cached(path_text, int(year), size, mtime_ns), dtype=float
    ).copy()


def clear_input_cache() -> None:
    """Clear process-local workbook caches after an input promotion event."""
    _load_year_cached.cache_clear()
    _load_company_y_cached.cache_clear()


def input_cache_info() -> dict[str, object]:
    """Expose cache diagnostics without exposing workbook contents."""
    return {
        "mrio": _load_year_cached.cache_info()._asdict(),
        "focal_demand": _load_company_y_cached.cache_info()._asdict(),
    }


def validate(mrio_year: MRIOYear) -> dict:
    """Sanity checks that must hold if the data loaded correctly, independent
    of whether the underlying MRIO data itself is 'correct' in any economic
    sense -- these are internal-consistency checks, not data-quality checks."""
    X_reconstructed = mrio_year.L @ mrio_year.Y_economy
    max_diff = float(np.abs(X_reconstructed - mrio_year.X).max())
    emissions_direct = mrio_year.fE @ mrio_year.X
    emissions_via_footprint = mrio_year.footprint(mrio_year.Y_economy)
    return {
        "year": mrio_year.year,
        "L_at_Y_economy_matches_X": max_diff < 1e-4,
        "max_abs_diff_X": max_diff,
        "direct_emissions_total": emissions_direct,
        "footprint_of_economy_wide_Y": emissions_via_footprint,
        "emissions_identity_holds": abs(emissions_direct - emissions_via_footprint) < 1e-4,
    }


if __name__ == "__main__":
    import json
    import sys

    mrio_path = sys.argv[1] if len(sys.argv) > 1 else "input_mrio_completed.xlsx"
    company_path = sys.argv[2] if len(sys.argv) > 2 else "Focal_Company_Demand_Converted.xlsx"

    all_results = {}
    for year in (2014, 2017):
        my = load_year(mrio_path, year)
        v = validate(my)
        print(f"[{year}] validation: {v}")
        assert v["L_at_Y_economy_matches_X"], "Leontief inverse failed to reconstruct X -- check row/col convention"
        assert v["emissions_identity_holds"], "fE@X does not match footprint(Y_economy) -- check data alignment"

        Y_company = load_company_Y(company_path, year)
        footprint_economy = my.footprint(my.Y_economy)
        footprint_company = my.footprint(Y_company)
        hotspots_company = my.hotspots(Y_company, top=15)

        all_results[year] = {
            "footprint_economy_wide": footprint_economy,
            "footprint_company": footprint_company,
            "units": {
                "economy_wide_footprint": "Mt CO2",
                "company_footprint": "t CO2",
                "company_demand": "USD",
            },
            "hotspots_company": hotspots_company.to_dict(orient="records"),
        }
        print(f"[{year}] company footprint: {footprint_company:.4f} t CO2")
        print(f"[{year}] economy-wide footprint: {footprint_economy:.4f} Mt CO2")
        print(hotspots_company.head(10).to_string(index=False))
        print()

    with open("mrio_results.json", "w") as f:
        json.dump(all_results, f, indent=2, default=float)
    print("Saved mrio_results.json")
