"""Offline regression battery for the v5.0.17 Solidity/source refactor.

These tests do not require Ganache, Web3, Streamlit, npm, or operational input
workbooks. They verify that the four-contract business surface is preserved
while the source layout is consolidated, and that the new role-aware event
notification policy behaves as documented.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import re
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "contracts" / "StrategicCarbonIntelligenceSystem.sol"
BASELINE = ROOT / "CONTRACT_LOGIC_COMPATIBILITY_BASELINE_v5_0_16.json"

CONTRACTS = (
    "Registration",
    "UpstreamCarbonEmissionsAnalysis",
    "HotspotsManagementAndGovernance",
    "QueryManagement",
)


def _strip_comments(text: str) -> str:
    text = re.sub(r"/\*.*?\*/", "", text, flags=re.S)
    return re.sub(r"//.*", "", text)


def _canonical(text: str) -> str:
    return " ".join(text.split())


def _contract_body(source: str, name: str) -> str:
    match = re.search(
        rf"\b(?:contract|abstract\s+contract)\s+{re.escape(name)}\b[^{{]*{{",
        source,
    )
    if match is None:
        raise AssertionError(f"Contract {name} was not found")
    start = match.end() - 1
    depth = 0
    for index in range(start, len(source)):
        character = source[index]
        if character == "{":
            depth += 1
        elif character == "}":
            depth -= 1
            if depth == 0:
                return source[start + 1 : index]
    raise AssertionError(f"Contract {name} is not closed")


def _function_hashes(body: str) -> dict[str, str]:
    clean = _strip_comments(body)
    result: dict[str, str] = {}
    position = 0
    pattern = re.compile(r"\bfunction\s+(\w+)\s*\(")
    while True:
        match = pattern.search(clean, position)
        if match is None:
            break
        cursor = match.end()
        parentheses = 1
        while cursor < len(clean) and parentheses:
            if clean[cursor] == "(":
                parentheses += 1
            elif clean[cursor] == ")":
                parentheses -= 1
            cursor += 1
        while cursor < len(clean) and clean[cursor] not in "{;":
            cursor += 1
        if cursor >= len(clean):
            raise AssertionError(f"Malformed function {match.group(1)}")
        if clean[cursor] == ";":
            end = cursor + 1
        else:
            braces = 0
            end = None
            for index in range(cursor, len(clean)):
                if clean[index] == "{":
                    braces += 1
                elif clean[index] == "}":
                    braces -= 1
                    if braces == 0:
                        end = index + 1
                        break
            if end is None:
                raise AssertionError(f"Function {match.group(1)} is not closed")
        snippet = _canonical(clean[match.start() : end])
        # Professional labels may change while executable logic remains fixed.
        # Remove Solidity string-literal content before hashing; control flow,
        # state access, modifiers, arguments, calculations and event calls remain sensitive.
        logic_snippet = re.sub(r'"(?:\\.|[^"\\])*"', '"<TEXT>"', snippet)
        header = logic_snippet.split("{", 1)[0].rstrip().rstrip(";").strip()
        result[header] = hashlib.sha256(logic_snippet.encode("utf-8")).hexdigest()
        position = end
    return result


def _events(body: str) -> list[str]:
    clean = _strip_comments(body)
    return sorted(
        _canonical(event)
        for event in re.findall(r"\bevent\s+\w+\s*\(.*?\)\s*;", clean, flags=re.S)
    )


def _constructor_parameters(body: str) -> str:
    match = re.search(r"\bconstructor\s*\((.*?)\)", _strip_comments(body), flags=re.S)
    return _canonical(match.group(1)) if match else ""


def _load_notification_module():
    """Load the policy helpers without requiring the external Web3 package."""

    fake_web3 = types.ModuleType("web3")

    class StubWeb3:
        @staticmethod
        def keccak(*, text: str):
            # Event-topic generation is not exercised in these policy tests.
            return bytes.fromhex(hashlib.sha256(text.encode("utf-8")).hexdigest())

    fake_web3.Web3 = StubWeb3
    fake_utils = types.ModuleType("web3._utils")
    fake_events = types.ModuleType("web3._utils.events")
    fake_events.get_event_data = lambda codec, event_abi, raw: raw

    module_name = "stakeholder_event_monitor_offline_test"
    spec = importlib.util.spec_from_file_location(module_name, ROOT / "stakeholder_event_monitor.py")
    if spec is None or spec.loader is None:
        raise AssertionError("Cannot load stakeholder_event_monitor.py")
    module = importlib.util.module_from_spec(spec)
    with mock.patch.dict(
        sys.modules,
        {
            "web3": fake_web3,
            "web3._utils": fake_utils,
            "web3._utils.events": fake_events,
            module_name: module,
        },
    ):
        spec.loader.exec_module(module)
    return module


class UnifiedSolidityCompatibilityTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = SOURCE.read_text(encoding="utf-8")
        cls.baseline = json.loads(BASELINE.read_text(encoding="utf-8"))

    def test_exactly_one_solidity_source_contains_four_deployable_contracts(self):
        solidity_files = sorted((ROOT / "contracts").glob("*.sol"))
        self.assertEqual(solidity_files, [SOURCE])
        self.assertEqual(self.source.count("interface IRegistration"), 1)
        self.assertEqual(self.source.count("abstract contract RegistrationAware"), 1)
        for name in CONTRACTS:
            self.assertRegex(self.source, rf"\bcontract\s+{name}\b")
        deployable = re.findall(r"(?m)^contract\s+(\w+)\b", self.source)
        self.assertEqual(deployable, list(CONTRACTS))

    def test_operational_contracts_share_one_registration_reference(self):
        self.assertEqual(self.source.count("IRegistration public immutable registration;"), 1)
        self.assertEqual(self.source.count("mapping(address => Role) private roleOf_;"), 1)
        for name in CONTRACTS[1:]:
            self.assertRegex(
                self.source,
                rf"contract\s+{name}\s+is\s+RegistrationAware",
            )
        self.assertIn("registration.roleOf(msg.sender)", self.source)
        self.assertIn("registration.oracleForRole(oracleRole) == msg.sender", self.source)

        declared_getters = set(
            re.findall(
                r"\b(?:address|uint\d*|string|bytes\d*|bool|Role|IRegistration|IRegistration\.Role)\s+public(?:\s+(?:immutable|constant))*\s+(\w+)\s*(?:=|;)",
                self.source,
            )
        )
        declared_getters.update(
            re.findall(r"\bmapping\s*\([^;]*?\)\s+public\s+(\w+)\s*;", self.source)
        )
        expected_getters = {
            getter
            for contract in self.baseline["contracts"].values()
            for getter in contract["public_getters"]
        }
        self.assertTrue(expected_getters.issubset(declared_getters))

    def test_function_logic_matches_baseline_except_reviewed_u19_deltas(self):
        delta_manifest = json.loads(
            (ROOT / "U19_CONTRACT_LOGIC_DELTA_SHA256.json").read_text(encoding="utf-8")
        )
        intentional_u19_deltas = set(delta_manifest["changed_functions"])
        intentional_u19_additions = set(delta_manifest["added_functions"])
        self.assertEqual(delta_manifest["allowed_logic_delta_count"], 7)
        self.assertEqual(delta_manifest["allowed_added_function_count"], 1)
        self.assertEqual(len(intentional_u19_deltas), 7)
        self.assertEqual(len(intentional_u19_additions), 1)
        for name in CONTRACTS:
            with self.subTest(contract=name):
                expected = self.baseline["contracts"][name]["function_hashes"]
                actual = _function_hashes(_contract_body(self.source, name))
                if name != "HotspotsManagementAndGovernance":
                    self.assertEqual(actual, expected)
                    continue

                changed = {
                    header
                    for header in set(expected) | set(actual)
                    if expected.get(header) != actual.get(header)
                }
                intentional_u21_additions = {
                    "function recordInterventionPerformance( uint256 interventionId, string calldata evidenceCID ) external onlyGovernor returns (uint256 observationIndex)",
                    "function getInterventionPerformanceEvidenceCIDs(uint256 interventionId) external view returns (string[] memory)",
                }
                self.assertEqual(
                    changed,
                    intentional_u19_deltas | intentional_u19_additions | intentional_u21_additions,
                )
                self.assertEqual(
                    set(actual) - set(expected),
                    intentional_u19_additions | intentional_u21_additions,
                )
                self.assertFalse(set(expected) - set(actual))
                for header in set(expected) - intentional_u19_deltas:
                    self.assertEqual(actual[header], expected[header])
                for header, record in delta_manifest["added_functions"].items():
                    self.assertEqual(actual[header], record["u19_logic_sha256"])

    def test_event_surfaces_match_v5_0_16_baseline(self):
        for name in CONTRACTS:
            with self.subTest(contract=name):
                expected = self.baseline["contracts"][name]["events"]
                actual = _events(_contract_body(self.source, name))
                if name == "HotspotsManagementAndGovernance":
                    expected = sorted(
                        expected
                        + [
                            "event InterventionPerformanceRecorded( uint256 indexed interventionId, uint256 indexed observationIndex, string evidenceCID, address indexed recordedBy );"
                        ]
                    )
                self.assertEqual(actual, expected)

    def test_constructor_inputs_and_role_guards_are_preserved(self):
        for name in CONTRACTS:
            with self.subTest(contract=name):
                expected = self.baseline["contracts"][name]["constructor_parameters"]
                actual = _constructor_parameters(_contract_body(self.source, name))
                self.assertEqual(actual, expected)
        self.assertIn("IRegistration.Role.MRIODataProvider", self.source)
        self.assertIn('"deployer is not the registered MRIO data provider"', self.source)
        self.assertGreaterEqual(self.source.count("IRegistration.Role.FocalCompany"), 3)
        self.assertEqual(
            self.source.count('"deployer is not the registered focal company"'),
            2,
        )

    def test_compiler_and_deployment_use_unified_artifact_stems(self):
        compile_script = (ROOT / "compile_contracts.js").read_text(encoding="utf-8")
        deploy_module = (ROOT / "deploy_contracts.py").read_text(encoding="utf-8")
        lifecycle = (ROOT / "dapp_lifecycle.py").read_text(encoding="utf-8")
        self.assertIn("sourceFiles.length !== 1", compile_script)
        self.assertIn("StrategicCarbonIntelligenceSystem.sol", compile_script)
        for name in CONTRACTS:
            stem = f"StrategicCarbonIntelligenceSystem_sol_{name}"
            self.assertIn(stem, deploy_module if name == "Registration" else lifecycle + deploy_module)

    def test_progressive_deployment_order_is_unchanged(self):
        page = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        markers = [
            "Stage 1 — Regulatory Authority deploys",
            "Stage 4 — MRIO Data Provider deploys",
            "Stage 9 — Focal Company deploys",
            "Stage 13 — Final synthesis: deploy QueryManagement",
            "Stage 14 — Submit strategic/general/hybrid queries on-chain",
        ]
        positions = [page.index(marker) for marker in markers]
        self.assertEqual(positions, sorted(positions))
        lifecycle = (ROOT / "dapp_lifecycle.py").read_text(encoding="utf-8")
        self.assertIn("upstream_baseline_complete", lifecycle)
        self.assertIn("intervention_decided", lifecycle)
        self.assertIn("aurora_complete", lifecycle)
        self.assertIn('"UpstreamCarbonEmissionsAnalysis": "mrio_provider"', lifecycle)
        self.assertIn('"HotspotsManagementAndGovernance": "focal_company"', lifecycle)
        self.assertIn('"QueryManagement": "focal_company"', lifecycle)


class StakeholderNotificationPolicyTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.monitor = _load_notification_module()
        cls.deployment = {
            "accounts": {
                "regulator": "0x0000000000000000000000000000000000000005",
                "mrio_provider": "0x0000000000000000000000000000000000000006",
                "focal_company": "0x0000000000000000000000000000000000000007",
                "registration_oracle": "0x0000000000000000000000000000000000000001",
                "upstream_oracle": "0x0000000000000000000000000000000000000002",
                "governance_oracle": "0x0000000000000000000000000000000000000003",
                "query_oracle": "0x0000000000000000000000000000000000000004",
            },
            "contracts": {
                "QueryManagement": {"address": "0xquery", "abi": []},
            },
        }

    def test_spa_request_and_completion_notify_all_principal_stakeholders(self):
        expected_roles = ["RegulatoryAuthority", "MRIODataProvider", "FocalCompany"]
        for event_name in ("StructuralPathAnalysisRequested", "StructuralPathAnalysisCompleted"):
            with self.subTest(event=event_name):
                roles, addresses, visibility = self.monitor._recipient_policy(
                    None,
                    self.deployment,
                    "UpstreamCarbonEmissionsAnalysis",
                    event_name,
                    {"requestId": 4, "year": 2017},
                )
                self.assertEqual(roles, expected_roles)
                self.assertEqual(len(addresses), 3)
                self.assertEqual(visibility, "all-principal-stakeholders")

    def test_active_recipient_roles_are_verified_against_registration(self):
        role_map = {
            self.deployment["accounts"]["regulator"]: 1,
            self.deployment["accounts"]["mrio_provider"]: 2,
            self.deployment["accounts"]["focal_company"]: 0,
        }
        deployment = json.loads(json.dumps(self.deployment))
        deployment["contracts"]["Registration"] = {"address": "0xregistration", "abi": []}

        class RoleCall:
            def __init__(self, address):
                self.address = address

            def call(self):
                return role_map.get(self.address, 0)

        class RegistrationFunctions:
            def roleOf(self, address):
                return RoleCall(address)

        class RegistrationContract:
            functions = RegistrationFunctions()

        class Eth:
            def contract(self, address, abi):
                return RegistrationContract()

        class W3:
            eth = Eth()

        roles, addresses, visibility = self.monitor._recipient_policy(
            W3(),
            deployment,
            "UpstreamCarbonEmissionsAnalysis",
            "StructuralPathAnalysisRequested",
            {"requestId": 4, "year": 2017},
        )
        self.assertEqual(roles, ["RegulatoryAuthority", "MRIODataProvider"])
        self.assertNotIn(self.deployment["accounts"]["focal_company"], addresses)
        self.assertEqual(visibility, "all-principal-stakeholders")

    def test_all_analytical_and_governance_events_use_shared_visibility(self):
        cases = [
            ("UpstreamCarbonEmissionsAnalysis", "MRIOCarbonAccountingComputed"),
            ("UpstreamCarbonEmissionsAnalysis", "ComputeFailed"),
            ("HotspotsManagementAndGovernance", "NetworkAnalysisRequested"),
            ("HotspotsManagementAndGovernance", "InterventionDecided"),
            ("HotspotsManagementAndGovernance", "RegionalSourcingOpportunityAnalysisCompleted"),
        ]
        for contract_name, event_name in cases:
            with self.subTest(event=event_name):
                roles, _, visibility = self.monitor._recipient_policy(
                    None, self.deployment, contract_name, event_name, {"requestId": 1}
                )
                self.assertEqual(
                    roles,
                    ["RegulatoryAuthority", "MRIODataProvider", "FocalCompany"],
                )
                self.assertEqual(visibility, "all-principal-stakeholders")

    def test_query_events_remain_requester_only(self):
        requester = self.deployment["accounts"]["mrio_provider"]
        roles, addresses, visibility = self.monitor._recipient_policy(
            None,
            self.deployment,
            "QueryManagement",
            "QueryRequested",
            {"requestId": 8, "requester": requester},
        )
        self.assertEqual(roles, ["MRIODataProvider"])
        self.assertEqual(addresses, [requester])
        self.assertEqual(visibility, "requester-only")

    def test_query_completion_resolves_original_requester(self):
        requester = self.deployment["accounts"]["focal_company"]

        class QueryCall:
            def call(self):
                return (requester, "question", "", 0, 1, 1, "cid", "", 0, 0, "oracle")

        class Functions:
            def getQuery(self, request_id):
                self.request_id = request_id
                return QueryCall()

        class Contract:
            functions = Functions()

        class Eth:
            def contract(self, address, abi):
                return Contract()

        class W3:
            eth = Eth()

        roles, addresses, visibility = self.monitor._recipient_policy(
            W3(),
            self.deployment,
            "QueryManagement",
            "QueryFulfilled",
            {"requestId": 11},
        )
        self.assertEqual(roles, ["FocalCompany"])
        self.assertEqual(addresses, [requester])
        self.assertEqual(visibility, "requester-only")

    def test_registration_notifications_are_limited_to_regulator_and_requester(self):
        requester = self.deployment["accounts"]["mrio_provider"]
        roles, addresses, visibility = self.monitor._recipient_policy(
            None,
            self.deployment,
            "Registration",
            "RegistrationRequested",
            {"requestId": 2, "requester": requester},
        )
        self.assertEqual(roles, ["RegulatoryAuthority", "MRIODataProvider"])
        self.assertEqual(addresses[0], self.deployment["accounts"]["regulator"])
        self.assertEqual(addresses[1], requester)
        self.assertEqual(visibility, "registration-parties")

    def test_read_unread_state_is_role_specific_and_rebuildable(self):
        records = [
            {"block_number": 4, "transaction_index": 0, "log_index": 1},
            {"block_number": 5, "transaction_index": 0, "log_index": 0},
        ]
        with tempfile.TemporaryDirectory() as temporary:
            deployment_path = Path(temporary) / "deployment.json"
            state = self.monitor.mark_notifications_seen(
                deployment_path,
                "RegulatoryAuthority",
                records,
            )
            self.assertEqual(state["RegulatoryAuthority"], [5, 0, 0])
            self.assertFalse(
                self.monitor.is_unread(records[0], "RegulatoryAuthority", state)
            )
            self.assertTrue(self.monitor.is_unread(records[1], "FocalCompany", state))

    def test_monitor_is_started_and_presented_by_the_dapp(self):
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        page = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        ui = (ROOT / "streamlit_app" / "stakeholder_notification_ui.py").read_text(encoding="utf-8")
        self.assertIn("stakeholder_event_monitor.py", launcher)
        self.assertIn("stakeholder_event_monitor_heartbeat.json", launcher)
        self.assertIn("render_stakeholder_notifications", page)
        self.assertIn("Refresh notifications from chain", ui)
        self.assertIn("requester-only", ui)

    def test_version_and_documentation_identity_are_consistent(self):
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8")
        package = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
        readme = (ROOT / "README_START_HERE.txt").read_text(encoding="utf-8")
        self.assertIn("5.0.17", version)
        self.assertEqual(package["version"], "5.0.17")
        self.assertIn("StrategicCarbonIntelligenceSystem.sol", readme)
        self.assertIn("stakeholder event", readme.casefold())


if __name__ == "__main__":
    unittest.main(verbosity=2)
