"""Connect producer-origin hotspots to network-wide systemic leverage nodes.

This U16 analytical bridge combines, without creating a new composite score:

* the comparison-year producer hotspot set from authoritative node-wise SDA;
* the unchanged pooled Pearson-CRITIC DLI ranking; and
* the unchanged U13 producer-specific CDR node-removal decomposition.

It reports Hotspot Structural Influence (HSI) and retains three route-specific
structural-coverage diagnostics: direct hotspot nodes, high-DLI non-hotspot
governance-mediated nodes, and a hybrid candidate set.  These are diagnostic
views only; U16 formal intervention selection uses one consolidated governance
funnel in intervention_governance.py.
All portfolio reductions are recomputed jointly under the same complete-node-
removal counterfactual.  They are structural diagnostics, not predicted or
guaranteed realizable abatement.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
from typing import Any, Iterable, Mapping

import numpy as np
import pandas as pd

from cdr_producer_linkage import CDRProducerLinkageResult

HOTSPOT_LEVERAGE_EXTENSION_ID = "v5.0.17-U16"
NODE_SUMMARY_FILENAME = "hotspot_leverage_node_summary_2017.csv"
PAIR_EVIDENCE_FILENAME = "hotspot_leverage_pair_evidence_2017.csv"
DIRECT_PORTFOLIO_FILENAME = "hotspot_leverage_direct_portfolio_2017.csv"
MEDIATED_PORTFOLIO_FILENAME = "hotspot_leverage_governance_mediated_portfolio_2017.csv"
HYBRID_PORTFOLIO_FILENAME = "hotspot_leverage_hybrid_portfolio_2017.csv"
WORKBOOK_FILENAME = "HOTSPOT_LEVERAGE_STRUCTURAL_COVERAGE_2017.xlsx"
METADATA_FILENAME = "hotspot_leverage_2017.json"
PORTFOLIO_COLUMNS = (
    "portfolio_type",
    "selection_step",
    "intervention_node",
    "intervention_region",
    "intervention_sector",
    "DLI",
    "dli_rank",
    "is_direct_hotspot_node",
    "marginal_hotspot_structural_reduction_tco2",
    "cumulative_hotspot_structural_reduction_tco2",
    "cumulative_hotspot_structural_coverage",
    "marginal_company_structural_reduction_tco2",
    "cumulative_company_structural_reduction_tco2",
    "cumulative_company_structural_coverage",
    "hotspot_set_share_of_company_footprint",
    "top_marginally_affected_hotspots",
    "selection_rule",
    "claim_boundary",
)


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _safe_divide(numerator: np.ndarray | float, denominator: np.ndarray | float) -> np.ndarray:
    numerator_array = np.asarray(numerator, dtype=float)
    denominator_array = np.asarray(denominator, dtype=float)
    out = np.zeros(np.broadcast_shapes(numerator_array.shape, denominator_array.shape), dtype=float)
    np.divide(numerator_array, denominator_array, out=out, where=np.abs(denominator_array) > 0.0)
    return out


def _top_links(node_codes: np.ndarray, values: np.ndarray, limit: int = 5) -> str:
    order = np.argsort(-np.asarray(values, dtype=float), kind="mergesort")
    parts: list[str] = []
    for index in order:
        value = float(values[index])
        if value <= 0.0:
            continue
        parts.append(f"{str(node_codes[index])}:{value:.6g}")
        if len(parts) >= int(limit):
            break
    return "; ".join(parts)


def _normalise_ranking(ranking: pd.DataFrame, year: int) -> pd.DataFrame:
    frame = ranking.copy()
    if "year" in frame.columns:
        frame = frame.loc[pd.to_numeric(frame["year"], errors="coerce") == int(year)].copy()
    required = {"node_code", "DLI", "dli_rank"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"DLI ranking is missing required columns: {missing}")
    frame["node_code"] = frame["node_code"].astype(str)
    frame["DLI"] = pd.to_numeric(frame["DLI"], errors="raise")
    frame["dli_rank"] = pd.to_numeric(frame["dli_rank"], errors="raise").astype(int)
    if frame["node_code"].duplicated().any():
        raise ValueError("DLI ranking contains duplicate node codes")
    return frame.sort_values(["dli_rank", "node_code"], kind="mergesort").reset_index(drop=True)


def _validate_node_sda(node_sda: pd.DataFrame, node_codes: np.ndarray) -> pd.DataFrame:
    required = {
        "node_code",
        "comparison_footprint_contribution_tco2",
        "comparison_share_of_company_footprint",
        "comparison_hotspot_rank",
        "comparison_cumulative_hotspot_share",
        "in_comparison_top_80_hotspot_set",
        "node_delta_intensity",
        "node_delta_technology",
        "node_delta_composition",
        "node_delta_scale",
        "node_dominant_driver",
        "node_dominant_driver_family",
        "node_temporal_status",
    }
    missing = sorted(required.difference(node_sda.columns))
    if missing:
        raise ValueError(f"Node-wise SDA is missing required columns: {missing}")
    frame = node_sda.copy()
    frame["node_code"] = frame["node_code"].astype(str)
    if frame["node_code"].duplicated().any():
        raise ValueError("Node-wise SDA contains duplicate node codes")
    expected = set(np.asarray(node_codes).astype(str))
    observed = set(frame["node_code"])
    if observed != expected:
        raise ValueError("Node-wise SDA and CDR linkage do not cover the same node universe")
    return frame


@dataclass(frozen=True)
class GreedyPortfolioResult:
    portfolio_type: str
    candidate_policy: str
    target_coverage: float
    frame: pd.DataFrame
    achieved_coverage: float
    achieved_company_coverage: float
    reached_target: bool
    stop_reason: str


@dataclass(frozen=True)
class HotspotLeverageResult:
    year: int
    hotspot_threshold: float
    high_dli_threshold: float
    high_dli_quantile: float
    hotspot_total_footprint: float
    company_total_footprint: float
    hotspot_nodes: pd.DataFrame
    node_summary: pd.DataFrame
    pair_evidence: pd.DataFrame
    portfolios: dict[str, GreedyPortfolioResult]

    @property
    def hotspot_count(self) -> int:
        return int(len(self.hotspot_nodes))


def _portfolio_greedy(
    *,
    portfolio_type: str,
    candidate_policy: str,
    candidate_indices: Iterable[int],
    node_codes: np.ndarray,
    regions: np.ndarray,
    sectors: np.ndarray,
    leontief: np.ndarray,
    demand: np.ndarray,
    intensity: np.ndarray,
    hotspot_indices: np.ndarray,
    dli_by_index: np.ndarray,
    rank_by_index: np.ndarray,
    direct_hotspot_flags: np.ndarray,
    target_coverage: float,
) -> GreedyPortfolioResult:
    node_codes = np.asarray(node_codes).astype(str)
    regions = np.asarray(regions).astype(str)
    sectors = np.asarray(sectors).astype(str)
    intensity = np.asarray(intensity, dtype=float)
    demand = np.asarray(demand, dtype=float)
    active = np.arange(len(node_codes), dtype=int)
    inverse = np.asarray(leontief, dtype=float).copy()
    output = inverse @ demand
    hotspot_set = set(int(index) for index in np.asarray(hotspot_indices, dtype=int))
    candidates = set(int(index) for index in candidate_indices)
    baseline_hotspot = float(sum(intensity[index] * output[index] for index in hotspot_set))
    baseline_company = float(intensity @ output)
    tolerance = max(abs(baseline_hotspot) * 1e-12, 1e-10)
    records: list[dict[str, Any]] = []
    cumulative_hotspot = 0.0
    cumulative_company = 0.0
    stop_reason = "candidate set exhausted"

    while candidates:
        position_lookup = {int(original): int(position) for position, original in enumerate(active)}
        active_hotspots = [index for index in hotspot_set if index in position_lookup]
        if not active_hotspots:
            stop_reason = "no hotspot footprint remains under the structural counterfactual"
            break
        current_hotspot = float(
            sum(intensity[index] * output[position_lookup[index]] for index in active_hotspots)
        )
        current_company = float(
            sum(intensity[original] * output[position] for position, original in enumerate(active))
        )
        best: tuple[float, float, str, int, np.ndarray, np.ndarray, np.ndarray] | None = None

        for candidate in sorted(candidates, key=lambda idx: node_codes[idx]):
            if candidate not in position_lookup:
                continue
            position = position_lookup[candidate]
            pivot = float(inverse[position, position])
            if abs(pivot) <= np.finfo(float).eps:
                continue
            keep_mask = np.ones(len(active), dtype=bool)
            keep_mask[position] = False
            keep_positions = np.flatnonzero(keep_mask)
            next_output = output[keep_mask] - inverse[keep_mask, position] * output[position] / pivot
            next_active = active[keep_mask]
            next_position = {int(original): int(pos) for pos, original in enumerate(next_active)}
            next_hotspot = float(
                sum(
                    intensity[index] * next_output[next_position[index]]
                    for index in active_hotspots
                    if index in next_position
                )
            )
            next_company = float(
                sum(intensity[original] * next_output[pos] for pos, original in enumerate(next_active))
            )
            marginal_hotspot = current_hotspot - next_hotspot
            marginal_company = current_company - next_company

            # Exact producer-resolved marginal vector for the currently active hotspots.
            hotspot_marginals = np.zeros(len(hotspot_indices), dtype=float)
            for offset, hotspot_index in enumerate(hotspot_indices):
                if int(hotspot_index) not in position_lookup:
                    continue
                h_position = position_lookup[int(hotspot_index)]
                before = intensity[int(hotspot_index)] * output[h_position]
                after = 0.0
                if int(hotspot_index) in next_position:
                    after = intensity[int(hotspot_index)] * next_output[next_position[int(hotspot_index)]]
                hotspot_marginals[offset] = before - after

            tie = (
                float(marginal_hotspot),
                float(dli_by_index[candidate]) if np.isfinite(dli_by_index[candidate]) else -np.inf,
                str(node_codes[candidate]),
                int(candidate),
                next_output,
                next_active,
                hotspot_marginals,
            )
            if best is None:
                best = tie
            else:
                # Maximum carbon marginal; then maximum DLI; then node code ascending.
                if tie[0] > best[0] + tolerance:
                    best = tie
                elif abs(tie[0] - best[0]) <= tolerance:
                    if tie[1] > best[1] + 1e-15:
                        best = tie
                    elif abs(tie[1] - best[1]) <= 1e-15 and tie[2] < best[2]:
                        best = tie

        if best is None or best[0] <= tolerance:
            stop_reason = "no remaining candidate provides a positive marginal hotspot reduction"
            break

        marginal_hotspot, _dli_tie, _code_tie, selected, next_output, next_active, hotspot_marginals = best
        selected_position = position_lookup[selected]
        pivot = float(inverse[selected_position, selected_position])
        keep_mask = np.ones(len(active), dtype=bool)
        keep_mask[selected_position] = False
        next_inverse = inverse[np.ix_(keep_mask, keep_mask)] - np.outer(
            inverse[keep_mask, selected_position], inverse[selected_position, keep_mask]
        ) / pivot
        next_company = float(
            sum(intensity[original] * next_output[pos] for pos, original in enumerate(next_active))
        )
        marginal_company = current_company - next_company
        cumulative_hotspot = baseline_hotspot - (current_hotspot - marginal_hotspot)
        cumulative_company = baseline_company - next_company
        coverage = cumulative_hotspot / baseline_hotspot if baseline_hotspot else 0.0
        top_indices = np.argsort(-hotspot_marginals, kind="mergesort")
        top_records = [
            f"{node_codes[int(hotspot_indices[index])]}:{float(hotspot_marginals[index]):.6g}"
            for index in top_indices
            if float(hotspot_marginals[index]) > tolerance
        ][:5]
        records.append(
            {
                "portfolio_type": portfolio_type,
                "selection_step": len(records) + 1,
                "intervention_node": str(node_codes[selected]),
                "intervention_region": str(regions[selected]),
                "intervention_sector": str(sectors[selected]),
                "DLI": float(dli_by_index[selected]) if np.isfinite(dli_by_index[selected]) else np.nan,
                "dli_rank": int(rank_by_index[selected]) if np.isfinite(rank_by_index[selected]) else np.nan,
                "is_direct_hotspot_node": bool(direct_hotspot_flags[selected]),
                "marginal_hotspot_structural_reduction_tco2": float(marginal_hotspot),
                "cumulative_hotspot_structural_reduction_tco2": float(cumulative_hotspot),
                "cumulative_hotspot_structural_coverage": float(coverage),
                "marginal_company_structural_reduction_tco2": float(marginal_company),
                "cumulative_company_structural_reduction_tco2": float(cumulative_company),
                "cumulative_company_structural_coverage": float(cumulative_company / baseline_company) if baseline_company else 0.0,
                "hotspot_set_share_of_company_footprint": float(baseline_hotspot / baseline_company) if baseline_company else 0.0,
                "top_marginally_affected_hotspots": "; ".join(top_records),
                "selection_rule": "largest exact positive marginal hotspot reduction; DLI tie-break only",
                "claim_boundary": "joint complete-node-removal structural diagnostic; not expected or guaranteed realizable abatement",
            }
        )
        candidates.remove(selected)
        active = next_active
        inverse = next_inverse
        output = next_output
        if coverage + 1e-12 >= float(target_coverage):
            stop_reason = "target structural hotspot coverage reached"
            break

    frame = pd.DataFrame.from_records(records, columns=list(PORTFOLIO_COLUMNS))
    achieved = float(frame["cumulative_hotspot_structural_coverage"].iloc[-1]) if not frame.empty else 0.0
    achieved_company = float(frame["cumulative_company_structural_coverage"].iloc[-1]) if not frame.empty else 0.0
    return GreedyPortfolioResult(
        portfolio_type=portfolio_type,
        candidate_policy=candidate_policy,
        target_coverage=float(target_coverage),
        frame=frame,
        achieved_coverage=achieved,
        achieved_company_coverage=achieved_company,
        reached_target=bool(achieved + 1e-12 >= float(target_coverage)),
        stop_reason=stop_reason,
    )


def compute_hotspot_leverage(
    model: Any,
    demand: np.ndarray,
    linkage: CDRProducerLinkageResult,
    node_sda: pd.DataFrame,
    dli_ranking: pd.DataFrame,
    *,
    hotspot_threshold: float = 0.80,
    high_dli_quantile: float = 0.75,
    target_coverage: float = 0.80,
) -> HotspotLeverageResult:
    """Build hotspot-leverage evidence and overlap-aware structural portfolios."""
    if int(model.year) != int(linkage.year):
        raise ValueError("MRIO model and CDR linkage years differ")
    if not 0.0 < float(high_dli_quantile) < 1.0:
        raise ValueError("high_dli_quantile must lie in (0, 1)")
    if not 0.0 < float(target_coverage) <= 1.0:
        raise ValueError("target_coverage must lie in (0, 1]")

    node_codes = np.asarray(linkage.node_codes).astype(str)
    regions = np.asarray(linkage.regions).astype(str)
    sectors = np.asarray(linkage.sectors).astype(str)
    if not np.array_equal(node_codes, np.asarray(model.node_codes).astype(str)):
        raise ValueError("MRIO model and CDR linkage node orders differ")
    node_sda_frame = _validate_node_sda(node_sda, node_codes)
    ranking = _normalise_ranking(dli_ranking, int(model.year))
    if set(ranking["node_code"]) != set(node_codes):
        raise ValueError("DLI ranking and CDR linkage do not cover the same node universe")

    sda_lookup = node_sda_frame.set_index("node_code")
    hotspot_nodes = node_sda_frame.loc[
        node_sda_frame["in_comparison_top_80_hotspot_set"].astype(bool)
    ].sort_values(["comparison_hotspot_rank", "node_code"], kind="mergesort").reset_index(drop=True)
    if hotspot_nodes.empty:
        raise RuntimeError("The node-wise SDA comparison-year hotspot set is empty")
    hotspot_codes = hotspot_nodes["node_code"].astype(str).tolist()
    code_to_index = {str(code): index for index, code in enumerate(node_codes)}
    hotspot_indices = np.asarray([code_to_index[code] for code in hotspot_codes], dtype=int)
    comparison_values = pd.to_numeric(
        hotspot_nodes["comparison_footprint_contribution_tco2"], errors="raise"
    ).to_numpy(dtype=float)
    hotspot_total = float(comparison_values.sum())
    if not np.isclose(
        float(linkage.baseline_total_footprint),
        float(pd.to_numeric(node_sda_frame["comparison_footprint_contribution_tco2"], errors="raise").sum()),
        rtol=1e-9,
        atol=max(1e-8, abs(float(linkage.baseline_total_footprint)) * 1e-9),
    ):
        raise RuntimeError("CDR linkage and node-wise SDA comparison footprints do not reconcile")

    ranking_lookup = ranking.set_index("node_code")
    dli = np.asarray([float(ranking_lookup.loc[code, "DLI"]) for code in node_codes], dtype=float)
    dli_rank = np.asarray([int(ranking_lookup.loc[code, "dli_rank"]) for code in node_codes], dtype=float)
    high_dli_threshold = float(pd.Series(dli).quantile(float(high_dli_quantile)))
    high_dli = dli >= high_dli_threshold
    direct_hotspot = np.zeros(len(node_codes), dtype=bool)
    direct_hotspot[hotspot_indices] = True

    avoided_hotspots = np.asarray(linkage.avoided_producer_footprint, dtype=float)[:, hotspot_indices]
    signed_hsi = avoided_hotspots.sum(axis=1)
    positive_hsi = np.maximum(avoided_hotspots, 0.0).sum(axis=1)
    affected_count = (avoided_hotspots > max(abs(hotspot_total) * 1e-12, 1e-10)).sum(axis=1)
    top_links = [_top_links(node_codes[hotspot_indices], avoided_hotspots[index, :]) for index in range(len(node_codes))]

    node_summary = pd.DataFrame(
        {
            "year": int(model.year),
            "intervention_node": node_codes,
            "intervention_region": regions,
            "intervention_sector": sectors,
            "DLI": dli,
            "dli_rank": dli_rank.astype(int),
            "dli_level": np.where(high_dli, "High", "Below upper quartile"),
            "is_high_dli_upper_quartile": high_dli,
            "is_direct_hotspot_node": direct_hotspot,
            "hotspot_structural_influence_tco2": signed_hsi,
            "hotspot_structural_influence_fraction": _safe_divide(signed_hsi, hotspot_total),
            "positive_pairwise_hotspot_influence_tco2": positive_hsi,
            "affected_hotspot_count": affected_count,
            "top_structurally_linked_hotspots": top_links,
            "intervention_route": np.select(
                [direct_hotspot & high_dli, direct_hotspot, (~direct_hotspot) & high_dli],
                ["direct-and-systemic", "direct-hotspot", "governance-mediated-candidate"],
                default="not in primary diagnostic candidate sets",
            ),
        }
    ).sort_values(
        ["hotspot_structural_influence_tco2", "DLI", "intervention_node"],
        ascending=[False, False, True],
        kind="mergesort",
    ).reset_index(drop=True)
    node_summary.insert(0, "hsi_rank", np.arange(1, len(node_summary) + 1, dtype=int))

    pair_records: list[dict[str, Any]] = []
    for intervention_index, intervention_code in enumerate(node_codes):
        for hotspot_offset, producer_index in enumerate(hotspot_indices):
            producer_code = node_codes[producer_index]
            sda_row = sda_lookup.loc[producer_code]
            baseline = float(linkage.baseline_producer_footprint[producer_index])
            avoided = float(avoided_hotspots[intervention_index, hotspot_offset])
            pair_records.append(
                {
                    "year": int(model.year),
                    "intervention_node": str(intervention_code),
                    "intervention_region": str(regions[intervention_index]),
                    "intervention_sector": str(sectors[intervention_index]),
                    "intervention_DLI": float(dli[intervention_index]),
                    "intervention_dli_rank": int(dli_rank[intervention_index]),
                    "intervention_is_high_dli": bool(high_dli[intervention_index]),
                    "intervention_is_direct_hotspot": bool(direct_hotspot[intervention_index]),
                    "hotspot_producer_node": str(producer_code),
                    "hotspot_producer_region": str(regions[producer_index]),
                    "hotspot_producer_sector": str(sectors[producer_index]),
                    "hotspot_rank": int(sda_row["comparison_hotspot_rank"]),
                    "baseline_hotspot_footprint_tco2": baseline,
                    "baseline_company_footprint_tco2": float(linkage.baseline_total_footprint),
                    "hotspot_set_footprint_tco2": hotspot_total,
                    "hotspot_set_share_of_company_footprint": hotspot_total / float(linkage.baseline_total_footprint) if float(linkage.baseline_total_footprint) else 0.0,
                    "avoided_hotspot_footprint_tco2": avoided,
                    "hotspot_reduction_fraction": avoided / baseline if baseline else 0.0,
                    "share_of_top80_hotspot_footprint": avoided / hotspot_total if hotspot_total else 0.0,
                    "hotspot_node_change_tco2": float(sda_row["node_footprint_change_tco2"]),
                    "hotspot_intensity_effect_tco2": float(sda_row["node_delta_intensity"]),
                    "hotspot_technology_effect_tco2": float(sda_row["node_delta_technology"]),
                    "hotspot_composition_effect_tco2": float(sda_row["node_delta_composition"]),
                    "hotspot_scale_effect_tco2": float(sda_row["node_delta_scale"]),
                    "hotspot_dominant_driver": str(sda_row["node_dominant_driver"]),
                    "hotspot_dominant_driver_family": str(sda_row["node_dominant_driver_family"]),
                    "hotspot_primary_adverse_driver": str(sda_row.get("node_primary_adverse_driver", "")),
                    "hotspot_primary_adverse_effect_tco2": float(sda_row.get("node_primary_adverse_effect_tco2", 0.0)),
                    "hotspot_secondary_adverse_drivers": str(sda_row.get("node_secondary_adverse_drivers", "")),
                    "hotspot_total_adverse_effect_tco2": float(sda_row.get("node_total_adverse_effect_tco2", 0.0)),
                    "hotspot_adverse_driver_concentration": float(sda_row.get("node_adverse_driver_concentration", np.nan)),
                    "hotspot_primary_beneficial_driver": str(sda_row.get("node_primary_beneficial_driver", "")),
                    "hotspot_primary_beneficial_effect_tco2": float(sda_row.get("node_primary_beneficial_effect_tco2", 0.0)),
                    "hotspot_secondary_beneficial_drivers": str(sda_row.get("node_secondary_beneficial_drivers", "")),
                    "hotspot_total_beneficial_effect_tco2": float(sda_row.get("node_total_beneficial_effect_tco2", 0.0)),
                    "hotspot_driver_pattern": str(sda_row.get("node_driver_pattern", "")),
                    "hotspot_temporal_status": str(sda_row["node_temporal_status"]),
                    "claim_boundary": "producer-resolved complete-node-removal linkage; not a causal forecast of an intensity-only intervention",
                }
            )
    pair_evidence = pd.DataFrame.from_records(pair_records).sort_values(
        ["intervention_dli_rank", "hotspot_rank", "intervention_node", "hotspot_producer_node"],
        kind="mergesort",
    ).reset_index(drop=True)

    direct_candidates = np.flatnonzero(direct_hotspot)
    mediated_candidates = np.flatnonzero(high_dli & ~direct_hotspot)
    hybrid_candidates = np.flatnonzero(high_dli | direct_hotspot)
    common_portfolio_arguments = {
        "node_codes": node_codes,
        "regions": regions,
        "sectors": sectors,
        "leontief": np.asarray(model.L, dtype=float),
        "demand": np.asarray(demand, dtype=float),
        "intensity": np.asarray(model.fE, dtype=float),
        "hotspot_indices": hotspot_indices,
        "dli_by_index": dli,
        "rank_by_index": dli_rank,
        "direct_hotspot_flags": direct_hotspot,
        "target_coverage": float(target_coverage),
    }
    portfolios = {
        "direct": _portfolio_greedy(
            portfolio_type="direct_hotspot",
            candidate_policy="comparison-year top-80 producer hotspot nodes only",
            candidate_indices=direct_candidates,
            **common_portfolio_arguments,
        ),
        "governance_mediated": _portfolio_greedy(
            portfolio_type="governance_mediated",
            candidate_policy="upper-quartile DLI nodes that are not top-80 producer hotspots",
            candidate_indices=mediated_candidates,
            **common_portfolio_arguments,
        ),
        "hybrid": _portfolio_greedy(
            portfolio_type="hybrid",
            candidate_policy="union of top-80 producer hotspots and upper-quartile DLI nodes",
            candidate_indices=hybrid_candidates,
            **common_portfolio_arguments,
        ),
    }

    return HotspotLeverageResult(
        year=int(model.year),
        hotspot_threshold=float(hotspot_threshold),
        high_dli_threshold=high_dli_threshold,
        high_dli_quantile=float(high_dli_quantile),
        hotspot_total_footprint=hotspot_total,
        company_total_footprint=float(linkage.baseline_total_footprint),
        hotspot_nodes=hotspot_nodes,
        node_summary=node_summary,
        pair_evidence=pair_evidence,
        portfolios=portfolios,
    )


def _format_workbook(path: Path) -> None:
    from openpyxl import load_workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    workbook = load_workbook(path)
    fill = PatternFill("solid", fgColor="1F4E78")
    font = Font(color="FFFFFF", bold=True)
    for worksheet in workbook.worksheets:
        worksheet.freeze_panes = "A2"
        worksheet.sheet_view.showGridLines = False
        if worksheet.max_row:
            for cell in worksheet[1]:
                cell.fill = fill
                cell.font = font
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            worksheet.auto_filter.ref = worksheet.dimensions
        for index, cells in enumerate(worksheet.columns, start=1):
            width = 10
            for cell in list(cells)[:250]:
                text = "" if cell.value is None else str(cell.value)
                width = max(width, min(46, len(text) + 2))
                if cell.row > 1:
                    cell.alignment = Alignment(vertical="top", wrap_text=True)
            worksheet.column_dimensions[get_column_letter(index)].width = width
    workbook.save(path)


def write_hotspot_leverage_artifacts(
    output_dir: str | Path,
    result: HotspotLeverageResult,
    *,
    input_hashes: Mapping[str, str],
    critic_evidence_cid: str,
    cdr_linkage_evidence_cid: str,
    node_sda_evidence_cid: str,
    source_network_result_cid: str = "",
    hotspot_leverage_evidence_cid: str = "",
) -> dict[str, Any]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    paths = {
        "node_summary": output / NODE_SUMMARY_FILENAME,
        "pair_evidence": output / PAIR_EVIDENCE_FILENAME,
        "direct_portfolio": output / DIRECT_PORTFOLIO_FILENAME,
        "governance_mediated_portfolio": output / MEDIATED_PORTFOLIO_FILENAME,
        "hybrid_portfolio": output / HYBRID_PORTFOLIO_FILENAME,
        "workbook": output / WORKBOOK_FILENAME,
    }
    result.node_summary.to_csv(paths["node_summary"], index=False)
    result.pair_evidence.to_csv(paths["pair_evidence"], index=False)
    result.portfolios["direct"].frame.to_csv(paths["direct_portfolio"], index=False)
    result.portfolios["governance_mediated"].frame.to_csv(
        paths["governance_mediated_portfolio"], index=False
    )
    result.portfolios["hybrid"].frame.to_csv(paths["hybrid_portfolio"], index=False)

    summary_rows = []
    for name, portfolio in result.portfolios.items():
        summary_rows.append(
            {
                "portfolio": name,
                "candidate_policy": portfolio.candidate_policy,
                "selected_node_count": int(len(portfolio.frame)),
                "target_structural_coverage": portfolio.target_coverage,
                "achieved_hotspot_structural_coverage": portfolio.achieved_coverage,
                "achieved_company_structural_coverage": portfolio.achieved_company_coverage,
                "reached_target": portfolio.reached_target,
                "stop_reason": portfolio.stop_reason,
            }
        )
    notes = pd.DataFrame(
        [
            {
                "topic": "No new composite score",
                "statement": "DLI screens systemic leverage; HSI and exact marginal structural coverage provide carbon-relevance evidence. They are not combined into another weighted score.",
            },
            {
                "topic": "Overlap control",
                "statement": "Every portfolio step jointly recomputes the remaining MRIO principal system, so marginal coverage is not the sum of overlapping individual CDR values.",
            },
            {
                "topic": "Claim boundary",
                "statement": "Coverage is a complete-node-removal structural diagnostic. It is not expected, feasible or guaranteed real-world abatement. Actionability and realistic intervention magnitudes remain separate decisions.",
            },
            {
                "topic": "Direct versus mediated",
                "statement": "Direct portfolios target producer hotspots. Governance-mediated portfolios use high-DLI non-hotspot nodes only where their structural linkage to hotspots is material.",
            },
        ]
    )
    with pd.ExcelWriter(paths["workbook"], engine="openpyxl") as writer:
        pd.DataFrame(summary_rows).to_excel(writer, sheet_name="Portfolio_Summary", index=False)
        result.hotspot_nodes.to_excel(writer, sheet_name="Top80_Hotspots", index=False)
        result.node_summary.to_excel(writer, sheet_name="Leverage_Node_Summary", index=False)
        result.portfolios["direct"].frame.to_excel(writer, sheet_name="Direct_Portfolio", index=False)
        result.portfolios["governance_mediated"].frame.to_excel(
            writer, sheet_name="Mediated_Portfolio", index=False
        )
        result.portfolios["hybrid"].frame.to_excel(writer, sheet_name="Hybrid_Portfolio", index=False)
        result.pair_evidence.to_excel(writer, sheet_name="Hotspot_Linkage_Evidence", index=False)
        notes.to_excel(writer, sheet_name="Methodology_Notes", index=False)
    _format_workbook(paths["workbook"])

    artifacts: dict[str, Any] = {}
    for name, path in paths.items():
        record: dict[str, Any] = {"filename": path.name, "sha256": _sha256_file(path)}
        if path.suffix.lower() == ".csv":
            with path.open("r", encoding="utf-8") as handle:
                record["row_count"] = int(sum(1 for _ in handle) - 1)
        artifacts[name] = record

    metadata = {
        "extension_id": HOTSPOT_LEVERAGE_EXTENSION_ID,
        "year": result.year,
        "hotspot_threshold": result.hotspot_threshold,
        "hotspot_count": result.hotspot_count,
        "hotspot_total_footprint_tco2": result.hotspot_total_footprint,
        "company_total_footprint_tco2": result.company_total_footprint,
        "hotspot_share_of_company_footprint": (
            result.hotspot_total_footprint / result.company_total_footprint
            if result.company_total_footprint
            else 0.0
        ),
        "high_dli_quantile": result.high_dli_quantile,
        "high_dli_threshold": result.high_dli_threshold,
        "portfolio_target_hotspot_structural_coverage": next(iter(result.portfolios.values())).target_coverage,
        "portfolio_summaries": summary_rows,
        "method": "diagnostic route views using producer-resolved hotspot linkage and exact greedy joint structural-coverage recomputation; formal selection uses one consolidated governance funnel",
        "hsi_formula": "HSI_k = sum_{j in top80 hotspots} Delta C_{j|-k}",
        "selection_formula": "Delta R_H(k|S) = R_H(S union {k}) - R_H(S)",
        "selection_boundary": "greedy compact structural portfolio, not a claim of global optimality",
        "abatement_boundary": "complete-node-removal structural coverage, not predicted or guaranteed realizable abatement",
        "actionability_boundary": "focal-company contractual and operational controllability is assessed only in the consolidated governance funnel",
        "coverage_denominators": "every portfolio reports both coverage of the hotspot set and coverage of the complete company footprint",
        "portfolio_authority": "direct, mediated, and hybrid tables are diagnostic route views, not competing formal portfolios",
        "dli_boundary": "BC, PR, CDR, IC, pooled Pearson-CRITIC weights, DLI scores and ranks remain unchanged",
        "input_hashes": {str(key): str(value) for key, value in input_hashes.items()},
        "critic_evidence_cid": str(critic_evidence_cid),
        "cdr_linkage_evidence_cid": str(cdr_linkage_evidence_cid),
        "node_sda_evidence_cid": str(node_sda_evidence_cid),
        "source_network_result_cid": str(source_network_result_cid),
        "hotspot_leverage_evidence_cid": str(hotspot_leverage_evidence_cid),
        "generated_at_utc": _utc_now(),
        "artifacts": artifacts,
    }
    metadata_path = output / METADATA_FILENAME
    temporary = metadata_path.with_name(f".{metadata_path.name}.tmp")
    temporary.write_text(json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    temporary.replace(metadata_path)
    return metadata


def bind_hotspot_leverage_metadata(
    output_dir: str | Path,
    source_network_result_cid: str,
    hotspot_leverage_evidence_cid: str,
) -> dict[str, Any]:
    path = Path(output_dir) / METADATA_FILENAME
    metadata = json.loads(path.read_text(encoding="utf-8"))
    metadata["source_network_result_cid"] = str(source_network_result_cid)
    metadata["hotspot_leverage_evidence_cid"] = str(hotspot_leverage_evidence_cid)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    temporary.replace(path)
    return metadata


def verify_hotspot_leverage_artifacts(
    output_dir: str | Path,
    *,
    expected_input_hashes: Mapping[str, str] | None = None,
) -> dict[str, Any]:
    output = Path(output_dir)
    path = output / METADATA_FILENAME
    if not path.is_file():
        raise FileNotFoundError("Hotspot-leverage evidence is unavailable. Complete node-wise SDA, SPA and pooled Network/DLI first.")
    metadata = json.loads(path.read_text(encoding="utf-8"))
    if metadata.get("extension_id") != HOTSPOT_LEVERAGE_EXTENSION_ID:
        raise RuntimeError("Hotspot-leverage metadata has an unexpected extension identity")
    if expected_input_hashes is not None and metadata.get("input_hashes") != {
        str(key): str(value) for key, value in expected_input_hashes.items()
    }:
        raise RuntimeError("Hotspot-leverage evidence is stale for the active input workbooks")
    for name, record in metadata.get("artifacts", {}).items():
        filename = str(record.get("filename", ""))
        if not filename or Path(filename).name != filename:
            raise RuntimeError(f"Unsafe hotspot-leverage filename for {name}")
        artifact = output / filename
        if not artifact.is_file():
            raise FileNotFoundError(f"Hotspot-leverage artifact is missing: {filename}")
        if _sha256_file(artifact) != str(record.get("sha256", "")):
            raise RuntimeError(f"Hotspot-leverage artifact failed SHA-256 verification: {filename}")
        if artifact.suffix.lower() == ".csv" and "row_count" in record:
            with artifact.open("r", encoding="utf-8") as handle:
                row_count = int(sum(1 for _ in handle) - 1)
            if row_count != int(record["row_count"]):
                raise RuntimeError(f"Hotspot-leverage artifact row count is invalid: {filename}")
    return metadata


__all__ = (
    "HOTSPOT_LEVERAGE_EXTENSION_ID",
    "GreedyPortfolioResult",
    "HotspotLeverageResult",
    "compute_hotspot_leverage",
    "write_hotspot_leverage_artifacts",
    "bind_hotspot_leverage_metadata",
    "verify_hotspot_leverage_artifacts",
    "NODE_SUMMARY_FILENAME",
    "PAIR_EVIDENCE_FILENAME",
    "DIRECT_PORTFOLIO_FILENAME",
    "MEDIATED_PORTFOLIO_FILENAME",
    "HYBRID_PORTFOLIO_FILENAME",
    "WORKBOOK_FILENAME",
    "METADATA_FILENAME",
    "PORTFOLIO_COLUMNS",
)
