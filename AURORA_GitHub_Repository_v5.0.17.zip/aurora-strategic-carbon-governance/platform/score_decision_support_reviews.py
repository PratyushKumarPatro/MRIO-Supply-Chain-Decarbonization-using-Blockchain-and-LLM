"""Aggregate independent expert reviews of DLI-based decision-support outputs."""
from __future__ import annotations

import argparse
import csv
import hashlib
import json
import statistics
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any


SCORE_FIELDS = (
    "strategic_relevance_1_to_5",
    "interpretability_1_to_5",
    "governance_actionability_1_to_5",
    "claim_boundary_clarity_1_to_5",
)
KEY_FIELDS = ("case_id", "artifact_type", "artifact_reference", "decision_year", "node_code")


def _review_identity(row: dict[str, Any]) -> tuple[str, ...]:
    """Return the one-reviewer/one-decision-case identity used for deduplication."""
    return tuple(str(row[field]).strip() for field in ("reviewer_id", *KEY_FIELDS))


def _assert_unique_reviewer_case_rows(rows: list[dict[str, Any]]) -> None:
    """Reject duplicate assessments before they can be silently overwritten in pairing."""
    seen: dict[tuple[str, ...], int] = {}
    for position, row in enumerate(rows, start=1):
        identity = _review_identity(row)
        source_position = int(row.get("_source_row", position))
        previous = seen.get(identity)
        if previous is not None:
            reviewer_id, case_id, artifact_type, artifact_reference, decision_year, node_code = identity
            raise ValueError(
                "Duplicate review for the same reviewer and decision case: "
                f"reviewer_id={reviewer_id!r}, case_id={case_id!r}, "
                f"artifact_type={artifact_type!r}, artifact_reference={artifact_reference!r}, decision_year={decision_year!r}, "
                f"node_code={node_code!r} (rows {previous} and {source_position}). "
                "Each reviewer may submit only one assessment per decision case."
            )
        seen[identity] = source_position


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _utc_from_timestamp(timestamp: float) -> str:
    return datetime.fromtimestamp(timestamp, timezone.utc).isoformat().replace("+00:00", "Z")


def _provenance_for_source(path: Path) -> dict[str, Any]:
    source = path.resolve()
    source_stat = source.stat()
    scorer = Path(__file__).resolve()
    return {
        "source_csv": str(source),
        "source_csv_sha256": _sha256_file(source),
        "source_csv_size_bytes": source_stat.st_size,
        "source_csv_modified_at_utc": _utc_from_timestamp(source_stat.st_mtime),
        "summary_generated_at_utc": datetime.now(timezone.utc).isoformat().replace("+00:00", "Z"),
        "scorer_script": scorer.name,
        "scorer_script_sha256": _sha256_file(scorer),
    }


def _assert_output_is_safe(source: Path, output: Path) -> None:
    """Protect the review evidence and any existing non-empty audit summary."""
    resolved_source = source.resolve()
    resolved_output = output.resolve()
    if resolved_output == resolved_source:
        raise ValueError("The output path must differ from the source review CSV.")
    if resolved_output.exists():
        if resolved_output.is_dir():
            raise ValueError(f"Output path is a directory: {resolved_output}")
        if resolved_output.stat().st_size > 0:
            raise FileExistsError(
                f"Refusing to overwrite non-empty audit summary: {resolved_output}. "
                "Choose a new --output path or archive the existing summary first."
            )


def _binary(value: str, field: str, row: int) -> int:
    text = str(value or "").strip().casefold()
    if text in {"yes", "y", "true", "1", "aligned"}:
        return 1
    if text in {"no", "n", "false", "0", "misaligned"}:
        return 0
    raise ValueError(f"Row {row}: {field} must be yes/no.")


def _score(value: str, field: str, row: int) -> float:
    try:
        parsed = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Row {row}: {field} must be a number from 1 to 5.") from exc
    if not 1.0 <= parsed <= 5.0:
        raise ValueError(f"Row {row}: {field} must be between 1 and 5.")
    return parsed


def load_reviews(path: Path) -> list[dict[str, Any]]:
    with Path(path).open(newline="", encoding="utf-8") as handle:
        reader = csv.DictReader(handle)
        required = {"reviewer_id", "priority_alignment_yes_no", *KEY_FIELDS, *SCORE_FIELDS}
        missing = required.difference(reader.fieldnames or [])
        if missing:
            raise ValueError(f"Review CSV is missing columns: {sorted(missing)}")
        rows: list[dict[str, Any]] = []
        for number, row in enumerate(reader, start=2):
            if not any(str(value or "").strip() for value in row.values()):
                continue
            if not all(str(row.get(field, "")).strip() for field in ("reviewer_id", *KEY_FIELDS)):
                raise ValueError(f"Row {number}: reviewer_id and all decision case fields are required.")
            parsed = {field: _score(row.get(field, ""), field, number) for field in SCORE_FIELDS}
            parsed.update({field: str(row[field]).strip() for field in ("reviewer_id", *KEY_FIELDS)})
            parsed["priority_aligned"] = _binary(row.get("priority_alignment_yes_no", ""), "priority_alignment_yes_no", number)
            parsed["_source_row"] = number
            rows.append(parsed)
    if not rows:
        raise ValueError("No completed expert-review rows were found.")
    _assert_unique_reviewer_case_rows(rows)
    return rows


def _cohens_kappa(pairs: list[tuple[int, int]]) -> tuple[float | None, str]:
    if not pairs:
        return None, "not_estimable_no_two_reviewer_pairs"
    observed = sum(left == right for left, right in pairs) / len(pairs)
    left_rate = {value: sum(left == value for left, _ in pairs) / len(pairs) for value in (0, 1)}
    right_rate = {value: sum(right == value for _, right in pairs) / len(pairs) for value in (0, 1)}
    expected = sum(left_rate[value] * right_rate[value] for value in (0, 1))
    if abs(1.0 - expected) <= 1e-12:
        return None, "not_estimable_constant_marginals"
    return round((observed - expected) / (1.0 - expected), 6), "estimated"


def score_reviews(rows: list[dict[str, Any]]) -> dict[str, Any]:
    _assert_unique_reviewer_case_rows(rows)
    output: dict[str, Any] = {"review_count": len(rows), "metrics": {}, "agreement": {}}
    for field in SCORE_FIELDS:
        values = [float(row[field]) for row in rows]
        output["metrics"][field] = {
            "mean": round(statistics.mean(values), 6),
            "n": len(values),
            "proportion_at_least_4": round(sum(value >= 4.0 for value in values) / len(values), 6),
        }
    aligned = [int(row["priority_aligned"]) for row in rows]
    output["metrics"]["priority_alignment"] = {
        "proportion_aligned": round(sum(aligned) / len(aligned), 6),
        "n": len(aligned),
    }
    grouped: dict[tuple[str, ...], list[dict[str, Any]]] = defaultdict(list)
    for row in rows:
        grouped[tuple(row[field] for field in KEY_FIELDS)].append(row)
    pairs: list[tuple[int, int]] = []
    for group in grouped.values():
        by_reviewer = {str(row["reviewer_id"]): row for row in group}
        if len(by_reviewer) != 2:
            continue
        first, second = sorted(by_reviewer)
        pairs.append((int(by_reviewer[first]["priority_aligned"]), int(by_reviewer[second]["priority_aligned"])))
    kappa, kappa_status = _cohens_kappa(pairs)
    output["agreement"] = {
        "paired_case_count": len(pairs),
        "cohens_kappa_priority_alignment": kappa,
        "cohens_kappa_status": kappa_status,
        "note": (
            "Kappa is calculated only when exactly two reviewers independently score the same decision case. "
            "It is null when no such pairs exist or when constant marginals make chance-corrected kappa non-estimable."
        ),
    }
    return output


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="Aggregate independent expert reviews of decision-support artefacts.")
    parser.add_argument("reviews", type=Path, help="Completed decision_support_expert_review_template.csv.")
    parser.add_argument("--output", type=Path, default=None, help="Output JSON path; defaults beside the review CSV.")
    args = parser.parse_args(argv)
    source = args.reviews.resolve()
    output = args.output or source.with_name("decision_support_expert_review_summary.json")
    _assert_output_is_safe(source, output)
    result = score_reviews(load_reviews(source))
    result["provenance"] = _provenance_for_source(source)
    output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(f"Decision-support expert-review summary written to {output}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
