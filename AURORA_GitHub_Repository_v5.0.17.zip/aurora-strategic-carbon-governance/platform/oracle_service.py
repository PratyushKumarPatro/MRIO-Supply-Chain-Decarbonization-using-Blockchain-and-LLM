"""Four specialized blockchain oracle adapters.

Each role uses a distinct Ganache address and a distinct process:

* registration -> RegistrationOracle
* upstream     -> UpstreamAnalyticsOracle
* governance   -> GovernanceOracle (network/DLI, AURORA and intervention workflow)
* query        -> QueryOracle

The adapters never calculate analytical results. They observe request events,
call the off-chain Data Orchestrator over HTTP, and submit role-authorized
fulfillment transactions to the originating contract.
"""
from __future__ import annotations

import argparse
import json
import os
import time
import traceback
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

from web3 import Web3

from orchestrator_client import OrchestratorClient
from transaction_inspector import safe_record_transaction

BASE_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = BASE_DIR / "runtime"
ACTIVITY_LOG = RUNTIME_DIR / "oracle_activity.jsonl"

ROLE_CONFIG = {
    "registration": {
        "account_key": "registration_oracle",
        "role_code": 4,
        "role_name": "RegistrationOracle",
    },
    "upstream": {
        "account_key": "upstream_oracle",
        "role_code": 5,
        "role_name": "UpstreamAnalyticsOracle",
    },
    "governance": {
        "account_key": "governance_oracle",
        "role_code": 6,
        "role_name": "GovernanceOracle",
    },
    "query": {
        "account_key": "query_oracle",
        "role_code": 7,
        "role_name": "QueryOracle",
    },
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _json_default(value: Any) -> str:
    if isinstance(value, bytes):
        return "0x" + value.hex()
    return str(value)


def append_activity(payload: dict[str, Any]) -> None:
    RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
    with ACTIVITY_LOG.open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(payload, default=_json_default, ensure_ascii=False) + "\n")


class OracleAdapter:
    def __init__(
        self,
        role: str,
        deployment_path: str | Path,
        orchestrator_url: str,
    ):
        if role not in ROLE_CONFIG:
            raise ValueError(f"Unknown oracle role: {role}")
        self.role = role
        self.config = ROLE_CONFIG[role]
        self.deployment_path = Path(deployment_path)
        self.deployment = json.loads(self.deployment_path.read_text(encoding="utf-8"))
        self.w3 = Web3(
            Web3.HTTPProvider(
                self.deployment["rpc_url"],
                request_kwargs={"timeout": 30},
            )
        )
        if not self.w3.is_connected():
            raise RuntimeError(f"Cannot connect to chain at {self.deployment['rpc_url']}")
        self.address = self.deployment["accounts"][self.config["account_key"]]
        self.client = OrchestratorClient(orchestrator_url)
        self.contracts = {
            name: self.w3.eth.contract(address=item["address"], abi=item["abi"])
            for name, item in self.deployment["contracts"].items()
        }
        self.registration = self.contracts["Registration"]
        onchain_role = int(self.registration.functions.roleOf(self.address).call())
        active_oracle = self.registration.functions.oracleForRole(
            int(self.config["role_code"])
        ).call()
        if onchain_role != int(self.config["role_code"]) or active_oracle.lower() != self.address.lower():
            raise RuntimeError(
                f"{self.address} is not the active {self.config['role_name']} "
                f"(role={onchain_role}, active={active_oracle})"
            )
        self.state_path = RUNTIME_DIR / f"oracle_{role}_state.json"
        self.heartbeat_path = RUNTIME_DIR / f"oracle_{role}_heartbeat.json"
        self.state = self._load_state()
        self.handled_total = int(self.state.get("handled_total", 0))

    def _deployment_fingerprint(self) -> str:
        return "|".join(
            [
                str(self.w3.eth.chain_id),
                *[
                    self.deployment["contracts"][name]["address"].lower()
                    for name in sorted(self.deployment["contracts"])
                ],
            ]
        )

    def _load_state(self) -> dict[str, Any]:
        RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        fingerprint = self._deployment_fingerprint()
        if self.state_path.exists():
            try:
                state = json.loads(self.state_path.read_text(encoding="utf-8"))
                if state.get("deployment_fingerprint") == fingerprint:
                    return state
            except Exception:
                pass
        return {
            "deployment_fingerprint": fingerprint,
            "next_block": int(self.deployment.get("deployment_block", 0)),
            "handled_total": 0,
        }

    def _save_state(self) -> None:
        self.state["handled_total"] = self.handled_total
        self.state_path.write_text(json.dumps(self.state, indent=2), encoding="utf-8")

    def _heartbeat(self, status: str = "running", error: str = "") -> None:
        payload = {
            "oracle_role": self.role,
            "onchain_role_name": self.config["role_name"],
            "onchain_role_code": self.config["role_code"],
            "address": self.address,
            "status": status,
            "error": error,
            "chain_id": self.w3.eth.chain_id,
            "latest_block": self.w3.eth.block_number,
            "next_block": self.state.get("next_block"),
            "handled_total": self.handled_total,
            "orchestrator_url": self.client.base_url,
            "deployment_path": str(self.deployment_path.resolve()),
            "package_root": str(BASE_DIR.resolve()),
            "deployment_fingerprint": self._deployment_fingerprint(),
            "updated_at_utc": utc_now(),
            "pid": os.getpid(),
        }
        self.heartbeat_path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

    def _transact(
        self,
        function,
        action: str,
        request_id: int,
        metadata: dict[str, Any] | None = None,
    ) -> str:
        tx_hash = function.transact({"from": self.address})
        receipt = self.w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
        tx_hex = receipt.transactionHash.hex()
        audit = safe_record_transaction(
            self.w3,
            self.deployment_path,
            receipt.transactionHash,
            receipt=receipt,
            actor_label=self.config["role_name"],
            action=action,
            source="oracle-service",
            request_id=request_id,
            metadata={
                "oracle_adapter": self.role,
                "oracle_role": self.config["role_name"],
                "oracle_address": self.address,
                **(metadata or {}),
            },
        )
        append_activity(
            {
                "time_utc": utc_now(),
                "oracle_role": self.role,
                "oracle_address": self.address,
                "action": action,
                "request_id": request_id,
                "transaction_hash": tx_hex,
                "block_hash": audit.get("block_hash", ""),
                "block_number": receipt.blockNumber,
                "gas_used": audit.get("gas_used", int(receipt.gasUsed)),
                "transaction_fee_wei": audit.get("transaction_fee_wei"),
            }
        )
        return tx_hex

    def _orchestrator_error_hash(
        self,
        operation: str,
        exc: Exception,
        context: dict[str, Any],
        request_context: dict[str, Any] | None = None,
    ) -> str | None:
        try:
            result = self.client.post(
                "/v1/error",
                {
                    "operation": operation,
                    "error": str(exc),
                    "context": context,
                    "request_context": request_context or {},
                },
            )
            return str(result["content_hash"])
        except Exception:
            return None

    def _events(self, contract_name: str, event_name: str, start: int, latest: int):
        contract = self.contracts[contract_name]
        event = getattr(contract.events, event_name)()
        return event.get_logs(fromBlock=start, toBlock=latest)

    def _request_context(
        self,
        event: Any,
        contract_name: str,
        request_id: int,
    ) -> dict[str, Any]:
        tx_hash = event.get("transactionHash")
        if hasattr(tx_hash, "hex"):
            tx_hash = tx_hash.hex()
        return {
            "architecture_version": self.deployment.get("architecture_version", ""),
            "chain_id": int(self.w3.eth.chain_id),
            "contract_name": contract_name,
            "contract_address": self.deployment["contracts"][contract_name]["address"],
            "event_name": str(event.get("event", "")),
            "request_id": int(request_id),
            "request_block": int(event.get("blockNumber", 0)),
            "request_log_index": int(event.get("logIndex", 0)),
            "request_transaction_hash": str(tx_hash or ""),
            "oracle_adapter": self.role,
            "oracle_role": self.config["role_name"],
            "oracle_address": self.address,
        }

    def _handle_registration(self, event) -> None:
        request_id = int(event["args"]["requestId"])
        stored = self.registration.functions.getRegistrationRequest(request_id).call()
        if int(stored[3]) != 0:
            return
        request_context = self._request_context(event, "Registration", request_id)
        result = self.client.post(
            "/v1/registration/verify",
            {
                "requester": event["args"]["requester"],
                "requested_role": int(event["args"]["requestedRole"]),
                "evidence_cid": event["args"]["evidenceCID"],
                "request_context": request_context,
            },
        )
        approved = bool(result["payload"]["approved"])
        self._transact(
            self.registration.functions.fulfillRegistration(
                request_id,
                approved,
                result["content_hash"],
            ),
            "fulfillRegistration",
            request_id,
        )
        print(
            f"[registration-oracle] request={request_id} approved={approved} "
            f"hash={result['content_hash'][:16]}..."
        )

    def _handle_data_update(self, event, kind: str) -> None:
        contract = self.contracts["UpstreamCarbonEmissionsAnalysis"]
        request_id = int(event["args"]["requestId"])
        stored = contract.functions.getDataUpdateRequest(request_id).call()
        status = int(stored[4])
        if status in {2, 3}:  # rejected or failed
            return
        request_context = self._request_context(
            event, "UpstreamCarbonEmissionsAnalysis", request_id
        )
        accepted = status == 1
        validation_result: dict[str, Any] | None = None
        if status == 0:
            validation_result = self.client.post(
                "/v1/upstream/data-validate",
                {
                    "kind": kind,
                    "data_hash": event["args"]["dataHash"],
                    "requester": event["args"]["requester"],
                    "request_context": request_context,
                },
            )
            accepted = bool(validation_result["payload"]["accepted"])
            self._transact(
                contract.functions.fulfillDataUpdate(
                    request_id,
                    accepted,
                    validation_result["content_hash"],
                ),
                "fulfillDataUpdate",
                request_id,
            )

        # Promotion is deliberately a separate post-fulfilment step.  The
        # workbook remains staged until the accepted decision is on-chain.
        promotion_hash = ""
        if accepted:
            promoted = self.client.post(
                "/v1/upstream/data-promote",
                {
                    "kind": kind,
                    "data_hash": event["args"]["dataHash"],
                    "requester": event["args"]["requester"],
                    "request_context": {
                        **request_context,
                        "promotion_after_fulfillment": True,
                    },
                },
            )
            promotion_hash = str(promoted["content_hash"])
        validation_hash = (
            str(validation_result["content_hash"])
            if validation_result is not None
            else str(stored[3])
        )
        print(
            f"[upstream-oracle] data request={request_id} kind={kind} "
            f"accepted={accepted} validation={validation_hash[:16]}... "
            f"promotion={promotion_hash[:16] if promotion_hash else 'none'}..."
        )

    def _handle_compute(self, event, endpoint: str, payload: dict[str, Any]) -> None:
        contract = self.contracts["UpstreamCarbonEmissionsAnalysis"]
        request_id = int(event["args"]["requestId"])
        stored = contract.functions.getComputeRequest(request_id).call()
        if int(stored[7]) != 0:
            return
        request_context = self._request_context(
            event, "UpstreamCarbonEmissionsAnalysis", request_id
        )
        request_payload = {**payload, "request_context": request_context}
        try:
            result = self.client.post(endpoint, request_payload)
            self._transact(
                contract.functions.fulfillCompute(request_id, result["content_hash"]),
                "fulfillCompute",
                request_id,
            )
            print(
                f"[upstream-oracle] compute request={request_id} endpoint={endpoint} "
                f"hash={result['content_hash'][:16]}..."
            )
        except Exception as exc:
            error_hash = self._orchestrator_error_hash(
                endpoint, exc, payload, request_context=request_context
            )
            if error_hash:
                self._transact(
                    contract.functions.failCompute(request_id, error_hash),
                    "failCompute",
                    request_id,
                )
                print(f"[upstream-oracle] request={request_id} failed: {exc}")
                return
            raise

    def _handle_network(self, event) -> None:
        contract = self.contracts["HotspotsManagementAndGovernance"]
        request_id = int(event["args"]["requestId"])
        stored = contract.functions.getNetworkRequest(request_id).call()
        status = int(stored[3])
        if status != 0:
            return

        request_context = self._request_context(
            event, "HotspotsManagementAndGovernance", request_id
        )
        payload = {
            "year": int(event["args"]["year"]),
            "request_context": request_context,
        }
        try:
            result = self.client.post("/v1/governance/network", payload)
            self._transact(
                contract.functions.fulfillNetworkAnalysis(
                    request_id,
                    result["content_hash"],
                ),
                "fulfillNetworkAnalysis",
                request_id,
                metadata={
                    "request_scope": "network",
                    "analysis_year": int(event["args"]["year"]),
                    "result_cid": result["content_hash"],
                    "intervention_portfolio_requires_stakeholder_selection": (
                        int(event["args"]["year"]) == 2017
                    ),
                },
            )
            print(
                f"[governance-oracle] network request={request_id} "
                f"year={int(event['args']['year'])} hash={result['content_hash'][:16]}...; "
                "no intervention is proposed until a stakeholder selects an option"
            )
        except Exception as exc:
            error_hash = self._orchestrator_error_hash(
                "network_analysis",
                exc,
                {"year": int(event["args"]["year"]), "request_id": request_id},
                request_context=request_context,
            )
            if error_hash:
                self._transact(
                    contract.functions.failNetworkAnalysis(request_id, error_hash),
                    "failNetworkAnalysis",
                    request_id,
                    metadata={"request_scope": "network", "error_cid": error_hash},
                )
                return
            raise

    def _handle_intervention_proposal(self, event) -> None:
        contract = self.contracts["HotspotsManagementAndGovernance"]
        request_id = int(event["args"]["requestId"])
        stored = contract.functions.getInterventionProposalRequest(request_id).call()
        status = int(stored[8])
        if status != 0:
            return

        request_context = self._request_context(
            event, "HotspotsManagementAndGovernance", request_id
        )
        payload = {
            "network_request_id": int(event["args"]["networkRequestId"]),
            "network_result_hash": str(event["args"]["networkResultHash"]),
            "node_code": str(event["args"]["nodeCode"]),
            "option_cid": str(event["args"]["optionCID"]),
            "requester": str(event["args"]["requester"]),
            "request_context": request_context,
        }
        try:
            result = self.client.post(
                "/v1/governance/intervention-proposal",
                payload,
            )
            auxiliary = result.get("auxiliary", {}) or {}
            required = [
                "dli_score_bps",
                "evidence_cid",
                "category",
                "action_cid",
            ]
            missing = [key for key in required if key not in auxiliary]
            if missing:
                raise RuntimeError(
                    "Intervention verification response is missing: " + ", ".join(missing)
                )
            self._transact(
                contract.functions.fulfillInterventionProposal(
                    request_id,
                    int(auxiliary["dli_score_bps"]),
                    str(auxiliary["evidence_cid"]),
                    str(auxiliary["category"]),
                    str(auxiliary["action_cid"]),
                    str(result["content_hash"]),
                ),
                "fulfillInterventionProposal",
                request_id,
                metadata={
                    "request_scope": "intervention_proposal",
                    "network_request_id": int(event["args"]["networkRequestId"]),
                    "node_code": str(event["args"]["nodeCode"]),
                    "option_cid": str(event["args"]["optionCID"]),
                    "verification_cid": str(result["content_hash"]),
                },
            )
            print(
                f"[governance-oracle] intervention selection request={request_id} "
                f"node={event['args']['nodeCode']} verified and proposed"
            )
        except Exception as exc:
            error_hash = self._orchestrator_error_hash(
                "intervention_proposal_verification",
                exc,
                payload,
                request_context=request_context,
            )
            if error_hash:
                self._transact(
                    contract.functions.failInterventionProposal(request_id, error_hash),
                    "failInterventionProposal",
                    request_id,
                    metadata={
                        "request_scope": "intervention_proposal",
                        "node_code": str(event["args"]["nodeCode"]),
                        "error_cid": error_hash,
                    },
                )
                print(
                    f"[governance-oracle] intervention selection request={request_id} failed: {exc}"
                )
                return
            raise

    def _handle_sourcing_opportunity(self, event) -> None:
        contract = self.contracts["HotspotsManagementAndGovernance"]
        request_id = int(event["args"]["requestId"])
        stored = contract.functions.getSourcingOpportunityRequest(request_id).call()
        status = int(stored[5])
        if status != 0:
            return

        request_context = self._request_context(
            event, "HotspotsManagementAndGovernance", request_id
        )
        payload = {
            "year": int(event["args"]["year"]),
            "network_request_id": int(event["args"]["networkRequestId"]),
            "network_result_hash": str(event["args"]["networkResultHash"]),
            "request_context": request_context,
        }
        try:
            result = self.client.post(
                "/v1/governance/sourcing-opportunities",
                payload,
            )
            self._transact(
                contract.functions.fulfillRegionalSourcingOpportunityAnalysis(
                    request_id,
                    result["content_hash"],
                ),
                "fulfillRegionalSourcingOpportunityAnalysis",
                request_id,
                metadata={"request_scope": "aurora", "result_cid": result["content_hash"]},
            )
            print(
                f"[governance-oracle] AURORA request={request_id} "
                f"hash={result['content_hash'][:16]}..."
            )
        except Exception as exc:
            error_hash = self._orchestrator_error_hash(
                "regional_sourcing_opportunity_analysis",
                exc,
                payload,
                request_context=request_context,
            )
            if error_hash:
                self._transact(
                    contract.functions.failRegionalSourcingOpportunityAnalysis(
                        request_id,
                        error_hash,
                    ),
                    "failRegionalSourcingOpportunityAnalysis",
                    request_id,
                    metadata={"request_scope": "aurora", "error_cid": error_hash},
                )
                print(
                    f"[governance-oracle] AURORA request={request_id} failed: {exc}"
                )
                return
            raise

    def _handle_query(self, event) -> None:
        contract = self.contracts["QueryManagement"]
        request_id = int(event["args"]["requestId"])
        stored = contract.functions.getQuery(request_id).call()
        if int(stored[5]) != 0:
            return
        mode_by_code = {0: "auto", 1: "research", 2: "general"}
        mode_code = int(event["args"]["assistantMode"])
        if mode_code not in mode_by_code:
            raise ValueError(f"Unsupported assistant mode code: {mode_code}")
        request_context = self._request_context(event, "QueryManagement", request_id)
        payload = {
            "requester": event["args"]["requester"],
            "query_text": event["args"]["queryText"],
            "data_reference_cid": event["args"]["dataReferenceCID"],
            "mode": mode_by_code[mode_code],
            "assistant_mode_code": mode_code,
            "request_context": request_context,
        }
        try:
            result = self.client.post("/v1/query", payload)
            route_enum = int(result["auxiliary"]["route_enum"])
            self._transact(
                contract.functions.fulfillQuery(
                    request_id,
                    route_enum,
                    result["content_hash"],
                ),
                "fulfillQuery",
                request_id,
            )
            print(
                f"[query-oracle] request={request_id} route={route_enum} "
                f"hash={result['content_hash'][:16]}..."
            )
        except Exception as exc:
            error_hash = self._orchestrator_error_hash(
                "strategic_query",
                exc,
                payload,
                request_context=request_context,
            )
            if error_hash:
                self._transact(
                    contract.functions.failQuery(request_id, error_hash),
                    "failQuery",
                    request_id,
                )
                print(f"[query-oracle] request={request_id} failed: {exc}")
                return
            raise

    def poll_once(self) -> int:
        start = int(self.state.get("next_block", 0))
        latest = int(self.w3.eth.block_number)
        if start > latest:
            self._heartbeat()
            return 0

        handlers: list[tuple[str, str, Callable[[Any], None]]] = []
        if self.role == "registration":
            handlers = [
                ("Registration", "RegistrationRequested", self._handle_registration),
            ]
        elif self.role == "upstream":
            handlers = [
                (
                    "UpstreamCarbonEmissionsAnalysis",
                    "MRIODataUpdateRequested",
                    lambda ev: self._handle_data_update(ev, "MRIOData"),
                ),
                (
                    "UpstreamCarbonEmissionsAnalysis",
                    "FocalCompanyDemandDataUpdateRequested",
                    lambda ev: self._handle_data_update(ev, "FocalDemandData"),
                ),
                (
                    "UpstreamCarbonEmissionsAnalysis",
                    "MRIOCarbonAccountingRequested",
                    lambda ev: self._handle_compute(
                        ev,
                        "/v1/upstream/mrio",
                        {"year": int(ev["args"]["year"])},
                    ),
                ),
                (
                    "UpstreamCarbonEmissionsAnalysis",
                    "StructuralPathAnalysisRequested",
                    lambda ev: self._handle_compute(
                        ev,
                        "/v1/upstream/spa",
                        {"year": int(ev["args"]["year"])},
                    ),
                ),
                (
                    "UpstreamCarbonEmissionsAnalysis",
                    "StructuralDecompositionAnalysisRequested",
                    lambda ev: self._handle_compute(
                        ev,
                        "/v1/upstream/sda",
                        {
                            "base_year": int(ev["args"]["baseYear"]),
                            "comparison_year": int(ev["args"]["comparisonYear"]),
                        },
                    ),
                ),
            ]
        elif self.role == "governance":
            handlers = [
                ("HotspotsManagementAndGovernance", "NetworkAnalysisRequested", self._handle_network),
                (
                    "HotspotsManagementAndGovernance",
                    "InterventionProposalRequested",
                    self._handle_intervention_proposal,
                ),
                (
                    "HotspotsManagementAndGovernance",
                    "RegionalSourcingOpportunityAnalysisRequested",
                    self._handle_sourcing_opportunity,
                ),
            ]
        elif self.role == "query":
            handlers = [
                ("QueryManagement", "QueryRequested", self._handle_query),
            ]

        collected: list[tuple[int, int, Callable[[Any], None], Any]] = []
        for contract_name, event_name, handler in handlers:
            for event in self._events(contract_name, event_name, start, latest):
                collected.append(
                    (
                        int(event["blockNumber"]),
                        int(event["logIndex"]),
                        handler,
                        event,
                    )
                )
        collected.sort(key=lambda item: (item[0], item[1]))

        handled = 0
        for _, _, handler, event in collected:
            handler(event)
            handled += 1
        self.handled_total += handled
        self.state["next_block"] = latest + 1
        self._save_state()
        self._heartbeat()
        return handled

    def run_forever(self, poll_interval: float) -> None:
        health = self.client.health()
        print(
            f"[{self.role}-oracle] address={self.address} role={self.config['role_name']} "
            f"chain={self.w3.eth.chain_id} orchestrator={health.get('service')}"
        )
        self._heartbeat()
        while True:
            try:
                handled = self.poll_once()
                if handled:
                    print(f"[{self.role}-oracle] handled {handled} event(s)")
                time.sleep(poll_interval)
            except KeyboardInterrupt:
                self._heartbeat(status="stopped")
                return
            except Exception as exc:
                traceback.print_exc()
                self._heartbeat(status="error", error=str(exc))
                time.sleep(max(2.0, poll_interval))


def main() -> None:
    parser = argparse.ArgumentParser(description="Run one specialized blockchain oracle adapter")
    parser.add_argument("--role", required=True, choices=sorted(ROLE_CONFIG))
    parser.add_argument("--deployment", default=str(BASE_DIR / "deployment.json"))
    parser.add_argument(
        "--orchestrator-url",
        default=os.getenv("ORCHESTRATOR_URL", "http://127.0.0.1:8765"),
    )
    parser.add_argument(
        "--poll-interval",
        type=float,
        default=float(os.getenv("ORACLE_POLL_INTERVAL", "1.0")),
    )
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()

    adapter = OracleAdapter(args.role, args.deployment, args.orchestrator_url)
    if args.once:
        count = adapter.poll_once()
        print(f"[{args.role}-oracle] handled {count} event(s)")
    else:
        adapter.run_forever(args.poll_interval)


if __name__ == "__main__":
    main()
