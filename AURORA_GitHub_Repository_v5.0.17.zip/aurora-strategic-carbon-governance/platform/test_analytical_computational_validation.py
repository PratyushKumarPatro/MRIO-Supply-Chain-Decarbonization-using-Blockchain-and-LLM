"""Focused tests for the deterministic validation report runner."""
from __future__ import annotations

import importlib.util
import importlib.machinery
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest import mock

import numpy as np
import pandas as pd

if importlib.util.find_spec("networkx") is None:
    networkx_stub = types.ModuleType("networkx")
    class _NetworkXTestGraph:
        def __init__(self):
            self._nodes = set()
            self._edges = []

        def add_nodes_from(self, nodes):
            self._nodes.update(nodes)

        def add_edge(self, left, right, **attributes):
            self._nodes.update((left, right))
            self._edges.append((left, right, attributes))

        def number_of_nodes(self):
            return len(self._nodes)

    networkx_stub.DiGraph = _NetworkXTestGraph
    networkx_stub.betweenness_centrality = lambda graph, **_kwargs: {
        node: 0.0 for node in sorted(graph._nodes)
    }
    networkx_stub.pagerank = lambda graph, **_kwargs: {
        node: (1.0 / len(graph._nodes) if graph._nodes else 0.0)
        for node in sorted(graph._nodes)
    }
    networkx_stub.__spec__ = importlib.machinery.ModuleSpec("networkx", loader=None)
    sys.modules["networkx"] = networkx_stub

import analytics_engine as ae
import validate_analytical_computational as validation


class AnalyticalComputationalValidationTests(unittest.TestCase):
    def test_focal_demand_gate_requires_complete_finite_nonnegative_vector(self):
        result = validation._validate_demand(np.zeros(ae.N), 2017)
        self.assertEqual(result["node_count"], ae.N)
        with self.assertRaises(validation.AnalyticalValidationError):
            validation._validate_demand(np.zeros(ae.N - 1), 2017)
        invalid = np.zeros(ae.N)
        invalid[0] = -1.0
        with self.assertRaises(validation.AnalyticalValidationError):
            validation._validate_demand(invalid, 2017)

    def test_report_states_internal_validation_boundary(self):
        result = {
            "validation_scope": "Internal analytical and computational consistency checks only.",
            "reference_years": [2014, 2017],
            "annual": {
                "2014": {
                    "mrio_internal_identity": {
                        "max_abs_diff_X": 0.0,
                        "direct_emissions_total": 1.0,
                        "footprint_of_economy_wide_Y": 1.0,
                    },
                    "hotspot_reconciliation_residual": 0.0,
                    "spa": {"exact_tier_check": {"coverage": 1.0}},
                    "dli": {"score_recomposition_max_abs_difference": 0.0},
                },
                "2017": {
                    "mrio_internal_identity": {
                        "max_abs_diff_X": 0.0,
                        "direct_emissions_total": 1.0,
                        "footprint_of_economy_wide_Y": 1.0,
                    },
                    "hotspot_reconciliation_residual": 0.0,
                    "spa": {"exact_tier_check": {"coverage": 1.0}},
                    "dli": {"score_recomposition_max_abs_difference": 0.0},
                },
            },
            "sda": {"reconciliation_residual": 0.0},
            "temporal_dli": {"node_count": ae.N},
            "pooled_critic_dli": {
                "method": "pooled Pearson-CRITIC DLI",
                "scope": "pooled-2014-2017",
                "correlation_method": "pearson",
                "weights": {"BC": 0.25, "PR": 0.25, "CDR": 0.25, "IC": 0.25},
                "legacy_fixed_weights_used": False,
            },
            "input_provenance": {
                "input_mode": "active_governed_inputs",
                "claim_boundary": "Inputs were bound to active hashes.",
            },
        }
        text = validation._report(
            result,
            mrio_path=validation.DEFAULT_MRIO,
            focal_path=validation.DEFAULT_FOCAL_DEMAND,
            hashes={"mrio": "m", "focal_demand": "f"},
        )
        self.assertIn("Internal analytical and computational consistency", text)
        self.assertIn("SDA reconciliation residual", text)
        self.assertIn("pooled 2014-2017 Pearson-CRITIC", text)

    def test_successful_two_year_run_uses_one_authoritative_pooled_critic_ranking(self):
        class DummyModel:
            def __init__(self, year, footprint):
                self.year = int(year)
                self._footprint = float(footprint)

            def footprint(self, _demand):
                return self._footprint

        def raw_metrics(year):
            index = np.arange(ae.N, dtype=float)
            year_shift = 0.0 if int(year) == 2014 else 0.35
            return pd.DataFrame(
                {
                    "year": int(year),
                    "node_code": [f"N{position:03d}" for position in range(ae.N)],
                    "region": [f"R{position % 7}" for position in range(ae.N)],
                    "sector": [f"S{position % 13}" for position in range(ae.N)],
                    "BC": (index % 31.0) + year_shift,
                    "PR": ((index * 7.0) % 47.0) + 0.5 * year_shift,
                    "CDR": np.log1p(index + 1.0) * (1.0 + year_shift),
                    "IC": np.sqrt(index + 1.0) + ((index % 17.0) / 19.0) + year_shift,
                }
            )

        def annual_result(model, _demand):
            return (
                {
                    "mrio_internal_identity": {},
                    "focal_demand": {"node_count": ae.N},
                    "focal_company_footprint": model._footprint,
                    "hotspot_sum": model._footprint,
                    "hotspot_reconciliation_residual": 0.0,
                    "spa": {},
                    "network_raw_metrics": {
                        "node_count": ae.N,
                        "criteria": list(validation.net.CRITERIA),
                        "finite": True,
                        "non_negative": True,
                    },
                },
                raw_metrics(model.year),
            )

        models = {2014: DummyModel(2014, 100.0), 2017: DummyModel(2017, 112.0)}
        base_inputs = types.SimpleNamespace(footprint=lambda: 100.0)
        comparison_inputs = types.SimpleNamespace(footprint=lambda: 112.0)
        provenance = {
            "input_mode": "unmanaged_external_exploration",
            "input_hashes": {"mrio": "m" * 64, "focal_demand": "f" * 64},
        }
        with (
            mock.patch.object(validation.ae, "load_year", side_effect=lambda _path, year: models[int(year)]),
            mock.patch.object(validation.ae, "load_company_Y", return_value=np.ones(ae.N)),
            mock.patch.object(validation, "_year_validation", side_effect=annual_result),
            mock.patch.object(
                validation.sda.SDAInputs,
                "from_year",
                side_effect=[base_inputs, comparison_inputs],
            ),
            mock.patch.object(validation.sda, "sda_decompose", return_value={"net_change": 12.0}),
            mock.patch.object(validation, "verify_input_snapshot"),
        ):
            result = validation.run_validation(
                Path("mrio.xlsx"),
                Path("focal.xlsx"),
                (2014, 2017),
                input_provenance=provenance,
            )

        pooled = result["pooled_critic_dli"]
        self.assertEqual(pooled["method"], "pooled Pearson-CRITIC DLI")
        self.assertEqual(pooled["scope"], "pooled-2014-2017")
        self.assertEqual(pooled["correlation_method"], "pearson")
        self.assertEqual(pooled["observation_count"], 2 * ae.N)
        self.assertEqual(pooled["node_count_per_year"], ae.N)
        self.assertFalse(pooled["legacy_fixed_weights_used"])
        self.assertAlmostEqual(sum(pooled["weights"].values()), 1.0, places=12)
        self.assertEqual(
            pooled["normalised_columns"],
            ["BC_norm_critic", "PR_norm_critic", "CDR_norm_critic", "IC_norm_critic"],
        )
        self.assertLessEqual(pooled["score_recomposition_max_abs_difference"], 1e-8)
        self.assertEqual(result["temporal_dli"]["node_count"], ae.N)
        for year in (2014, 2017):
            annual_dli = result["annual"][str(year)]["dli"]
            self.assertEqual(annual_dli["method"], "pooled Pearson-CRITIC DLI")
            self.assertEqual(annual_dli["scope"], "pooled-2014-2017")
            self.assertEqual(annual_dli["correlation_method"], "pearson")
            self.assertFalse(annual_dli["legacy_fixed_weights_used"])
            self.assertEqual(annual_dli["node_count"], ae.N)
            self.assertEqual(len(annual_dli["top_15"]), 15)

    def test_managed_binding_rejects_workbook_hash_not_equal_to_active_manifest(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mrio = root / "input_mrio_completed.xlsx"
            focal = root / "Focal_Company_Demand_Converted.xlsx"
            mrio.write_bytes(b"mrio bytes")
            focal.write_bytes(b"focal bytes")
            with (
                mock.patch.object(validation, "PACKAGE_ROOT", root),
                mock.patch.object(
                    validation,
                    "_validate_workbook_schema_and_alignment",
                    return_value={"node_order_alignment": True},
                ),
                mock.patch.object(
                    validation.onboarding,
                    "active_input_hashes",
                    return_value={"mrio": "0" * 64, "focal_demand": "1" * 64},
                ),
                mock.patch.object(
                    validation.onboarding,
                    "active_input_record",
                    return_value={"status": "active", "activated_at_utc": "now"},
                ),
            ):
                with self.assertRaises(validation.AnalyticalValidationError):
                    validation.bind_input_provenance(mrio, focal)

    def test_unmanaged_mode_is_explicit_and_snapshot_mutation_is_rejected(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mrio = root / "external_mrio.xlsx"
            focal = root / "external_focal.xlsx"
            mrio.write_bytes(b"external mrio")
            focal.write_bytes(b"external focal")
            with (
                mock.patch.object(validation, "PACKAGE_ROOT", root),
                mock.patch.object(
                    validation,
                    "_validate_workbook_schema_and_alignment",
                    return_value={"node_order_alignment": True},
                ),
            ):
                provenance = validation.bind_input_provenance(
                    mrio,
                    focal,
                    allow_unmanaged_inputs=True,
                )
                self.assertEqual(provenance["input_mode"], "unmanaged_external_exploration")
                self.assertIn("must not be reported", provenance["claim_boundary"])
                focal.write_bytes(b"changed during run")
                with self.assertRaises(validation.AnalyticalValidationError):
                    validation.verify_input_snapshot(mrio, focal, provenance)

    def test_schema_alignment_failure_is_not_silently_bypassed(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            mrio = root / "external_mrio.xlsx"
            focal = root / "external_focal.xlsx"
            mrio.write_bytes(b"external mrio")
            focal.write_bytes(b"external focal")
            with mock.patch.object(
                validation,
                "_validate_workbook_schema_and_alignment",
                side_effect=ValueError("Focal-company Node_Code ordering does not match MRIO Metadata ordering."),
            ):
                with self.assertRaisesRegex(ValueError, "Node_Code ordering"):
                    validation.bind_input_provenance(mrio, focal, allow_unmanaged_inputs=True)

    def test_spa_tier_gate_rejects_nonfinite_and_overshooting_series(self):
        class DummyMRIO:
            year = 2017
            Z = np.array([[0.0]], dtype=float)
            X = np.array([1.0], dtype=float)
            fE = np.array([np.nan], dtype=float)

            @staticmethod
            def footprint(_demand):
                return 1.0

        with self.assertRaises(validation.AnalyticalValidationError):
            validation._spa_exact_tier_check(DummyMRIO(), np.array([1.0]), validation.spa.SPAConfig(exact_max_tier=1))

        class OvershootMRIO:
            year = 2017
            Z = np.array([[2.0]], dtype=float)
            X = np.array([1.0], dtype=float)
            fE = np.array([1.0], dtype=float)

            @staticmethod
            def footprint(_demand):
                return 1.0

        with self.assertRaises(validation.AnalyticalValidationError):
            validation._spa_exact_tier_check(OvershootMRIO(), np.array([1.0]), validation.spa.SPAConfig(exact_max_tier=1))


if __name__ == "__main__":
    unittest.main(verbosity=2)
