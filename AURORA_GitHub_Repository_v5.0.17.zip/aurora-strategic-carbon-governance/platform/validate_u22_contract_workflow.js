'use strict';

// U22 executable contract regression for the governed methodology order:
// temporal Network/DLI -> AURORA -> intervention governance -> monitored performance. Run after
// `npm ci` and `npm run compile`; no external Ganache process is required.

const fs = require('fs');
const path = require('path');
const ganache = require('ganache');
const { keccak_256: keccak256 } = require('js-sha3');

const root = __dirname;

function word(value) {
  const bigint = typeof value === 'boolean' ? (value ? 1n : 0n) : BigInt(value);
  return bigint.toString(16).padStart(64, '0');
}

function addressWord(value) {
  return String(value).toLowerCase().replace(/^0x/, '').padStart(64, '0');
}

function encodeArguments(types, values) {
  if (types.length !== values.length) throw new Error('ABI argument count mismatch');
  const head = [];
  const tail = [];
  let tailBytes = 0;
  for (let index = 0; index < types.length; index += 1) {
    const type = types[index];
    const value = values[index];
    if (type === 'string') {
      head.push(word(types.length * 32 + tailBytes));
      const encoded = Buffer.from(String(value), 'utf8').toString('hex');
      const padded = encoded.padEnd(Math.ceil(encoded.length / 64) * 64, '0');
      const item = word(encoded.length / 2) + padded;
      tail.push(item);
      tailBytes += item.length / 2;
    } else if (type === 'address') {
      head.push(addressWord(value));
    } else if (type === 'bool' || /^uint(?:8|16|256)?$/.test(type)) {
      head.push(word(value));
    } else {
      throw new Error(`Unsupported ABI type in contract validator: ${type}`);
    }
  }
  return head.join('') + tail.join('');
}

function callData(signature, types, values) {
  return `0x${keccak256(signature).slice(0, 8)}${encodeArguments(types, values)}`;
}

async function waitForReceipt(provider, hash) {
  for (let attempt = 0; attempt < 200; attempt += 1) {
    const receipt = await provider.request({ method: 'eth_getTransactionReceipt', params: [hash] });
    if (receipt) return receipt;
    await new Promise((resolve) => setTimeout(resolve, 25));
  }
  throw new Error(`Timed out waiting for transaction ${hash}`);
}

async function send(provider, from, data, to = undefined) {
  const transaction = { from, data, gas: '0xb71b00' };
  if (to) transaction.to = to;
  const hash = await provider.request({ method: 'eth_sendTransaction', params: [transaction] });
  const receipt = await waitForReceipt(provider, hash);
  if (receipt.status !== '0x1') throw new Error(`Transaction reverted: ${hash}`);
  return receipt;
}

async function expectRevert(action, label) {
  try {
    await action();
  } catch (_error) {
    return;
  }
  throw new Error(`Expected revert was not observed: ${label}`);
}

async function main() {
  const provider = ganache.provider({
    logging: { quiet: true },
    wallet: { totalAccounts: 10 },
    chain: { chainId: 1337 },
  });
  try {
    const accounts = await provider.request({ method: 'eth_accounts', params: [] });
    const [regulator, registrationOracle, governanceOracle, focalCompany] = accounts;

    const registrationBin = fs.readFileSync(
      path.join(root, 'StrategicCarbonIntelligenceSystem_sol_Registration.bin'),
      'utf8',
    ).trim();
    const governanceBin = fs.readFileSync(
      path.join(root, 'StrategicCarbonIntelligenceSystem_sol_HotspotsManagementAndGovernance.bin'),
      'utf8',
    ).trim();
    const queryBin = fs.readFileSync(
      path.join(root, 'StrategicCarbonIntelligenceSystem_sol_QueryManagement.bin'),
      'utf8',
    ).trim();

    const registrationDeployment = await send(
      provider,
      regulator,
      `0x${registrationBin}${encodeArguments(['address'], [registrationOracle])}`,
    );
    const registration = registrationDeployment.contractAddress;

    await send(
      provider,
      regulator,
      callData('assignOracleRole(address,uint8)', ['address', 'uint8'], [governanceOracle, 6]),
      registration,
    );
    await send(
      provider,
      focalCompany,
      callData('requestRegistration(uint8,string)', ['uint8', 'string'], [3, 'focal-evidence']),
      registration,
    );
    await send(
      provider,
      registrationOracle,
      callData(
        'fulfillRegistration(uint256,bool,string)',
        ['uint256', 'bool', 'string'],
        [0, true, 'registration-verification'],
      ),
      registration,
    );

    const governanceDeployment = await send(
      provider,
      focalCompany,
      `0x${governanceBin}${encodeArguments(['address'], [registration])}`,
    );
    const governance = governanceDeployment.contractAddress;

    // The decision-year request cannot precede fulfilled 2014 evidence.
    await expectRevert(
      () => send(
        provider,
        focalCompany,
        callData('performNetworkAnalysis(uint16)', ['uint16'], [2017]),
        governance,
      ),
      '2017 Network/DLI before 2014',
    );
    await expectRevert(
      () => send(
        provider,
        focalCompany,
        callData('performNetworkAnalysis(uint16)', ['uint16'], [2020]),
        governance,
      ),
      'unsupported Network/DLI year',
    );

    // Establish the temporal 2014 -> 2017 Network/DLI evidence pair.
    await send(
      provider,
      focalCompany,
      callData('performNetworkAnalysis(uint16)', ['uint16'], [2014]),
      governance,
    );
    await send(
      provider,
      governanceOracle,
      callData('fulfillNetworkAnalysis(uint256,string)', ['uint256', 'string'], [0, 'network-2014']),
      governance,
    );
    await send(
      provider,
      focalCompany,
      callData('performNetworkAnalysis(uint16)', ['uint16'], [2017]),
      governance,
    );
    await send(
      provider,
      governanceOracle,
      callData('fulfillNetworkAnalysis(uint256,string)', ['uint256', 'string'], [1, 'network-2017']),
      governance,
    );
    const boundBaseline = await provider.request({
      method: 'eth_call',
      params: [
        {
          to: governance,
          data: callData(
            'getTemporalBaselineNetworkRequest(uint256)',
            ['uint256'],
            [1],
          ),
        },
        'latest',
      ],
    });
    if (BigInt(boundBaseline) !== 0n) {
      throw new Error(`2017 Network/DLI did not expose its exact 2014 baseline: ${boundBaseline}`);
    }

    // AURORA is available with zero interventions, but formal intervention
    // governance waits for the AURORA result rather than blocking AURORA.
    await send(
      provider,
      focalCompany,
      callData(
        'performRegionalSourcingOpportunityAnalysis(uint16,uint256)',
        ['uint16', 'uint256'],
        [2017, 1],
      ),
      governance,
    );
    await expectRevert(
      () => send(
        provider,
        focalCompany,
        callData(
          'requestInterventionProposal(uint256,string,string)',
          ['uint256', 'string', 'string'],
          [1, 'shared-node', 'option-a'],
        ),
        governance,
      ),
      'intervention while AURORA pending',
    );

    // Failed AURORA does not permanently deadlock the lifecycle.
    await send(
      provider,
      governanceOracle,
      callData(
        'failRegionalSourcingOpportunityAnalysis(uint256,string)',
        ['uint256', 'string'],
        [0, 'aurora-transient-error'],
      ),
      governance,
    );
    await send(
      provider,
      focalCompany,
      callData(
        'performRegionalSourcingOpportunityAnalysis(uint16,uint256)',
        ['uint16', 'uint256'],
        [2017, 1],
      ),
      governance,
    );
    await expectRevert(
      () => send(
        provider,
        focalCompany,
        callData(
          'performRegionalSourcingOpportunityAnalysis(uint16,uint256)',
          ['uint16', 'uint256'],
          [2017, 1],
        ),
        governance,
      ),
      'duplicate pending AURORA',
    );
    await send(
      provider,
      governanceOracle,
      callData(
        'fulfillRegionalSourcingOpportunityAnalysis(uint256,string)',
        ['uint256', 'string'],
        [1, 'aurora-2017'],
      ),
      governance,
    );
    await expectRevert(
      () => send(
        provider,
        focalCompany,
        callData(
          'performRegionalSourcingOpportunityAnalysis(uint16,uint256)',
          ['uint16', 'uint256'],
          [2014, 1],
        ),
        governance,
      ),
      'mismatched AURORA year',
    );
    await expectRevert(
      () => send(
        provider,
        focalCompany,
        callData(
          'performRegionalSourcingOpportunityAnalysis(uint16,uint256)',
          ['uint16', 'uint256'],
          [2017, 1],
        ),
        governance,
      ),
      'duplicate fulfilled AURORA',
    );
    await send(
      provider,
      focalCompany,
      callData('performNetworkAnalysis(uint16)', ['uint16'], [2017]),
      governance,
    );
    await expectRevert(
      () => send(
        provider,
        focalCompany,
        callData(
          'performRegionalSourcingOpportunityAnalysis(uint16,uint256)',
          ['uint16', 'uint256'],
          [2017, 2],
        ),
        governance,
      ),
      'unfulfilled 2017 Network/DLI evidence',
    );

    // Two distinct verified options for the same node are allowed; an exact
    // duplicate is not. Both fulfillments reuse one hotspot and create separate
    // intervention records.
    await send(
      provider,
      focalCompany,
      callData(
        'requestInterventionProposal(uint256,string,string)',
        ['uint256', 'string', 'string'],
        [1, 'shared-node', 'option-a'],
      ),
      governance,
    );
    await send(
      provider,
      focalCompany,
      callData(
        'requestInterventionProposal(uint256,string,string)',
        ['uint256', 'string', 'string'],
        [1, 'shared-node', 'option-b'],
      ),
      governance,
    );
    await expectRevert(
      () => send(
        provider,
        focalCompany,
        callData(
          'requestInterventionProposal(uint256,string,string)',
          ['uint256', 'string', 'string'],
          [1, 'shared-node', 'option-a'],
        ),
        governance,
      ),
      'exact duplicate intervention option',
    );
    await send(
      provider,
      governanceOracle,
      callData(
        'fulfillInterventionProposal(uint256,uint256,string,string,string,string)',
        ['uint256', 'uint256', 'string', 'string', 'string', 'string'],
        [0, 5000, 'evidence-a', 'engagement', 'option-a', 'verification-a'],
      ),
      governance,
    );
    await send(
      provider,
      governanceOracle,
      callData(
        'fulfillInterventionProposal(uint256,uint256,string,string,string,string)',
        ['uint256', 'uint256', 'string', 'string', 'string', 'string'],
        [1, 5000, 'evidence-b', 'standards', 'option-b', 'verification-b'],
      ),
      governance,
    );
    await send(
      provider,
      focalCompany,
      callData(
        'requestInterventionProposal(uint256,string,string)',
        ['uint256', 'string', 'string'],
        [1, 'shared-node', 'option-c'],
      ),
      governance,
    );
    await send(
      provider,
      governanceOracle,
      callData(
        'failInterventionProposal(uint256,string)',
        ['uint256', 'string'],
        [2, 'verification-error'],
      ),
      governance,
    );
    await send(
      provider,
      focalCompany,
      callData(
        'requestInterventionProposal(uint256,string,string)',
        ['uint256', 'string', 'string'],
        [1, 'shared-node', 'option-c'],
      ),
      governance,
    );

    await expectRevert(
      () => send(
        provider,
        focalCompany,
        callData(
          'recordInterventionPerformance(uint256,string)',
          ['uint256', 'string'],
          [0, 'performance-before-approval'],
        ),
        governance,
      ),
      'performance evidence before approval',
    );
    await send(
      provider,
      focalCompany,
      callData('decideIntervention(uint256,bool)', ['uint256', 'bool'], [0, true]),
      governance,
    );
    await send(
      provider,
      focalCompany,
      callData(
        'recordInterventionPerformance(uint256,string)',
        ['uint256', 'string'],
        [0, 'performance-evidence-cid'],
      ),
      governance,
    );

    // QueryManagement bytecode remains role-restricted. The sequential final-
    // support gate is enforced by the guided deployment/runtime layer.
    await send(
      provider,
      focalCompany,
      `0x${queryBin}${encodeArguments(['address'], [registration])}`,
    );

    process.stdout.write(
      'U22 contract workflow PASS: temporal DLI, AURORA, intervention governance, approval, monitored-performance anchoring, and Query deployment validated.\n',
    );
  } finally {
    await provider.disconnect();
  }
}

main().catch((error) => {
  process.stderr.write(`${error.stack || error}\n`);
  process.exitCode = 1;
});
