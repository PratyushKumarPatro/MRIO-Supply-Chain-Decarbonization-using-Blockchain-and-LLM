"""Pure U19 lifecycle rules for the coherent post-DLI methodology sequence.

The 2017 AURORA assessment follows the two-year Network/DLI evidence.  The
intervention-governance workspace follows AURORA. Query Management opens only
after the intervention branch reaches either an on-chain human decision or a
verified no-governance-ready-option outcome.

This module deliberately has no Web3, filesystem, or pandas dependency so the
gate semantics can be tested independently of the deployment runtime.
"""
from __future__ import annotations

from collections.abc import Iterable, Mapping
from typing import Any

AURORA_LIFECYCLE_EXTENSION_ID = "v5.0.17-U18"
METHODOLOGY_LIFECYCLE_EXTENSION_ID = "v5.0.17-U19"

MAPPED_MECHANISM_STATUS = "Mapped from primary adverse node-SDA driver"
PASSED_LINKAGE_STATUS = "Pass"
TERMINAL_ACTIONABILITY_STATUSES = frozenset(
    {"Verified actionable", "Not actionable"}
)


def aurora_request_ready(*, governance_deployed: bool, temporal_dli_complete: bool) -> bool:
    """Return whether the 2017 AURORA stage may be requested."""

    return bool(governance_deployed and temporal_dli_complete)


def query_management_ready(
    *,
    temporal_dli_complete: bool,
    aurora_complete: bool,
    intervention_governance_resolved: bool,
) -> bool:
    """Return whether final decision support may deploy."""

    return bool(
        temporal_dli_complete
        and aurora_complete
        and intervention_governance_resolved
    )


def intervention_workspace_ready(*, aurora_complete: bool) -> bool:
    """Return whether the post-AURORA intervention workspace should be exposed."""

    return bool(aurora_complete)


def _records(value: Iterable[Mapping[str, Any]] | Any) -> list[Mapping[str, Any]]:
    """Normalize a record iterable or DataFrame-like object without importing pandas."""

    if value is None:
        return []
    if hasattr(value, "to_dict"):
        value = value.to_dict(orient="records")
    records = list(value)
    if not all(isinstance(record, Mapping) for record in records):
        raise ValueError("Intervention eligibility evidence must contain mapping records")
    return records


def _count(value: Any, label: str) -> int:
    try:
        result = int(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be a non-negative integer") from exc
    if result < 0:
        raise ValueError(f"{label} must be a non-negative integer")
    return result


def evaluate_intervention_governance(
    eligibility_records: Iterable[Mapping[str, Any]] | Any,
    *,
    governance_ready_option_count: int,
    selected_intervention_count: int,
    all_selected_interventions_decided: bool,
    evidence_verified: bool,
) -> dict[str, Any]:
    """Evaluate the intervention branch using verified current evidence.

    Evidence is fail-closed.  A verified zero-option outcome is terminal only
    after every pair requiring actionability review is either ``Verified
    actionable`` or ``Not actionable``.  When governance-ready options exist,
    at least one must be selected and every selected proposal must be decided.
    A selected-but-pending proposal always takes precedence over the zero-option
    rule.
    """

    option_count = _count(
        governance_ready_option_count, "governance_ready_option_count"
    )
    selected_count = _count(
        selected_intervention_count, "selected_intervention_count"
    )

    if not evidence_verified:
        return {
            "intervention_governance_evidence_verified": False,
            "intervention_actionability_review_complete": False,
            "required_actionability_pair_count": 0,
            "terminal_actionability_pair_count": 0,
            "governance_ready_option_count": 0,
            "verified_no_governance_ready_intervention": False,
            "verified_no_governance_ready_options": False,
            "no_governance_ready_intervention": False,
            "intervention_governance_resolved": False,
            "intervention_governance_outcome_complete": False,
            "outcome_complete": False,
            "intervention_governance_resolution_basis": (
                "Current intervention-governance evidence is unavailable or failed verification."
            ),
        }

    records = _records(eligibility_records)
    required_fields = {
        "mechanism_mapping_status",
        "linkage_gate_status",
        "assessment_status",
    }
    if records:
        missing = sorted(
            field
            for field in required_fields
            if any(field not in record for record in records)
        )
        if missing:
            raise ValueError(
                "Intervention eligibility evidence is missing required fields: "
                + ", ".join(missing)
            )

    required_records = [
        record
        for record in records
        if str(record.get("mechanism_mapping_status", "")).strip()
        == MAPPED_MECHANISM_STATUS
        and str(record.get("linkage_gate_status", "")).strip()
        == PASSED_LINKAGE_STATUS
    ]
    terminal_count = sum(
        str(record.get("assessment_status", "")).strip()
        in TERMINAL_ACTIONABILITY_STATUSES
        for record in required_records
    )
    actionability_complete = terminal_count == len(required_records)

    verified_zero_option = bool(
        selected_count == 0 and option_count == 0 and actionability_complete
    )
    selected_and_decided = bool(
        selected_count > 0 and all_selected_interventions_decided
    )
    resolved = bool(selected_and_decided or verified_zero_option)

    if selected_count > 0:
        if selected_and_decided:
            basis = (
                "At least one verified governance-ready intervention was selected and "
                "every selected proposal has an on-chain governance decision."
            )
        else:
            basis = (
                "One or more interventions are selected, but every selected proposal "
                "has not yet received an on-chain governance decision."
            )
    elif option_count > 0:
        basis = (
            "Verified governance-ready intervention options exist and await formal selection."
        )
    elif not actionability_complete:
        basis = (
            "No governance-ready option is currently available, but required actionability "
            "assessments are incomplete."
        )
    else:
        basis = (
            "The current evidence package is verified, every required actionability review "
            "is terminal, and no governance-ready intervention option exists."
        )

    return {
        "intervention_governance_evidence_verified": True,
        "intervention_actionability_review_complete": actionability_complete,
        "required_actionability_pair_count": len(required_records),
        "terminal_actionability_pair_count": terminal_count,
        "governance_ready_option_count": option_count,
        "verified_no_governance_ready_intervention": verified_zero_option,
        "verified_no_governance_ready_options": verified_zero_option,
        "no_governance_ready_intervention": verified_zero_option,
        "intervention_governance_resolved": resolved,
        "intervention_governance_outcome_complete": resolved,
        "outcome_complete": resolved,
        "intervention_governance_resolution_basis": basis,
    }


__all__ = (
    "AURORA_LIFECYCLE_EXTENSION_ID",
    "METHODOLOGY_LIFECYCLE_EXTENSION_ID",
    "MAPPED_MECHANISM_STATUS",
    "PASSED_LINKAGE_STATUS",
    "TERMINAL_ACTIONABILITY_STATUSES",
    "aurora_request_ready",
    "intervention_workspace_ready",
    "query_management_ready",
    "evaluate_intervention_governance",
)
