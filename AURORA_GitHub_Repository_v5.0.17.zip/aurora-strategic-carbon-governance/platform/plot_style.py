"""Shared Plotly presentation rules for the deployed Streamlit interface.

The analytical figures are created in several workspaces. Keeping typography
here makes titles, axes, legends, and in-chart labels consistently legible when
figures are exported for publication, without changing plotted data, ordering,
scales, units, or calculations.
"""
from __future__ import annotations

from typing import Any


FIGURE_TITLE_FONT_SIZE = 24
AXIS_TITLE_FONT_SIZE = 20
AXIS_TICK_FONT_SIZE = 17
LEGEND_TITLE_FONT_SIZE = 18
LEGEND_FONT_SIZE = 17
TRACE_TEXT_FONT_SIZE = 17
BASE_FONT_SIZE = 17
AXIS_FONT_FAMILY = "Arial Black, Arial, sans-serif"


def style_plotly_axes(figure: Any) -> Any:
    """Apply publication-readable typography to a Plotly figure.

    The historical function name is retained for compatibility with all U23
    workspaces. The style now covers the complete figure, including non-
    Cartesian charts, while preserving every analytical and visual encoding.
    """

    axis_title_font = {
        "family": AXIS_FONT_FAMILY,
        "size": AXIS_TITLE_FONT_SIZE,
    }
    axis_tick_font = {
        "family": AXIS_FONT_FAMILY,
        "size": AXIS_TICK_FONT_SIZE,
    }
    base_font = {
        "family": AXIS_FONT_FAMILY,
        "size": BASE_FONT_SIZE,
    }
    title_font = {
        "family": AXIS_FONT_FAMILY,
        "size": FIGURE_TITLE_FONT_SIZE,
    }
    legend_font = {
        "family": AXIS_FONT_FAMILY,
        "size": LEGEND_FONT_SIZE,
    }
    legend_title_font = {
        "family": AXIS_FONT_FAMILY,
        "size": LEGEND_TITLE_FONT_SIZE,
    }
    trace_text_font = {
        "family": AXIS_FONT_FAMILY,
        "size": TRACE_TEXT_FONT_SIZE,
    }
    figure.update_layout(
        font=base_font,
        title_font=title_font,
        legend={
            "font": legend_font,
            "title": {"font": legend_title_font},
        },
        hoverlabel={"font": base_font},
    )
    figure.update_xaxes(
        title_font=axis_title_font,
        tickfont=axis_tick_font,
        automargin=True,
    )
    figure.update_yaxes(
        title_font=axis_title_font,
        tickfont=axis_tick_font,
        automargin=True,
    )
    figure.update_traces(textfont=trace_text_font)
    return figure


__all__ = (
    "AXIS_FONT_FAMILY",
    "AXIS_TICK_FONT_SIZE",
    "AXIS_TITLE_FONT_SIZE",
    "BASE_FONT_SIZE",
    "FIGURE_TITLE_FONT_SIZE",
    "LEGEND_FONT_SIZE",
    "LEGEND_TITLE_FONT_SIZE",
    "TRACE_TEXT_FONT_SIZE",
    "style_plotly_axes",
)
