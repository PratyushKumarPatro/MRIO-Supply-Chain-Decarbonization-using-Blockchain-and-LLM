"""Intent-aware, evidence-grounded strategic assistant for Strategic Carbon Intelligence & Governance.

Runtime path:
    question
      -> deterministic domain guard and multi-intent analysis
      -> mandatory concept, methodology, analytical, strategic, or scenario plan
      -> optional local Ollama plan augmentation
      -> plan validation and repair
      -> curated knowledge records plus deterministic MRIO / SPA / SDA / DLI /
         intervention / scenario / AURORA tools
      -> provenance-bearing evidence bundle
      -> compositional deterministic answer
      -> optional validated Ollama wording
      -> deterministic grounded fallback if the local model fails

The local LLM is never the source of authoritative quantitative results. It can
suggest relevant optional tools and improve wording, but it cannot block an
in-domain question, remove mandatory evidence, change the requested answer type,
or invent study-specific results or parameters.
"""
from __future__ import annotations

import json
import hashlib
import math
import os
import re
import socket
import urllib.error
import urllib.request
from dataclasses import asdict, dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

import analytics_engine as ae
import network_engine as net
import sda_engine as sda
import node_sda_engine as node_sda
import hotspot_leverage as hotspot_link
import intervention_governance as intervention_gov
import scenario_engine as scenario
import knowledge_layer as knowledge
import query_intelligence as qi

BASE_DIR = Path(__file__).resolve().parent
MRIO_PATH = BASE_DIR / "input_mrio_completed.xlsx"
COMPANY_PATH = BASE_DIR / "Focal_Company_Demand_Converted.xlsx"

VALID_TOOLS = {
    "concept_knowledge",
    "methodology_knowledge",
    "footprint",
    "hotspots",
    "sda",
    "dli",
    "temporal_dli",
    "priority_ranking",
    "node_profile",
    "interventions",
    "intervention_governance",
    "spa_paths",
    "counterfactual_scenario",
    "sourcing_opportunity_analysis",
    "retrieval",
}

GENERIC_NODE_VALUES = {
    "",
    "all",
    "any",
    "top",
    "highest",
    "best",
    "none",
    "null",
    "n/a",
    "na",
    "unspecified",
}

PLANNER_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "intent": {
            "type": "string",
            "description": "A short description of the carbon-governance question.",
        },
        "tool_calls": {
            "type": "array",
            "maxItems": 8,
            "items": {
                "type": "object",
                "additionalProperties": False,
                "properties": {
                    "tool": {
                        "type": "string",
                        "enum": sorted(VALID_TOOLS),
                    },
                    "year": {
                        "type": "string",
                        "enum": ["2014", "2017", "change", "unspecified"],
                    },
                    "node_code": {
                        "type": "string",
                        "description": "Exact country-sector code only, for example ARE-nmm. Omit when no exact node was named.",
                    },
                    "top_n": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 20,
                    },
                    "theta": {
                        "type": "string",
                        "description": "Company sector share as a decimal such as 0.02. Omit for non-scenario questions.",
                    },
                    "reduction_pct": {
                        "type": "string",
                        "description": "Node intensity reduction as a decimal such as 0.30. Omit unless explicitly stated.",
                    },
                    "query": {
                        "type": "string",
                        "description": "Knowledge or retrieval query. Omit for non-knowledge tools.",
                    },
                },
                "required": ["tool"],
            },
        },
    },
    "required": ["intent", "tool_calls"],
}

SYNTHESIS_SCHEMA = {
    "type": "object",
    "additionalProperties": False,
    "properties": {
        "answer_type": {
            "type": "string",
            "enum": [
                "conceptual",
                "methodological",
                "analytical",
                "strategic",
                "scenario",
                "composite",
            ],
        },
        "narrative_answer": {
            "type": "string",
            "description": "A direct, coherent answer in connected paragraphs. Integrate evidence, interpretation, action and material limitations instead of exposing disconnected evidence blocks.",
        },
        "supporting_claims": {
            "type": "array",
            "maxItems": 8,
            "items": {"type": "string"},
        },
        "material_limitations": {
            "type": "array",
            "maxItems": 5,
            "items": {"type": "string"},
        },
    },
    "required": [
        "answer_type",
        "narrative_answer",
        "supporting_claims",
        "material_limitations",
    ],
}



@dataclass
class ToolEvidence:
    tool: str
    parameters: dict[str, Any]
    source: str
    data: Any


@dataclass
class AssistantResult:
    question: str
    plan: dict[str, Any]
    route: str
    evidence: list[dict[str, Any]]
    answer: str


class OllamaClient:
    """Minimal local Ollama HTTP client. No cloud account or API key is used."""

    def __init__(
        self,
        base_url: str | None = None,
        model: str | None = None,
        timeout: int | None = None,
    ):
        self.base_url = (
            base_url or os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434")
        ).rstrip("/")
        self.model = model or os.getenv("OLLAMA_MODEL", "qwen3:4b")
        self.timeout = int(timeout or os.getenv("OLLAMA_TIMEOUT", "600"))

    def _request(self, path: str, payload: dict | None = None) -> dict:
        url = f"{self.base_url}{path}"
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        req = urllib.request.Request(
            url,
            data=data,
            headers={"Content-Type": "application/json"},
        )
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as resp:
                return json.loads(resp.read().decode("utf-8"))
        except (TimeoutError, socket.timeout) as exc:
            raise RuntimeError(
                f"Ollama timed out after {self.timeout} seconds while running `{self.model}`. "
                "Validated deterministic project results may still be available, but LLM-first interpretation and open-ended reasoning were unavailable. "
                "Use qwen3:4b or qwen3:1.7b, close memory-heavy applications, or increase OLLAMA_TIMEOUT. "
                f"Original error: {exc}"
            ) from exc
        except urllib.error.HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", errors="replace")[:500]
            except Exception:
                detail = ""
            raise RuntimeError(
                f"Ollama returned HTTP {exc.code} at {self.base_url}. {detail}"
            ) from exc
        except urllib.error.URLError as exc:
            raise RuntimeError(
                f"Cannot reach Ollama at {self.base_url}. Start Ollama and pull the selected model "
                f"with `ollama pull {self.model}`. Original error: {exc}"
            ) from exc

    def list_models(self) -> list[str]:
        payload = self._request("/api/tags")
        return [
            m.get("name", "")
            for m in payload.get("models", [])
            if m.get("name")
        ]

    def model_details(self) -> list[dict[str, Any]]:
        """Return the locally installed Ollama model catalogue.

        The conversational interface uses this to populate a model selector
        from the same local service used by Ollama Desktop. Keeping the raw
        detail fields also lets the interface display parameter size and
        quantisation without maintaining a separate model registry.
        """

        payload = self._request("/api/tags")
        models = payload.get("models", [])
        return [dict(model) for model in models if model.get("name")]

    def chat_messages(
        self,
        messages: list[dict[str, Any]],
        system: str = "",
        model: str | None = None,
        num_predict: int = 1200,
        temperature: float = 0.25,
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        """Run a multi-turn local Ollama chat and return text plus metrics.

        This is intentionally separate from :meth:`chat_json`: research
        planning and research synthesis continue to use constrained structured
        outputs, while general conversation uses the normal Ollama chat
        interface. The method accepts standard Ollama message history and can
        also carry function definitions for future validated agent loops.
        """

        prepared: list[dict[str, Any]] = []
        if system:
            prepared.append({"role": "system", "content": system})
        for message in messages:
            role = str(message.get("role", "user")).strip().lower()
            if role not in {"user", "assistant", "system", "tool"}:
                continue
            content = str(message.get("content", "")).strip()
            if not content and role != "assistant":
                continue
            item: dict[str, Any] = {"role": role, "content": content}
            if role == "tool" and message.get("tool_name"):
                item["tool_name"] = str(message["tool_name"])
            prepared.append(item)

        payload: dict[str, Any] = {
            "model": model or self.model,
            "stream": False,
            "messages": prepared,
            "think": False,
            "keep_alive": "30m",
            "options": {
                "temperature": temperature,
                "num_predict": num_predict,
            },
        }
        if tools:
            payload["tools"] = tools

        out = self._request("/api/chat", payload)
        message = out.get("message", {}) or {}
        return {
            "content": str(message.get("content", "")).strip(),
            "message": message,
            "model": out.get("model", model or self.model),
            "done_reason": out.get("done_reason", ""),
            "metrics": {
                "total_duration": out.get("total_duration"),
                "load_duration": out.get("load_duration"),
                "prompt_eval_count": out.get("prompt_eval_count"),
                "prompt_eval_duration": out.get("prompt_eval_duration"),
                "eval_count": out.get("eval_count"),
                "eval_duration": out.get("eval_duration"),
            },
        }

    def chat_json(
        self,
        system: str,
        user: str,
        schema: dict,
        model: str | None = None,
        num_predict: int = 512,
        temperature: float = 0.0,
    ) -> dict:
        payload = {
            "model": model or self.model,
            "stream": False,
            "format": schema,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "think": False,
            "keep_alive": "30m",
            "options": {
                "temperature": temperature,
                "num_predict": num_predict,
            },
        }
        out = self._request("/api/chat", payload)
        text = out.get("message", {}).get("content", "").strip()
        try:
            parsed = json.loads(text)
        except json.JSONDecodeError as exc:
            raise RuntimeError(
                f"Ollama returned invalid structured output: {text[:500]}"
            ) from exc
        if not isinstance(parsed, dict):
            raise RuntimeError("Ollama structured output was not a JSON object.")
        return parsed

    def chat_text(self, system: str, user: str, model: str | None = None) -> str:
        payload = {
            "model": model or self.model,
            "stream": False,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user},
            ],
            "think": False,
            "keep_alive": "30m",
            "options": {"temperature": 0.2, "num_predict": 1200},
        }
        out = self._request("/api/chat", payload)
        return out.get("message", {}).get("content", "").strip()


class DeterministicOnlyClient:
    """Immediate no-LLM client used when Ollama is disabled or unavailable.

    Planner and synthesis calls catch this exception and use the validated
    deterministic plan and grounded answer without waiting for a network timeout.
    """

    model = "deterministic-only"

    def chat_json(
        self,
        system: str,
        user: str,
        schema: dict,
        model: str | None = None,
        num_predict: int = 512,
        temperature: float = 0.0,
    ) -> dict:
        raise RuntimeError("Local Ollama augmentation is disabled or unavailable.")

    def chat_messages(
        self,
        messages: list[dict[str, Any]],
        system: str = "",
        model: str | None = None,
        num_predict: int = 1200,
        temperature: float = 0.25,
        tools: list[dict[str, Any]] | None = None,
    ) -> dict[str, Any]:
        raise RuntimeError("Local Ollama conversation is disabled or unavailable.")


def make_client(base_url: str | None = None, model: str | None = None):
    return OllamaClient(base_url=base_url, model=model)


def make_deterministic_client():
    return DeterministicOnlyClient()


# ---------------------------------------------------------------------------
# Packaged artifacts and cached deterministic inputs


def _artifact_dirs() -> list[Path]:
    candidates = [BASE_DIR / "data", BASE_DIR / "streamlit_app" / "data", BASE_DIR]
    return [p for p in candidates if p.exists()]


def _find_artifact(name: str) -> Path | None:
    for folder in _artifact_dirs():
        p = folder / name
        if p.exists():
            return p
    return None


def _load_year_inputs(year: int):
    my = ae.load_year(str(MRIO_PATH), year)
    company_y = ae.load_company_Y(str(COMPANY_PATH), year)
    return my, company_y


def _sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def _active_input_hashes() -> dict[str, str]:
    missing = [str(p.name) for p in (MRIO_PATH, COMPANY_PATH) if not p.exists()]
    if missing:
        raise RuntimeError(
            "Operational analytical inputs have not been uploaded and activated through the Governance & Audit Control workspace: "
            + ", ".join(missing)
        )
    return {"mrio": _sha256_file(MRIO_PATH), "focal_demand": _sha256_file(COMPANY_PATH)}


def _reference_input_hashes() -> dict[str, str] | None:
    # No packaged operational data fallback is permitted in the real-time onboarding build.
    return None


def _runtime_analytics_dirs() -> list[Path]:
    candidates = [
        BASE_DIR / "runtime" / "active_analytics",
        BASE_DIR.parent / "runtime" / "active_analytics",
    ]
    output: list[Path] = []
    for path in candidates:
        resolved = path.resolve()
        if resolved not in [item.resolve() for item in output]:
            output.append(path)
    return output


def _runtime_frame(kind: str, year: int) -> pd.DataFrame | None:
    if str(kind) == "dli":
        try:
            return _authoritative_pooled_dli_slice(int(year))
        except Exception:
            return None
    for runtime in _runtime_analytics_dirs():
        csv_path = runtime / f"{kind}_{int(year)}.csv"
        meta_path = runtime / f"{kind}_{int(year)}.json"
        if not csv_path.exists() or not meta_path.exists():
            continue
        try:
            meta = json.loads(meta_path.read_text(encoding="utf-8"))
            active_hashes = _active_input_hashes()
            if meta.get("input_hashes") != active_hashes:
                continue
            if _sha256_file(csv_path) != str(meta.get("frame_sha256", "")):
                continue
            source_cid = str(meta.get("source_result_cid", "")).strip().lower()
            if len(source_cid) != 64 or any(
                ch not in "0123456789abcdef" for ch in source_cid
            ):
                continue
            if str(kind) != "spa":
                # Other legacy convenience mirrors do not yet have a defined
                # immutable result schema and are not used for authoritative
                # SPA or DLI answers.
                continue
            index = json.loads(
                (BASE_DIR / "runtime" / "result_index.json").read_text(encoding="utf-8")
            )
            record = index["results"][f"spa:{int(year)}"]
            if (
                record.get("input_hashes") != active_hashes
                or str(record.get("content_hash", "")).strip().lower() != source_cid
            ):
                continue
            envelope = None
            for candidate in (
                BASE_DIR / "content_store" / f"{source_cid}.json",
                BASE_DIR / "content_store" / source_cid,
            ):
                if candidate.is_file():
                    body = candidate.read_bytes()
                    if hashlib.sha256(body).hexdigest() != source_cid:
                        raise RuntimeError("SPA content failed its SHA-256 CID check")
                    envelope = json.loads(body.decode("utf-8"))
                    break
            if not isinstance(envelope, dict) or envelope.get("namespace") != "structural_path_analysis":
                continue
            material = envelope.get("payload", {})
            payload = material.get("payload", {}) if isinstance(material, dict) else {}
            if (
                material.get("operation") != "structural_path_analysis"
                or int(payload.get("year", -1)) != int(year)
                or payload.get("input_hashes") != active_hashes
            ):
                continue
            authoritative = pd.DataFrame(payload.get("paths", []))
            mirror = pd.read_csv(csv_path)
            if authoritative.empty or set(mirror.columns) != set(authoritative.columns):
                continue
            authoritative = authoritative.loc[:, list(mirror.columns)]
            try:
                pd.testing.assert_frame_equal(
                    mirror.reset_index(drop=True),
                    authoritative.reset_index(drop=True),
                    check_dtype=False,
                    check_exact=False,
                    rtol=1e-12,
                    atol=1e-12,
                )
            except AssertionError:
                continue
            return mirror
        except Exception:
            continue
    return None


def _authoritative_pooled_dli_slice(year: int) -> pd.DataFrame:
    """Load one annual DLI slice from the immutable active 2017 result.

    The fulfilled 2014 Network request is required baseline evidence, but its
    response is annual-provisional because the 2017 observations did not yet
    exist.  Once the 2017 request is fulfilled, that one immutable response is
    the authority for both jointly normalized and jointly weighted slices.
    """
    reference_year = int(year)
    if reference_year not in {2014, 2017}:
        raise ValueError("Authoritative temporal DLI is available only for 2014 and 2017")
    active_hashes = _active_input_hashes()
    index_path = BASE_DIR / "runtime" / "result_index.json"
    try:
        index = json.loads(index_path.read_text(encoding="utf-8"))
        record = index["results"]["network:2017"]
        baseline_record = index["results"]["network:2014"]
    except Exception as exc:
        raise RuntimeError(
            "The active pooled 2017 Network/DLI result is unavailable"
        ) from exc
    if record.get("input_hashes") != active_hashes:
        raise RuntimeError("The active pooled Network/DLI result is stale for the uploaded workbooks")
    cid = str(record.get("content_hash", "")).strip().lower()
    if len(cid) != 64 or any(ch not in "0123456789abcdef" for ch in cid):
        raise RuntimeError("The active pooled Network/DLI result CID is invalid")

    envelope = None
    for candidate in (BASE_DIR / "content_store" / f"{cid}.json", BASE_DIR / "content_store" / cid):
        if not candidate.is_file():
            continue
        body = candidate.read_bytes()
        if hashlib.sha256(body).hexdigest() != cid:
            raise RuntimeError("The active pooled Network/DLI result failed its SHA-256 CID check")
        envelope = json.loads(body.decode("utf-8"))
        break
    if not isinstance(envelope, dict):
        raise RuntimeError("The immutable active pooled Network/DLI result is unavailable")
    if envelope.get("namespace") != "network_and_critic_dli_analysis":
        raise RuntimeError("The active result CID is not Network/DLI evidence")
    material = envelope.get("payload", {})
    payload = material.get("payload", {}) if isinstance(material, dict) else {}
    authority = payload.get("temporal_dli_authority", {}) if isinstance(payload, dict) else {}
    slices = payload.get("authoritative_dli_slices", {}) if isinstance(payload, dict) else {}
    weighting = payload.get("dli_weighting", {}) if isinstance(payload, dict) else {}
    weights = weighting.get("weights", {}) if isinstance(weighting, dict) else {}
    if (
        material.get("operation") != "network_and_critic_dli_analysis"
        or int(payload.get("year", -1)) != 2017
        or payload.get("input_hashes") != active_hashes
        or not bool(payload.get("pooled_critic_ready", False))
        or authority.get("method") != "one pooled two-year Pearson-CRITIC calculation"
        or authority.get("years") != [2014, 2017]
        or baseline_record.get("input_hashes") != active_hashes
        or str(
            authority.get("baseline_evidence_network_result_cid", "")
        ).strip().lower()
        != str(baseline_record.get("content_hash", "")).strip().lower()
        or not isinstance(weights, dict)
        or set(weights) != set(net.CRITERIA)
        or not all(
            math.isfinite(float(weights[criterion]))
            and float(weights[criterion]) >= 0.0
            for criterion in net.CRITERIA
        )
        or not math.isclose(
            sum(float(weights[criterion]) for criterion in net.CRITERIA),
            1.0,
            rel_tol=1e-10,
            abs_tol=1e-12,
        )
    ):
        raise RuntimeError("The active 2017 result is not authoritative pooled temporal DLI evidence")
    rows = slices.get(str(reference_year)) if isinstance(slices, dict) else None
    if not isinstance(rows, list) or not rows:
        raise RuntimeError(f"The authoritative pooled DLI slice for {reference_year} is unavailable")
    frame = pd.DataFrame(rows)
    required = {
        "year", "node_code", "region", "sector", "DLI", "dli_rank",
        *net.CRITERIA,
        *[f"{criterion}_critic_weight_contribution" for criterion in net.CRITERIA],
    }
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise RuntimeError(
            f"The authoritative pooled DLI slice for {reference_year} is incomplete: {missing}"
        )
    if not (pd.to_numeric(frame["year"], errors="coerce") == reference_year).all():
        raise RuntimeError("The authoritative pooled DLI slice contains a mismatched year")
    frame = frame.sort_values(["dli_rank", "node_code"], kind="mergesort").reset_index(drop=True)
    frame.attrs["critic_weights"] = {
        criterion: float(weights[criterion]) for criterion in net.CRITERIA
    }
    frame.attrs["source_network_result_cid"] = cid
    return frame


def _verified_node_sda_evidence() -> dict[str, Any] | None:
    """Load only hash-verified node-wise SDA evidence for the active inputs."""
    try:
        active_hashes = _active_input_hashes()
    except Exception:
        return None
    for runtime in _runtime_analytics_dirs():
        try:
            metadata = node_sda.verify_node_sda_artifacts(
                runtime, expected_input_hashes=active_hashes
            )
            artifacts = metadata.get("artifacts", {})
            all_name = artifacts.get("all_nodes", {}).get("filename", node_sda.ALL_NODES_FILENAME)
            hotspot_name = artifacts.get("hotspot_nodes", {}).get("filename", node_sda.HOTSPOTS_FILENAME)
            return {
                "runtime_dir": runtime,
                "metadata": metadata,
                "all_nodes": pd.read_csv(runtime / str(all_name)),
                "hotspot_nodes": pd.read_csv(runtime / str(hotspot_name)),
            }
        except Exception:
            continue
    return None


def _verified_hotspot_leverage_evidence() -> dict[str, Any] | None:
    """Load only hash-verified U16 hotspot-leverage evidence for active inputs."""
    try:
        active_hashes = _active_input_hashes()
    except Exception:
        return None
    for runtime in _runtime_analytics_dirs():
        try:
            metadata = hotspot_link.verify_hotspot_leverage_artifacts(
                runtime, expected_input_hashes=active_hashes
            )
            artifacts = metadata.get("artifacts", {})
            frames: dict[str, pd.DataFrame] = {}
            for key in (
                "node_summary",
                "pair_evidence",
                "direct_portfolio",
                "governance_mediated_portfolio",
                "hybrid_portfolio",
            ):
                record = artifacts.get(key, {})
                filename = str(record.get("filename", ""))
                if filename:
                    frames[key] = pd.read_csv(runtime / filename)
            return {"runtime_dir": runtime, "metadata": metadata, **frames}
        except Exception:
            continue
    return None


def _verified_intervention_governance_evidence() -> dict[str, Any] | None:
    """Load only current, post-AURORA U16 intervention-governance evidence."""
    try:
        active_hashes = _active_input_hashes()
        index = json.loads(
            (BASE_DIR / "runtime" / "result_index.json").read_text(encoding="utf-8")
        )
        network_record = index["results"]["network:2017"]
        aurora_record = index["results"]["aurora:2017"]
        if (
            network_record.get("input_hashes") != active_hashes
            or aurora_record.get("input_hashes") != active_hashes
        ):
            return None
        network_cid = str(network_record.get("content_hash", "")).strip().lower()
        aurora_cid = str(aurora_record.get("content_hash", "")).strip().lower()
        if len(network_cid) != 64 or len(aurora_cid) != 64:
            return None
    except Exception:
        return None
    for runtime in _runtime_analytics_dirs():
        try:
            metadata = intervention_gov.verify_intervention_governance_artifacts(
                runtime,
                expected_input_hashes=active_hashes,
                expected_source_network_result_cid=network_cid,
                expected_source_aurora_result_cid=aurora_cid,
            )
            return {
                "runtime_dir": runtime,
                "metadata": metadata,
                **intervention_gov.load_intervention_governance_frames(runtime),
            }
        except Exception:
            continue
    return None


def _load_dli_cached(year: int) -> pd.DataFrame:
    try:
        return _authoritative_pooled_dli_slice(year)
    except Exception as exc:
        raise RuntimeError(
            f"No authoritative pooled DLI evidence matching the active uploaded workbooks is available for {year}. "
            "Complete the governed 2014 Network baseline and 2017 Network decision requests first."
        ) from exc


def _load_dli(year: int) -> pd.DataFrame:
    return _load_dli_cached(year).copy()


def _known_node_lookup() -> dict[str, str]:
    lookup: dict[str, str] = {}
    for year in (2017, 2014):
        try:
            values = _load_dli(year)["node_code"].astype(str).tolist()
        except Exception:
            continue
        for code in values:
            lookup[code.casefold()] = code
            lookup[code.replace("-", "_").casefold()] = code
            lookup[code.replace("-", " ").casefold()] = code
    return lookup


@lru_cache(maxsize=1)
def _rag_index():
    p = _find_artifact("rag_documents.json")
    if not p:
        return [], None, None
    with open(p, encoding="utf-8") as f:
        docs = json.load(f)
    if not docs:
        return [], None, None
    texts = [
        f"{d.get('doc_type', '')} {d.get('title', '')} {d.get('text', '')}"
        for d in docs
    ]
    vectorizer = TfidfVectorizer(stop_words="english", ngram_range=(1, 2))
    matrix = vectorizer.fit_transform(texts)
    return docs, vectorizer, matrix


# ---------------------------------------------------------------------------
# Deterministic scope guard, intent extraction, and plan validation


def _detect_year(question: str) -> str:
    q = question.casefold()
    has_2014 = "2014" in q
    has_2017 = "2017" in q
    if (has_2014 and has_2017) or re.search(
        r"\b(change|changed|over time|trend|decompos)", q
    ):
        return "change"
    if has_2014:
        return "2014"
    if has_2017:
        return "2017"
    return "2017"


def _detect_top_n(question: str, default: int = 5) -> int:
    match = re.search(r"\btop\s+(\d{1,2})\b", question, flags=re.IGNORECASE)
    if not match:
        match = re.search(
            r"\b(?:first|best|highest)\s+(\d{1,2})\b",
            question,
            flags=re.IGNORECASE,
        )
    if not match:
        return default
    return max(1, min(20, int(match.group(1))))


def _extract_node_code(question: str) -> str:
    lookup = _known_node_lookup()
    q = question.casefold()
    for variant, canonical in sorted(lookup.items(), key=lambda item: len(item[0]), reverse=True):
        pattern = r"(?<![a-z0-9])" + re.escape(variant) + r"(?![a-z0-9])"
        if re.search(pattern, q):
            return canonical
    return ""


def _normalise_node_code(value: Any, question: str = "") -> str:
    fallback = _extract_node_code(question) if question else ""
    if value is None:
        return fallback
    raw = str(value).strip()
    if raw.casefold() in GENERIC_NODE_VALUES:
        return fallback
    lookup = _known_node_lookup()
    candidates = {
        raw.casefold(),
        raw.replace("_", "-").casefold(),
        raw.replace(" ", "-").casefold(),
    }
    for candidate in candidates:
        if candidate in lookup:
            return lookup[candidate]
    return fallback


def _parse_theta_value(value: Any) -> str:
    if value is None:
        return ""
    raw = str(value).strip().replace("%", "")
    if not raw or raw.casefold() in {"none", "null", "n/a", "na", "high", "low"}:
        return ""
    try:
        number = float(raw)
    except (TypeError, ValueError):
        return ""
    if number > 1.0 and number <= 100.0:
        number /= 100.0
    if not (0.0 < number <= 1.0):
        return ""
    return f"{number:.12g}"


def _detect_theta(question: str) -> str:
    q = question.casefold()
    # Theta is the focal company's share of sector demand.  Do not treat every
    # percentage in a scenario as theta: a domestic-share floor or an
    # intensity-reduction percentage belongs to a different deterministic
    # tool.  The percentage must therefore be tied explicitly to company or
    # sector demand.
    percent_patterns = [
        r"\b(?:company|focal[- ]company|sector)\s+(?:demand\s+)?share\s*(?:of|=|to|at)?\s*(\d+(?:\.\d+)?)\s*%",
        r"\b(?:represented|representing|represents?)\s*(\d+(?:\.\d+)?)\s*%\s+(?:of\s+)?(?:the\s+)?sector\s+demand\b",
        r"\b(\d+(?:\.\d+)?)\s*%\s+(?:of\s+)?(?:the\s+)?sector\s+demand\b",
        r"\btheta\s*(?:of|=|to|at)?\s*(\d+(?:\.\d+)?)\s*%",
    ]
    for pattern in percent_patterns:
        match = re.search(pattern, q)
        if match:
            return _parse_theta_value(float(match.group(1)) / 100.0)

    decimal_patterns = [
        r"\b(?:company|focal[- ]company|sector)\s+(?:demand\s+)?share\s*(?:of|=|to|at)?\s*(0\.\d+|1\.0+)\b",
        r"\btheta\s*(?:of|=|to|at)?\s*(0\.\d+|1\.0+)\b",
    ]
    for pattern in decimal_patterns:
        match = re.search(pattern, q)
        if match:
            return _parse_theta_value(match.group(1))
    if re.search(r"\b(double|doubled|twice)\b", q):
        if re.search(r"\b(company|focal[- ]company|sector)\b.{0,30}\bshare\b", q):
            return "0.02"
    return ""


def _detect_reduction_pct(question: str) -> str:
    """Extract an explicitly requested node-intensity reduction fraction."""

    q = question.casefold()
    if not re.search(
        r"\b(reduc(?:e|ed|tion)|cut|lower|decreas(?:e|ed)|intensity|clinker|substitut|electrif)\b",
        q,
    ):
        return ""
    # Percentages tied to company share or domestic-share constraints are not
    # node-intensity reductions.
    if re.search(r"\b(company|sector)\s+share\b|\bdomestic\s+(?:share|floor)\b", q):
        return ""
    match = re.search(r"(\d+(?:\.\d+)?)\s*%", q)
    if match:
        value = float(match.group(1)) / 100.0
        return f"{value:.12g}" if 0.0 < value < 1.0 else ""
    match = re.search(
        r"\b(?:reduction|cut|lower(?:ed)? by|intensity reduction)\s*(?:of|=|to|by)?\s*(0\.\d+)\b",
        q,
    )
    if match:
        value = float(match.group(1))
        return f"{value:.12g}" if 0.0 < value < 1.0 else ""
    return ""


def _is_sourcing_opportunity_question(question: str) -> bool:
    """Detect AURORA regional-opportunity and structural-analogue questions."""

    q = question.casefold()
    opportunity_signal = bool(
        re.search(
            r"\b(aurora|regional sourcing opportunit|regional alternative|"
            r"alternative region|same[- ]sector alternative|structural analogue|"
            r"production (?:behavio[u]?r|structure|profile)|"
            r"consumption (?:behavio[u]?r|pattern)|market profile|"
            r"intermediate consumption matrix|similar sector.*region|"
            r"where else could .* source|which region.*investigat|"
            r"shift to another region|regional variant)\b",
            q,
        )
    )
    generic_alternative = bool(
        re.search(r"\b(alternative suppliers?|sourcing alternatives?)\b", q)
        and re.search(r"\b(region|sector|mrio|dli|production|consumption)\b", q)
    )
    return opportunity_signal or generic_alternative


def _is_counterfactual_question(question: str, node_code: str, reduction_pct: str) -> bool:
    q = question.casefold()
    return bool(
        node_code
        and (
            reduction_pct
            or re.search(
                r"\b(counterfactual|what if|scenario|abatement|intensity scenario|"
                r"clinker substitution|electrification)\b",
                q,
            )
        )
    )


def _deterministic_scope(question: str) -> tuple[str, str]:
    """Conservative domain guard.

    The page itself is a carbon-governance application, so ambiguous questions
    default to in-scope. A question is rejected only when it is clearly unrelated
    and contains no carbon/supply-chain signal. This avoids false rejections by a
    small local model.
    """

    q = question.casefold()
    domain_patterns = [
        r"carbon",
        r"emission",
        r"footprint",
        r"decarbon",
        r"climate",
        r"sustainab",
        r"supply chain",
        r"supplier",
        r"sourcing",
        r"hotspot",
        r"\bdli\b",
        r"leverage",
        r"\bmrio\b",
        r"\bspa\b",
        r"\bsda\b",
        r"structural path",
        r"intervention",
        r"country[- ]sector",
        r"which node",
        r"network central",
        r"sector demand",
        r"upstream",
        r"governance",
    ]
    if any(re.search(pattern, q) for pattern in domain_patterns):
        return "in_scope", "carbon or supply-chain governance signal detected"

    clearly_unrelated = [
        r"area of (?:a )?circle",
        r"radius of (?:a )?circle",
        r"weather",
        r"football",
        r"cricket score",
        r"recipe",
        r"translate this",
        r"capital of [a-z]",
        r"write (?:a )?poem",
        r"medical diagnosis",
    ]
    if any(re.search(pattern, q) for pattern in clearly_unrelated):
        return "out_of_scope", "question is explicitly unrelated to the deployed domain"

    return "in_scope", "ambiguous question accepted in the domain-specific assistant"


def _tool_call(
    tool: str,
    year: str = "2017",
    node_code: str = "",
    top_n: int = 5,
    theta: str = "",
    query: str = "",
    reduction_pct: str = "",
) -> dict[str, Any]:
    return {
        "tool": tool,
        "year": year,
        "node_code": node_code,
        "top_n": max(1, min(20, int(top_n))),
        "theta": theta,
        "reduction_pct": reduction_pct,
        "query": query,
    }


def _deterministic_profile(question: str) -> dict[str, Any]:
    """Create the authoritative multi-intent profile for a user question.

    The profile distinguishes conceptual, methodological, analytical,
    strategic, and scenario needs. These labels are multi-valued: a question
    may legitimately require a definition plus deterministic computation.
    """

    q = question.casefold()
    scope, scope_reason = _deterministic_scope(question)
    year = _detect_year(question)
    node_code = _extract_node_code(question)
    top_n = _detect_top_n(question)
    theta = _detect_theta(question)
    reduction_pct = _detect_reduction_pct(question)
    knowledge_intent = knowledge.analyse_knowledge_intent(
        question,
        named_node=node_code,
    )
    intents: list[str] = []
    calls: list[dict[str, Any]] = []

    if scope == "out_of_scope":
        return {
            "scope": scope,
            "scope_reason": scope_reason,
            "year": year,
            "node_code": node_code,
            "top_n": top_n,
            "theta": theta,
            "reduction_pct": reduction_pct,
                "response_mode": "out_of_scope",
            "intents": ["out_of_scope"],
            "calls": [],
            "knowledge_intent": knowledge_intent,
        }

    concept_matches = knowledge_intent.get("concept_matches", [])
    conceptual_comparison = bool(
        len(concept_matches) >= 2
        and re.search(r"\b(compare|comparison|differ|difference|versus|vs\.?)\b", q)
        and not re.search(
            r"\b2014\b|\b2017\b|\bour\b|\bfocal[- ]company\b|\bcompany'?s\b|"
            r"\brank(?:ed|ing)?\b|\bscore\b|\bvalue\b|\bresult\b|\btop\b|"
            r"\bhighest\b|\bhow much\b|\bscenario\b|%",
            q,
        )
    )
    conceptual = bool(knowledge_intent.get("conceptual")) or conceptual_comparison
    methodological = bool(knowledge_intent.get("methodological"))

    if conceptual:
        intents.append("conceptual definition")
        calls.append(
            _tool_call(
                "concept_knowledge",
                "unspecified",
                top_n=min(4, max(1, top_n)),
                query=question,
            )
        )

    if methodological:
        intents.append("study methodology explanation")
        calls.append(
            _tool_call(
                "methodology_knowledge",
                "unspecified",
                top_n=min(4, max(1, top_n)),
                query=question,
            )
        )

    priority = bool(
        re.search(
            r"\b(which|what)\s+(?:country[- ]sector\s+)?node\b|"
            r"\b(which|what)\s+(?:supplier|sector|country[- ]sector)\b.*"
            r"\b(prioriti[sz]|target|focus|decarbon|intervene|strategic|critical)\b|"
            r"\b(best|most\s+(?:strategic|important|critical)|highest[- ]priority)\s+"
            r"(?:node|supplier|sector|country[- ]sector)\b|"
            r"prioriti[sz]|where should .*\b(focus|intervene|act|target|start)\b|"
            r"\b(greatest|highest|maximum)\s+(?:decarbonization\s+)?(?:leverage|impact)\b|"
            r"management.*\b(focus|target|prioriti[sz]|intervene)\b|"
            r"high[- ]dli.*(?:rather|versus|vs\.?|instead)",
            q,
        )
    )
    company_share_scenario = bool(theta) or bool(
        re.search(
            r"\b(company|sector)\s+share\b|\brepresented\b|\brepresenting\b|"
            r"\bdouble(?:d)?\s+(?:the\s+)?(?:company|sector)?\s*share\b",
            q,
        )
    )
    counterfactual = _is_counterfactual_question(
        question,
        node_code,
        reduction_pct,
    )
    sourcing_opportunity_question = _is_sourcing_opportunity_question(question)
    sourcing_screen_action = bool(
        sourcing_opportunity_question
        and (
            re.search(
                r"\b(which|identify|find|screen|recommend|shortlist|opportunit|"
                r"alternative regions?|shift|investigat|compare candidates?)\b",
                q,
            )
            or not (conceptual or methodological)
        )
    )
    # Empirical regional sourcing questions are handled by AURORA rather than
    # the generic whole-network priority or intervention routes. Pure definition
    # or method questions stay in the knowledge layer.
    if sourcing_screen_action:
        priority = False
    sda_mentioned = bool(
        re.search(r"\bsda\b|\bstructural decomposition(?: analysis)?\b", q)
    )
    sda_result_cue = bool(
        re.search(
            r"\b(?:show|showed|shown|finding|findings|result|results|effect|effects|"
            r"contribution|contributions|driver|drivers)\b|"
            r"\bwhat did\b|\bwhich effect\b|\bwhy did\b",
            q,
        )
    )
    change = year == "change" or bool(
        re.search(
            r"\bwhy did .*\b(change|increase|decrease)|"
            r"\bstructural decomposition\b|"
            r"\bbetween\s+2014\s+and\s+2017\b",
            q,
        )
    ) or bool(sda_mentioned and sda_result_cue and not methodological)

    explicit_result_cue = bool(
        node_code
        or re.search(
            r"\b2014\b|\b2017\b|\bour\b|\bfocal[- ]company\b|\bcompany'?s\b|"
            r"\brank(?:ed|ing)?\b|\bscore\b|\bvalue\b|\bresult\b|\bwhich\b|"
            r"\btop\b|\bhighest\b|\bhow much\b|\bchange(?:d)?\b|\bscenario\b|%",
            q,
        )
    )

    if priority:
        intents.append("cross-model node prioritization")
        priority_year = "2017" if year == "change" else year
        calls.append(_tool_call("priority_ranking", priority_year, top_n=top_n))

    if sourcing_screen_action:
        intents.append("regional sourcing opportunity screening")
        sourcing_year = "2017" if year == "change" else year
        calls.append(
            _tool_call(
                "sourcing_opportunity_analysis",
                sourcing_year,
                top_n=top_n,
            )
        )

    if counterfactual:
        intents.append("node-intensity counterfactual scenario")
        scenario_year = "2017" if year == "change" else year
        calls.append(
            _tool_call(
                "counterfactual_scenario",
                scenario_year,
                node_code=node_code,
                top_n=top_n,
                reduction_pct=reduction_pct,
            )
        )

    if company_share_scenario:
        intents.append("company-share footprint scenario")
        scenario_year = "2017" if year == "change" else year
        calls.append(
            _tool_call(
                "footprint",
                scenario_year,
                top_n=top_n,
                theta=theta,
            )
        )

    if change:
        intents.append("2014-to-2017 structural decomposition")
        calls.append(_tool_call("sda", "change", top_n=top_n))

    # A named node normally requests empirical evidence. A pure definition such
    # as "What is DLI?" must not be converted into a ranking query; conversely,
    # "What does DLI mean for ARE-nmm?" needs both concept and node evidence.
    node_interpretation = bool(
        node_code
        and re.search(
            r"\b(for|about|evidence|important|importance|strategic|profile|why|mean)\b",
            q,
        )
    )
    if node_code and not priority and not counterfactual and (
        not conceptual or node_interpretation or explicit_result_cue
    ):
        intents.append("named-node profile")
        node_year = "2017" if year == "change" else year
        calls.append(
            _tool_call(
                "node_profile",
                node_year,
                node_code=node_code,
                top_n=top_n,
            )
        )

    footprint_empirical = bool(
        re.search(r"\bfootprint\b|\bembodied carbon\b|\bupstream emissions?\b", q)
        and (not conceptual or explicit_result_cue)
    )
    if (
        footprint_empirical
        and not company_share_scenario
        and not change
       
        and not sourcing_screen_action
    ):
        intents.append("footprint accounting")
        calls.append(_tool_call("footprint", year, top_n=top_n))

    hotspot_empirical = bool(
        re.search(
            r"\bhotspots?\b|\blargest emissions?\b|\btop emissions?\b|"
            r"\bemissions? contributors?\b",
            q,
        )
        and (not conceptual or explicit_result_cue)
    )
    if hotspot_empirical and not priority and not node_code:
        intents.append("emission hotspot ranking")
        calls.append(_tool_call("hotspots", year, top_n=top_n))

    dli_empirical = bool(
        re.search(
            r"\b(dli|decarbonization leverage|network leverage|centrality|pagerank|"
            r"betweenness|dependency risk|criticality)\b",
            q,
        )
        and (not conceptual or explicit_result_cue)
    )
    temporal_dli_requested = bool(
        dli_empirical
        and re.search(
            r"\btemporal\b|\btrajectory\b|\bevolv(?:e|ed|ing|ution)\b|"
            r"\bcompare\b.*\bdli\b|\bdli\b.*\bcompare\b|"
            r"\bdli\b.*\b2014\b.*\b2017\b|\b2014\b.*\b2017\b.*\bdli\b|"
            r"\bchange(?:d|s)?\b.*\bdli\b|\bdli\b.*\bchange(?:d|s)?\b",
            q,
        )
    )
    if temporal_dli_requested and not priority and not node_code and not sourcing_screen_action:
        intents.append("2014-to-2017 temporal DLI comparison")
        calls.append(_tool_call("temporal_dli", "2017", top_n=top_n))
    elif dli_empirical and not priority and not node_code and not sourcing_screen_action:
        intents.append("network and DLI evidence")
        calls.append(_tool_call("dli", year, top_n=top_n))

    intervention_governance_empirical = bool(
        re.search(
            r"\bformal governance\b|\bgovernance[- ]ready\b|\bgovernance eligib(?:le|ility)\b|"
            r"\bactionabil(?:ity|e)\b|\bdriver[- ]compatib(?:le|ility)\b|"
            r"\bverified actionable\b|\bformal intervention options?\b",
            q,
        )
        and (not conceptual or explicit_result_cue)
    )
    if intervention_governance_empirical and not priority and not sourcing_screen_action:
        intents.append("formal intervention governance evidence")
        calls.append(
            _tool_call(
                "intervention_governance",
                "2017",
                node_code=node_code,
                top_n=top_n,
            )
        )

    intervention_empirical = bool(
        re.search(
            r"\binterventions?\b|\brecommend(?:ed|ation)?\b|"
            r"\brecommended actions?\b|what should .* do|\bmanagement actions?\b|"
            r"\bdecarbonization actions?\b|\blevers?\b",
            q,
        )
        and (not conceptual or explicit_result_cue)
    )
    if (
        intervention_empirical
        and not intervention_governance_empirical
        and not priority
        and not node_code
        and not sourcing_screen_action
    ):
        intents.append("deterministic intervention recommendation")
        calls.append(_tool_call("interventions", year, top_n=top_n))

    spa_empirical = bool(
        re.search(
            r"\bspa\b|\bstructural paths?\b|\bpathways?\b|\btiers?\b|"
            r"\bupstream paths?\b",
            q,
        )
        and (not conceptual or explicit_result_cue)
    )
    if spa_empirical and not priority and not node_code:
        intents.append("structural path evidence")
        calls.append(_tool_call("spa_paths", year, top_n=top_n))

    if not calls:
        intents.append("domain contextual retrieval")
        calls.append(
            _tool_call(
                "retrieval",
                "unspecified",
                top_n=max(4, top_n),
                query=question,
            )
        )

    mode_labels: list[str] = []
    if conceptual:
        mode_labels.append("conceptual")
    if methodological:
        mode_labels.append("methodological")
    if priority or intervention_empirical or intervention_governance_empirical or sourcing_screen_action:
        mode_labels.append("strategic")
    if company_share_scenario or counterfactual:
        mode_labels.append("scenario")
    analytical_tools = {
        "footprint",
        "hotspots",
        "sda",
        "dli",
        "priority_ranking",
        "node_profile",
        "interventions",
        "intervention_governance",
        "spa_paths",
        "counterfactual_scenario",
        "sourcing_opportunity_analysis",
        }
    if any(call["tool"] in analytical_tools for call in calls) and not (
        priority or intervention_empirical or intervention_governance_empirical or company_share_scenario or counterfactual or sourcing_screen_action
    ):
        mode_labels.append("analytical")
    unique_modes = list(dict.fromkeys(mode_labels))
    response_mode = unique_modes[0] if len(unique_modes) == 1 else "composite"
    if not unique_modes:
        response_mode = "analytical" if calls[0]["tool"] != "retrieval" else "methodological"

    return {
        "scope": scope,
        "scope_reason": scope_reason,
        "year": year,
        "node_code": node_code,
        "top_n": top_n,
        "theta": theta,
        "reduction_pct": reduction_pct,
        "response_mode": response_mode,
        "intents": intents,
        "calls": calls,
        "knowledge_intent": knowledge_intent,
    }


def _allowed_llm_tools(profile: dict[str, Any]) -> set[str]:
    """Return the union of tools relevant to the deterministic multi-intent profile."""

    intents = set(profile.get("intents", []))
    allowed: set[str] = set()
    if "conceptual definition" in intents:
        # A pure definition should not expand into a study-method explanation
        # unless the question independently contains methodology intent.
        allowed.update({"concept_knowledge", "retrieval"})
    if "study methodology explanation" in intents:
        allowed.update({"methodology_knowledge", "concept_knowledge", "retrieval"})
    if "cross-model node prioritization" in intents:
        allowed.update(
            {
                "priority_ranking",
                "hotspots",
                "dli",
                "interventions",
                "intervention_governance",
                "spa_paths",
                "methodology_knowledge",
                "retrieval",
            }
        )
    if "named-node profile" in intents:
        allowed.update(
            {
                "node_profile",
                "hotspots",
                "dli",
                "interventions",
                "intervention_governance",
                "spa_paths",
                "concept_knowledge",
                "methodology_knowledge",
                "retrieval",
            }
        )
    if "company-share footprint scenario" in intents:
        allowed.update({"footprint", "methodology_knowledge", "retrieval"})
    if "node-intensity counterfactual scenario" in intents:
        allowed.update(
            {"counterfactual_scenario", "node_profile", "methodology_knowledge", "retrieval"}
        )
    if "regional sourcing opportunity screening" in intents:
        allowed.update(
            {
                "sourcing_opportunity_analysis",
                "methodology_knowledge",
                "dli",
                "footprint",
                "retrieval",
            }
        )
    if "2014-to-2017 structural decomposition" in intents:
        allowed.update({"sda", "footprint", "methodology_knowledge", "retrieval"})
    if "emission hotspot ranking" in intents:
        allowed.update(
            {"hotspots", "dli", "interventions", "intervention_governance", "spa_paths", "concept_knowledge", "retrieval"}
        )
    if "network and DLI evidence" in intents:
        allowed.update(
            {"dli", "hotspots", "interventions", "intervention_governance", "spa_paths", "concept_knowledge", "retrieval"}
        )
    if "deterministic intervention recommendation" in intents:
        allowed.update(
            {"interventions", "intervention_governance", "dli", "hotspots", "spa_paths", "methodology_knowledge", "retrieval"}
        )
    if "formal intervention governance evidence" in intents:
        allowed.update(
            {"intervention_governance", "dli", "hotspots", "spa_paths", "methodology_knowledge", "retrieval"}
        )
    if "structural path evidence" in intents:
        allowed.update(
            {"spa_paths", "hotspots", "dli", "concept_knowledge", "retrieval"}
        )
    if "footprint accounting" in intents:
        allowed.update(
            {"footprint", "hotspots", "concept_knowledge", "methodology_knowledge", "retrieval"}
        )
    if "domain contextual retrieval" in intents:
        allowed.update({"concept_knowledge", "methodology_knowledge", "retrieval"})
    return allowed or set(VALID_TOOLS)


def _normalise_year(value: Any, default_year: str, tool: str) -> str:
    raw = str(value or "").strip()
    if raw not in {"2014", "2017", "change", "unspecified"}:
        raw = default_year
    if tool == "sda":
        return "change"
    if tool in {"concept_knowledge", "methodology_knowledge", "retrieval"}:
        return "unspecified"
    if raw in {"change", "unspecified"}:
        return "2017"
    return raw


def _normalise_call(
    call: Any,
    question: str,
    profile: dict[str, Any],
    adjustments: list[str],
) -> dict[str, Any] | None:
    if not isinstance(call, dict):
        adjustments.append("discarded a non-object LLM tool call")
        return None
    tool = str(call.get("tool", "")).strip()
    if tool not in VALID_TOOLS:
        adjustments.append(f"discarded unknown tool {tool!r}")
        return None

    # Parameters are grounded in the user's words, not invented by the LLM.
    year = _normalise_year(profile["year"], profile["year"], tool)
    node = profile.get("node_code", "")
    top_n = max(1, min(20, int(profile.get("top_n") or 5)))
    theta = profile.get("theta", "")
    reduction_pct = profile.get("reduction_pct", "")
    query = (
        question
        if tool in {"concept_knowledge", "methodology_knowledge", "retrieval"}
        else ""
    )

    llm_node = str(call.get("node_code") or "").strip()
    if llm_node and _normalise_node_code(llm_node) != node:
        adjustments.append(f"ignored ungrounded node_code {llm_node!r} from the LLM plan")
    llm_theta = str(call.get("theta") or "").strip()
    if llm_theta and _parse_theta_value(llm_theta) != theta:
        adjustments.append(f"ignored ungrounded theta {llm_theta!r} from the LLM plan")
    llm_reduction = str(call.get("reduction_pct") or "").strip()
    if llm_reduction and _parse_theta_value(llm_reduction) != reduction_pct:
        adjustments.append(
            f"ignored ungrounded reduction_pct {llm_reduction!r} from the LLM plan"
        )
    llm_year = str(call.get("year") or "").strip()
    if llm_year and _normalise_year(llm_year, profile["year"], tool) != year:
        adjustments.append(f"ignored ungrounded year {llm_year!r} from the LLM plan")
    if call.get("top_n") not in (None, "", top_n):
        try:
            if int(call.get("top_n")) != top_n:
                adjustments.append(
                    "replaced LLM top_n with the value extracted from the question"
                )
        except (TypeError, ValueError):
            adjustments.append(
                "replaced invalid LLM top_n with the value extracted from the question"
            )

    if tool == "node_profile" and not node:
        if "cross-model node prioritization" in profile["intents"]:
            adjustments.append(
                "converted node_profile without an exact node code to priority_ranking"
            )
            tool = "priority_ranking"
        else:
            adjustments.append(
                "discarded node_profile because no valid country-sector code was supplied"
            )
            return None
    if tool == "counterfactual_scenario" and not node:
        adjustments.append(
            "discarded counterfactual_scenario because no valid country-sector code was supplied"
        )
        return None

    allowed_tools = _allowed_llm_tools(profile)
    if tool not in allowed_tools:
        adjustments.append(
            f"discarded LLM tool {tool!r} because it was not relevant to the deterministic intent"
        )
        return None

    if tool != "footprint":
        theta = ""
    if tool != "counterfactual_scenario":
        reduction_pct = ""
    if tool not in {
        "node_profile",
        "hotspots",
        "dli",
        "interventions",
        "intervention_governance",
        "spa_paths",
        "counterfactual_scenario",
    }:
        node = ""

    return _tool_call(
        tool,
        year,
        node,
        top_n,
        theta,
        query,
        reduction_pct,
    )


def _merge_calls(calls: list[dict[str, Any]]) -> list[dict[str, Any]]:
    merged: dict[tuple[Any, ...], dict[str, Any]] = {}
    for call in calls:
        key = (
            call["tool"],
            call["year"],
            call["node_code"],
            call["theta"],
            call.get("reduction_pct", ""),
            call["query"]
            if call["tool"] in {"concept_knowledge", "methodology_knowledge", "retrieval"}
            else "",
        )
        if key in merged:
            merged[key]["top_n"] = max(merged[key]["top_n"], call["top_n"])
        else:
            merged[key] = dict(call)
    return list(merged.values())[:8]


def _finalise_plan(
    question: str,
    profile: dict[str, Any],
    raw_llm_plan: dict[str, Any] | None,
    llm_status: str,
    llm_error: str = "",
) -> dict[str, Any]:
    if profile["scope"] == "out_of_scope":
        return {
            "scope": "out_of_scope",
            "response_mode": "out_of_scope",
            "intent": "out-of-domain request",
            "tool_calls": [],
            "planner_validation": {
                "mode": "deterministic domain guard",
                "scope_reason": profile["scope_reason"],
                "llm_status": "not_called",
                "adjustments": [],
            },
        }

    adjustments: list[str] = []
    llm_calls: list[dict[str, Any]] = []
    if isinstance(raw_llm_plan, dict):
        for call in raw_llm_plan.get("tool_calls", []) or []:
            normalised = _normalise_call(call, question, profile, adjustments)
            if normalised is not None:
                llm_calls.append(normalised)

    mandatory_calls = list(profile["calls"])
    calls = _merge_calls(mandatory_calls + llm_calls)

    if "cross-model node prioritization" in profile["intents"] and not any(
        call["tool"] == "priority_ranking" for call in calls
    ):
        calls.insert(
            0,
            _tool_call(
                "priority_ranking",
                "2017" if profile["year"] == "change" else profile["year"],
                top_n=profile["top_n"],
            ),
        )
        calls = _merge_calls(calls)
        adjustments.append("added mandatory priority_ranking evidence")

    if not calls:
        calls = [
            _tool_call(
                "retrieval",
                "unspecified",
                top_n=max(4, profile["top_n"]),
                query=question,
            )
        ]
        adjustments.append("added retrieval fallback because no valid call remained")

    raw_intent = ""
    if isinstance(raw_llm_plan, dict):
        raw_intent = str(raw_llm_plan.get("intent", "")).strip()
    intent = "; ".join(profile["intents"])

    knowledge_intent = profile.get("knowledge_intent", {})
    validation = {
        "mode": "intent-aware deterministic guard plus local LLM augmentation",
        "scope_reason": profile["scope_reason"],
        "response_mode": profile.get("response_mode", "analytical"),
        "deterministic_intents": profile["intents"],
        "mandatory_tools": [call["tool"] for call in mandatory_calls],
        "matched_concepts": [
            row.get("id") for row in knowledge_intent.get("concept_matches", [])
        ],
        "matched_methodologies": [
            row.get("id") for row in knowledge_intent.get("methodology_matches", [])
        ],
        "llm_status": llm_status,
        "adjustments": adjustments,
    }
    if raw_intent:
        validation["llm_proposed_intent"] = raw_intent
    if llm_error:
        validation["llm_error"] = llm_error
    if raw_llm_plan is not None:
        validation["raw_llm_plan"] = raw_llm_plan

    return {
        "scope": "in_scope",
        "response_mode": profile.get("response_mode", "analytical"),
        "intent": intent,
        "tool_calls": calls,
        "planner_validation": validation,
    }


def plan_query(client, question: str) -> dict[str, Any]:
    """Build a validated hybrid plan.

    Deterministic rules establish scope and mandatory evidence. The local LLM may
    add useful tools, but its output is validated and cannot veto the baseline.
    """

    profile = _deterministic_profile(question)
    if profile["scope"] == "out_of_scope":
        return _finalise_plan(question, profile, None, "not_called")

    system = (
        "You propose optional tool additions for a focal-company Strategic Carbon Intelligence assistant. "
        "A deterministic layer has already established domain scope, response mode, parameters, and mandatory tools. "
        "Do not remove or contradict those tools and do not calculate any result. Return only JSON matching the schema. "
        "Use concept_knowledge for definitions such as 'What is carbon accounting?' or 'What is DLI?'. "
        "Use methodology_knowledge for how the study calculates, implements, validates, or limits a method. "
        "Do not answer a definition question by retrieving year-specific analytical summaries. "
        "Use priority_ranking for whole-network management prioritization; node_profile only when an exact node code is named; "
        "sda for 2014-to-2017 change; footprint for footprint values or company-share scaling; hotspots for magnitude rankings; "
        "dli for leverage rankings; interventions and intervention_governance for the same hash-verified hotspot-driver-path-linkage-actionability governance funnel; spa_paths for pathways; counterfactual_scenario for an explicitly "
        "named node and reduction scenario; sourcing_opportunity_analysis for same-sector regional analogues using production, market, linkage, carbon and DLI evidence; and retrieval only for "
        "context not already covered by the curated concept or methodology tools. Never invent a year, node, percentage."
    )
    knowledge_intent = profile.get("knowledge_intent", {})
    planner_input = {
        "question": question,
        "detected_context": {
            "response_mode": profile.get("response_mode"),
            "year": profile["year"],
            "named_node": profile["node_code"] or None,
            "theta": profile["theta"] or None,
            "reduction_pct": profile.get("reduction_pct") or None,
            "deterministic_intents": profile["intents"],
            "mandatory_tools": [call["tool"] for call in profile["calls"]],
            "matched_concepts": [
                row.get("id") for row in knowledge_intent.get("concept_matches", [])
            ],
            "matched_methodologies": [
                row.get("id")
                for row in knowledge_intent.get("methodology_matches", [])
            ],
        },
        "examples": [
            {
                "question": "What is carbon accounting?",
                "tool_calls": [{"tool": "concept_knowledge"}],
            },
            {
                "question": "How is carbon accounting implemented in this study?",
                "tool_calls": [{"tool": "methodology_knowledge"}],
            },
            {
                "question": "What is DLI, and which node ranks highest in 2017?",
                "tool_calls": [
                    {"tool": "concept_knowledge"},
                    {"tool": "priority_ranking", "year": "2017"},
                ],
            },
            {
                "question": "What is the DLI of ARE-nmm?",
                "tool_calls": [
                    {"tool": "node_profile", "year": "2017", "node_code": "ARE-nmm"}
                ],
            },
            {
                "question": "What if ARE-nmm emissions intensity fell by 30%?",
                "tool_calls": [
                    {
                        "tool": "counterfactual_scenario",
                        "year": "2017",
                        "node_code": "ARE-nmm",
                        "reduction_pct": "0.30",
                    }
                ],
            },
            {
                "question": "Which same-sector regional alternatives should the company investigate based on production and consumption behaviour, carbon multipliers and DLI?",
                "tool_calls": [
                    {
                        "tool": "sourcing_opportunity_analysis",
                        "year": "2017"
                    }
                ],
            },
        ],
    }

    model = os.getenv("OLLAMA_PLANNER_MODEL", client.model)
    try:
        raw = client.chat_json(
            system,
            json.dumps(planner_input, indent=2),
            PLANNER_SCHEMA,
            model=model,
            num_predict=600,
            temperature=0.0,
        )
        return _finalise_plan(question, profile, raw, "ok")
    except Exception as exc:
        return _finalise_plan(
            question,
            profile,
            None,
            "fallback",
            str(exc),
        )


# ---------------------------------------------------------------------------
# Validated deterministic tools


def _year(value: str) -> int:
    return int(value) if value in {"2014", "2017"} else 2017


def tool_footprint(year: int, theta: str = "") -> dict:
    """Return the baseline footprint from the uploaded USD demand vector.

    The direct proxy-company model contains no company-share/theta parameter.
    The optional ``theta`` argument is retained only for backward-compatible
    request parsing and is rejected rather than used to rescale the demand.
    """
    my, company_y = _load_year_inputs(year)
    out = {
        "year": year,
        "company_demand_total": float(company_y.sum()),
        "company_demand_unit": "USD",
        "company_footprint": my.footprint(company_y),
        "company_footprint_unit": "t CO2",
        "economy_wide_footprint": my.footprint(my.Y_economy),
        "economy_wide_footprint_unit": "Mt CO2",
        "scaling_rule": "none; uploaded Company_<year>_USD values are used directly",
    }
    if theta:
        out["scenario_error"] = (
            "Company-share/theta scaling is disabled for the direct proxy-company demand model. "
            "Use a sourced node-intensity scenario instead."
        )
    return out


def tool_hotspots(year: int, top_n: int = 5, node_code: str = "") -> dict:
    my, company_y = _load_year_inputs(year)
    if node_code:
        full = my.hotspots(company_y, top=len(my.node_codes)).copy()
        full["hotspot_rank"] = range(1, len(full) + 1)
        row = full[full["node_code"].str.upper() == node_code.upper()]
        return {
            "year": year,
            "requested_node": node_code,
            "node": row.to_dict(orient="records"),
        }
    df = my.hotspots(company_y, top=top_n).copy()
    df["hotspot_rank"] = range(1, len(df) + 1)
    return {"year": year, "top_hotspots": df.to_dict(orient="records")}


def tool_sda() -> dict:
    my14, company_y14 = _load_year_inputs(2014)
    my17, company_y17 = _load_year_inputs(2017)
    company14 = sda.SDAInputs.from_year(my14, company_y14)
    company17 = sda.SDAInputs.from_year(my17, company_y17)
    economy14 = sda.SDAInputs.from_year(my14, my14.Y_economy)
    economy17 = sda.SDAInputs.from_year(my17, my17.Y_economy)
    result = {
        "company_effects": sda.sda_decompose(company14, company17),
        "company_footprint_2014": company14.footprint(),
        "company_footprint_2017": company17.footprint(),
        "company_net_change": company17.footprint() - company14.footprint(),
        "economy_wide_effects_context": sda.sda_decompose(economy14, economy17),
        "interpretation_rule": (
            "Company SDA provides the total four-factor change. Authoritative node-wise SDA "
            "attributes the same effects to producer nodes; economy-wide SDA is contextual and "
            "path-level SDA remains a secondary bounded-path mechanism drill-down."
        ),
    }
    evidence = _verified_node_sda_evidence()
    if evidence is None:
        result["node_wise_sda_status"] = (
            "No hash-verified node-wise SDA matching the active workbooks is available. "
            "Complete the governed SDA request first."
        )
        return result

    metadata = evidence["metadata"]
    hotspot_frame = evidence["hotspot_nodes"].copy()
    columns = [
        name
        for name in [
            "node_code",
            "region",
            "sector",
            "comparison_hotspot_rank",
            "comparison_footprint_contribution_tco2",
            "comparison_share_of_company_footprint",
            "node_footprint_change_tco2",
            "node_delta_intensity",
            "node_delta_technology",
            "node_delta_composition",
            "node_delta_scale",
            "node_delta_demand",
            "node_dominant_driver",
            "node_dominant_driver_family",
            "node_temporal_status",
            "node_has_offsetting_drivers",
        ]
        if name in hotspot_frame.columns
    ]
    result["node_wise_sda"] = {
        "extension_id": metadata.get("extension_id"),
        "method": metadata.get("method"),
        "factor_names": metadata.get("factor_names"),
        "node_count": metadata.get("node_count"),
        "top80_hotspot_count": metadata.get("comparison_hotspot_count"),
        "top80_hotspot_coverage": metadata.get("comparison_hotspot_coverage"),
        "maximum_row_reconciliation_residual_tco2": metadata.get(
            "maximum_row_reconciliation_residual_tco2"
        ),
        "maximum_column_reconciliation_residual_tco2": metadata.get(
            "maximum_column_reconciliation_residual_tco2"
        ),
        "top80_hotspot_node_drivers": hotspot_frame[columns].head(20).to_dict(orient="records"),
        "authority_boundary": (
            "The signed four-factor node effects are authoritative temporal attribution. "
            "The dominant-driver label is descriptive; node-wise SDA does not enter DLI."
        ),
    }
    return result


def tool_dli(year: int, top_n: int = 5, node_code: str = "") -> dict:
    df = _load_dli(year).copy()
    df["dli_rank"] = range(1, len(df) + 1)
    cols = [
        c
        for c in [
            "node_code",
            "region",
            "sector",
            "dli_rank",
            "BC_norm_critic",
            "PR_norm_critic",
            "CDR_norm_critic",
            "IC_norm_critic",
            "DLI",
        ]
        if c in df.columns
    ]
    if node_code:
        row = df[df["node_code"].str.upper() == node_code.upper()]
        return {
            "year": year,
            "requested_node": node_code,
            "node": row[cols].to_dict(orient="records"),
        }
    return {"year": year, "top_dli": df.head(top_n)[cols].to_dict(orient="records")}


def tool_temporal_dli(top_n: int = 10) -> dict:
    """Deterministic 2014-to-2017 governance-leverage comparison."""
    df14 = _load_dli(2014)
    df17 = _load_dli(2017)
    temporal = net.compute_temporal_dli(df14, df17, base_year=2014, comparison_year=2017)
    counts = temporal["two_period_status"].value_counts().to_dict()
    current = temporal.sort_values("dli_rank_2017").head(top_n)
    rising = temporal.sort_values("delta_DLI", ascending=False).head(top_n)
    falling = temporal.sort_values("delta_DLI", ascending=True).head(top_n)
    cols = [
        "node_code", "region", "sector", "DLI_2014", "dli_rank_2014",
        "DLI_2017", "dli_rank_2017", "delta_DLI", "rank_change",
        "two_period_status",
        "delta_BC_contribution", "delta_PR_contribution",
        "delta_CDR_contribution", "delta_IC_contribution",
    ]
    return {
        "base_year": 2014,
        "comparison_year": 2017,
        "annual_dli_rule": "2014 and 2017 are scored on one pooled min-max scale using a common Pearson-CRITIC weight vector",
        "temporal_dli_rule": "score changes therefore reflect metric changes rather than a changing annual weighting system",
        "dli_weighting_method": "pooled Pearson-CRITIC only",
        "dli_weights": dict(df17.attrs.get("critic_weights", {})),
        "two_period_status_counts": counts,
        "current_2017_priorities_with_trajectory": current[cols].to_dict(orient="records"),
        "largest_increases": rising[cols].to_dict(orient="records"),
        "largest_decreases": falling[cols].to_dict(orient="records"),
    }


def tool_interventions(year: int, top_n: int = 5, node_code: str = "") -> dict:
    """Compatibility alias for the single U16 formal intervention funnel.

    U16 deliberately retires top-DLI sector-rule intervention generation. The
    assistant can explain only hash-verified governance evidence and cannot
    turn a DLI rank into an intervention recommendation.
    """
    result = tool_intervention_governance(year=year, top_n=top_n, node_code=node_code)
    return {
        **result,
        "legacy_top_dli_intervention_authority": False,
        "selection_boundary": (
            "DLI screens systemic leverage only. Formal intervention evidence must connect a producer hotspot, "
            "its signed node-SDA adverse driver, path mechanism evidence, positive producer linkage, and verified actionability."
        ),
    }


def tool_intervention_governance(
    year: int = 2017,
    top_n: int = 10,
    node_code: str = "",
) -> dict:
    """Return hash-verified U16 intervention-governance evidence.

    The LLM may explain deterministic records but cannot calculate or alter
    MRIO/SDA/DLI/linkage results, assign actionability, or promote an option.
    """
    if int(year) != 2017:
        return {
            "year": year,
            "status": "not_applicable",
            "message": "Formal intervention governance is defined for the 2017 decision year.",
        }
    evidence = _verified_intervention_governance_evidence()
    if evidence is None:
        return {
            "year": 2017,
            "status": "unavailable",
            "message": (
                "No hash-verified intervention evidence matching the active inputs is available. "
                "Complete SPA 2014/2017, SDA 2014-2017, Network 2014, and Network 2017."
            ),
        }
    eligibility = evidence.get("eligibility", pd.DataFrame()).copy()
    options = evidence.get("governance_options", pd.DataFrame()).copy()
    portfolio = evidence.get("governance_ready", pd.DataFrame()).copy()
    node_actionability = evidence.get("node_actionability", pd.DataFrame()).copy()
    pair_feasibility = evidence.get("pair_feasibility", pd.DataFrame()).copy()
    if node_code:
        code = node_code.upper()
        eligibility = eligibility.loc[
            eligibility.get("intervention_node", pd.Series(dtype=str)).astype(str).str.upper().eq(code)
        ]
        options = options.loc[
            options.get("node_code", pd.Series(dtype=str)).astype(str).str.upper().eq(code)
        ]
        portfolio = portfolio.loc[
            portfolio.get("intervention_node", pd.Series(dtype=str)).astype(str).str.upper().eq(code)
        ]
        node_actionability = node_actionability.loc[
            node_actionability.get("intervention_node", pd.Series(dtype=str)).astype(str).str.upper().eq(code)
        ]
        candidate_ids = set(eligibility.get("candidate_id", pd.Series(dtype=str)).astype(str))
        pair_feasibility = pair_feasibility.loc[
            pair_feasibility.get("candidate_id", pd.Series(dtype=str)).astype(str).isin(candidate_ids)
        ]
    pair_columns = [column for column in [
        "candidate_id", "intervention_node", "hotspot_producer_node", "intervention_route",
        "intervention_DLI", "intervention_dli_rank", "baseline_hotspot_footprint_tco2",
        "avoided_hotspot_footprint_tco2", "hotspot_reduction_fraction",
        "hotspot_primary_adverse_driver", "hotspot_primary_adverse_effect_tco2",
        "hotspot_primary_beneficial_driver", "hotspot_primary_beneficial_effect_tco2",
        "hotspot_intensity_effect_tco2", "hotspot_technology_effect_tco2",
        "hotspot_composition_effect_tco2", "hotspot_scale_effect_tco2",
        "represented_path_link_status", "represented_path_primary_adverse_driver",
        "represented_path_change_tco2", "pathway_mechanism_note",
        "recommended_action", "mechanism_mapping_status", "assessment_status",
        "governance_eligibility_status", "evidence_reference",
    ] if column in eligibility.columns]
    option_columns = [column for column in [
        "node_code", "mechanism_code", "dli_rank", "dli_score", "category", "action", "channel",
        "driven_by", "beneficial_drivers_to_preserve", "pathway_mechanism_evidence",
        "intervention_route", "hotspot_targets",
        "cumulative_governance_supported_hotspot_coverage",
        "cumulative_governance_supported_company_coverage", "option_cid",
        "governance_eligibility_status", "claim_boundary",
    ] if column in options.columns]
    portfolio_columns = [column for column in [
        "selection_step", "intervention_node", "DLI", "dli_rank", "eligible_hotspots",
        "governance_supported_marginal_reduction_tco2",
        "cumulative_governance_supported_hotspot_coverage",
        "cumulative_governance_supported_company_coverage", "stop_boundary",
    ] if column in portfolio.columns]
    metadata = evidence["metadata"]
    return {
        "year": 2017,
        "requested_node": node_code or None,
        "status": "verified",
        "candidate_evidence": eligibility[pair_columns].head(top_n).to_dict(orient="records"),
        "node_actionability": node_actionability.head(top_n).to_dict(orient="records"),
        "pair_mechanism_feasibility": pair_feasibility.head(top_n).to_dict(orient="records"),
        "governance_ready_portfolio": portfolio[portfolio_columns].head(top_n).to_dict(orient="records"),
        "governance_ready_options": options[option_columns].head(top_n).to_dict(orient="records"),
        "governance_ready_option_count": int(metadata.get("governance_ready_option_count", 0)),
        "eligibility_status_counts": metadata.get("eligibility_status_counts", {}),
        "portfolio_summary": metadata.get("portfolio_summary", {}),
        "path_identity_rule": metadata.get("path_identity_rule"),
        "authority_boundary": (
            "The LLM explains only hash-verified evidence. It cannot create numerical results, infer actionability, "
            "change mechanism mapping, or declare an unlisted option governance eligible."
        ),
        "abatement_boundary": metadata.get("abatement_boundary"),
    }


def tool_spa_paths(year: int, top_n: int = 5, node_code: str = "") -> dict:
    df = _runtime_frame("spa", year)
    if df is None:
        return {
            "year": year,
            "error": (
                "No SPA evidence matching the active uploaded workbooks is available. "
                "Run the Structural Path Analysis blockchain request first."
            ),
        }
    if node_code:
        mask = df["path_codes"].astype(str).str.contains(
            node_code,
            case=False,
            regex=False,
        )
        df = df[mask]
    cols = [
        c
        for c in ["depth", "path_codes", "contribution", "cumulative_share"]
        if c in df.columns
    ]
    return {
        "year": year,
        "requested_node": node_code or None,
        "top_paths": df.head(top_n)[cols].to_dict(orient="records"),
    }


def tool_priority_ranking(year: int, top_n: int = 5) -> dict:
    """Return DLI screening plus U16 route-diagnostic carbon relevance evidence.

    DLI remains the authoritative network-wide systemic-leverage ranking. The
    direct, mediated, and hybrid route tables are diagnostics only; the single
    U16 actionability-gated governance funnel is the formal intervention authority.
    """

    my, company_y = _load_year_inputs(year)
    dli = _load_dli(year).copy()
    dli["dli_rank"] = range(1, len(dli) + 1)

    hotspots = my.hotspots(company_y, top=len(my.node_codes)).copy()
    hotspots["hotspot_rank"] = range(1, len(hotspots) + 1)

    candidates = dli.head(top_n).merge(
        hotspots[
            [
                "node_code",
                "hotspot_rank",
                "footprint_contribution",
                "share_of_total",
            ]
        ],
        on="node_code",
        how="left",
    )
    candidate_cols = [
        "node_code",
        "region",
        "sector",
        "dli_rank",
        "DLI",
        "BC_norm",
        "PR_norm",
        "CDR_norm",
        "IC_norm",
        "hotspot_rank",
        "footprint_contribution",
        "share_of_total",
    ]
    candidate_cols = [name for name in candidate_cols if name in candidates.columns]
    candidate_records = candidates[candidate_cols].to_dict(orient="records")
    recommended = dict(candidate_records[0]) if candidate_records else {}
    recommended_code = str(recommended.get("node_code", ""))
    spa_support = (
        tool_spa_paths(year, top_n=5, node_code=recommended_code).get("top_paths", [])
        if recommended_code
        else []
    )
    recommended["spa_support"] = spa_support
    recommended["interpretation_boundary"] = (
        "Highest DLI identifies the leading systemic-leverage screening result; it is not by "
        "itself evidence of the largest emissions reduction or focal-company actionability."
    )

    output = {
        "year": year,
        "selection_rule": (
            "Use DLI only to screen network-wide systemic leverage. Formal intervention selection separately requires "
            "dominant producer-hotspot relevance, signed node-SDA adverse-driver evidence, union path-SDA mechanism context, "
            "positive producer linkage, and stakeholder-verified actionability. No additional weighted score is created."
        ),
        "recommended_node": recommended,
        "top_dli_screening_candidates": candidate_records,
        "dli_weighting_method": "pooled Pearson-CRITIC only",
        "dli_weights": ({row["criterion"]: float(row["critic_weight"]) for row in pd.read_csv(BASE_DIR / "runtime" / "active_analytics" / "critic_authoritative_weights.csv").to_dict(orient="records")} if (BASE_DIR / "runtime" / "active_analytics" / "critic_authoritative_weights.csv").is_file() else {}),
        "methodological_note": (
            "DLI retains only normalized BC, PR, CDR and IC under one pooled Pearson-CRITIC weight vector. "
            "Node-wise SDA, HSI and portfolio coverage are separate explanatory/selection evidence and do not enter DLI. Structural coverage is not predicted or guaranteed abatement."
        ),
    }

    linkage = _verified_hotspot_leverage_evidence() if int(year) == 2017 else None
    if linkage is None:
        output["hotspot_leverage_status"] = (
            "No hash-verified hotspot-leverage route diagnostic matching the active inputs is available for this year. "
            "Complete governed node-wise SDA and 2017 pooled Network/DLI first."
        )
        return output

    metadata = linkage["metadata"]
    portfolio_output: dict[str, Any] = {}
    frame_keys = {
        "direct": "direct_portfolio",
        "governance_mediated": "governance_mediated_portfolio",
        "hybrid": "hybrid_portfolio",
    }
    summaries = {str(row.get("portfolio")): row for row in metadata.get("portfolio_summaries", [])}
    for label, frame_key in frame_keys.items():
        frame = linkage.get(frame_key, pd.DataFrame()).copy()
        columns = [
            name
            for name in [
                "selection_step",
                "intervention_node",
                "intervention_region",
                "intervention_sector",
                "DLI",
                "dli_rank",
                "is_direct_hotspot_node",
                "marginal_hotspot_structural_reduction_tco2",
                "cumulative_hotspot_structural_reduction_tco2",
                "cumulative_hotspot_structural_coverage",
                "cumulative_company_structural_coverage",
                "hotspot_set_share_of_company_footprint",
                "top_marginally_affected_hotspots",
                "claim_boundary",
            ]
            if name in frame.columns
        ]
        portfolio_output[label] = {
            "summary": summaries.get(label, {}),
            "selected_nodes": frame[columns].to_dict(orient="records"),
        }
    output["route_diagnostic_structural_portfolios"] = portfolio_output
    output["hotspot_leverage_boundaries"] = {
        "hotspot_definition": "smallest comparison-year producer-origin set reaching at least 80% of focal-company footprint",
        "overlap_control": "each next node is evaluated by exact marginal joint counterfactual coverage, not by adding individual CDR values",
        "claim_boundary": metadata.get("abatement_boundary"),
        "actionability_boundary": metadata.get("actionability_boundary"),
        "optimality_boundary": metadata.get("selection_boundary"),
    }
    return output


def tool_node_profile(year: int, node_code: str) -> dict:
    if not node_code:
        return {"error": "node_profile requires an exact node_code"}
    output = {
        "year": year,
        "node_code": node_code,
        "dli": tool_dli(year, node_code=node_code),
        "hotspot": tool_hotspots(year, node_code=node_code),
        "intervention": tool_interventions(year, top_n=20, node_code=node_code),
        "paths": tool_spa_paths(year, top_n=5, node_code=node_code),
    }

    node_evidence = _verified_node_sda_evidence()
    if node_evidence is not None:
        frame = node_evidence["all_nodes"]
        row = frame.loc[frame["node_code"].astype(str).str.upper() == node_code.upper()].copy()
        columns = [
            name
            for name in [
                "node_code",
                "region",
                "sector",
                "base_footprint_contribution_tco2",
                "comparison_footprint_contribution_tco2",
                "comparison_hotspot_rank",
                "in_comparison_top_80_hotspot_set",
                "node_footprint_change_tco2",
                "node_delta_intensity",
                "node_delta_technology",
                "node_delta_composition",
                "node_delta_scale",
                "node_delta_demand",
                "node_dominant_driver",
                "node_dominant_driver_family",
                "node_primary_adverse_driver",
                "node_primary_adverse_effect_tco2",
                "node_secondary_adverse_drivers",
                "node_primary_beneficial_driver",
                "node_primary_beneficial_effect_tco2",
                "node_secondary_beneficial_drivers",
                "node_driver_pattern",
                "node_temporal_status",
                "node_has_offsetting_drivers",
            ]
            if name in row.columns
        ]
        output["authoritative_node_wise_sda"] = row[columns].to_dict(orient="records")
        output["node_sda_boundary"] = (
            "Signed four-factor producer-node SDA is authoritative temporal attribution; "
            "path-level SDA is secondary and node SDA does not enter DLI."
        )
    else:
        output["node_sda_status"] = "No verified node-wise SDA matching the active inputs is available."

    linkage = _verified_hotspot_leverage_evidence() if int(year) == 2017 else None
    if linkage is not None:
        summary = linkage.get("node_summary", pd.DataFrame())
        summary_row = summary.loc[
            summary.get("intervention_node", pd.Series(dtype=str)).astype(str).str.upper() == node_code.upper()
        ].copy() if not summary.empty else pd.DataFrame()
        summary_cols = [
            name
            for name in [
                "hsi_rank",
                "intervention_node",
                "DLI",
                "dli_rank",
                "dli_level",
                "is_high_dli_upper_quartile",
                "is_direct_hotspot_node",
                "hotspot_structural_influence_tco2",
                "hotspot_structural_influence_fraction",
                "affected_hotspot_count",
                "top_structurally_linked_hotspots",
                "intervention_route",
            ]
            if name in summary_row.columns
        ]
        output["hotspot_leverage_summary"] = summary_row[summary_cols].to_dict(orient="records")

        pairs = linkage.get("pair_evidence", pd.DataFrame())
        if not pairs.empty and "intervention_node" in pairs.columns:
            pair_rows = pairs.loc[
                pairs["intervention_node"].astype(str).str.upper() == node_code.upper()
            ].copy()
            if "avoided_hotspot_footprint_tco2" in pair_rows.columns:
                pair_rows = pair_rows.sort_values(
                    ["avoided_hotspot_footprint_tco2", "hotspot_rank"],
                    ascending=[False, True],
                    kind="mergesort",
                )
            pair_cols = [
                name
                for name in [
                    "hotspot_producer_node",
                    "hotspot_rank",
                    "baseline_hotspot_footprint_tco2",
                    "avoided_hotspot_footprint_tco2",
                    "hotspot_reduction_fraction",
                    "share_of_top80_hotspot_footprint",
                    "hotspot_node_change_tco2",
                    "hotspot_intensity_effect_tco2",
                    "hotspot_technology_effect_tco2",
                    "hotspot_composition_effect_tco2",
                    "hotspot_scale_effect_tco2",
                    "hotspot_dominant_driver",
                    "hotspot_dominant_driver_family",
                    "claim_boundary",
                ]
                if name in pair_rows.columns
            ]
            output["linked_top80_hotspot_evidence"] = pair_rows[pair_cols].head(10).to_dict(orient="records")

        membership: dict[str, list[dict[str, Any]]] = {}
        for label, key in (
            ("direct", "direct_portfolio"),
            ("governance_mediated", "governance_mediated_portfolio"),
            ("hybrid", "hybrid_portfolio"),
        ):
            frame = linkage.get(key, pd.DataFrame())
            if frame.empty or "intervention_node" not in frame.columns:
                membership[label] = []
                continue
            selected = frame.loc[
                frame["intervention_node"].astype(str).str.upper() == node_code.upper()
            ]
            membership[label] = selected.to_dict(orient="records")
        output["structural_portfolio_membership"] = membership
        output["hotspot_leverage_boundary"] = (
            "Producer-resolved complete-node-removal coverage is a structural diagnostic, not "
            "predicted or guaranteed abatement; focal-company actionability is assessed separately."
        )
    else:
        output["hotspot_leverage_status"] = "No verified 2017 hotspot-leverage evidence matching the active inputs is available."
    return output


def tool_concept_knowledge(query: str, top_n: int = 3) -> dict:
    matches = knowledge.match_concepts(query, top_n=max(1, min(5, top_n)))
    return {
        "query": query,
        "evidence_class": "conceptual definition",
        "matches": matches,
        "note": (
            "These records are curated domain definitions. They explain concepts but do not "
            "replace deterministic study results."
        ),
    }


def tool_methodology_knowledge(query: str, top_n: int = 3) -> dict:
    # Use the same curated concept-to-method links as the intent analyser so
    # concise questions such as "How is AURORA implemented?" cannot be displaced
    # by a weak TF-IDF neighbour from another method.
    analysed = knowledge.analyse_knowledge_intent(query)
    matches = analysed.get("methodology_matches", [])[: max(1, min(5, top_n))]
    if not matches:
        matches = knowledge.match_methodologies(query, top_n=max(1, min(5, top_n)))
    return {
        "query": query,
        "evidence_class": "study methodology",
        "matches": matches,
        "note": (
            "These records describe the deployed study design and module boundaries. "
            "Numerical outputs remain the responsibility of the deterministic engines."
        ),
    }


def tool_counterfactual_scenario(
    year: int,
    node_code: str,
    reduction_pct: str = "",
) -> dict:
    if not node_code:
        return {
            "year": year,
            "error": "counterfactual_scenario requires an exact country-sector node code",
        }
    my, company_y = _load_year_inputs(year)
    clean_reduction = _parse_theta_value(reduction_pct)
    if clean_reduction:
        reduction = float(clean_reduction)
        if not 0.0 < reduction < 1.0:
            return {
                "year": year,
                "node_code": node_code,
                "error": "reduction_pct must be greater than 0 and less than 1",
            }
        result = scenario.counterfactual_footprint(
            my,
            company_y,
            node_code,
            reduction,
        )
        result.update(
            {
                "year": year,
                "scenario_source": "user-specified node-intensity reduction",
                "interpretation_rule": (
                    "Only the selected node's environmental intensity changes; the Leontief "
                    "structure and company demand are held fixed. This is a comparative-static "
                    "accounting scenario, not a forecast."
                ),
            }
        )
        return result

    library_results = scenario.run_scenario_library(my, company_y, node_code)
    return {
        "year": year,
        "node_code": node_code,
        "scenario_source": "deterministic sourced scenario library",
        "scenarios": library_results,
        "not_yet_sourced": scenario.NOT_YET_SOURCED if not library_results else [],
        "interpretation_rule": (
            "Each scenario changes only the selected node's environmental intensity while "
            "holding the reference-year production structure and company demand fixed."
        ),
    }


def tool_sourcing_opportunity_analysis(year: int, top_n: int = 5) -> dict:
    """Return the fulfilled, hash-verified AURORA result used by governance."""

    year = int(year)
    if year != 2017:
        raise RuntimeError("Governed AURORA decision intelligence is available for 2017")
    active_hashes = _active_input_hashes()
    result_index_path = BASE_DIR / "runtime" / "result_index.json"
    try:
        index = json.loads(result_index_path.read_text(encoding="utf-8"))
        aurora_record = index["results"]["aurora:2017"]
        network_record = index["results"]["network:2017"]
    except Exception as exc:
        raise RuntimeError(
            "No fulfilled AURORA result is indexed for the active deployment"
        ) from exc
    if aurora_record.get("input_hashes") != active_hashes:
        raise RuntimeError("The indexed AURORA result is stale for the active inputs")
    content_hash = str(aurora_record.get("content_hash", "")).lower()
    if len(content_hash) != 64:
        raise RuntimeError("The indexed AURORA CID is invalid")
    content_path = BASE_DIR / "content_store" / f"{content_hash}.json"
    if not content_path.is_file():
        content_path = BASE_DIR / "content_store" / content_hash
    body = content_path.read_bytes()
    if hashlib.sha256(body).hexdigest() != content_hash:
        raise RuntimeError("The governed AURORA result failed its SHA-256 CID check")
    envelope = json.loads(body.decode("utf-8"))
    if str(envelope.get("namespace", "")) != "regional_sourcing_opportunity_analysis":
        raise RuntimeError("The indexed result is not an AURORA evidence package")
    material = envelope.get("payload", {})
    if not isinstance(material, dict) or str(material.get("operation", "")) != "regional_sourcing_opportunity_analysis":
        raise RuntimeError("The governed AURORA result envelope is malformed")
    result = material.get("payload", {})
    if not isinstance(result, dict) or int(result.get("year", -1)) != year:
        raise RuntimeError("The governed AURORA result year is invalid")
    if result.get("input_hashes") != active_hashes:
        raise RuntimeError("The governed AURORA payload is stale for the active inputs")
    if str(result.get("network_result_hash", "")).lower() != str(
        network_record.get("content_hash", "")
    ).lower():
        raise RuntimeError("The governed AURORA result is not bound to the active 2017 Network/DLI result")
    opportunities = result.get("recommended_opportunities", [])
    limit = max(1, min(20, int(top_n)))
    return {
        "governed_result_cid": content_hash,
        "evidence_status": "fulfilled-and-cid-verified",
        "method": result.get("method"),
        "method_name": result.get("method_name"),
        "year": year,
        "configuration": result.get("configuration"),
        "threshold_calibration": result.get("threshold_calibration"),
        "company_footprint": result.get("company_footprint"),
        "demanded_sector_count": result.get("demanded_sector_count"),
        "recommended_count": len(opportunities),
        "recommended_opportunities": opportunities[:limit],
        "eligible_candidates": result.get("eligible_candidates", []),
        "pareto_efficient_candidates": result.get("pareto_efficient_candidates", []),
        "decision_funnel": result.get("decision_funnel", []),
        "decision_funnel_summary": result.get("decision_funnel_summary", {}),
        "sector_summaries": result.get("sector_summaries", []),
        "current_mix": result.get("current_mix", []),
        "cross_year_comparison": result.get("cross_year_comparison"),
        "selection_logic": result.get("selection_logic", {}),
        "non_additivity_note": result.get("non_additivity_note"),
        "display_cap_note": result.get("display_cap_note"),
        "claim_boundary": result.get("claim_boundary"),
        "dli_rule": result.get("dli_rule"),
    }


def tool_retrieval(query: str, top_n: int = 4) -> dict:
    """Retrieve contextual documents without mixing evidence classes.

    Definition questions are filtered to concept documents and study-method
    questions to methodology documents. Numerical result questions may search
    the analytical summaries. This prevents a generic definition request from
    returning unrelated year-specific rankings.
    """

    meta_hint = qi.deterministic_understanding(query)
    if meta_hint.get("route_hint") == "system_meta":
        return {
            "query": query,
            "retrieved": [],
            "filter": "system-meta route required",
            "relevance_gate": {
                "passed": False,
                "reason": (
                    "The question concerns deployment or architecture and must be handled by the curated system_knowledge route rather than the analytical RAG corpus."
                ),
            },
        }

    docs, vectorizer, matrix = _rag_index()
    if not docs or vectorizer is None or matrix is None:
        return {
            "query": query,
            "retrieved": [],
            "note": "No curated RAG documents were found.",
        }

    intent = knowledge.analyse_knowledge_intent(query)
    allowed_types: set[str] | None = None
    filter_reason = "analytical/contextual corpus"
    if intent.get("conceptual"):
        allowed_types = {"concept_definition"}
        filter_reason = "conceptual evidence only"
    elif intent.get("methodological"):
        allowed_types = {"methodology_context"}
        filter_reason = "methodology evidence only"

    candidate_indices = [
        index
        for index, doc in enumerate(docs)
        if allowed_types is None or str(doc.get("doc_type")) in allowed_types
    ]
    if not candidate_indices:
        return {
            "query": query,
            "retrieved": [],
            "filter": filter_reason,
            "note": "No documents were available in the required evidence class.",
        }

    similarities = cosine_similarity(vectorizer.transform([query]), matrix).flatten()
    candidate_indices.sort(key=lambda index: float(similarities[index]), reverse=True)
    top_score = float(similarities[candidate_indices[0]]) if candidate_indices else 0.0
    minimum_score = 0.075 if allowed_types is not None else 0.10
    relative_floor = top_score * 0.42
    threshold = max(minimum_score, relative_floor)
    selected = []
    for index in candidate_indices:
        score = float(similarities[index])
        if score < threshold:
            continue
        selected.append(
            {
                "doc_id": docs[index].get("doc_id"),
                "title": docs[index].get("title"),
                "year": docs[index].get("year"),
                "doc_type": docs[index].get("doc_type"),
                "score": score,
                "text": docs[index].get("text"),
            }
        )
        if len(selected) >= top_n:
            break
    return {
        "query": query,
        "filter": filter_reason,
        "relevance_gate": {
            "passed": bool(selected),
            "minimum_score": minimum_score,
            "top_score": top_score,
            "relative_floor": relative_floor,
            "applied_threshold": threshold,
            "discarded_count": max(0, len(candidate_indices) - len(selected)),
        },
        "retrieved": selected,
    }


def _source_for(tool: str) -> str:
    return {
        "concept_knowledge": "domain_knowledge.json conceptual glossary via knowledge_layer.py",
        "methodology_knowledge": "domain_knowledge.json study-method records via knowledge_layer.py",
        "footprint": "analytics_engine.py",
        "hotspots": "analytics_engine.py",
        "sda": "sda_engine.py",
        "dli": "network_engine.py runtime DLI evidence for the active uploaded inputs",
        "temporal_dli": "network_engine.py pooled-normalized 2014-to-2017 DLI comparison from active runtime evidence",
        "priority_ranking": (
            "network_engine.py + analytics_engine.py + hash-verified node/path-SDA, linkage, and governance evidence"
        ),
        "node_profile": (
            "analytics_engine.py + network_engine.py + hash-verified node/path-SDA, linkage, and governance evidence"
        ),
        "interventions": "hash-verified intervention-governance evidence (compatibility alias)",
        "intervention_governance": (
            "hash-verified signed hotspot driver, union path-SDA mechanism evidence, producer linkage, "
            "node actionability, pair feasibility, one joint portfolio, and governance-ready options"
        ),
        "spa_paths": "spa_engine.py runtime evidence for the active uploaded inputs",
        "counterfactual_scenario": "scenario_engine.py + analytics_engine.py",
        "sourcing_opportunity_analysis": (
            "fulfilled, SHA-256 CID-verified AURORA result indexed for the active inputs and bound to the active 2017 Network/DLI result"
        ),
        "retrieval": "intent-filtered curated RAG evidence corpus",
    }.get(tool, "unknown")


def execute_tool_call(call: dict[str, Any], question: str) -> ToolEvidence:
    name = str(call.get("tool", "retrieval"))
    year = _year(str(call.get("year", "2017")))
    top_n = max(1, min(20, int(call.get("top_n") or 5)))
    node = _normalise_node_code(call.get("node_code"), question)
    theta = _parse_theta_value(call.get("theta"))
    reduction_pct = _parse_theta_value(call.get("reduction_pct"))
    query = str(call.get("query") or question).strip() or question
    params = {
        "year": year,
        "top_n": top_n,
        "node_code": node,
        "theta": theta,
        "reduction_pct": reduction_pct,
        "query": query,
    }

    if name == "concept_knowledge":
        data = tool_concept_knowledge(query, top_n)
    elif name == "methodology_knowledge":
        data = tool_methodology_knowledge(query, top_n)
    elif name == "footprint":
        data = tool_footprint(year, theta)
    elif name == "hotspots":
        data = tool_hotspots(year, top_n, node)
    elif name == "sda":
        data = tool_sda()
    elif name == "dli":
        data = tool_dli(year, top_n, node)
    elif name == "temporal_dli":
        data = tool_temporal_dli(top_n)
    elif name == "priority_ranking":
        data = tool_priority_ranking(year, top_n)
    elif name == "node_profile":
        data = tool_node_profile(year, node)
    elif name == "interventions":
        data = tool_interventions(year, top_n, node)
    elif name == "intervention_governance":
        data = tool_intervention_governance(year, top_n, node)
    elif name == "spa_paths":
        data = tool_spa_paths(year, top_n, node)
    elif name == "counterfactual_scenario":
        data = tool_counterfactual_scenario(year, node, reduction_pct)
    elif name == "sourcing_opportunity_analysis":
        data = tool_sourcing_opportunity_analysis(year, top_n)
    elif name == "retrieval":
        data = tool_retrieval(query, top_n)
    else:
        data = {"error": f"Unknown tool {name}"}

    return ToolEvidence(name, params, _source_for(name), data)


def execute_plan(plan: dict[str, Any], question: str) -> list[dict[str, Any]]:
    if plan.get("scope") != "in_scope":
        return [
            {
                "tool": "scope_guard",
                "parameters": {},
                "source": "deterministic domain guard",
                "data": {
                    "status": "out_of_scope",
                    "message": (
                        "The question is clearly outside the deployed Strategic Carbon Intelligence & Governance carbon-governance evidence domain."
                    ),
                },
            }
        ]

    calls = plan.get("tool_calls", []) or []
    if not calls:
        calls = [
            _tool_call(
                "retrieval",
                "unspecified",
                top_n=4,
                query=question,
            )
        ]

    evidence: list[dict[str, Any]] = []
    for call in calls:
        try:
            evidence.append(asdict(execute_tool_call(call, question)))
        except Exception as exc:
            tool_name = str(call.get("tool", "unknown")) if isinstance(call, dict) else "unknown"
            evidence.append(
                {
                    "tool": tool_name,
                    "parameters": call if isinstance(call, dict) else {},
                    "source": _source_for(tool_name),
                    "data": {
                        "status": "tool_error",
                        "error_type": type(exc).__name__,
                        "message": str(exc),
                    },
                }
            )
    return evidence


def derive_route(evidence: list[dict[str, Any]]) -> str:
    tools = {e.get("tool") for e in evidence}
    if "scope_guard" in tools:
        return "retrieval"
    knowledge_tools = {"concept_knowledge", "methodology_knowledge", "retrieval"}
    if tools and tools.issubset(knowledge_tools):
        return "retrieval"
    if tools & knowledge_tools:
        return "composite"
    return "compute" if len(tools) == 1 else "composite"



# ---------------------------------------------------------------------------
# Reliable synthesis


def _tool_data(evidence: list[dict[str, Any]], tool: str) -> dict | None:
    for item in evidence:
        if item.get("tool") == tool and isinstance(item.get("data"), dict):
            data = item["data"]
            # Tool-execution failures are reported separately as warnings.  Do
            # not pass their diagnostic payload into a result formatter, which
            # would otherwise render misleading "None" values.
            if data.get("status") == "tool_error":
                continue
            return data
    return None


def _fmt(value: Any, digits: int = 4) -> str:
    try:
        return f"{float(value):.{digits}f}"
    except (TypeError, ValueError):
        return str(value)


def _pct(value: Any, digits: int = 2) -> str:
    try:
        return f"{100.0 * float(value):.{digits}f}%"
    except (TypeError, ValueError):
        return str(value)


def _clean_sentence(value: Any) -> str:
    text = re.sub(r"\s+", " ", str(value or "")).strip()
    if text and text[-1] not in ".!?":
        text += "."
    return text


def _join_prose(items: list[Any]) -> str:
    return " ".join(
        sentence
        for sentence in (_clean_sentence(item) for item in items)
        if sentence
    )


def _lower_initial(value: str) -> str:
    text = str(value or "").strip()
    if not text:
        return text
    first_token = re.match(r"^[A-Za-z][A-Za-z0-9-]*", text)
    token = first_token.group(0) if first_token else ""
    # Preserve domain acronyms such as DLI, MRIO, SPA, SDA and AURORA instead
    # of producing awkward forms such as ``dLI`` inside connected prose.
    if token and len(token) >= 2 and token.upper() == token:
        return text
    return text[:1].lower() + text[1:]


def _join_clauses(items: list[Any]) -> str:
    cleaned = [
        _lower_initial(re.sub(r"\s+", " ", str(item)).strip().rstrip(" .;:"))
        for item in items
        if str(item).strip()
    ]
    if not cleaned:
        return ""
    if len(cleaned) == 1:
        return cleaned[0]
    if len(cleaned) == 2:
        separator = "; and " if any("," in item for item in cleaned) else " and "
        return f"{cleaned[0]}{separator}{cleaned[1]}"
    return "; ".join(cleaned[:-1]) + f"; and {cleaned[-1]}"


def _procedure_prose(items: list[Any]) -> str:
    steps = [re.sub(r"\s+", " ", str(item)).strip().rstrip(".") for item in items if str(item).strip()]
    if not steps:
        return ""
    labels = ["First", "Next", "Then", "After that", "Finally"]
    rendered = []
    for index, step in enumerate(steps):
        label = labels[index] if index < len(labels) else f"Step {index + 1}"
        rendered.append(f"{label}, {step[0].lower() + step[1:] if step else step}.")
    return " ".join(rendered)


def deterministic_synthesis(
    question: str,
    plan: dict[str, Any],
    evidence: list[dict[str, Any]],
) -> str:
    """Guaranteed user-facing answer assembled only from validated evidence.

    The answer is compositional rather than first-match-wins. A single question
    can therefore receive a definition, a study-method explanation, and one or
    more deterministic result sections without one evidence class displacing
    another.
    """

    if plan.get("scope") != "in_scope" or _tool_data(evidence, "scope_guard"):
        return (
            "This assistant is limited to the deployed Strategic Carbon Intelligence & Governance carbon-governance domain, "
            "including carbon-accounting concepts, study methodology, supply-chain evidence, "
            "strategic interventions, scenarios, and sourcing analysis."
        )

    sections: list[str] = []

    concept_data = _tool_data(evidence, "concept_knowledge")
    if concept_data and concept_data.get("matches"):
        concept_blocks: list[str] = []
        concept_matches = concept_data["matches"][:4]
        concept_ids = {str(entry.get("id", "")) for entry in concept_matches}
        comparison_ids: set[str] = set()
        if (
            {"dli", "hotspot"}.issubset(concept_ids)
            and re.search(
                r"\b(?:differ|difference|compare|comparison|versus|vs\.?)\b",
                question,
                flags=re.IGNORECASE,
            )
        ):
            concept_blocks.append(
                "An emissions hotspot and the Decarbonization Leverage Index answer different management questions. "
                "A hotspot ranks country-sector nodes by their modeled contribution to the selected focal-company "
                "footprint, so it identifies where carbon exposure is concentrated. By contrast, DLI combines "
                "network position, carbon dependency risk and intervention criticality to identify where management "
                "action may have disproportionate strategic leverage. A node can therefore be a large hotspot without "
                "being the strongest governance-leverage point, or it can rank highly on DLI without being the largest "
                "emitter. In this framework, hotspot and SPA evidence corroborate the exposure and pathway associated "
                "with a DLI priority; they do not replace the declared DLI governance rule."
            )
            comparison_ids.update({"dli", "hotspot"})

        for entry in concept_matches:
            if str(entry.get("id", "")) in comparison_ids:
                continue
            term = str(entry.get("term", "Concept")).strip()
            definition = str(entry.get("definition", "")).strip()
            application = str(entry.get("framework_application", "")).strip()
            distinctions = [
                str(item).strip()
                for item in entry.get("key_distinctions", [])
                if str(item).strip()
            ]
            pieces = [definition or f"{term} is not defined in the packaged glossary."]
            if application:
                application_text = re.sub(
                    r"^in this deployment,?\s*",
                    "",
                    application,
                    flags=re.IGNORECASE,
                )
                pieces.append(f"In this Strategic Carbon Intelligence & Governance framework, {_lower_initial(application_text)}")
            if distinctions:
                joined_distinctions = _join_clauses(distinctions[:3])
                if joined_distinctions:
                    pieces.append("The main distinctions are that " + joined_distinctions + ".")
            concept_blocks.append(_join_prose(pieces))
        sections.append("\n\n".join(concept_blocks))

    methodology_data = _tool_data(evidence, "methodology_knowledge")
    if methodology_data and methodology_data.get("matches"):
        method_blocks: list[str] = []
        for entry in methodology_data["matches"][:3]:
            title = str(entry.get("title", "Study methodology")).strip()
            purpose = str(entry.get("purpose", "")).strip()
            procedure = [
                str(item).strip()
                for item in entry.get("procedure", [])
                if str(item).strip()
            ]
            outputs = [
                str(item).strip()
                for item in entry.get("outputs", [])
                if str(item).strip()
            ]
            boundary = str(entry.get("boundary", "")).strip()
            modules = [
                str(item).strip()
                for item in entry.get("modules", [])
                if str(item).strip()
            ]
            limitations = [
                str(item).strip()
                for item in entry.get("limitations", [])
                if str(item).strip()
            ]
            pieces: list[str] = []
            if purpose:
                pieces.append(f"**{title}.** {purpose}")
            else:
                pieces.append(f"**{title}.**")
            procedure_text = _procedure_prose(procedure)
            if procedure_text:
                pieces.append(procedure_text)
            if outputs:
                pieces.append("The method produces " + "; ".join(item.rstrip(".") for item in outputs) + ".")
            if boundary:
                pieces.append(f"Its methodological boundary is that {boundary[0].lower() + boundary[1:] if boundary else boundary}")
            if modules:
                pieces.append("It is implemented in " + ", ".join(f"`{item}`" for item in modules) + ".")
            if limitations:
                pieces.append("However, " + _join_clauses(limitations[:3]) + ".")
            method_blocks.append(_join_prose(pieces))
        sections.append("\n\n".join(method_blocks))

    priority = _tool_data(evidence, "priority_ranking")
    if priority and priority.get("recommended_node"):
        rec = priority["recommended_node"]
        code = rec.get("node_code", "the highest-DLI node")
        action = rec.get("action") or "apply the packaged deterministic intervention rule"
        channel = rec.get("channel") or "the relevant management channel"
        driver = rec.get("driven_by") or "the combined DLI components"
        spa = rec.get("spa_support") or []
        evidence_sentences = [
            f"Management should prioritize **{code}** for the {priority.get('year', 2017)} decarbonization program because it ranks **#{int(rec.get('dli_rank', 1))}** on the Decarbonization Leverage Index, with a DLI score of **{_fmt(rec.get('DLI'), 6)}**.",
            f"The recommendation is also supported by the emissions-hotspot analysis, where the node ranks **#{int(rec.get('hotspot_rank', 1))}** and contributes **{_fmt(rec.get('footprint_contribution'), 6)} t CO₂**, or **{_pct(rec.get('share_of_total'))}** of the focal-company footprint.",
            f"Its principal leverage driver is **{driver}**, with normalized components BC={_fmt(rec.get('BC_norm'))}, PR={_fmt(rec.get('PR_norm'))}, CDR={_fmt(rec.get('CDR_norm'))}, and IC={_fmt(rec.get('IC_norm'))}.",
        ]
        if spa:
            first_path = spa[0]
            evidence_sentences.append(
                f"Structural Path Analysis further corroborates the priority through `{first_path.get('path_codes')}`, with a contribution of **{_fmt(first_path.get('contribution'), 6)} t CO₂**."
            )
        evidence_sentences.append(
            "Taken together, this evidence shows that the choice is not based on emissions magnitude alone: DLI provides the primary governance rule by combining network position, structural dependency and intervention relevance, while the hotspot and SPA results confirm material exposure and an actionable pathway."
        )
        action_text = str(action or "").strip().rstrip(".")
        action_paragraph = (
            f"The recommended management response is to {_lower_initial(action_text)}. "
            f"The delivery channel is **{channel}**."
        )
        limitation_paragraph = (
            "However, this remains a model-based screening priority rather than an implementation decision. "
            "Cost, technical feasibility, supplier readiness, quality constraints, contractual leverage and updated primary emissions data must be checked before action is approved."
        )
        sections.append(
            "\n\n".join(
                [
                    _join_prose(evidence_sentences),
                    _join_prose([action_paragraph]),
                    limitation_paragraph,
                ]
            )
        )

    sda_data = _tool_data(evidence, "sda")
    if sda_data:
        effects = sda_data.get("company_effects", {})
        sections.append(
            "\n".join(
                [
                    "### Change in the focal-company footprint",
                    f"The footprint changed from **{_fmt(sda_data.get('company_footprint_2014'), 6)} t CO₂** in 2014 to **{_fmt(sda_data.get('company_footprint_2017'), 6)} t CO₂** in 2017, a net change of **{_fmt(sda_data.get('company_net_change'), 6)} t CO₂**.",
                    "",
                    "The deterministic SDA attributes the change to "
                    f"intensity **{_fmt(effects.get('intensity'), 6)} t CO₂**, "
                    f"technology **{_fmt(effects.get('technology'), 6)} t CO₂**, "
                    f"composition **{_fmt(effects.get('composition'), 6)} t CO₂**, and "
                    f"scale **{_fmt(effects.get('scale'), 6)} t CO₂** effects.",
                    "",
                    "**Interpretation:** The negative scale effect more than offset the positive intensity and technology effects. Company-level effects are the primary evidence; economy-wide effects are contextual only.",
                ]
            )
        )

    footprint = _tool_data(evidence, "footprint")
    if footprint:
        if "scenario_footprint" in footprint:
            sections.append(
                "\n".join(
                    [
                        "### Company-share footprint scenario",
                        f"At a company sector share of **{_pct(footprint.get('scenario_theta'))}**, the deterministic {footprint.get('year')} footprint is **{_fmt(footprint.get('scenario_footprint'), 6)} t CO₂**, compared with the packaged **{_pct(footprint.get('baseline_theta'))}** baseline footprint of **{_fmt(footprint.get('company_footprint'), 6)} t CO₂**.",
                        "",
                        "This is a linear scaling of the same demand composition, not a behavioral, price, capacity, or supplier-response forecast.",
                    ]
                )
            )
        else:
            sections.append(
                "\n".join(
                    [
                        f"### Focal-company footprint, {footprint.get('year')}",
                        f"The deterministic embodied-carbon footprint is **{_fmt(footprint.get('company_footprint'), 6)} t CO₂**. The economy-wide footprint in the same MRIO system is **{_fmt(footprint.get('economy_wide_footprint'), 6)} Mt CO₂**.",
                    ]
                )
            )

    node_profile = _tool_data(evidence, "node_profile")
    if node_profile:
        code = node_profile.get("node_code", "the requested node")
        dli_rows = node_profile.get("dli", {}).get("node", [])
        hot_rows = node_profile.get("hotspot", {}).get("node", [])
        interventions = node_profile.get("intervention", {}).get("intervention", [])
        paths = node_profile.get("paths", {}).get("top_paths", [])
        sentences = [f"The evidence profile for **{code}** combines its DLI position, footprint exposure, structural-path support and deterministic intervention channel."]
        if dli_rows:
            row = dli_rows[0]
            sentences.append(
                f"It holds DLI rank **#{row.get('dli_rank')}**, with DLI **{_fmt(row.get('DLI'), 6)}** and normalized components BC={_fmt(row.get('BC_norm'))}, PR={_fmt(row.get('PR_norm'))}, CDR={_fmt(row.get('CDR_norm'))}, and IC={_fmt(row.get('IC_norm'))}."
            )
        if hot_rows:
            row = hot_rows[0]
            sentences.append(
                f"It also holds hotspot rank **#{row.get('hotspot_rank')}**, with a footprint contribution of **{_fmt(row.get('footprint_contribution'), 6)} t CO₂**, equal to **{_pct(row.get('share_of_total'))}** of the focal-company footprint."
            )
        if paths:
            row = paths[0]
            sentences.append(
                f"The leading active-input path containing the node is `{row.get('path_codes')}`, contributing **{_fmt(row.get('contribution'), 6)} t CO₂**."
            )
        if interventions:
            row = interventions[0]
            sentences.append(
                f"Accordingly, the deterministic intervention category is **{row.get('category')}**: {row.get('action')} The delivery channel is **{row.get('channel')}**."
            )
        sentences.append(
            "This remains a screening profile; implementation still requires current primary data and checks of cost, feasibility, quality, supplier readiness and contractual leverage."
        )
        sections.append(_join_prose(sentences))

    hotspots = _tool_data(evidence, "hotspots")
    dli_data = _tool_data(evidence, "dli")
    comparison_requested = bool(
        re.search(
            r"\b(compare|comparison|versus|vs\.?|differ|difference|rather than|instead of)\b",
            question,
            flags=re.IGNORECASE,
        )
    )
    if (
        comparison_requested
        and hotspots
        and hotspots.get("top_hotspots")
        and dli_data
        and dli_data.get("top_dli")
    ):
        hotspot_top = hotspots["top_hotspots"][0]
        dli_top = dli_data["top_dli"][0]
        hotspot_code = str(hotspot_top.get("node_code", ""))
        dli_code = str(dli_top.get("node_code", ""))
        if hotspot_code.casefold() == dli_code.casefold():
            finding = (
                f"Both rankings identify **{dli_code}**. It is the largest footprint contributor "
                f"at **{_pct(hotspot_top.get('share_of_total'))}** and also the highest-DLI node "
                f"with DLI **{_fmt(dli_top.get('DLI'), 6)}**."
            )
        else:
            finding = (
                f"The largest emissions hotspot is **{hotspot_code}** at "
                f"**{_pct(hotspot_top.get('share_of_total'))}** of the footprint, whereas the "
                f"highest-DLI node is **{dli_code}** with DLI "
                f"**{_fmt(dli_top.get('DLI'), 6)}**."
            )
        sections.append(
            "\n".join(
                [
                    "### Hotspot versus DLI comparison",
                    finding,
                    "",
                    "A hotspot answers **where the largest modeled emissions exposure occurs**. "
                    "DLI answers **where the declared combination of network position, carbon "
                    "dependency, and intervention criticality indicates the greatest governance "
                    "leverage**. Agreement between the rankings strengthens the screening case; "
                    "disagreement would signal that emissions magnitude and strategic leverage "
                    "should be considered separately.",
                ]
            )
        )

    if hotspots and hotspots.get("top_hotspots"):
        rows = hotspots["top_hotspots"]
        lines = ["### Emissions hotspots"]
        lines.extend(
            f"- **{row.get('node_code')}**: rank #{row.get('hotspot_rank')}, contribution {_fmt(row.get('footprint_contribution'), 6)}, share {_pct(row.get('share_of_total'))}"
            for row in rows
        )
        sections.append("\n".join(lines))

    if dli_data and dli_data.get("top_dli"):
        rows = dli_data["top_dli"]
        lines = ["### DLI ranking"]
        lines.extend(
            f"- **{row.get('node_code')}**: DLI rank #{row.get('dli_rank')}, DLI={_fmt(row.get('DLI'), 6)}"
            for row in rows
        )
        sections.append("\n".join(lines))

    temporal_dli_data = _tool_data(evidence, "temporal_dli")
    if temporal_dli_data and temporal_dli_data.get("current_2017_priorities_with_trajectory"):
        rows = temporal_dli_data["current_2017_priorities_with_trajectory"]
        lines = ["### Temporal DLI: 2014 → 2017"]
        lines.append(
            "2017 remains the principal decision year; both annual rankings and their score change come from the same pooled two-year normalization and Pearson-CRITIC weights."
        )
        lines.extend(
            f"- **{row.get('node_code')}**: rank {row.get('dli_rank_2014')} → {row.get('dli_rank_2017')}; "
            f"pooled ΔDLI={_fmt(row.get('delta_DLI'), 6)}; **{row.get('two_period_status')}**."
            for row in rows
        )
        sections.append("\n".join(lines))

    governance = _tool_data(evidence, "intervention_governance")
    if governance:
        lines = ["### Integrated intervention governance"]
        counts = governance.get("counts", {}) if isinstance(governance.get("counts"), dict) else {}
        lines.append(
            "The governed method keeps hotspot magnitude, all signed node-SDA effects, exact-path SDA mechanism evidence, DLI leverage, producer-resolved linkage, and actionability as separate evidence dimensions. "
            "It does not add node-wise SDA to DLI and does not create another weighted composite score."
        )
        lines.append(
            f"The verified evidence currently contains **{counts.get('candidate_pairs', 0)}** hotspot--leverage candidate pairs, "
            f"**{counts.get('formally_eligible_pairs', 0)}** formally eligible pairs, and "
            f"**{counts.get('governance_ready_options', 0)}** governance-ready options."
        )
        selected = governance.get("governance_ready_options", []) or []
        if selected:
            lines.append("Only the following current options have passed positive linkage, deterministic adverse-driver mechanism mapping, and stakeholder-attested node/pair actionability:")
            for row in selected:
                lines.append(
                    f"- **{row.get('node_code')}** → {row.get('hotspot_targets')}: {row.get('action')} "
                    f"(route: {row.get('intervention_route')}; status: {row.get('governance_eligibility_status')})."
                )
        else:
            lines.append(
                "No formal option is currently available. This is intentional until an accountable stakeholder documents the required actionability evidence; the LLM cannot infer or assign that status."
            )
        lines.append(
            "All reported coverage is a complete-node-removal structural diagnostic, not predicted, feasible, or guaranteed real-world abatement."
        )
        sections.append("\n".join(lines))

    interventions = _tool_data(evidence, "interventions")
    if interventions and interventions.get("interventions"):
        rows = interventions["interventions"]
        lines = ["### Deterministic intervention recommendations"]
        lines.extend(
            f"- **{row.get('node_code')}**: {row.get('action')} ({row.get('channel')})"
            for row in rows
        )
        sections.append("\n".join(lines))

    paths = _tool_data(evidence, "spa_paths")
    if paths and paths.get("top_paths"):
        rows = paths["top_paths"]
        lines = ["### Structural paths"]
        lines.extend(
            f"- `{row.get('path_codes')}`: contribution {_fmt(row.get('contribution'), 6)}, depth {row.get('depth')}"
            for row in rows
        )
        sections.append("\n".join(lines))

    counterfactual = _tool_data(evidence, "counterfactual_scenario")
    if counterfactual:
        if counterfactual.get("error"):
            sections.append(
                "### Counterfactual scenario\n" + str(counterfactual.get("error"))
            )
        elif counterfactual.get("scenarios") is not None:
            scenarios = counterfactual.get("scenarios", [])
            lines = [
                f"### Packaged counterfactual scenarios for {counterfactual.get('node_code')}"
            ]
            if scenarios:
                for item in scenarios:
                    lines.append(
                        f"- **{item.get('label')}**: node-intensity reduction {_pct(item.get('reduction_pct'))}; scenario footprint **{_fmt(item.get('scenario_footprint'), 6)} t CO₂**; total-footprint saving **{_pct(item.get('pct_of_total_footprint_saved'))}**."
                    )
                    lines.append(f"  Source recorded in package: {item.get('citation')}")
            else:
                lines.append(
                    "No sourced counterfactual scenario is available for this node. The system deliberately does not substitute an assumed reduction."
                )
            lines.extend(["", str(counterfactual.get("interpretation_rule", ""))])
            sections.append("\n".join(lines))
        else:
            sections.append(
                "\n".join(
                    [
                        f"### Counterfactual scenario for {counterfactual.get('node_code')}",
                        f"A **{_pct(counterfactual.get('reduction_pct'))}** reduction in the node's own environmental intensity changes the {counterfactual.get('year')} footprint from **{_fmt(counterfactual.get('baseline_footprint'), 6)} t CO₂** to **{_fmt(counterfactual.get('scenario_footprint'), 6)} t CO₂**.",
                        f"The absolute saving is **{_fmt(counterfactual.get('absolute_saving'), 6)} t CO₂**, equal to **{_pct(counterfactual.get('pct_of_total_footprint_saved'))}** of the total baseline footprint.",
                        "",
                        str(counterfactual.get("interpretation_rule", "")),
                    ]
                )
            )

    sourcing_opportunities = _tool_data(
        evidence, "sourcing_opportunity_analysis"
    )
    if sourcing_opportunities:
        rows = sourcing_opportunities.get("recommended_opportunities", [])
        lines = [
            f"### AURORA Regional Opportunity Intelligence, {sourcing_opportunities.get('year')}",
            (
                "AURORA assesses **regional variants of the same demanded sector** using "
                "production-structure similarity, downstream-market similarity, observed "
                "MRIO linkage, embodied-carbon multipliers, and DLI governance evidence."
            ),
        ]
        if rows:
            lines.append(
                f"The current active-input screening returned **{sourcing_opportunities.get('recommended_count')}** "
                "Pareto-efficient opportunities; the leading records requested are:"
            )
            for row in rows:
                stable = (
                    "stable across both reference years"
                    if row.get("stable_reference_year_signal")
                    else "year-specific signal"
                )
                lines.append(
                    f"- **{row.get('sector')} -> {row.get('node_code')}**: "
                    f"production similarity {_pct(row.get('production_sector_similarity'))}; "
                    f"market similarity {_pct(row.get('market_sector_similarity'))}; "
                    f"multiplier improvement {_pct(row.get('relative_multiplier_reduction'))}; "
                    f"UAE intermediate-sales share {_pct(row.get('focal_region_intermediate_sales_share'))}; "
                    f"Pareto efficient {'yes' if row.get('pareto_efficient') else 'no'}; "
                    f"DLI {_fmt(row.get('DLI'), 6)} (rank #{row.get('dli_rank')}, "
                    f"dominant component {row.get('dominant_dli_component')}); "
                    f"{row.get('observed_linkage_tier')}; {stable}."
                )
                lines.append(
                    f"  Recommendation: {row.get('recommendation')}. "
                    f"Governance lens: {row.get('dli_governance_lens')}"
                )
        else:
            lines.append(
                "No candidate passed the configured same-sector structural, carbon, "
                "linkage, and Pareto screening rules for the selected year."
            )
        lines.extend(
            [
                "",
                str(sourcing_opportunities.get("non_additivity_note", "")),
                str(sourcing_opportunities.get("display_cap_note", "")),
                str(sourcing_opportunities.get("claim_boundary", "")),
                str(sourcing_opportunities.get("dli_rule", "")),
            ]
        )
        sections.append("\n".join(lines))

    retrieval = _tool_data(evidence, "retrieval")
    if retrieval and retrieval.get("retrieved") and not sections:
        rows = retrieval["retrieved"]
        sections.append(
            "\n\n".join(
                f"**{row.get('title')}**\n\n{row.get('text')}" for row in rows[:3]
            )
        )

    errors = [
        item.get("data", {}).get("message")
        for item in evidence
        if isinstance(item.get("data"), dict)
        and item.get("data", {}).get("status") == "tool_error"
    ]
    if errors:
        sections.append(
            "**Tool warning:** "
            + "; ".join(str(error) for error in errors if error)
        )

    if sections:
        return "\n\n".join(section for section in sections if section.strip())
    return (
        "The question is in scope, but the available conceptual, methodological, and "
        "analytical evidence did not contain enough information to support a grounded answer."
    )


def _clean_string_list(value: Any) -> list[str]:
    if not isinstance(value, list):
        return []
    return [str(item).strip() for item in value if str(item).strip()]


def _valid_synthesis(
    output: dict[str, Any],
    question: str,
    evidence: list[dict[str, Any]],
    deterministic_draft: str,
    plan: dict[str, Any],
) -> tuple[bool, dict[str, Any]]:
    if not isinstance(output, dict):
        return False, {"aligned": False, "reasons": ["structured synthesis was not an object"]}

    narrative = str(output.get("narrative_answer", "")).strip()
    if len(narrative) < 60:
        return False, {"aligned": False, "reasons": ["narrative answer is too short"]}

    answer_type = str(output.get("answer_type", "")).strip()
    allowed_types = {
        "conceptual",
        "methodological",
        "analytical",
        "strategic",
        "scenario",
        "composite",
    }
    if answer_type not in allowed_types:
        return False, {"aligned": False, "reasons": ["invalid answer type"]}
    expected_mode = str(plan.get("response_mode", "analytical"))
    if expected_mode in allowed_types and answer_type != expected_mode:
        return False, {"aligned": False, "reasons": ["answer type changed the validated response mode"]}

    supporting_claims = _clean_string_list(output.get("supporting_claims"))
    limitations = _clean_string_list(output.get("material_limitations"))
    combined = " ".join([narrative, *supporting_claims, *limitations]).casefold()

    prohibited = [
        "we are given",
        "per the instruction",
        "the instructions say",
        "the prompt",
        "scope_guard",
        "out_of_scope",
        "the response should",
        "let me construct",
        "i need to",
        "outside the scope",
    ]
    if any(phrase in combined for phrase in prohibited):
        return False, {"aligned": False, "reasons": ["model exposed planning or prompt internals"]}

    if answer_type == "conceptual" and not _tool_data(evidence, "concept_knowledge"):
        return False, {"aligned": False, "reasons": ["conceptual answer lacks concept evidence"]}
    if answer_type == "methodological" and not _tool_data(evidence, "methodology_knowledge"):
        return False, {"aligned": False, "reasons": ["method answer lacks methodology evidence"]}
    if answer_type == "scenario" and not (
        _tool_data(evidence, "footprint")
        or _tool_data(evidence, "counterfactual_scenario")
    ):
        return False, {"aligned": False, "reasons": ["scenario answer lacks scenario evidence"]}
    if answer_type == "composite" and not supporting_claims:
        return False, {"aligned": False, "reasons": ["composite answer did not identify supporting claims"]}

    concept_data = _tool_data(evidence, "concept_knowledge")
    if concept_data and concept_data.get("matches"):
        terms = [
            str(row.get("term", "")).casefold()
            for row in concept_data["matches"]
            if str(row.get("term", "")).strip()
        ]
        if answer_type in {"conceptual", "composite"} and terms and not any(
            term in combined for term in terms
        ):
            return False, {"aligned": False, "reasons": ["requested concept is absent from the answer"]}

    required_anchor = ""
    priority = _tool_data(evidence, "priority_ranking")
    if priority and priority.get("recommended_node"):
        recommendation = priority["recommended_node"]
        required_anchor = str(recommendation.get("node_code", "")).strip()
        if required_anchor and required_anchor.casefold() not in combined:
            return False, {"aligned": False, "reasons": ["recommended node is absent from the answer"]}
        if len(supporting_claims) < 2:
            return False, {"aligned": False, "reasons": ["priority answer lacks multiple evidence anchors"]}
        action_text = str(recommendation.get("action", "")).casefold()
        action_tokens = {
            token
            for token in re.findall(r"[a-z0-9]+", action_text)
            if len(token) > 3 and token not in {"with", "from", "that", "this", "into", "their"}
        }
        narrative_tokens = set(re.findall(r"[a-z0-9]+", narrative.casefold()))
        minimum_action_overlap = min(2, len(action_tokens))
        if minimum_action_overlap and len(action_tokens & narrative_tokens) < minimum_action_overlap:
            return False, {"aligned": False, "reasons": ["priority answer omits the evidence-backed management action"]}
        if not re.search(r"\b(however|limitation|screening|requires?|must|before implementation|subject to)\b", narrative, re.IGNORECASE):
            return False, {"aligned": False, "reasons": ["priority answer omits the decision limitation"]}

    # Reject unsupported numerical claims and invented country-sector codes.
    rendered = _render_structured_synthesis(output)
    allowed_text = json.dumps(evidence, default=str) + " " + deterministic_draft
    allowed_numbers = set(re.findall(r"[-+]?\d+(?:\.\d+)?", allowed_text))
    output_numbers = set(re.findall(r"[-+]?\d+(?:\.\d+)?", rendered))
    if any(number not in allowed_numbers for number in output_numbers):
        return False, {"aligned": False, "reasons": ["unsupported numerical claim"]}

    code_pattern = r"\b[A-Z]{3}[-_][A-Za-z0-9]+\b"
    allowed_codes = {
        code.replace("_", "-").casefold()
        for code in re.findall(code_pattern, allowed_text, flags=re.IGNORECASE)
    }
    output_codes = {
        code.replace("_", "-").casefold()
        for code in re.findall(code_pattern, rendered, flags=re.IGNORECASE)
    }
    if not output_codes.issubset(allowed_codes):
        return False, {"aligned": False, "reasons": ["invented country-sector code"]}

    alignment = qi.assess_answer_alignment(
        question,
        rendered,
        expected_mode=answer_type,
        required_anchor=required_anchor,
    )
    if not alignment.get("aligned"):
        return False, alignment
    return True, alignment


def _render_structured_synthesis(output: dict[str, Any]) -> str:
    """Render only the connected narrative; structured claims remain in audit data."""

    return str(output.get("narrative_answer", "")).strip()


def synthesize(
    client,
    question: str,
    plan: dict[str, Any],
    evidence: list[dict[str, Any]],
) -> str:
    """Produce an intent-faithful answer with a deterministic fail-safe.

    Quantitative authority remains with the deterministic tools. The optional
    local model may improve wording and connect evidence, but it must preserve
    the validated response mode and cannot replace a requested definition or
    methodology explanation with an unrelated result summary.
    """

    deterministic_draft = deterministic_synthesis(question, plan, evidence)
    response_mode = str(plan.get("response_mode", "analytical"))
    priority = _tool_data(evidence, "priority_ranking")
    required_anchor = ""
    if priority and priority.get("recommended_node"):
        required_anchor = str(priority["recommended_node"].get("node_code", "")).strip()
    deterministic_alignment = qi.assess_answer_alignment(
        question,
        deterministic_draft,
        expected_mode=response_mode,
        required_anchor=required_anchor,
    )
    plan["answer_alignment"] = {
        **deterministic_alignment,
        "answer_source": "deterministic_draft",
    }
    if plan.get("scope") != "in_scope":
        return deterministic_draft

    # Do not make a second slow model call after planner timeout/unavailability.
    # The complete deterministic answer is already available from the executed
    # evidence bundle.
    if plan.get("planner_validation", {}).get("llm_status") != "ok":
        plan["synthesis_validation"] = {
            "status": "not_called",
            "reason": "planner model was unavailable or rejected; coherent deterministic synthesis used",
        }
        return deterministic_draft

    system = (
        "You are the user-facing synthesis layer of an intent-aware, evidence-grounded "
        "carbon-governance assistant. Return only JSON matching the schema and answer "
        "the user's semantic intent directly. Output the final answer, not private reasoning. "
        "Do not mention prompts, schemas, planning internals, scope_guard, or evidence JSON. "
        "The validated response_mode is authoritative and must be copied exactly into answer_type. "
        "Write a coherent analytical narrative rather than a sequence of labeled evidence fragments. "
        "For a focused question, use one to three connected paragraphs and avoid headings and bullets unless "
        "the user explicitly asks for a list or ranking. Lead with the direct answer, explain why the evidence "
        "supports it, then integrate the practical action and material limitation. Use transitions such as "
        "because, in addition, taken together, therefore, and however where they improve the logic. "
        "For conceptual mode, begin with a plain-language definition from concept_knowledge; do not "
        "substitute year-specific results or rankings. For methodological mode, explain the study's "
        "purpose, procedure, boundary, outputs, and limitations from methodology_knowledge. For a "
        "composite question, answer the concept or method first and then integrate the requested "
        "deterministic evidence. For analytical, strategic, or scenario modes, use the executed tools "
        "and state the direct result before interpretation. Use only supplied evidence for all claims "
        "specific to the focal company, study, nodes, years, rankings, scenarios, and numbers. Do not "
        "calculate or invent MRIO, SPA, SDA, DLI, sourcing, scenario, or intervention values. When a "
        "recommended_node is present, name it directly and explain the evidence-backed management "
        "rationale. Preserve supplied values and state practical limitations. Put the complete user-facing "
        "prose in narrative_answer; supporting_claims and material_limitations are audit fields and should not "
        "be rendered as a disconnected list in the narrative."
    )
    payload = {
        "question": question,
        "response_mode": response_mode,
        "validated_plan": plan,
        "evidence": evidence,
        "grounded_deterministic_draft": deterministic_draft,
        "narrative_order": (
            "definition or method first, then study application and requested deterministic result, connected as prose"
            if response_mode in {"conceptual", "methodological", "composite"}
            else "direct result, evidence-backed reason, management action, then limitation, connected as prose"
        ),
    }
    model = os.getenv("OLLAMA_SYNTHESIS_MODEL", client.model)
    try:
        output = client.chat_json(
            system,
            json.dumps(payload, indent=2, default=str),
            SYNTHESIS_SCHEMA,
            model=model,
            num_predict=1200,
            temperature=0.1,
        )
        valid, alignment = _valid_synthesis(
            output,
            question,
            evidence,
            deterministic_draft,
            plan,
        )
        if valid:
            plan["answer_alignment"] = {
                **alignment,
                "answer_source": "local_llm_validated",
            }
            plan["synthesis_validation"] = {
                "status": "ok",
                "model": model,
                "narrative_style": "connected paragraphs",
            }
            return _render_structured_synthesis(output)
        plan["synthesis_validation"] = {
            "status": "rejected",
            "model": model,
            "reason": alignment,
            "fallback": "coherent deterministic synthesis",
        }
    except Exception as exc:
        plan["synthesis_validation"] = {
            "status": "fallback",
            "model": model,
            "error": str(exc),
            "fallback": "coherent deterministic synthesis",
        }
    return deterministic_draft


def answer_question(client, question: str) -> AssistantResult:
    plan = plan_query(client, question)
    evidence = execute_plan(plan, question)
    route = derive_route(evidence)
    answer = synthesize(client, question, plan, evidence)
    return AssistantResult(question, plan, route, evidence, answer)
