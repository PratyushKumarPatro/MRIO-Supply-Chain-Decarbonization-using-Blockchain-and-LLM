"""Stakeholder-controlled, real-time analytical input onboarding.

Uploaded Excel workbooks are first stored in a staging area.  They are not made
active merely because the Streamlit client accepted the bytes.  The active file
is changed only after the Upstream Analytics Oracle has (1) independently
validated the staged bytes through the Data Orchestrator and (2) recorded the
accepted hash in the ``UpstreamCarbonEmissionsAnalysis`` contract defined in ``contracts/StrategicCarbonIntelligenceSystem.sol``.

The module contains no Web3 calls.  It is shared by the Streamlit governance platform and the
Data Orchestrator so both sides apply the same structural checks.
"""
from __future__ import annotations

import hashlib
import json
import shutil
import tempfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

import analytics_engine as ae

BASE_DIR = Path(__file__).resolve().parent
RUNTIME_DIR = BASE_DIR / "runtime"
STAGING_DIR = RUNTIME_DIR / "input_staging"
ACTIVE_INPUT_DIR = RUNTIME_DIR / "active_inputs"
PENDING_MANIFEST = STAGING_DIR / "pending_inputs.json"
ACTIVE_MANIFEST = ACTIVE_INPUT_DIR / "active_inputs.json"
RESULT_INDEX = RUNTIME_DIR / "result_index.json"
ACTIVE_ANALYTICS_DIR = RUNTIME_DIR / "active_analytics"
DLI_SENSITIVITY_DIR = RUNTIME_DIR / "dli_sensitivity"
DLI_SENSITIVITY_HISTORY_DIR = RUNTIME_DIR / "dli_sensitivity_history"

KIND_CONFIG = {
    "mrio": {
        "canonical_name": "input_mrio_completed.xlsx",
        "expected_account": "mrio_provider",
        "actor": "MRIO Data Provider",
    },
    "focal_demand": {
        "canonical_name": "Focal_Company_Demand_Converted.xlsx",
        "expected_account": "focal_company",
        "actor": "Focal Company",
    },
}


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def sha256_bytes(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def sha256_file(path: str | Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path, default: Any) -> Any:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value
    except Exception:
        return default


def _write_json_atomic(path: Path, payload: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(json.dumps(payload, indent=2, default=str), encoding="utf-8")
    temporary.replace(path)


def validate_mrio_bytes(body: bytes) -> dict[str, Any]:
    """Validate the workbook schema and the two MRIO accounting identities.

    A temporary *directory* is used instead of ``NamedTemporaryFile``.  More
    importantly, ``pd.ExcelFile`` is opened as a context manager and therefore
    closed before Windows attempts to remove the temporary workbook.  Without
    this explicit close, openpyxl/pandas can retain a file handle and Windows
    raises ``WinError 32`` during cleanup even though validation itself passed.
    """
    with tempfile.TemporaryDirectory(prefix="rq3_mrio_upload_") as temp_dir:
        temp_path = Path(temp_dir) / "uploaded_mrio.xlsx"
        temp_path.write_bytes(body)

        with pd.ExcelFile(temp_path, engine="openpyxl") as book:
            sheet_names = list(book.sheet_names)

        required_sheets = {"2014", "2017", "Metadata"}
        missing = sorted(required_sheets.difference(sheet_names))
        if missing:
            raise ValueError(
                "MRIO workbook is missing required sheet(s): " + ", ".join(missing)
            )
        metadata = pd.read_excel(temp_path, sheet_name="Metadata", engine="openpyxl")
        required_columns = {"Node_Code", "Region_Code", "Sector_Code"}
        missing_columns = sorted(required_columns.difference(metadata.columns))
        if missing_columns:
            raise ValueError(
                "MRIO Metadata sheet is missing column(s): "
                + ", ".join(missing_columns)
            )
        if len(metadata) != ae.N:
            raise ValueError(
                f"MRIO Metadata has {len(metadata)} rows; expected {ae.N} country-sector nodes."
            )
        node_codes = metadata["Node_Code"].astype(str).tolist()
        if len(set(node_codes)) != ae.N:
            raise ValueError("MRIO Metadata Node_Code values must be unique.")
        validations: dict[str, Any] = {}
        for year in (2014, 2017):
            my = ae.load_year(str(temp_path), year)
            checks = ae.validate(my)
            if not checks.get("L_at_Y_economy_matches_X"):
                raise ValueError(f"Leontief reconstruction failed for {year}: {checks}")
            if not checks.get("emissions_identity_holds"):
                raise ValueError(f"Emissions identity failed for {year}: {checks}")
            validations[str(year)] = checks
        return {
            "kind": "mrio",
            "sha256": sha256_bytes(body),
            "size_bytes": len(body),
            "node_count": len(node_codes),
            "years": [2014, 2017],
            "node_codes": node_codes,
            "validation": validations,
        }


def _active_mrio_node_codes() -> list[str] | None:
    path = BASE_DIR / KIND_CONFIG["mrio"]["canonical_name"]
    if not path.exists():
        return None
    metadata = pd.read_excel(path, sheet_name="Metadata")
    if "Node_Code" not in metadata.columns:
        return None
    return metadata["Node_Code"].astype(str).tolist()


def validate_focal_demand_bytes(
    body: bytes,
    expected_node_codes: list[str] | None = None,
) -> dict[str, Any]:
    """Validate the focal-company demand workbook against the active MRIO nodes."""
    if expected_node_codes is None:
        expected_node_codes = _active_mrio_node_codes()
    if not expected_node_codes:
        raise ValueError(
            "An accepted and active MRIO workbook is required before focal-company demand can be validated."
        )
    with tempfile.TemporaryDirectory(prefix="rq3_demand_upload_") as temp_dir:
        temp_path = Path(temp_dir) / "uploaded_focal_demand.xlsx"
        temp_path.write_bytes(body)

        with pd.ExcelFile(temp_path, engine="openpyxl") as book:
            sheet_names = list(book.sheet_names)

        if "Converted_Demand" not in sheet_names:
            raise ValueError(
                "Focal-company workbook is missing the required Converted_Demand sheet."
            )
        frame = pd.read_excel(
            temp_path,
            sheet_name="Converted_Demand",
            engine="openpyxl",
        )
        required_columns = {"Node_Code", "Company_2014_USD", "Company_2017_USD"}
        missing = sorted(required_columns.difference(frame.columns))
        if missing:
            raise ValueError(
                "Converted_Demand is missing column(s): " + ", ".join(missing)
            )
        if len(frame) != ae.N:
            raise ValueError(
                f"Converted_Demand has {len(frame)} rows; expected {ae.N} country-sector nodes."
            )
        node_codes = frame["Node_Code"].astype(str).tolist()
        if node_codes != list(expected_node_codes):
            raise ValueError(
                "Focal-company Node_Code ordering does not match the active MRIO Metadata ordering."
            )
        totals: dict[str, float] = {}
        for year in (2014, 2017):
            column = f"Company_{year}_USD"
            values = pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=float)
            if not np.isfinite(values).all():
                raise ValueError(f"{column} contains non-finite or non-numeric values.")
            if (values < 0).any():
                raise ValueError(f"{column} contains negative demand values.")
            totals[str(year)] = float(values.sum())
        return {
            "kind": "focal_demand",
            "sha256": sha256_bytes(body),
            "size_bytes": len(body),
            "node_count": len(node_codes),
            "years": [2014, 2017],
            "node_codes": node_codes,
            "total_demand": totals,
        }


def validate_bytes(kind: str, body: bytes) -> dict[str, Any]:
    normalised = normalise_kind(kind)
    if normalised == "mrio":
        return validate_mrio_bytes(body)
    return validate_focal_demand_bytes(body)


def normalise_kind(kind: str) -> str:
    value = str(kind).strip().lower().replace("-", "_")
    if value in {"mrio", "mriodata", "0"}:
        return "mrio"
    if value in {"focal", "focal_demand", "focaldemand", "focaldemanddata", "1"}:
        return "focal_demand"
    raise ValueError(f"Unsupported input kind: {kind}")


def stage_upload(
    kind: str,
    body: bytes,
    *,
    actor_address: str,
    original_name: str,
    validation: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Save bytes in staging and return the immutable staged-input record."""
    normalised = normalise_kind(kind)
    validation = validation or validate_bytes(normalised, body)
    digest = sha256_bytes(body)
    if digest != str(validation.get("sha256", "")):
        raise ValueError("Validation hash does not match the uploaded bytes.")
    STAGING_DIR.mkdir(parents=True, exist_ok=True)
    canonical_name = KIND_CONFIG[normalised]["canonical_name"]
    staged_path = STAGING_DIR / f"{digest}_{canonical_name}"
    if not staged_path.exists():
        temporary = staged_path.with_name(f".{staged_path.name}.tmp")
        temporary.write_bytes(body)
        temporary.replace(staged_path)
    manifest = _read_json(PENDING_MANIFEST, {})
    record = {
        "kind": normalised,
        "sha256": digest,
        "actor": KIND_CONFIG[normalised]["actor"],
        "actor_address": str(actor_address),
        "original_name": str(original_name),
        "staged_path": str(staged_path),
        "staged_at_utc": utc_now(),
        "validation": {k: v for k, v in validation.items() if k != "node_codes"},
        "status": "staged",
    }
    manifest[f"{normalised}:{digest}"] = record
    _write_json_atomic(PENDING_MANIFEST, manifest)
    return record


def get_staged_record(kind: str, digest: str) -> dict[str, Any]:
    normalised = normalise_kind(kind)
    digest = str(digest).strip().lower()
    record = _read_json(PENDING_MANIFEST, {}).get(f"{normalised}:{digest}")
    if not isinstance(record, dict):
        raise FileNotFoundError(
            f"No staged {normalised} workbook is registered for SHA-256 {digest}."
        )
    path = Path(record.get("staged_path", ""))
    if not path.is_file():
        raise FileNotFoundError(f"The staged workbook no longer exists: {path}")
    if sha256_file(path) != digest:
        raise ValueError("The staged workbook hash no longer matches the submitted SHA-256.")
    return record


def validate_staged_for_oracle(
    kind: str,
    digest: str,
    requester: str,
    deployment: dict[str, Any],
) -> dict[str, Any]:
    """Independently revalidate a staged workbook for the Upstream Oracle."""
    normalised = normalise_kind(kind)
    config = KIND_CONFIG[normalised]
    expected = str(deployment.get("accounts", {}).get(config["expected_account"], ""))
    if not expected or str(requester).lower() != expected.lower():
        raise PermissionError(
            f"Requester is not the configured {config['actor']} Ethereum address."
        )
    record = get_staged_record(normalised, digest)
    if str(record.get("actor_address", "")).lower() != expected.lower():
        raise PermissionError("The staged workbook was not submitted by the authorized account.")
    body = Path(record["staged_path"]).read_bytes()
    validation = validate_bytes(normalised, body)
    if validation["sha256"] != str(digest).lower():
        raise ValueError("Independent validation produced a different SHA-256 value.")
    return {
        "kind": normalised,
        "accepted": True,
        "submitted_hash": str(digest).lower(),
        "requester": requester,
        "authorized_actor": config["actor"],
        "staged_path": record["staged_path"],
        "validation": {k: v for k, v in validation.items() if k != "node_codes"},
        "validation_method": "independent SHA-256, Excel schema, node alignment, and accounting checks",
    }


def _atomic_copy(source: Path, target: Path) -> None:
    target.parent.mkdir(parents=True, exist_ok=True)
    temporary = target.with_name(f".{target.name}.promote.tmp")
    shutil.copyfile(source, temporary)
    temporary.replace(target)


def invalidate_downstream_runtime(reason: str) -> None:
    """Hide old results from the active UI while preserving content-addressed audit files."""
    if RESULT_INDEX.exists():
        archived = RUNTIME_DIR / "result_index_history"
        archived.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        shutil.copyfile(RESULT_INDEX, archived / f"result_index_{stamp}.json")
        RESULT_INDEX.unlink(missing_ok=True)
    if ACTIVE_ANALYTICS_DIR.exists():
        shutil.rmtree(ACTIVE_ANALYTICS_DIR)
    # Weight-sensitivity reports are derived from a fulfilled DLI ranking and
    # its active MRIO/focal-demand hashes.  Archive the complete active view
    # rather than deleting its immutable runs, but remove its latest pointers
    # from the active location so Streamlit cannot display stale evidence.
    if DLI_SENSITIVITY_DIR.exists():
        DLI_SENSITIVITY_HISTORY_DIR.mkdir(parents=True, exist_ok=True)
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        archived_sensitivity = DLI_SENSITIVITY_HISTORY_DIR / stamp
        collision = 1
        while archived_sensitivity.exists():
            archived_sensitivity = DLI_SENSITIVITY_HISTORY_DIR / f"{stamp}_{collision:02d}"
            collision += 1
        DLI_SENSITIVITY_DIR.replace(archived_sensitivity)
        _write_json_atomic(
            archived_sensitivity / "archive_metadata.json",
            {
                "archived_at_utc": utc_now(),
                "reason": reason,
                "source_runtime_directory": "dli_sensitivity",
                "display_policy": (
                    "Archived sensitivity results are audit records only and are never read by the active Streamlit view."
                ),
            },
        )
    marker = {
        "invalidated_at_utc": utc_now(),
        "reason": reason,
    }
    _write_json_atomic(RUNTIME_DIR / "last_result_invalidation.json", marker)


def promote_staged_after_onchain_acceptance(
    kind: str,
    digest: str,
    requester: str,
    deployment: dict[str, Any],
) -> dict[str, Any]:
    """Promote validated staged bytes only after the accepted fulfilment transaction."""
    normalised = normalise_kind(kind)
    validation = validate_staged_for_oracle(normalised, digest, requester, deployment)
    record = get_staged_record(normalised, digest)
    source = Path(record["staged_path"])
    canonical_name = KIND_CONFIG[normalised]["canonical_name"]
    targets = [BASE_DIR / canonical_name, BASE_DIR / "streamlit_app" / canonical_name]
    ACTIVE_INPUT_DIR.mkdir(parents=True, exist_ok=True)
    active_manifest = _read_json(ACTIVE_MANIFEST, {})
    existing = active_manifest.get(normalised, {}) if isinstance(active_manifest, dict) else {}
    if (
        isinstance(existing, dict)
        and str(existing.get("sha256", "")).lower() == str(digest).lower()
        and all(target.is_file() and sha256_file(target) == str(digest).lower() for target in targets)
    ):
        return existing
    for target in targets:
        _atomic_copy(source, target)
    active_record = {
        **record,
        "status": "active",
        "activated_at_utc": utc_now(),
        "active_paths": [str(path) for path in targets],
    }
    active_manifest[normalised] = active_record

    # A changed MRIO system invalidates the previously aligned focal-demand file.
    if normalised == "mrio":
        previous_demand = active_manifest.pop("focal_demand", None)
        for target in [
            BASE_DIR / KIND_CONFIG["focal_demand"]["canonical_name"],
            BASE_DIR / "streamlit_app" / KIND_CONFIG["focal_demand"]["canonical_name"],
        ]:
            target.unlink(missing_ok=True)
        if previous_demand:
            active_record["invalidated_previous_focal_demand"] = previous_demand.get("sha256")

    _write_json_atomic(ACTIVE_MANIFEST, active_manifest)
    # Clear process-local workbook/Leontief caches immediately after an input
    # promotion.  The file-signature cache also invalidates automatically, but
    # explicit clearing releases the old matrices and makes the governance
    # transition unambiguous.
    try:
        import analytics_engine as _analytics_engine
        _analytics_engine.clear_input_cache()
    except Exception:
        # Input promotion remains authoritative even if a worker has not yet
        # imported the analytics module; newly loaded files still use a new
        # stat signature.
        pass
    invalidate_downstream_runtime(
        f"Active {normalised} input changed to {digest}; dependent results require recomputation."
    )
    pending = _read_json(PENDING_MANIFEST, {})
    key = f"{normalised}:{str(digest).lower()}"
    if key in pending:
        pending[key]["status"] = "promoted"
        pending[key]["promoted_at_utc"] = utc_now()
        _write_json_atomic(PENDING_MANIFEST, pending)
    return active_record


def active_input_record(kind: str) -> dict[str, Any] | None:
    return _read_json(ACTIVE_MANIFEST, {}).get(normalise_kind(kind))


def active_input_hash(kind: str) -> str:
    record = active_input_record(kind) or {}
    return str(record.get("sha256", ""))


def active_input_hashes(require_both: bool = True) -> dict[str, str]:
    values = {
        "mrio": active_input_hash("mrio"),
        "focal_demand": active_input_hash("focal_demand"),
    }
    if require_both and not all(values.values()):
        missing = [key for key, value in values.items() if not value]
        raise RuntimeError(
            "Operational analytical inputs have not been uploaded and activated: "
            + ", ".join(missing)
        )
    return values
