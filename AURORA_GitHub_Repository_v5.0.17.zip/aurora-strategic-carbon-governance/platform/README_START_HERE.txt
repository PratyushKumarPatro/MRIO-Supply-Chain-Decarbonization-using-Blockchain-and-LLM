Strategic Carbon Intelligence & Governance Platform v5.0.17
================================================================

This deployable successor preserves the established MRIO, SPA, SDA, pooled
Pearson-CRITIC DLI, producer-linkage, AURORA, intervention-abatement ranges,
formal human governance, and observed-performance anchoring. It makes the
Blockchain and LLM-based System page the sole operational control plane for the
complete intervention workflow. The Intervention Governance sidebar workspace
is a read-only results, provenance, and download surface.

The deployable Solidity source is contracts\StrategicCarbonIntelligenceSystem.sol,
and the stakeholder event monitor remains part of the governed runtime.

Use the exact clean Windows installation sequence in:

    U23_WINDOWS_DEPLOYMENT_COMMANDS.txt

Do not copy deployment.json, runtime, content_store, .venv, node_modules, old
contract addresses, or user input workbooks into a clean validation deployment.

GOVERNED SEQUENCE
-----------------
1. Register the regulator, focal company, data provider, and four Oracles.
2. Validate and anchor MRIO and focal-company demand workbooks.
3. Complete MRIO footprint, producer hotspots, bounded dynamic-coverage SPA,
   company/node/path SDA, and their verified evidence artifacts.
4. Complete Network/DLI for 2014 and then 2017 using one pooled normalization
   and one common Pearson-CRITIC weight vector.
5. Run the 2017 AURORA regional opportunity assessment after temporal DLI.
   AURORA means Analogue-based Upstream Regional Opportunity and Resilience Assessment.
6. On the Blockchain and LLM-based System page, explicitly compute Stage 12
   intervention evidence and candidate mappings from producer magnitude,
   complete-network linkage, DLI, signed node-SDA, path-SDA refinement, and
   fulfilled AURORA context.
7. On that same page, select a producer hotspot and its linked leverage node,
   then review the deterministic driver-to-mechanism mapping.
8. Record named node-level actionability and pair-specific technical feasibility
   on the Blockchain page.
9. Make an explicit abatement-evidence decision: either quantify an intervention-
   specific conservative/expected/ambitious range using documented effectiveness,
   coverage and adoption, or document why quantification is not defensible yet.
10. Generate and inspect the governance-ready portfolio. The sidebar workspace
    provides detailed read-only tables, charts, provenance, and downloads.
11. On the Blockchain page, select one intervention and submit it to the
    Governance Oracle; then separately approve or reject the verified proposal.
12. Open final LLM decision support only after the intervention branch is resolved,
    including a verified no-option result after a complete assessment where applicable.
13. For an approved and implemented intervention, submit a like-for-like monitored
    hotspot footprint and evidence reference; anchor the observation CID on-chain
    without overwriting the original scenario.

FOUR EMISSIONS QUANTITIES
-------------------------
- Baseline hotspot footprint: observed reference-year producer emissions.
- Structurally associated footprint: complete-node-removal linkage diagnostic.
  This is not predicted abatement.
- Intervention-abatement range: assumption-bound comparative estimate using the
  smaller of baseline and positive structural linkage as the affected footprint,
  multiplied by conservative/expected/ambitious effectiveness, implementation
  coverage, and adoption.
- Observed reduction: baseline minus the stakeholder-submitted post-deployment
  footprint. The platform verifies lineage and arithmetic, while the named
  evidence document remains the authority for external measurement truth.

Silent omission is not governance-ready. If defensible scenario inputs are
unavailable, explicitly choose “Proceed without quantification” and record the
reason, accountable assessor, role, and supporting reference. The system then
reports “Documented unquantified” rather than inventing a percentage.

INTERVENTION GOVERNANCE CONTROL AND RESULTS
-------------------------------------------
All intervention mutations occur on the Blockchain and LLM-based System page:
evidence computation, hotspot/leverage selection, actionability, technical
feasibility, an explicit quantified or documented-unquantified scenario decision,
portfolio generation, formal option
selection, Oracle verification, approval/rejection, and approved-intervention
monitoring.

The Intervention Governance sidebar workspace unlocks after Stage 12 evidence is
computed. It provides read-only connected result views: integrated pair evidence;
recorded actionability and feasibility; abatement scenarios and comparative chart;
governance-ready portfolio; immutable formal options; and downloads/provenance.

The Blockchain-page scenario form requires a named assessor, role and evidence
reference. Quantification additionally requires ordered effectiveness bounds,
implementation coverage, adoption, confidence, and limitations. A documented
non-quantification requires a reason and future quantification plan.
Packaged literature sensitivities are displayed only where present and never fill
organizational coverage or adoption automatically.

BLOCKCHAIN AND FINAL SUPPORT
----------------------------
The formal option CID contains the analytical evidence, actionability evidence,
scenario assumptions, range, provenance, and claim boundary reviewed at selection.
Selection is not approval. The Governance Oracle verifies the immutable option,
and an authorized focal-company or regulatory account records approval or rejection.

Final decision support is locked until every selected proposal has a formal
decision or the verified assessment establishes that no governance-ready option
exists. After approval, monitored-performance CIDs may be appended to the
intervention. The original scenario is never overwritten.

METHOD BOUNDARIES
-----------------
- DLI identifies structural intervention leverage; it is not a t CO2 estimate.
- SPA explains supply-chain routes; path emissions are not automatically avoided.
- SDA explains historical change drivers; it does not predict future abatement.
- AURORA adds regional opportunity evidence; it does not overwrite DLI or approve action.
- Structural coverage remains distinct from scenario and observed reductions.
- Scenario values are comparative estimates, not forecasts or guarantees.
- Blockchain establishes authorization, integrity, provenance, and ordering; it
  does not prove the external truth of a monitoring document.
- The LLM retrieves and explains governed evidence. It cannot recalculate the
  authoritative analytics, invent actionability, or change lifecycle state.

CURRENT RELEASE DOCUMENTS
-------------------------
- U23_EVIDENCE_BOUND_ABATEMENT_DECISION_GUIDE.txt
- U23_WINDOWS_DEPLOYMENT_COMMANDS.txt
- U23_WINDOWS_DEPLOYMENT_VALIDATION_REPORT.txt
- U23_FINAL_READY_STATUS.json
- U23_CONTRACT_CONTINUITY_SHA256.json
- PLATFORM_DEPLOYMENT_COMMANDS.txt

U22 and earlier release records, including the Blockchain control-plane guide,
are retained as historical assurance material.
