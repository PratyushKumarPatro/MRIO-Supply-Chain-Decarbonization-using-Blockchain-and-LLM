"""Operational SPA-SDA-pathway-relevance and CRITIC-DLI integration.

This service is called directly by the custom Data Orchestrator.  It does not
search module globals, register Flask/FastAPI routes, or rely on monkey patches.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any, Callable, Mapping
import hashlib
import json
import os
import shutil

import numpy as np
import pandas as pd

import analytics_engine as ae
import node_sda_engine as node_sda
import hotspot_leverage as hotspot_link
from critic_dli_core import CRITERIA
from spa_sda_pathway_bridge import (
    FACTORS,
    ModelAdapter,
    allocate_temporal_drivers_to_nodes,
    build_path_panel,
    cluster_baseline_paths,
    compute_pathway_participation,
    mark_dominant_display_paths,
    merge_node_strategy,
    parse_path,
    summarize_classes,
    classify_signed_driver_effects,
)

INTEGRATION_RELEASE_ID = "v5.0.17-U17"
PATH_PAIR_EVIDENCE_FILENAME = "hotspot_leverage_pathway_evidence_2017.csv"
PATH_TRANSITIONS_FILENAME = "spa_path_transitions_2014_2017.csv"
PATH_NODE_ALLOCATION_FILENAME = "represented_path_effect_allocation_by_node.csv"


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _runtime_dir(explicit: str | Path | None = None) -> Path:
    if explicit is not None:
        return Path(explicit)
    return Path(os.environ.get("SCIG_RUNTIME_DIR") or Path(__file__).resolve().parent / "runtime")


def _load_spa_artifact(
    runtime: Path,
    year: int,
    expected_input_hashes: Mapping[str, str],
) -> tuple[pd.DataFrame, dict[str, Any]]:
    active = runtime / "active_analytics"
    csv_path = active / f"spa_screened_paths_{int(year)}.csv"
    meta_path = active / f"spa_screened_paths_{int(year)}.json"
    if not csv_path.is_file() or not meta_path.is_file():
        raise FileNotFoundError(
            f"Complete bounded SPA artifact for {year} is unavailable. Re-run the governed SPA request for that year."
        )
    metadata = json.loads(meta_path.read_text(encoding="utf-8"))
    if metadata.get("input_hashes") != dict(expected_input_hashes):
        raise RuntimeError(f"SPA {year} artifact does not match the active input hashes")
    observed_hash = _sha256_file(csv_path)
    if observed_hash != str(metadata.get("frame_sha256", "")):
        raise RuntimeError(f"SPA {year} artifact hash mismatch")

    # The mutable active CSV is only a convenience mirror.  Bind it to the
    # currently indexed immutable SPA result and independently verify that
    # content-addressed envelope before allowing it into downstream SPA/SDA.
    source_cid = str(metadata.get("source_result_cid", "")).strip().lower()
    if (
        len(source_cid) != 64
        or any(character not in "0123456789abcdef" for character in source_cid)
    ):
        raise RuntimeError(f"SPA {year} artifact has no valid source result CID")
    index_path = runtime / "result_index.json"
    try:
        index = json.loads(index_path.read_text(encoding="utf-8"))
        active_record = index["results"][f"spa:{int(year)}"]
    except Exception as exc:
        raise RuntimeError(f"Active SPA {year} result index is unavailable") from exc
    if (
        str(active_record.get("content_hash", "")).strip().lower() != source_cid
        or active_record.get("input_hashes") != dict(expected_input_hashes)
    ):
        raise RuntimeError(f"SPA {year} artifact is not bound to the active result CID")

    envelope_path = runtime.parent / "content_store" / f"{source_cid}.json"
    if not envelope_path.is_file():
        envelope_path = runtime.parent / "content_store" / source_cid
    if not envelope_path.is_file():
        raise RuntimeError(f"Immutable SPA {year} result package is unavailable")
    envelope_bytes = envelope_path.read_bytes()
    if hashlib.sha256(envelope_bytes).hexdigest() != source_cid:
        raise RuntimeError(f"Immutable SPA {year} result package failed its CID check")
    try:
        envelope = json.loads(envelope_bytes.decode("utf-8"))
        material = envelope["payload"]
        payload = material["payload"]
    except Exception as exc:
        raise RuntimeError(f"Immutable SPA {year} result package is malformed") from exc
    if (
        envelope.get("namespace") != "structural_path_analysis"
        or material.get("operation") != "structural_path_analysis"
        or int(payload.get("year", -1)) != int(year)
        or payload.get("input_hashes") != dict(expected_input_hashes)
    ):
        raise RuntimeError(f"Immutable SPA {year} result package has the wrong provenance")
    committed = payload.get("screened_paths_artifact", {})
    if (
        not isinstance(committed, dict)
        or str(committed.get("filename", "")) != csv_path.name
        or str(committed.get("sha256", "")).lower() != observed_hash
        or str(metadata.get("committed_artifact_sha256", "")).lower()
        != observed_hash
    ):
        raise RuntimeError(f"SPA {year} screened artifact is not committed by its source CID")

    frame = pd.read_csv(csv_path)
    required = {"path_codes", "contribution", "depth"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"SPA {year} artifact is missing columns: {missing}")
    if (
        len(frame) != int(metadata.get("screened_path_count", -1))
        or len(frame) != int(metadata.get("row_count", -1))
        or len(frame) != int(committed.get("row_count", -1))
        or len(frame) != int(payload.get("screened_path_count", -1))
    ):
        raise ValueError(f"SPA {year} artifact row count does not match its metadata")
    return frame, metadata


def _load_authoritative_node_sda(
    runtime: Path, expected_input_hashes: Mapping[str, str]
) -> tuple[pd.DataFrame, dict[str, Any]]:
    active = runtime / "active_analytics"
    metadata = node_sda.verify_node_sda_artifacts(
        active, expected_input_hashes=expected_input_hashes
    )
    frame = pd.read_csv(active / node_sda.ALL_NODES_FILENAME)
    required = {
        "node_code",
        "node_delta_intensity",
        "node_delta_technology",
        "node_delta_composition",
        "node_delta_scale",
        "node_dominant_driver",
        "node_temporal_status",
        "in_comparison_top_80_hotspot_set",
    }
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Authoritative node-wise SDA is missing columns: {missing}")
    return frame, metadata


def _load_hotspot_leverage_frames(
    runtime: Path, expected_input_hashes: Mapping[str, str]
) -> tuple[dict[str, pd.DataFrame], dict[str, Any]]:
    active = runtime / "active_analytics"
    metadata = hotspot_link.verify_hotspot_leverage_artifacts(
        active, expected_input_hashes=expected_input_hashes
    )
    filenames = {
        "node_summary": hotspot_link.NODE_SUMMARY_FILENAME,
        "pair_evidence": hotspot_link.PAIR_EVIDENCE_FILENAME,
        "direct_portfolio": hotspot_link.DIRECT_PORTFOLIO_FILENAME,
        "governance_mediated_portfolio": hotspot_link.MEDIATED_PORTFOLIO_FILENAME,
        "hybrid_portfolio": hotspot_link.HYBRID_PORTFOLIO_FILENAME,
    }
    return {name: pd.read_csv(active / filename) for name, filename in filenames.items()}, metadata


def _union_paths(*frames: pd.DataFrame) -> set[tuple[str, ...]]:
    """Return the union of exact ordered path identities across study years.

    A node may be common to both years while its complete path changes. Such
    paths remain separate identities. Every union path is evaluated under both
    annual MRIO states; an exact route is zero only when its factor product is
    structurally zero. Beam-selection membership is reported separately so a
    screening omission is never misclassified as physical path disappearance.
    """
    paths: set[tuple[str, ...]] = set()
    for frame in frames:
        for value in frame["path_codes"].dropna():
            path = parse_path(value)
            if path:
                paths.add(path)
    if not paths:
        raise RuntimeError("No valid country-sector path codes were found in the SPA artifacts")
    return paths


# Historical private name retained only for callers; semantics are explicitly
# union-based rather than an intersection of surviving exact paths.
def _common_paths(*frames: pd.DataFrame) -> set[tuple[str, ...]]:
    return _union_paths(*frames)


def _company_sda_from_node_metadata(metadata: Mapping[str, Any]) -> dict[str, Any]:
    """Reuse the authoritative company-SDA values embedded in node-SDA evidence."""
    effects = {
        factor: float(metadata[f"company_{factor}_effect_tco2"])
        for factor in FACTORS
    }
    base = float(metadata["company_base_footprint_tco2"])
    comparison = float(metadata["company_comparison_footprint_tco2"])
    change = comparison - base
    return {
        "footprint_base_tCO2": base,
        "footprint_comparison_tCO2": comparison,
        "complete_change_tCO2": change,
        "effects": effects,
        "reconciliation_residual_tCO2": float(sum(effects.values()) - change),
        "source": "authoritative node-SDA metadata; no redundant runtime SDA recomputation",
    }


def build_hotspot_leverage_path_evidence(
    pair_evidence: pd.DataFrame,
    path_panel: pd.DataFrame,
) -> pd.DataFrame:
    """Attach bounded-SPA/path-SDA mechanism evidence to each hotspot pair.

    Path evidence is supporting diagnostic evidence, not a mandatory gate:
    bounded SPA may not represent every system-wide dependency detected by the
    complete CDR counterfactual.  Exact ordered path identities are preserved,
    including persistent, emerging, disappearing and reconfigured routes.
    """
    if pair_evidence.empty:
        return pair_evidence.copy()
    required = {"intervention_node", "hotspot_producer_node"}
    missing = sorted(required.difference(pair_evidence.columns))
    if missing:
        raise ValueError(f"Hotspot pair evidence is missing columns: {missing}")

    accumulators: dict[tuple[str, str], dict[str, Any]] = {}
    for record in path_panel.to_dict(orient="records"):
        nodes_raw = record.get("path_nodes", [])
        nodes = [str(node) for node in nodes_raw]
        if not nodes:
            continue
        terminal = str(record.get("terminal_emitter_node", nodes[-1]))
        unique_nodes = sorted(set(nodes))
        for leverage in unique_nodes:
            key = (leverage, terminal)
            bucket = accumulators.setdefault(
                key,
                {
                    "records": [],
                    "effects": {factor: 0.0 for factor in FACTORS},
                },
            )
            bucket["records"].append(record)
            for factor in FACTORS:
                bucket["effects"][factor] += float(record.get(f"delta_{factor}", 0.0))

    tolerance = 1e-12
    rows: list[dict[str, Any]] = []
    for pair in pair_evidence.to_dict(orient="records"):
        key = (str(pair["intervention_node"]), str(pair["hotspot_producer_node"]))
        bucket = accumulators.get(key)
        if not bucket:
            path_fields = {
                "represented_path_link_count": 0,
                "represented_path_link_status": "no bounded represented path containing the pair",
                "represented_persistent_path_count": 0,
                "represented_emerging_path_count": 0,
                "represented_disappearing_path_count": 0,
                "represented_reconfigured_path_count": 0,
                "represented_path_baseline_tco2": 0.0,
                "represented_path_comparison_tco2": 0.0,
                "represented_path_change_tco2": 0.0,
                "represented_path_primary_adverse_driver": "",
                "represented_path_primary_adverse_effect_tco2": 0.0,
                "represented_path_secondary_adverse_drivers": "",
                "represented_path_primary_beneficial_driver": "",
                "represented_path_primary_beneficial_effect_tco2": 0.0,
                "represented_path_driver_pattern": "no bounded represented path evidence",
                "top_relevant_exact_paths": "",
            }
        else:
            records = list(bucket["records"])
            classification = classify_signed_driver_effects(bucket["effects"], tolerance)
            sorted_paths = sorted(
                records,
                key=lambda item: (
                    -abs(float(item.get("comparison_contribution", 0.0))),
                    str(item.get("path_id", "")),
                ),
            )
            top_paths = [
                f"{item.get('path_id', '')} [{item.get('path_identity_status', '')}; "
                f"2017={float(item.get('comparison_contribution', 0.0)):.6g}; "
                f"change={float(item.get('delta_path_contribution', 0.0)):.6g}]"
                for item in sorted_paths[:5]
            ]
            statuses = [str(item.get("path_identity_status", "")) for item in records]
            reconfigured = [
                str(item.get("route_reconfiguration_status", ""))
                for item in records
            ]
            path_fields = {
                "represented_path_link_count": int(len(records)),
                "represented_path_link_status": "bounded represented path evidence available",
                "represented_persistent_path_count": int(sum(value == "persistent exact path" for value in statuses)),
                "represented_emerging_path_count": int(sum(value == "emerging exact path" for value in statuses)),
                "represented_disappearing_path_count": int(sum(value == "disappearing exact path" for value in statuses)),
                "represented_reconfigured_path_count": int(sum(value != "not reconfigured" for value in reconfigured)),
                "represented_path_baseline_tco2": float(sum(float(item.get("baseline_contribution", 0.0)) for item in records)),
                "represented_path_comparison_tco2": float(sum(float(item.get("comparison_contribution", 0.0)) for item in records)),
                "represented_path_change_tco2": float(sum(float(item.get("delta_path_contribution", 0.0)) for item in records)),
                "represented_path_primary_adverse_driver": str(classification["primary_adverse_driver"]),
                "represented_path_primary_adverse_effect_tco2": float(classification["primary_adverse_effect_tco2"]),
                "represented_path_secondary_adverse_drivers": str(classification["secondary_adverse_drivers"]),
                "represented_path_primary_beneficial_driver": str(classification["primary_beneficial_driver"]),
                "represented_path_primary_beneficial_effect_tco2": float(classification["primary_beneficial_effect_tco2"]),
                "represented_path_driver_pattern": str(classification["driver_pattern"]),
                "top_relevant_exact_paths": " | ".join(top_paths),
            }
        rows.append({
            **pair,
            **path_fields,
            "path_evidence_authority_boundary": (
                "Path-SDA explains represented route change and informs mechanism design; "
                "it does not alter node-SDA, DLI, or producer-resolved CDR linkage, and absence "
                "from bounded SPA does not negate a system-wide CDR relationship."
            ),
        })
    return pd.DataFrame.from_records(rows)


def _write_content_copy(source: Path, content_store: Path) -> str:
    digest = _sha256_file(source)
    content_store.mkdir(parents=True, exist_ok=True)
    extension_target = content_store / f"{digest}{source.suffix}"
    extensionless_target = content_store / digest
    if not extension_target.exists():
        shutil.copyfile(source, extension_target)
    if not extensionless_target.exists():
        shutil.copyfile(source, extensionless_target)
    return digest


def _format_workbook(path: Path) -> None:
    from openpyxl import load_workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    workbook = load_workbook(path)
    header_fill = PatternFill("solid", fgColor="1F4E78")
    header_font = Font(color="FFFFFF", bold=True)
    caution_fill = PatternFill("solid", fgColor="FCE4D6")
    for worksheet in workbook.worksheets:
        worksheet.freeze_panes = "A2"
        worksheet.sheet_view.showGridLines = False
        if worksheet.max_row >= 1:
            for cell in worksheet[1]:
                cell.fill = header_fill
                cell.font = header_font
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            worksheet.auto_filter.ref = worksheet.dimensions
        for column_index, column_cells in enumerate(worksheet.columns, start=1):
            width = 10
            for cell in list(column_cells)[:200]:
                value = "" if cell.value is None else str(cell.value)
                width = max(width, min(42, len(value) + 2))
                if cell.row > 1:
                    cell.alignment = Alignment(vertical="top", wrap_text=True)
            worksheet.column_dimensions[get_column_letter(column_index)].width = width
        if worksheet.title in {"Methodology_Notes", "Provenance"}:
            for row in worksheet.iter_rows(min_row=2):
                row[0].fill = caution_fill
    workbook.save(path)


def _export_results(
    runtime: Path,
    panel: pd.DataFrame,
    diagnostics: pd.DataFrame,
    cluster_info: Mapping[str, Any],
    class_summary: pd.DataFrame,
    participation: pd.DataFrame,
    temporal_nodes: pd.DataFrame,
    path_temporal_nodes: pd.DataFrame,
    path_transitions: pd.DataFrame,
    pair_path_evidence: pd.DataFrame,
    hotspot_frames: Mapping[str, pd.DataFrame],
    strategy: pd.DataFrame,
    critic_weights: pd.DataFrame,
    critic_ranking: pd.DataFrame,
    summary: Mapping[str, Any],
    reconciliation: Mapping[str, Any],
    participation_metadata: Mapping[str, Any],
    dominant_metadata: Mapping[str, Any],
    source_metadata: Mapping[str, Any],
) -> tuple[dict[str, Path], dict[str, str]]:
    output = runtime / "active_analytics"
    output.mkdir(parents=True, exist_ok=True)
    files: dict[str, Path] = {
        "path_evidence": output / "spa_sda_integrated_paths.csv",
        "class_driver_matrix": output / "spa_sda_path_class_driver_matrix.csv",
        "pathway_participation": output / "spa_emissions_weighted_node_participation.csv",
        "node_temporal_drivers": output / "spa_sda_node_driver_evidence.csv",
        "represented_path_effect_allocation": output / PATH_NODE_ALLOCATION_FILENAME,
        "path_transitions": output / PATH_TRANSITIONS_FILENAME,
        "hotspot_leverage_pathway_evidence": output / PATH_PAIR_EVIDENCE_FILENAME,
        "node_strategy": output / "spa_sda_critic_dli_node_synthesis.csv",
        "cluster_diagnostics": output / "spa_path_cluster_diagnostics.csv",
        "cluster_centroids": output / "spa_path_cluster_centroids.csv",
        "workbook": output / "SPA_SDA_CRITIC_DLI_Integrated_Results.xlsx",
    }
    hotspot_file_map = {
        "hotspot_leverage_node_summary": hotspot_link.NODE_SUMMARY_FILENAME,
        "hotspot_leverage_pair_evidence": hotspot_link.PAIR_EVIDENCE_FILENAME,
        "hotspot_leverage_direct_portfolio": hotspot_link.DIRECT_PORTFOLIO_FILENAME,
        "hotspot_leverage_governance_mediated_portfolio": hotspot_link.MEDIATED_PORTFOLIO_FILENAME,
        "hotspot_leverage_hybrid_portfolio": hotspot_link.HYBRID_PORTFOLIO_FILENAME,
        "hotspot_leverage_workbook": hotspot_link.WORKBOOK_FILENAME,
        "node_sda_workbook": node_sda.WORKBOOK_FILENAME,
    }
    for name, filename in hotspot_file_map.items():
        candidate = output / filename
        if candidate.is_file():
            files[name] = candidate

    path_export = panel.drop(
        columns=[
            column
            for column in panel.columns
            if column in {"path_nodes", "baseline_edge_coefficients", "comparison_edge_coefficients"}
        ],
        errors="ignore",
    )
    path_export.to_csv(files["path_evidence"], index=False)
    class_summary.to_csv(files["class_driver_matrix"], index=False)
    participation.to_csv(files["pathway_participation"], index=False)
    temporal_nodes.to_csv(files["node_temporal_drivers"], index=False)
    path_temporal_nodes.to_csv(files["represented_path_effect_allocation"], index=False)
    path_transitions.to_csv(files["path_transitions"], index=False)
    pair_path_evidence.to_csv(files["hotspot_leverage_pathway_evidence"], index=False)
    strategy.to_csv(files["node_strategy"], index=False)
    diagnostics.to_csv(files["cluster_diagnostics"], index=False)
    centroids = pd.DataFrame(cluster_info.get("centroids", []))
    centroids.to_csv(files["cluster_centroids"], index=False)

    notes = pd.DataFrame(
        [
            {
                "topic": "SPA participation",
                "statement": participation_metadata.get("non_additivity_note"),
            },
            {
                "topic": "87%-of-total coverage-aligned display subset",
                "statement": str(dominant_metadata.get("authority_boundary")) + " The complete bounded path evidence is retained in spa_sda_integrated_paths.csv; the workbook includes the complete coverage-aligned display subset.",
            },
            {
                "topic": "SDA authority boundary",
                "statement": "Company-level SDA remains the complete aggregate decomposition. Authoritative node-wise SDA applies the same four-factor 24-permutation method to every producer node and reconciles to the company result. Path-level SDA retains all signed effects and supplies a secondary mechanism drill-down; the largest positive effect is the primary adverse intervention driver and negative effects are beneficial/offsetting evidence.",
            },
            {
                "topic": "Cross-year path identity",
                "statement": "The panel uses the union of complete ordered path identities. A node common to both years may follow different paths. Every union route is evaluated under both annual MRIO states; structural zeros support emerging/disappearing labels, while bounded-SPA beam-selection membership is reported separately to avoid treating screen omission as physical disappearance.",
            },
            {
                "topic": "DLI weighting",
                "statement": "BC, PR, CDR and IC are selected theoretically; their weights are derived exclusively through pooled Pearson-CRITIC.",
            },
            {
                "topic": "Hotspot-leverage structural coverage",
                "statement": "DLI is not combined with HSI into another score. Exact joint marginal portfolios control overlap under the existing complete-node-removal counterfactual; their coverage is not predicted realizable abatement.",
            },
            {
                "topic": "Classification",
                "statement": "H/M/L labels are descriptive. Continuous SPA participation, Shapley effects and CRITIC-DLI values remain authoritative.",
            },
        ]
    )
    provenance = pd.DataFrame(
        [
            {"field": key, "value": json.dumps(value, sort_keys=True) if isinstance(value, (dict, list)) else value}
            for key, value in {**source_metadata, **summary}.items()
        ]
    )

    with pd.ExcelWriter(files["workbook"], engine="openpyxl") as writer:
        pd.DataFrame([summary]).to_excel(writer, "Summary", index=False)
        diagnostics.to_excel(writer, "Cluster_Diagnostics", index=False)
        centroids.to_excel(writer, "Cluster_Centroids", index=False)
        pd.DataFrame(cluster_info.get("leave_one_feature_out", [])).to_excel(
            writer, "Feature_Robustness", index=False
        )
        class_summary.to_excel(writer, "Class_Driver_Matrix", index=False)
        participation.to_excel(writer, "SPA_Node_Participation", index=False)
        temporal_nodes.to_excel(writer, "Node_SDA_Authoritative", index=False)
        path_temporal_nodes.to_excel(writer, "Represented_Path_Allocation", index=False)
        path_transitions.to_excel(writer, "Path_Transitions", index=False)
        pair_path_evidence.to_excel(writer, "Hotspot_Leverage_Paths", index=False)
        strategy.to_excel(writer, "Node_Strategic_Synthesis", index=False)
        if "node_summary" in hotspot_frames:
            hotspot_frames["node_summary"].to_excel(writer, "Hotspot_Leverage", index=False)
        if "direct_portfolio" in hotspot_frames:
            hotspot_frames["direct_portfolio"].to_excel(writer, "Direct_Portfolio", index=False)
        if "governance_mediated_portfolio" in hotspot_frames:
            hotspot_frames["governance_mediated_portfolio"].to_excel(writer, "Mediated_Portfolio", index=False)
        if "hybrid_portfolio" in hotspot_frames:
            hotspot_frames["hybrid_portfolio"].to_excel(writer, "Hybrid_Portfolio", index=False)
        critic_weights.to_excel(writer, "CRITIC_Weights", index=False)
        critic_ranking.to_excel(writer, "CRITIC_DLI_2017", index=False)
        # Keep the complete bounded path table in the committed CSV. The workbook
        # carries the U17 87%-of-total coverage-aligned display subset.
        workbook_paths = path_export.loc[
            path_export.get("in_dominant_display_set", False).astype(bool)
        ].copy() if "in_dominant_display_set" in path_export.columns else path_export.copy()
        workbook_paths.to_excel(
            writer, sheet_name="Displayed_Path_Evidence", index=False
        )
        pd.DataFrame([reconciliation]).to_excel(writer, "SDA_Reconciliation", index=False)
        notes.to_excel(writer, "Methodology_Notes", index=False)
        provenance.to_excel(writer, "Provenance", index=False)
    _format_workbook(files["workbook"])

    hashes = {name: _sha256_file(path) for name, path in files.items()}
    return files, hashes


def run_integrated_methodology(
    *,
    runtime_dir: str | Path | None = None,
    mrio_path: str | Path | None = None,
    company_path: str | Path | None = None,
    critic_ranking: pd.DataFrame,
    critic_weights: pd.DataFrame,
    input_hashes: Mapping[str, str],
    critic_evidence_cid: str,
    store_content_fn: Callable[[Any, str], str] | None = None,
) -> dict[str, Any]:
    """Run the operational integrated method and write all reporting artifacts."""
    runtime = _runtime_dir(runtime_dir)
    root = Path(__file__).resolve().parent
    mrio_path = Path(mrio_path or root / "input_mrio_completed.xlsx")
    company_path = Path(company_path or root / "Focal_Company_Demand_Converted.xlsx")

    spa14, meta14 = _load_spa_artifact(runtime, 2014, input_hashes)
    spa17, meta17 = _load_spa_artifact(runtime, 2017, input_hashes)
    paths = _union_paths(spa14, spa17)

    my14 = ae.load_year(str(mrio_path), 2014)
    my17 = ae.load_year(str(mrio_path), 2017)
    y14 = ae.load_company_Y(str(company_path), 2014)
    y17 = ae.load_company_Y(str(company_path), 2017)
    base = ModelAdapter.from_mrio(my14, y14)
    comparison = ModelAdapter.from_mrio(my17, y17)

    base_selected_paths = {
        parse_path(value) for value in spa14["path_codes"].dropna() if parse_path(value)
    }
    comparison_selected_paths = {
        parse_path(value) for value in spa17["path_codes"].dropna() if parse_path(value)
    }
    panel = build_path_panel(
        paths,
        base,
        comparison,
        base_selected_paths=base_selected_paths,
        comparison_selected_paths=comparison_selected_paths,
    )
    panel, diagnostics, cluster_info = cluster_baseline_paths(panel)

    footprint14 = float(my14.footprint(y14))
    footprint17 = float(my17.footprint(y17))
    panel, dominant_metadata = mark_dominant_display_paths(
        panel,
        0.87,
        full_comparison_footprint=footprint17,
    )
    class_summary = summarize_classes(panel, footprint14, footprint17)
    participation, participation_metadata = compute_pathway_participation(
        panel, base.node_codes, footprint17
    )
    path_temporal_nodes = allocate_temporal_drivers_to_nodes(panel, base.node_codes)
    temporal_nodes, node_sda_metadata = _load_authoritative_node_sda(runtime, input_hashes)
    hotspot_frames, hotspot_leverage_metadata = _load_hotspot_leverage_frames(runtime, input_hashes)
    pair_path_evidence = build_hotspot_leverage_path_evidence(
        hotspot_frames["pair_evidence"], panel
    )
    transition_columns = [
        column for column in [
            "path_id", "demand_gateway_node", "terminal_emitter_node", "depth",
            "path_identity_status", "bounded_spa_selection_status",
            "selected_in_baseline_bounded_spa", "selected_in_comparison_bounded_spa",
            "route_transition_id", "route_reconfiguration_status",
            "baseline_contribution", "comparison_contribution", "delta_path_contribution",
            "primary_adverse_driver", "primary_adverse_effect_tco2",
            "secondary_adverse_drivers", "primary_beneficial_driver",
            "primary_beneficial_effect_tco2", "driver_pattern", "structural_path_class",
        ] if column in panel.columns
    ]
    path_transitions = panel.loc[
        panel["path_identity_status"].ne("persistent exact path")
        | panel["route_reconfiguration_status"].ne("not reconfigured"),
        transition_columns,
    ].sort_values(
        ["terminal_emitter_node", "demand_gateway_node", "path_id"], kind="mergesort"
    ).reset_index(drop=True)

    ranking17 = critic_ranking.loc[
        pd.to_numeric(critic_ranking["year"], errors="coerce") == 2017
    ].sort_values("dli_rank")
    strategy, strategy_metadata = merge_node_strategy(
        participation, temporal_nodes, ranking17
    )
    hotspot_summary = hotspot_frames["node_summary"].rename(
        columns={"intervention_node": "node_code"}
    )
    hotspot_columns = [
        column
        for column in [
            "node_code", "hsi_rank", "is_high_dli_upper_quartile",
            "is_direct_hotspot_node", "hotspot_structural_influence_tco2",
            "hotspot_structural_influence_fraction", "affected_hotspot_count",
            "top_structurally_linked_hotspots", "intervention_route",
        ]
        if column in hotspot_summary.columns
    ]
    strategy = strategy.merge(
        hotspot_summary[hotspot_columns].drop_duplicates("node_code"),
        on="node_code",
        how="left",
        validate="one_to_one",
    )
    strategy["integrated_decision_role"] = np.select(
        [
            strategy.get("is_direct_hotspot_node", False).fillna(False).astype(bool)
            & strategy.get("is_high_dli_upper_quartile", False).fillna(False).astype(bool),
            strategy.get("is_direct_hotspot_node", False).fillna(False).astype(bool),
            strategy.get("is_high_dli_upper_quartile", False).fillna(False).astype(bool),
        ],
        ["direct hotspot and systemic leverage", "direct hotspot", "governance-mediated leverage candidate"],
        default="secondary network node",
    )

    company_sda = _company_sda_from_node_metadata(node_sda_metadata)
    path_effects = {
        factor: float(panel[f"delta_{factor}"].sum()) for factor in FACTORS
    }
    represented_change = float(panel["delta_path_contribution"].sum())
    complete_change = float(company_sda["complete_change_tCO2"])
    node_effect_sums = {
        factor: float(pd.to_numeric(temporal_nodes[f"node_delta_{factor}"], errors="raise").sum())
        for factor in FACTORS
    }
    reconciliation = {
        "complete_change_tCO2": complete_change,
        "node_wise_change_tCO2": float(pd.to_numeric(temporal_nodes["node_footprint_change_tco2"], errors="raise").sum()),
        "node_wise_maximum_row_residual_tCO2": float(node_sda_metadata.get("maximum_row_reconciliation_residual_tco2", np.nan)),
        "node_wise_maximum_column_residual_tCO2": float(node_sda_metadata.get("maximum_column_reconciliation_residual_tco2", np.nan)),
        **{f"node_wise_{factor}_effect_tCO2": node_effect_sums[factor] for factor in FACTORS},
        "represented_path_change_tCO2": represented_change,
        "represented_change_share": represented_change / complete_change if complete_change else None,
        "unrepresented_change_tCO2": complete_change - represented_change,
        **{
            f"complete_{factor}_effect_tCO2": float(company_sda["effects"].get(factor, np.nan))
            for factor in FACTORS
        },
        **{
            f"represented_{factor}_effect_tCO2": path_effects[factor]
            for factor in FACTORS
        },
        **{
            f"unrepresented_{factor}_effect_tCO2": float(company_sda["effects"].get(factor, np.nan)) - path_effects[factor]
            for factor in FACTORS
        },
    }

    summary = {
        "release_id": INTEGRATION_RELEASE_ID,
        "method": "Producer-node four-factor Shapley/SDA + role-specific emissions-weighted SPA participation + secondary path-level Shapley/SDA + pooled CRITIC-DLI + producer-resolved hotspot-leverage structural coverage",
        "base_year": 2014,
        "comparison_year": 2017,
        "union_exact_path_count": int(len(panel)),
        "persistent_exact_path_count": int(panel["path_identity_status"].eq("persistent exact path").sum()),
        "emerging_exact_path_count": int(panel["path_identity_status"].eq("emerging exact path").sum()),
        "disappearing_exact_path_count": int(panel["path_identity_status"].eq("disappearing exact path").sum()),
        "reconfigured_exact_path_member_count": int(panel["route_reconfiguration_status"].ne("not reconfigured").sum()),
        "direct_path_count": int((panel["depth"] == 0).sum()),
        "upstream_path_count": int((panel["depth"] >= 1).sum()),
        "selected_upstream_k": int(cluster_info.get("selected_k", 0)),
        "selected_silhouette": cluster_info.get("silhouette"),
        "cluster_stability_ari_min": cluster_info.get("stability_adjusted_rand_index_min"),
        "cluster_stability_ari_mean": cluster_info.get("stability_adjusted_rand_index_mean"),
        "base_footprint_tCO2": footprint14,
        "comparison_footprint_tCO2": footprint17,
        "complete_change_tCO2": complete_change,
        "represented_path_change_tCO2": represented_change,
        "represented_change_share": reconciliation["represented_change_share"],
        "represented_current_footprint_share": participation_metadata["represented_footprint_share"],
        "dominant_display_path_count": dominant_metadata["dominant_path_count"],
        "dominant_display_share_of_represented": dominant_metadata["achieved_share_of_represented"],
        "dominant_display_share_of_full_footprint": dominant_metadata.get("achieved_share_of_full_footprint"),
        "dominant_display_target_share_of_full_footprint": dominant_metadata.get("target_share_of_full_footprint"),
        "dominant_display_target_reached": dominant_metadata.get("threshold_reached"),
        "dominant_display_target_shortfall_tCO2": dominant_metadata.get("target_shortfall_tCO2"),
        "dli_weighting": "pooled Pearson-CRITIC only",
        "legacy_fixed_dli_weights_used": False,
        "path_classes_frozen_from": "2014 baseline path characteristics",
        "spa_participation_authority": "all bounded represented paths",
        "dominant_path_set_role": "87%-of-complete-footprint coverage-aligned display subset only",
        "node_sda_authority": "complete producer-node four-factor 24-permutation decomposition",
        "comparison_top80_hotspot_count": int(node_sda_metadata.get("comparison_hotspot_count", 0)),
        "comparison_top80_hotspot_coverage": float(node_sda_metadata.get("comparison_hotspot_coverage", np.nan)),
        "hotspot_leverage_extension_id": hotspot_leverage_metadata.get("extension_id"),
        "hotspot_leverage_claim_boundary": hotspot_leverage_metadata.get("abatement_boundary"),
    }

    source_metadata = {
        "input_hashes": dict(input_hashes),
        "spa_2014_source_result_cid": meta14.get("source_result_cid"),
        "spa_2017_source_result_cid": meta17.get("source_result_cid"),
        "critic_evidence_cid": critic_evidence_cid,
        "node_sda_evidence_cid": node_sda_metadata.get("node_sda_evidence_cid"),
        "hotspot_leverage_evidence_cid": hotspot_leverage_metadata.get("hotspot_leverage_evidence_cid"),
        "cross_year_path_universe": "union of exact ordered path identities from 2014 and 2017; each route evaluated in both annual MRIO states",
        "path_selection_boundary": "bounded-SPA selection presence is separate from physical/material path presence",
        "exact_path_identity_rule": "complete ordered country-sector node sequence",
        "absent_year_path_rule": "exact path contribution is evaluated as zero when its edge product or focal demand is absent/negligible in that year",
        "common_node_rule": "a common node may participate in different exact paths in the two years; no same-path requirement is imposed",
    }

    files, file_hashes = _export_results(
        runtime,
        panel,
        diagnostics,
        cluster_info,
        class_summary,
        participation,
        temporal_nodes,
        path_temporal_nodes,
        path_transitions,
        pair_path_evidence,
        hotspot_frames,
        strategy,
        critic_weights,
        ranking17,
        summary,
        reconciliation,
        participation_metadata,
        dominant_metadata,
        source_metadata,
    )

    # ``runtime`` is <package>/runtime; the shared content store is at <package>/content_store.
    content_store = runtime.parent / "content_store"
    artifact_cids = {
        name: _write_content_copy(path, content_store)
        for name, path in files.items()
    }

    evidence_basis = {
        "release_id": INTEGRATION_RELEASE_ID,
        "summary": summary,
        "source_metadata": source_metadata,
        "cluster_information": cluster_info,
        "class_driver_matrix": class_summary.to_dict(orient="records"),
        "participation_metadata": participation_metadata,
        "dominant_display_metadata": dominant_metadata,
        "strategy_metadata": strategy_metadata,
        "node_sda_metadata": node_sda_metadata,
        "hotspot_leverage_metadata": hotspot_leverage_metadata,
        "path_identity_summary": {
            "union_exact_path_count": int(len(panel)),
            "persistent_exact_path_count": int(panel["path_identity_status"].eq("persistent exact path").sum()),
            "emerging_exact_path_count": int(panel["path_identity_status"].eq("emerging exact path").sum()),
            "disappearing_exact_path_count": int(panel["path_identity_status"].eq("disappearing exact path").sum()),
            "reconfigured_exact_path_member_count": int(panel["route_reconfiguration_status"].ne("not reconfigured").sum()),
        },
        "sda_reconciliation": reconciliation,
        "artifact_cids": artifact_cids,
        "artifact_sha256": file_hashes,
        "top_node_strategy_records": strategy.head(50).to_dict(orient="records"),
    }
    if store_content_fn is not None:
        integrated_evidence_cid = store_content_fn(
            evidence_basis, "spa_sda_critic_dli_integrated_evidence"
        )
    else:
        body = json.dumps(evidence_basis, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")
        integrated_evidence_cid = hashlib.sha256(body).hexdigest()
        (content_store / f"{integrated_evidence_cid}.json").write_text(
            json.dumps(evidence_basis, indent=2, sort_keys=True, default=str),
            encoding="utf-8",
        )

    result = {
        **evidence_basis,
        "integrated_evidence_cid": integrated_evidence_cid,
        "files": {name: str(path) for name, path in files.items()},
    }
    result_path = runtime / "active_analytics" / "spa_sda_critic_dli_integrated_result.json"
    result_path.write_text(json.dumps(result, indent=2, default=str), encoding="utf-8")
    return result
