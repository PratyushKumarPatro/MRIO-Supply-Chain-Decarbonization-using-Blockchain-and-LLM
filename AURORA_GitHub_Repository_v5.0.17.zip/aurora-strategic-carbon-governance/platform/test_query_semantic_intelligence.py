"""Offline regression battery for v5.0.17 query intelligence and narrative output.

The tests require no blockchain, Ollama server, or operational Excel inputs.
They verify routing, retrieval isolation, audit structure, answer alignment, and
coherent deterministic synthesis using representative evidence.
"""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import data_orchestrator as orchestrator
import dual_capability_assistant as ca
import knowledge_layer as knowledge
import query_intelligence as qi
import strategic_assistant as sa
import system_meta_assistant as sma


DEPLOYMENT_CHALLENGE_QUESTION = (
    "what are the challenges do you see when it comes to the deployment of this entire system?"
)
PRIORITY_QUESTION = "Which node should management prioritize for decarbonization and why?"


class SemanticClassifierClient:
    model = "semantic-test-model"

    def chat_json(self, system, user, schema, model=None, num_predict=512, temperature=0.0):
        return {
            "primary_intent": "system_meta",
            "domain_relevance": "project",
            "requires_project_evidence": True,
            "requires_deterministic_computation": False,
            "requires_architecture_knowledge": True,
            "requires_general_reasoning": True,
            "user_goal": "Explain the deployed query-routing design.",
            "confidence": 0.91,
        }




class NarrativeSynthesisClient:
    model = "narrative-test-model"

    def chat_json(self, system, user, schema, model=None, num_predict=1200, temperature=0.1):
        answer_types = schema.get("properties", {}).get("answer_type", {}).get("enum", [])
        if answer_types == ["system_meta"]:
            payload = json.loads(user)
            ids = [row["id"] for row in payload["curated_system_evidence"][:4]]
            return {
                "answer_type": "system_meta",
                "narrative_answer": (
                    "The deployment faces a concentrated trust and availability risk because the four oracle roles and "
                    "the Data Orchestrator run on one host, while the current Ganache and local content-store setup is "
                    "designed for feasibility rather than production resilience. In addition, on-chain query text can "
                    "create confidentiality concerns, and local-model routing can still produce a fluent but irrelevant "
                    "answer when relevance controls are weak. Taken together, production hardening should distribute "
                    "operational roles, protect query content, replicate stored evidence, and retain deterministic "
                    "answer-alignment checks; however, these controls do not remove the need for accountable human governance."
                ),
                "covered_record_ids": ids,
                "material_limitations_included": True,
            }
        return {
            "answer_type": "strategic",
            "narrative_answer": (
                "Management should prioritize ARE-nmm for the 2017 decarbonization program because its DLI score of "
                "0.449321 places it at rank 1, while its hotspot contribution of 0.114507 represents 30.45% of the "
                "focal-company footprint and SPA corroborates the same node with a contribution of 0.109703. Taken "
                "together, the evidence supports specifying low-carbon or blended cement and evaluating supplementary "
                "cementitious materials through direct control. However, this is a screening priority, so cost, technical "
                "feasibility, supplier readiness, quality and updated primary data must be checked before implementation."
            ),
            "supporting_claims": [
                "ARE-nmm is the highest-DLI node.",
                "Hotspot and SPA evidence corroborate the recommendation.",
            ],
            "material_limitations": [
                "Implementation requires feasibility and updated primary-data checks."
            ],
        }


class QuerySemanticIntelligenceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.client = sa.make_deterministic_client()

    def test_deployment_challenge_routes_to_system_meta(self):
        route, metadata = ca.classify_route(
            DEPLOYMENT_CHALLENGE_QUESTION,
            mode="auto",
            client=self.client,
        )
        self.assertEqual(route, "system_meta")
        understanding = metadata["query_understanding"]
        self.assertEqual(understanding["primary_intent"], "system_meta")
        self.assertFalse(understanding["requires_deterministic_computation"])
        self.assertTrue(understanding["requires_architecture_knowledge"])

    def test_priority_and_general_routes_are_preserved(self):
        research_route, _ = ca.classify_route(PRIORITY_QUESTION, client=self.client)
        general_route, _ = ca.classify_route("What is the capital of Japan?", client=self.client)
        hybrid_route, _ = ca.classify_route(
            "Compare our DLI approach with conventional supplier engagement.",
            client=self.client,
        )
        self.assertEqual(research_route, "research")
        self.assertEqual(general_route, "general")
        self.assertEqual(hybrid_route, "hybrid")

    def test_ambiguous_project_question_can_use_guarded_semantic_model(self):
        route, metadata = ca.classify_route(
            "Tell me about this package in relation to our plans.",
            mode="auto",
            client=SemanticClassifierClient(),
        )
        self.assertEqual(route, "system_meta")
        self.assertEqual(metadata["query_understanding"]["source"], "local_llm")
        self.assertEqual(metadata["query_understanding"]["model_status"], "ok")

    def test_system_meta_answer_is_relevant_grounded_and_serialisable(self):
        result = ca.answer_turn(
            self.client,
            DEPLOYMENT_CHALLENGE_QUESTION,
            mode="auto",
        )
        self.assertEqual(result.route, "system_meta")
        self.assertIn(result.blockchain_route, {"retrieval", "composite"})
        self.assertTrue(result.plan["answer_alignment"]["aligned"])
        self.assertEqual([item["tool"] for item in result.evidence], ["system_knowledge"])
        self.assertFalse(result.provenance["quantitative_tools_executed"])
        lower = result.answer.casefold()
        self.assertIn("deployment", lower)
        self.assertTrue(any(term in lower for term in ("oracle", "ganache", "querymanagement")))
        self.assertTrue(any(term in lower for term in ("challenge", "risk", "concern")))
        self.assertNotEqual(lower.split()[0:2], ["emissions", "hotspot"])
        serialised = ca.serialise_result(result)
        json.dumps(serialised)
        self.assertEqual(serialised["system_answer"], result.answer)

    def test_system_meta_follow_up_uses_structured_state(self):
        first = ca.answer_turn(self.client, DEPLOYMENT_CHALLENGE_QUESTION, mode="auto")
        route, _ = ca.classify_route(
            "How can we improve it?",
            mode="auto",
            state=first.state,
            client=self.client,
        )
        self.assertEqual(route, "system_meta")

    def test_research_knowledge_retrieval_is_not_used_for_system_meta(self):
        intent = knowledge.analyse_knowledge_intent(DEPLOYMENT_CHALLENGE_QUESTION)
        self.assertTrue(intent["system_meta"])
        self.assertFalse(intent["conceptual"])
        self.assertFalse(intent["methodological"])
        retrieval = sa.tool_retrieval({"query": DEPLOYMENT_CHALLENGE_QUESTION, "top_n": 3})
        self.assertEqual(retrieval["retrieved"], [])
        self.assertEqual(retrieval["filter"], "system-meta route required")
        self.assertFalse(retrieval["relevance_gate"]["passed"])

    def test_original_irrelevant_response_fails_alignment(self):
        irrelevant = (
            "Emissions hotspot. An emissions hotspot is a country, sector, supplier category, "
            "process, or pathway that contributes a comparatively large share of the selected "
            "carbon footprint. Intervention criticality is a modeled indicator. Consumption-based "
            "carbon accounting attributes emissions to final demand."
        )
        alignment = qi.assess_answer_alignment(
            DEPLOYMENT_CHALLENGE_QUESTION,
            irrelevant,
            expected_mode="system_meta",
        )
        self.assertFalse(alignment["aligned"])
        self.assertTrue(alignment["reasons"])

    def test_system_retrieval_has_diverse_deployment_evidence(self):
        retrieval = sma.retrieve_system_evidence(DEPLOYMENT_CHALLENGE_QUESTION, top_n=7)
        ids = {row["id"] for row in retrieval["retrieved"]}
        self.assertGreaterEqual(len(ids), 6)
        self.assertIn("single_host_trust_boundary", ids)
        self.assertIn("ganache_to_production_chain", ids)
        self.assertIn("llm_query_understanding_and_hallucination", ids)

    def test_priority_fallback_is_connected_narrative(self):
        evidence = [
            {
                "tool": "priority_ranking",
                "parameters": {"year": 2017, "top_n": 5},
                "source": "strategic_assistant.py::tool_priority_ranking",
                "data": {
                    "year": 2017,
                    "recommended_node": {
                        "node_code": "ARE-nmm",
                        "dli_rank": 1,
                        "DLI": 0.449321,
                        "hotspot_rank": 1,
                        "footprint_contribution": 0.114507,
                        "share_of_total": 0.3045,
                        "driven_by": "carbon dependency risk (removal impact)",
                        "BC_norm": 0.0033,
                        "PR_norm": 0.0087,
                        "CDR_norm": 1.0,
                        "IC_norm": 0.5870,
                        "spa_support": [
                            {"path_codes": "ARE-nmm", "contribution": 0.109703}
                        ],
                        "action": (
                            "Specify low-carbon or blended cement and aggregate mixes; evaluate "
                            "supplementary cementitious materials (fly ash, slag) to displace clinker."
                        ),
                        "channel": "Direct control (domestic UAE operations)",
                    },
                },
            }
        ]
        plan = {"scope": "in_scope", "response_mode": "strategic"}
        answer = sa.deterministic_synthesis(PRIORITY_QUESTION, plan, evidence)
        self.assertNotIn("###", answer)
        self.assertFalse(any(line.lstrip().startswith("- ") for line in answer.splitlines()))
        self.assertIn("Management should prioritize **ARE-nmm**", answer)
        self.assertIn("0.449321", answer)
        self.assertIn("30.45%", answer)
        self.assertIn("0.109703", answer)
        self.assertIn("recommended management response", answer)
        self.assertIn("However", answer)
        alignment = qi.assess_answer_alignment(
            PRIORITY_QUESTION,
            answer,
            expected_mode="strategic",
            required_anchor="ARE-nmm",
        )
        self.assertTrue(alignment["aligned"])
        self.assertTrue(alignment["narrative_quality"]["coherent"])
        self.assertEqual(alignment["narrative_quality"]["bullets"], 0)



    def test_conceptual_comparison_does_not_execute_analytical_tools(self):
        result = sa.answer_question(
            self.client,
            "Compare DLI and an emissions hotspot.",
        )
        self.assertEqual(result.plan["response_mode"], "conceptual")
        self.assertEqual([item["tool"] for item in result.evidence], ["concept_knowledge"])
        self.assertTrue(result.plan["answer_alignment"]["aligned"])
        self.assertIn("answer different management questions", result.answer)
        self.assertIn("By contrast, DLI combines", result.answer)
        self.assertNotIn("dLI", result.answer)

    def test_independent_short_question_does_not_inherit_prior_node_or_year(self):
        question = "Compare DLI and an emissions hotspot."
        prior = ca.ConversationState(
            active_year="2014",
            active_node="ARE-nmm",
            last_route="research",
            last_research_question="Which node should management prioritize?",
        )
        self.assertEqual(ca.enrich_research_question(question, prior), question)
        result = ca.answer_turn(self.client, question, mode="auto", state=prior)
        self.assertEqual(result.route, "research")
        self.assertEqual(
            [item.get("tool") for item in result.evidence],
            ["concept_knowledge"],
        )
        self.assertIn("Decarbonization Leverage Index", result.answer)
        self.assertNotIn("dLI", result.answer)

    def test_methodology_acronym_alignment_and_concept_prose(self):
        method = sa.answer_question(self.client, "How is SDA calculated in this study?")
        self.assertEqual(method.plan["response_mode"], "methodological")
        self.assertTrue(method.plan["answer_alignment"]["aligned"])
        self.assertIn("Structural decomposition analysis", method.answer)
        concept = sa.answer_question(self.client, "What is carbon accounting?")
        self.assertTrue(concept.plan["answer_alignment"]["aligned"])
        self.assertNotIn("In this Strategic Carbon Intelligence & Governance framework, in this deployment", concept.answer)
        self.assertNotIn("###", concept.answer)

    def test_old_priority_fragment_format_fails_narrative_gate(self):
        old_answer = """### Strategic priority for 2017

**Recommendation:** Prioritize **ARE-nmm** for the decarbonization program.

**Deterministic evidence**

- DLI rank **#1**, with DLI **0.449321**.
- Hotspot rank **#1**, contributing **0.114507**, or **30.45%** of the focal-company footprint.
- SPA corroborates the priority through `ARE-nmm`, with contribution **0.109703**.

**Strategic reasoning:** The choice is not based on emissions magnitude alone.

**Recommended action:** Specify low-carbon or blended cement.

**Decision limitation:** Feasibility must be checked."""
        alignment = qi.assess_answer_alignment(
            PRIORITY_QUESTION,
            old_answer,
            expected_mode="strategic",
            required_anchor="ARE-nmm",
        )
        self.assertFalse(alignment["aligned"])
        self.assertFalse(alignment["narrative_quality"]["coherent"])

    def test_validated_model_synthesis_returns_connected_priority_narrative(self):
        evidence = [
            {
                "tool": "priority_ranking",
                "data": {
                    "year": 2017,
                    "recommended_node": {
                        "node_code": "ARE-nmm",
                        "dli_rank": 1,
                        "DLI": 0.449321,
                        "hotspot_rank": 1,
                        "footprint_contribution": 0.114507,
                        "share_of_total": 0.3045,
                        "driven_by": "carbon dependency risk (removal impact)",
                        "BC_norm": 0.0033,
                        "PR_norm": 0.0087,
                        "CDR_norm": 1.0,
                        "IC_norm": 0.5870,
                        "spa_support": [{"path_codes": "ARE-nmm", "contribution": 0.109703}],
                        "action": (
                            "Specify low-carbon or blended cement and aggregate mixes; evaluate "
                            "supplementary cementitious materials (fly ash, slag) to displace clinker."
                        ),
                        "channel": "Direct control (domestic UAE operations)",
                    },
                },
            }
        ]
        plan = {
            "scope": "in_scope",
            "response_mode": "strategic",
            "planner_validation": {"llm_status": "ok"},
        }
        answer = sa.synthesize(NarrativeSynthesisClient(), PRIORITY_QUESTION, plan, evidence)
        self.assertEqual(plan["synthesis_validation"]["status"], "ok")
        self.assertTrue(plan["answer_alignment"]["aligned"])
        self.assertNotIn("###", answer)
        self.assertIn("However", answer)
        self.assertIn("ARE-nmm", answer)

    def test_validated_model_system_answer_uses_composite_audit_route(self):
        result = ca.answer_turn(
            NarrativeSynthesisClient(),
            DEPLOYMENT_CHALLENGE_QUESTION,
            mode="auto",
        )
        self.assertEqual(result.route, "system_meta")
        self.assertEqual(result.blockchain_route, "composite")
        self.assertEqual(result.model_metrics["synthesis_source"], "local_llm_validated")
        self.assertTrue(result.plan["answer_alignment"]["aligned"])
        self.assertNotIn("###", result.answer)


    def test_orchestrator_stores_complete_system_meta_audit_package(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with (
                mock.patch.object(orchestrator, "CONTENT_STORE", root / "content_store"),
                mock.patch.object(orchestrator, "RESULTS_DIR", root / "results"),
                mock.patch.object(orchestrator, "RESULT_INDEX_PATH", root / "runtime" / "result_index.json"),
            ):
                service = orchestrator.DataOrchestrator(
                    deployment_path=root / "deployment.json",
                    client=self.client,
                )
                gate = {
                    "input_hashes": {"mrio": "1" * 64, "focal_demand": "2" * 64},
                    "network_2014_cid": "3" * 64,
                    "network_2017_cid": "4" * 64,
                    "aurora_2017_cid": "5" * 64,
                    "pooled_critic_ready": True,
                    "intervention_governance_dependency": "none",
                }
                with mock.patch.object(
                    service,
                    "_require_current_query_methodology_gate",
                    return_value=gate,
                ):
                    response = service.process_query(
                        requester="0x0000000000000000000000000000000000000001",
                        query_text=DEPLOYMENT_CHALLENGE_QUESTION,
                        mode="auto",
                        request_context={"event": "QueryRequested", "request_id": 1},
                    )
                self.assertEqual(response.auxiliary["assistant_route"], "system_meta")
                self.assertEqual(response.auxiliary["route_enum"], 3)
                stored = orchestrator.load_content(response.content_hash)
                assistant = stored["payload"]["payload"]["assistant_result"]
                self.assertEqual(assistant["route"], "system_meta")
                self.assertTrue(assistant["plan"]["answer_alignment"]["aligned"])
                self.assertEqual(assistant["evidence"][0]["tool"], "system_knowledge")
                self.assertEqual(stored["payload"]["request_context"]["request_id"], 1)


    def test_package_version_and_runtime_checks_are_consistent(self):
        root = Path(__file__).resolve().parent
        package = json.loads((root / "package.json").read_text(encoding="utf-8"))
        self.assertEqual(package["version"], "5.0.17")
        version_text = (root / "VERSION.txt").read_text(encoding="utf-8")
        architecture = "5.0.17-u23-evidence-bound-abatement-decision"
        self.assertIn("5.0.17", version_text)
        self.assertIn(architecture, version_text)
        server_text = (root / "orchestrator_server.py").read_text(encoding="utf-8")
        self.assertIn("PACKAGE_VERSION", server_text)
        self.assertIn('from release_identity import PACKAGE_VERSION, RELEASE_IDENTITY, RELEASE_PATCH', server_text)
        self.assertIn('$candidate.version -eq "5.0.17"', (root / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8"))
        for name in ("compile_contracts.js", "deploy_contracts.py", "prepare_dapp_lifecycle.py"):
            self.assertIn(architecture, (root / name).read_text(encoding="utf-8"))
        self.assertEqual(
            (root / "system_knowledge.json").read_bytes(),
            (root / "streamlit_app" / "data" / "system_knowledge.json").read_bytes(),
        )
        self.assertEqual(
            (root / "domain_knowledge.json").read_bytes(),
            (root / "streamlit_app" / "data" / "domain_knowledge.json").read_bytes(),
        )

    def test_root_and_streamlit_assistant_layers_match(self):
        root = Path(__file__).resolve().parent
        python_modules = (
            "dual_capability_assistant.py",
            "llm_first_orchestrator.py",
            "strategic_assistant.py",
            "knowledge_layer.py",
            "query_intelligence.py",
            "system_meta_assistant.py",
        )
        for name in python_modules:
            bridge = (root / "streamlit_app" / name).read_text(encoding="utf-8")
            self.assertIn("Compatibility bridge to the single authoritative U16 module", bridge)
            self.assertIn(f"parent.parent / '{name}'", bridge)
        self.assertEqual(
            (root / "system_knowledge.json").read_bytes(),
            (root / "streamlit_app" / "system_knowledge.json").read_bytes(),
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
