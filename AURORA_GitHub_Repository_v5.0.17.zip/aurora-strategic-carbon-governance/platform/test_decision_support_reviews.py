"""Tests for the independent decision-support expert-review scorer."""
from __future__ import annotations

import csv
import hashlib
import json
import tempfile
import unittest
from pathlib import Path

import score_decision_support_reviews as reviews


def row(reviewer: str, aligned: int, case_id: str = "DLI-2017-001") -> dict:
    return {
        "reviewer_id": reviewer,
        "case_id": case_id,
        "artifact_type": "DLI weight-sensitivity report",
        "artifact_reference": "Network/DLI CID: test-cid; report SHA-256: test-report",
        "decision_year": "2017",
        "node_code": "ARE-nmm",
        "strategic_relevance_1_to_5": 4.0,
        "interpretability_1_to_5": 5.0,
        "governance_actionability_1_to_5": 4.0,
        "claim_boundary_clarity_1_to_5": 5.0,
        "priority_aligned": aligned,
    }


CSV_FIELDS = (
    "reviewer_id",
    "case_id",
    "artifact_type",
    "artifact_reference",
    "decision_year",
    "node_code",
    *reviews.SCORE_FIELDS,
    "priority_alignment_yes_no",
)


def write_completed_review_csv(path: Path, rows: list[dict]) -> None:
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDS)
        writer.writeheader()
        for item in rows:
            writer.writerow(
                {
                    "reviewer_id": item["reviewer_id"],
                    "case_id": item["case_id"],
                    "artifact_type": item["artifact_type"],
                    "artifact_reference": item["artifact_reference"],
                    "decision_year": item["decision_year"],
                    "node_code": item["node_code"],
                    **{field: item[field] for field in reviews.SCORE_FIELDS},
                    "priority_alignment_yes_no": "yes" if item["priority_aligned"] else "no",
                }
            )


class DecisionSupportReviewTests(unittest.TestCase):
    def test_scores_and_non_degenerate_two_reviewer_kappa(self):
        result = reviews.score_reviews(
            [
                row("expert-a", 1, "DLI-2017-001"),
                row("expert-b", 1, "DLI-2017-001"),
                row("expert-a", 0, "DLI-2017-002"),
                row("expert-b", 0, "DLI-2017-002"),
            ]
        )
        self.assertEqual(result["review_count"], 4)
        self.assertEqual(result["metrics"]["priority_alignment"]["proportion_aligned"], 0.5)
        self.assertEqual(result["agreement"]["paired_case_count"], 2)
        self.assertEqual(result["agreement"]["cohens_kappa_priority_alignment"], 1.0)
        self.assertEqual(result["agreement"]["cohens_kappa_status"], "estimated")

    def test_constant_marginals_report_kappa_as_not_estimable(self):
        result = reviews.score_reviews([row("expert-a", 1), row("expert-b", 1)])
        self.assertEqual(result["agreement"]["paired_case_count"], 1)
        self.assertIsNone(result["agreement"]["cohens_kappa_priority_alignment"])
        self.assertEqual(result["agreement"]["cohens_kappa_status"], "not_estimable_constant_marginals")

    def test_duplicate_reviewer_case_rows_are_rejected(self):
        with self.assertRaisesRegex(ValueError, "Duplicate review for the same reviewer"):
            reviews.score_reviews([row("expert-a", 1), row("expert-a", 0)])

    def test_cli_records_source_provenance_and_refuses_overwrite(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            source = root / "completed_reviews.csv"
            output = root / "summary.json"
            write_completed_review_csv(
                source,
                [
                    row("expert-a", 1, "DLI-2017-001"),
                    row("expert-b", 1, "DLI-2017-001"),
                    row("expert-a", 0, "DLI-2017-002"),
                    row("expert-b", 0, "DLI-2017-002"),
                ],
            )

            self.assertEqual(reviews.main([str(source), "--output", str(output)]), 0)
            summary = json.loads(output.read_text(encoding="utf-8"))
            provenance = summary["provenance"]
            self.assertEqual(provenance["source_csv"], str(source.resolve()))
            self.assertEqual(provenance["source_csv_sha256"], hashlib.sha256(source.read_bytes()).hexdigest())
            self.assertEqual(provenance["source_csv_size_bytes"], source.stat().st_size)
            self.assertTrue(provenance["source_csv_modified_at_utc"].endswith("Z"))
            self.assertTrue(provenance["summary_generated_at_utc"].endswith("Z"))
            self.assertEqual(provenance["scorer_script"], "score_decision_support_reviews.py")
            self.assertEqual(
                provenance["scorer_script_sha256"],
                hashlib.sha256(Path(reviews.__file__).read_bytes()).hexdigest(),
            )

            with self.assertRaisesRegex(FileExistsError, "Refusing to overwrite non-empty audit summary"):
                reviews.main([str(source), "--output", str(output)])

    def test_loader_rejects_duplicate_reviewer_case_rows(self):
        with tempfile.TemporaryDirectory() as temporary:
            source = Path(temporary) / "duplicate_reviews.csv"
            write_completed_review_csv(source, [row("expert-a", 1), row("expert-a", 0)])
            with self.assertRaisesRegex(ValueError, "Duplicate review for the same reviewer"):
                reviews.load_reviews(source)


if __name__ == "__main__":
    unittest.main(verbosity=2)
