"""Operational intervention-governance controls for the Blockchain page.

The Blockchain page is the platform control plane.  This module owns every
mutable intervention action: evidence materialization, candidate selection,
stakeholder actionability, pair feasibility, and explicit abatement-scenario
attestation or accountable non-quantification.  The separate Intervention Governance workspace is deliberately
read-only and presents the resulting evidence, portfolio, options and exports.
"""
from __future__ import annotations

import os
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st

import intervention_governance as governance_method
import scenario_engine as scenario_library
from content_retrieval import retrieve_content
from orchestrator_client import OrchestratorClient


def _result_cid(state: dict[str, Any], kind: str, year: int) -> str:
    groups = state.get("active_results", {}) if isinstance(state, dict) else {}
    group = groups.get(kind, {}) if isinstance(groups, dict) else {}
    record = group.get(str(year), {}) if isinstance(group, dict) else {}
    return str(record.get("content_hash", "")).strip().lower() if isinstance(record, dict) else ""


def _clean_text(value: Any) -> str:
    if value is None:
        return ""
    try:
        if pd.isna(value):
            return ""
    except (TypeError, ValueError):
        pass
    text = str(value).strip()
    return "" if text.lower() in {"nan", "none", "<na>"} else text


def _choice_index(options: list[str], value: Any) -> int:
    text = _clean_text(value) or "Not assessed"
    return options.index(text) if text in options else options.index("Not assessed")


def _percentage(value: Any) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return 0.0
    return number * 100.0 if pd.notna(number) else 0.0


def _load_governed_frames(
    state: dict[str, Any], root_dir: str | Path
) -> tuple[Path, str, str, dict[str, Any], dict[str, pd.DataFrame]]:
    active_dir = Path(root_dir) / "runtime" / "active_analytics"
    network_cid = _result_cid(state, "network", 2017)
    aurora_cid = _result_cid(state, "aurora", 2017)
    if not network_cid or not aurora_cid:
        raise FileNotFoundError("Complete the governed 2017 Network/DLI and AURORA stages first.")
    metadata = governance_method.verify_intervention_governance_artifacts(
        active_dir,
        expected_input_hashes=state.get("active_input_hashes", {}),
        expected_source_network_result_cid=network_cid,
        expected_source_aurora_result_cid=aurora_cid,
    )
    return (
        active_dir,
        network_cid,
        aurora_cid,
        metadata,
        governance_method.load_intervention_governance_frames(active_dir),
    )


def _aurora_sector_context(
    aurora_cid: str,
    sector: str,
    root_dir: str | Path,
) -> list[dict[str, Any]]:
    """Return current same-sector AURORA recommendations for context only."""

    retrieved = retrieve_content(
        aurora_cid,
        orchestrator_url=os.getenv("ORCHESTRATOR_URL", "http://127.0.0.1:8765"),
        roots=[Path(root_dir)],
        timeout=10.0,
        retries=2,
        retry_delay=0.25,
    )
    envelope = retrieved.content if isinstance(retrieved.content, dict) else {}
    material = envelope.get("payload", {}) if isinstance(envelope, dict) else {}
    analytical = material.get("payload", {}) if isinstance(material, dict) else {}
    rows = analytical.get("recommended_opportunities", []) if isinstance(analytical, dict) else []
    return [
        dict(row)
        for row in rows
        if isinstance(row, dict) and str(row.get("sector", "")) == str(sector)
    ]


def _materialize_button(
    network_cid: str,
    aurora_cid: str,
    *,
    reason: str,
) -> None:
    st.info(
        "The AURORA result is complete. Generate the intervention candidate register, "
        "signed-driver mappings, structural linkages and initial governance evidence from "
        "the verified analytical chain. Detailed results will then appear in the Intervention "
        "Governance sidebar workspace."
    )
    if reason:
        st.caption(f"Current intervention-evidence status: {reason}")
    if st.button(
        "Compute intervention evidence and candidate mappings",
        key="blockchain_compute_intervention_evidence",
        type="primary",
        use_container_width=True,
    ):
        try:
            with st.spinner("Verifying evidence CIDs and computing the intervention register..."):
                result = OrchestratorClient().materialize_intervention_governance(
                    network_cid,
                    aurora_cid,
                    request_context={
                        "source": "blockchain_intervention_control_plane",
                        "operation": "compute_intervention_evidence",
                        "control_plane": "blockchain_page",
                    },
                )
        except Exception as exc:
            st.error(f"Intervention evidence computation failed: {exc}")
        else:
            payload = result.get("payload", {}) if isinstance(result, dict) else {}
            st.session_state["blockchain_intervention_operation"] = {
                "ok": True,
                "message": (
                    f"Intervention evidence computed for {int(payload.get('candidate_pair_count', 0)):,} "
                    f"candidate pair(s); CID {payload.get('intervention_governance_evidence_cid', '')}."
                ),
            }
            st.rerun()


def render_intervention_control_plane(
    state: dict[str, Any],
    root_dir: str | Path,
) -> bool:
    """Render evidence computation and assessment controls.

    Returns True only when a current, hash-verified intervention register is
    available.  Formal on-chain option selection and decisions remain in the
    calling Blockchain page immediately below these controls.
    """

    st.markdown("#### Step 12.1 — Compute intervention evidence")
    network_cid = _result_cid(state, "network", 2017)
    aurora_cid = _result_cid(state, "aurora", 2017)
    if not network_cid or not aurora_cid:
        st.info("Locked until the 2017 Network/DLI and AURORA results are fulfilled.")
        return False

    try:
        _, network_cid, aurora_cid, metadata, frames = _load_governed_frames(
            state, root_dir
        )
    except Exception as exc:
        _materialize_button(network_cid, aurora_cid, reason=str(exc))
        return False

    operation = st.session_state.pop("blockchain_intervention_operation", None)
    if isinstance(operation, dict) and operation.get("message"):
        st.success(str(operation["message"]))
    st.success(
        "Intervention evidence is current and verified; "
        f"{int(metadata.get('candidate_pair_count', 0)):,} candidate pair(s), "
        f"evidence CID `{metadata.get('intervention_governance_evidence_cid', '')}`."
    )
    st.caption(
        "The computation preserves hotspot magnitude, node/path SDA, DLI and AURORA as separate "
        "evidence dimensions. It deterministically maps the producer hotspot's largest positive "
        "node-SDA driver to an intervention mechanism; the user does not manually override that mapping."
    )

    eligibility = frames["eligibility"]
    if eligibility.empty:
        st.warning("No positively linked intervention candidate is available in the verified evidence.")
        return True

    status_counts = metadata.get("eligibility_status_counts", {})
    p1, p2, p3, p4 = st.columns(4)
    p1.metric("Candidate pairs", f"{len(eligibility):,}")
    p2.metric(
        "Assessed pairs",
        f"{int((~eligibility['assessment_status'].astype(str).eq('Not yet assessed')).sum()):,}",
    )
    p3.metric(
        "Eligible pairs",
        f"{int(status_counts.get(governance_method.ELIGIBLE_STATUS, 0)):,}",
    )
    p4.metric(
        "Formal options", f"{int(metadata.get('governance_ready_option_count', 0)):,}"
    )

    st.markdown("#### Step 12.2 — Select a producer hotspot and leverage node")
    hotspot_summary = (
        eligibility.groupby("hotspot_producer_node", as_index=False)
        .agg(
            hotspot_rank=("hotspot_rank", "min"),
            baseline=("baseline_hotspot_footprint_tco2", "max"),
            linked_nodes=("intervention_node", "nunique"),
        )
        .sort_values(
            ["baseline", "hotspot_rank", "hotspot_producer_node"],
            ascending=[False, True, True],
            kind="mergesort",
        )
    )
    hotspot_labels = {
        (
            f"Hotspot rank {int(row.hotspot_rank)} — {row.hotspot_producer_node} | "
            f"{float(row.baseline):,.6f} t CO2 | {int(row.linked_nodes)} linked leverage node(s)"
        ): str(row.hotspot_producer_node)
        for row in hotspot_summary.itertuples()
    }
    selected_hotspot_label = st.selectbox(
        "Producer hotspot",
        list(hotspot_labels),
        key="blockchain_intervention_hotspot",
    )
    selected_hotspot = hotspot_labels[selected_hotspot_label]
    subset = eligibility.loc[
        eligibility["hotspot_producer_node"].astype(str).eq(selected_hotspot)
    ].sort_values(
        ["avoided_hotspot_footprint_tco2", "intervention_dli_rank", "intervention_node"],
        ascending=[False, True, True],
        kind="mergesort",
    )
    st.caption(
        "Hotspots are ordered by baseline footprint. Linked nodes are ordered by structural "
        "contribution to the selected hotspot, with DLI rank used as a secondary priority signal."
    )
    node_labels = {
        (
            f"DLI rank {int(row.intervention_dli_rank)} — {row.intervention_node} | "
            f"structural linkage {float(row.avoided_hotspot_footprint_tco2):,.6f} t CO2 | "
            f"route: {getattr(row, 'intervention_route', '')}"
        ): str(row.candidate_id)
        for row in subset.itertuples()
    }
    selected_node_label = st.selectbox(
        "Linked leverage/intervention node",
        list(node_labels),
        key="blockchain_intervention_node",
    )
    candidate_id = node_labels[selected_node_label]
    selected = subset.loc[
        subset["candidate_id"].astype(str).eq(candidate_id)
    ].iloc[0]
    selected_node = str(selected["intervention_node"])
    st.caption(
        f"Deterministic mapping for this pair: {selected.get('hotspot_primary_adverse_driver', '')} → "
        f"{selected.get('intervention_category', '')}."
    )

    m1, m2, m3, m4 = st.columns(4)
    m1.metric(
        "Hotspot baseline",
        f"{float(selected['baseline_hotspot_footprint_tco2']):,.6f} t CO2",
    )
    m2.metric(
        "Structural linkage",
        f"{float(selected['avoided_hotspot_footprint_tco2']):,.6f} t CO2",
    )
    m3.metric(
        "Linked hotspot fraction", f"{float(selected['hotspot_reduction_fraction']):.2%}"
    )
    m4.metric("Leverage-node DLI", f"{float(selected['intervention_DLI']):.6f}")

    lifecycle = state.get("lifecycle", {}) if isinstance(state, dict) else {}
    if lifecycle.get("intervention_governance_resolved"):
        st.info(
            "The current intervention-governance branch is resolved. Its assessment register is "
            "read-only; inspect the formal decision and post-deployment controls below."
        )
        return True
    formal_requests = (
        state.get("active_results", {})
        .get("intervention_requests", {})
        .get("2017", [])
        if isinstance(state, dict)
        else []
    )
    if any(
        isinstance(item, dict) and int(item.get("status", -1)) in {0, 1}
        for item in formal_requests
    ):
        st.info(
            "The assessment register is frozen because a current option has entered formal on-chain "
            "governance. Complete Oracle verification and the approval or rejection decision below."
        )
        return True

    with st.expander("Inspect driver evidence and deterministic intervention mapping", expanded=True):
        st.dataframe(
            pd.DataFrame(
                [{
                    "intensity effect (t CO2)": selected.get("hotspot_intensity_effect_tco2"),
                    "technology effect (t CO2)": selected.get("hotspot_technology_effect_tco2"),
                    "composition effect (t CO2)": selected.get("hotspot_composition_effect_tco2"),
                    "scale effect (t CO2)": selected.get("hotspot_scale_effect_tco2"),
                    "primary adverse driver": selected.get("hotspot_primary_adverse_driver"),
                    "primary beneficial driver": selected.get("hotspot_primary_beneficial_driver"),
                    "path-SDA adverse driver": selected.get("represented_path_primary_adverse_driver"),
                    "mapped category": selected.get("intervention_category"),
                    "delivery channel": selected.get("delivery_channel"),
                }]
            ),
            use_container_width=True,
            hide_index=True,
        )
        st.write(str(selected.get("recommended_action", "")))
        st.caption(str(selected.get("mechanism_mapping_basis", "")))
        if _clean_text(selected.get("pathway_mechanism_note")):
            st.info(_clean_text(selected.get("pathway_mechanism_note")))

        st.markdown("##### AURORA regional-opportunity context")
        try:
            regional_rows = _aurora_sector_context(
                aurora_cid,
                str(selected.get("hotspot_producer_sector", "")),
                root_dir,
            )
        except Exception as exc:
            st.warning(f"AURORA context could not be retrieved: {exc}")
        else:
            if regional_rows:
                regional_columns = [
                    column for column in [
                        "node_code", "region", "sector", "relative_multiplier_reduction",
                        "modelled_full_reallocation_opportunity", "observed_linkage_tier",
                        "recommendation", "stable_reference_year_signal",
                    ] if column in regional_rows[0]
                ]
                st.dataframe(
                    pd.DataFrame(regional_rows)[regional_columns],
                    use_container_width=True,
                    hide_index=True,
                )
            else:
                st.info(
                    "No same-sector AURORA candidate is recommended for investigation for this producer sector."
                )
            st.caption(
                "AURORA is strategic regional screening context, not an automatic supplier change or proof of "
                "technical feasibility. The named stakeholder assessment below remains authoritative for practical feasibility."
            )

    st.markdown("#### Step 12.3 — Record actionability, feasibility and scenario evidence")
    st.caption(
        "Use Yes only where accountable stakeholder evidence exists. Node-level governance evidence is "
        "reused for every pair sharing this leverage node; technical feasibility and abatement assumptions "
        "remain specific to the selected hotspot–mechanism pair."
    )
    choices = list(governance_method.ASSESSMENT_VALUES)
    labels = {
        "direct_or_contractual_relationship": "Direct or contractual relationship",
        "specification_or_procurement_control": "Specification or procurement control",
        "supplier_selection_or_substitution_authority": "Supplier-selection or substitution authority",
        "emissions_disclosure_right": "Emissions-disclosure right",
        "audit_or_verification_right": "Audit or verification right",
        "implementation_owner_identified": "Implementation owner identified",
        "resource_or_budget_path_identified": "Resource or budget path identified",
    }
    with st.form(f"blockchain_intervention_assessment_{candidate_id}"):
        answers: dict[str, Any] = {}
        left, right = st.columns(2)
        for index, field in enumerate(governance_method.NODE_ACTIONABILITY_FIELDS):
            target = left if index % 2 == 0 else right
            answers[field] = target.selectbox(
                labels[field],
                choices,
                index=_choice_index(choices, selected.get(field)),
                key=f"blockchain_{field}_{candidate_id}",
            )
        answers["technical_feasibility_confirmed"] = st.selectbox(
            "Technical feasibility of this hotspot–leverage mechanism",
            choices,
            index=_choice_index(
                choices, selected.get("technical_feasibility_confirmed")
            ),
            key=f"blockchain_technical_feasibility_{candidate_id}",
        )
        assessor_name = st.text_input(
            "Assessor name",
            value=_clean_text(selected.get("assessor_name")),
            key=f"blockchain_assessor_name_{candidate_id}",
        )
        assessor_role = st.text_input(
            "Assessor role",
            value=_clean_text(selected.get("assessor_role")),
            key=f"blockchain_assessor_role_{candidate_id}",
        )
        evidence_reference = st.text_input(
            "Evidence reference or governed document CID",
            value=_clean_text(selected.get("evidence_reference")),
            key=f"blockchain_evidence_reference_{candidate_id}",
        )
        assessment_notes = st.text_area(
            "Assessment notes",
            value=_clean_text(selected.get("assessment_notes")),
            key=f"blockchain_assessment_notes_{candidate_id}",
        )
        prospective_actionability, prospective_basis = governance_method.assess_actionability(
            {
                **answers,
                "assessor_name": assessor_name,
                "assessor_role": assessor_role,
                "evidence_reference": evidence_reference,
                "assessment_notes": assessment_notes,
            }
        )
        st.caption(
            f"Current actionability readiness: {prospective_actionability}. {prospective_basis}"
        )

        # Replaces the legacy U21 control labelled
        # "Include a conservative/expected/ambitious reduction scenario".
        st.markdown("##### Required pre-decision abatement evidence choice")
        st.caption(
            "Before an intervention can become governance-ready, explicitly quantify its comparative "
            "reduction range or document why a defensible estimate is not currently available."
        )
        stored_decision = _clean_text(selected.get("scenario_quantification_decision"))
        if not stored_decision:
            stored_status = _clean_text(selected.get("scenario_status"))
            if stored_status in {"Quantified scenario", "Incomplete scenario"}:
                stored_decision = "Quantify reduction scenario"
            elif stored_status == "Documented unquantified":
                stored_decision = "Proceed without quantification"
            else:
                stored_decision = "Not decided"
        scenario_choices = list(governance_method.SCENARIO_DECISION_VALUES)
        scenario_decision = st.radio(
            "Abatement evidence decision",
            scenario_choices,
            index=(scenario_choices.index(stored_decision) if stored_decision in scenario_choices else 0),
            horizontal=True,
            key=f"blockchain_scenario_decision_{candidate_id}",
        )
        scenario_values: dict[str, Any] = {
            "scenario_quantification_decision": scenario_decision,
        }
        scenario_validation_errors: list[str] = []
        if scenario_decision == "Quantify reduction scenario":
            packaged = scenario_library.SCENARIO_LIBRARY.get(
                str(selected.get("hotspot_producer_node", "")), []
            )
            if packaged:
                references = "; ".join(
                    f"{item.label}: {item.reduction_pct:.1%}" for item in packaged
                )
                st.info(
                    f"Packaged literature sensitivities: {references}. These are reference evidence only; "
                    "implementation coverage and adoption still require stakeholder justification."
                )
            s1, s2, s3 = st.columns(3)
            scenario_values["scenario_conservative_effectiveness_fraction"] = (
                s1.number_input(
                    "Conservative effectiveness (%)", 0.0, 100.0,
                    _percentage(selected.get("scenario_conservative_effectiveness_fraction")), 1.0,
                    key=f"blockchain_scenario_low_{candidate_id}",
                ) / 100.0
            )
            scenario_values["scenario_expected_effectiveness_fraction"] = (
                s2.number_input(
                    "Expected effectiveness (%)", 0.0, 100.0,
                    _percentage(selected.get("scenario_expected_effectiveness_fraction")), 1.0,
                    key=f"blockchain_scenario_expected_{candidate_id}",
                ) / 100.0
            )
            scenario_values["scenario_ambitious_effectiveness_fraction"] = (
                s3.number_input(
                    "Ambitious effectiveness (%)", 0.0, 100.0,
                    _percentage(selected.get("scenario_ambitious_effectiveness_fraction")), 1.0,
                    key=f"blockchain_scenario_high_{candidate_id}",
                ) / 100.0
            )
            s4, s5, s6 = st.columns(3)
            scenario_values["scenario_implementation_coverage_fraction"] = (
                s4.number_input(
                    "Implementation coverage (%)", 0.0, 100.0,
                    _percentage(selected.get("scenario_implementation_coverage_fraction")), 1.0,
                    key=f"blockchain_scenario_coverage_{candidate_id}",
                ) / 100.0
            )
            scenario_values["scenario_adoption_fraction"] = (
                s5.number_input(
                    "Expected adoption (%)", 0.0, 100.0,
                    _percentage(selected.get("scenario_adoption_fraction")), 1.0,
                    key=f"blockchain_scenario_adoption_{candidate_id}",
                ) / 100.0
            )
            confidence_options = ["Low", "Medium", "High"]
            current_confidence = _clean_text(selected.get("scenario_confidence"))
            scenario_values["scenario_confidence"] = s6.selectbox(
                "Confidence",
                confidence_options,
                index=(confidence_options.index(current_confidence) if current_confidence in confidence_options else 0),
                key=f"blockchain_scenario_confidence_{candidate_id}",
            )
            scenario_values["scenario_assessor_name"] = st.text_input(
                "Scenario assessor name",
                value=_clean_text(selected.get("scenario_assessor_name")) or assessor_name,
                key=f"blockchain_scenario_assessor_{candidate_id}",
            )
            scenario_values["scenario_assessor_role"] = st.text_input(
                "Scenario assessor role",
                value=_clean_text(selected.get("scenario_assessor_role")) or assessor_role,
                key=f"blockchain_scenario_role_{candidate_id}",
            )
            scenario_values["scenario_evidence_reference"] = st.text_input(
                "Scenario evidence reference",
                value=_clean_text(selected.get("scenario_evidence_reference")) or evidence_reference,
                key=f"blockchain_scenario_evidence_{candidate_id}",
            )
            scenario_values["scenario_notes"] = st.text_area(
                "Scenario assumptions and limitations",
                value=_clean_text(selected.get("scenario_notes")),
                key=f"blockchain_scenario_notes_{candidate_id}",
            )
            scenario_values["scenario_non_quantification_reason"] = ""

            addressable = min(
                max(0.0, float(selected.get("baseline_hotspot_footprint_tco2", 0.0))),
                max(0.0, float(selected.get("avoided_hotspot_footprint_tco2", 0.0))),
            )
            multiplier = (
                scenario_values["scenario_implementation_coverage_fraction"]
                * scenario_values["scenario_adoption_fraction"]
            )
            preview = [
                addressable * scenario_values[field] * multiplier
                for field in (
                    "scenario_conservative_effectiveness_fraction",
                    "scenario_expected_effectiveness_fraction",
                    "scenario_ambitious_effectiveness_fraction",
                )
            ]
            st.caption(
                "Preview = capped structurally associated footprint × effectiveness × implementation coverage × adoption."
            )
            p1, p2, p3, p4 = st.columns(4)
            p1.metric("Addressable footprint", f"{addressable:,.6f} t CO2")
            p2.metric("Conservative preview", f"{preview[0]:,.6f} t CO2")
            p3.metric("Expected preview", f"{preview[1]:,.6f} t CO2")
            p4.metric("Ambitious preview", f"{preview[2]:,.6f} t CO2")
            if not (
                scenario_values["scenario_conservative_effectiveness_fraction"]
                <= scenario_values["scenario_expected_effectiveness_fraction"]
                <= scenario_values["scenario_ambitious_effectiveness_fraction"]
            ):
                scenario_validation_errors.append(
                    "Effectiveness must satisfy conservative ≤ expected ≤ ambitious."
                )
            for field, label in (
                ("scenario_assessor_name", "scenario assessor name"),
                ("scenario_assessor_role", "scenario assessor role"),
                ("scenario_evidence_reference", "scenario evidence reference"),
            ):
                if not _clean_text(scenario_values.get(field)):
                    scenario_validation_errors.append(f"Enter the {label}.")
        elif scenario_decision == "Proceed without quantification":
            scenario_values.update(
                {field: None for field in governance_method.SCENARIO_NUMERIC_FIELDS}
            )
            scenario_values["scenario_non_quantification_reason"] = st.text_area(
                "Reason a defensible reduction range is unavailable",
                value=_clean_text(selected.get("scenario_non_quantification_reason")),
                key=f"blockchain_scenario_unquantified_reason_{candidate_id}",
            )
            scenario_values["scenario_assessor_name"] = st.text_input(
                "Scenario decision assessor name",
                value=_clean_text(selected.get("scenario_assessor_name")) or assessor_name,
                key=f"blockchain_scenario_waiver_assessor_{candidate_id}",
            )
            scenario_values["scenario_assessor_role"] = st.text_input(
                "Scenario decision assessor role",
                value=_clean_text(selected.get("scenario_assessor_role")) or assessor_role,
                key=f"blockchain_scenario_waiver_role_{candidate_id}",
            )
            scenario_values["scenario_evidence_reference"] = st.text_input(
                "Evidence reference supporting non-quantification",
                value=_clean_text(selected.get("scenario_evidence_reference")) or evidence_reference,
                key=f"blockchain_scenario_waiver_evidence_{candidate_id}",
            )
            scenario_values["scenario_confidence"] = ""
            scenario_values["scenario_notes"] = st.text_area(
                "Limitations and future quantification plan",
                value=_clean_text(selected.get("scenario_notes")),
                key=f"blockchain_scenario_waiver_notes_{candidate_id}",
            )
            for field, label in (
                ("scenario_non_quantification_reason", "reason for non-quantification"),
                ("scenario_assessor_name", "scenario decision assessor name"),
                ("scenario_assessor_role", "scenario decision assessor role"),
                ("scenario_evidence_reference", "supporting evidence reference"),
            ):
                if not _clean_text(scenario_values.get(field)):
                    scenario_validation_errors.append(f"Enter the {label}.")
        else:
            scenario_values.update(
                {field: None for field in governance_method.SCENARIO_NUMERIC_FIELDS}
            )
            scenario_values.update({
                field: ""
                for field in governance_method.SCENARIO_TEXT_FIELDS
                if field != "scenario_quantification_decision"
            })
            if prospective_actionability == "Verified actionable":
                scenario_validation_errors.append(
                    "Choose whether to quantify the scenario or proceed without quantification."
                )

        submitted = st.form_submit_button(
            "Record evidence and generate governance-ready options",
            type="primary",
            use_container_width=True,
        )

    if submitted:
        if scenario_validation_errors:
            st.error(
                "The intervention cannot become governance-ready yet: "
                + " ".join(scenario_validation_errors)
            )
            return True
        answers.update(
            {
                "assessor_name": assessor_name,
                "assessor_role": assessor_role,
                "evidence_reference": evidence_reference,
                "assessment_notes": assessment_notes,
            }
        )
        answers.update(scenario_values)
        try:
            with st.spinner("Recording the attestation and rebuilding the governed portfolio..."):
                result = OrchestratorClient().record_intervention_actionability(
                    network_cid,
                    candidate_id,
                    answers,
                    request_context={
                        "source": "blockchain_intervention_control_plane",
                        "operation": "record_actionability_and_generate_options",
                        "control_plane": "blockchain_page",
                        "intervention_node": selected_node,
                        "hotspot_producer_node": str(selected["hotspot_producer_node"]),
                        "mechanism_code": str(selected.get("mechanism_code", "")),
                    },
                )
        except Exception as exc:
            st.error(f"The intervention assessment could not be recorded: {exc}")
        else:
            payload = result.get("payload", {}) if isinstance(result, dict) else {}
            st.session_state["blockchain_intervention_operation"] = {
                "ok": True,
                "message": (
                    f"Assessment recorded as {payload.get('assessment_status', 'completed')}; "
                    f"abatement evidence: {payload.get('scenario_status', 'not decided')}; "
                    f"{int(payload.get('governance_ready_option_count', 0)):,} governance-ready option(s) available."
                ),
            }
            st.rerun()

    st.caption(
        "Detailed pair evidence, scenarios, portfolio construction, formal option CIDs and downloads "
        "are available in the read-only Intervention Governance sidebar workspace."
    )
    return True


__all__ = ("render_intervention_control_plane",)
