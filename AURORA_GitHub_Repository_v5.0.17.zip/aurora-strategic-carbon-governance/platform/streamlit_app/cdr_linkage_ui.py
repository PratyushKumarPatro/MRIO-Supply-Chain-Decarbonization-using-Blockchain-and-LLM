"""Streamlit view for the U13 producer-specific CDR linkage diagnostic."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
import plotly.express as px
import streamlit as st

import cdr_producer_linkage as cdr_link
import runtime_ui as rui
from plot_style import style_plotly_axes
from ui_units import FOCAL_EMISSIONS_UNIT


@st.cache_data(show_spinner=False)
def _read_linkage_tables(
    pairwise_path: str,
    pairwise_sha256: str,
    intervention_path: str,
    intervention_sha256: str,
    producer_path: str,
    producer_sha256: str,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Read immutable-by-hash artifact snapshots into the Streamlit cache."""
    del pairwise_sha256, intervention_sha256, producer_sha256
    return (
        pd.read_csv(pairwise_path, compression="gzip"),
        pd.read_csv(intervention_path),
        pd.read_csv(producer_path),
    )


def _network_result_cid(state: dict[str, Any], year: int) -> str:
    record = state.get("active_results", {}).get("network", {}).get(str(int(year)), {})
    return str(record.get("content_hash", ""))


def _percentage(value: float) -> str:
    return f"{float(value):.2%}"


def _metric_value(value: float) -> str:
    return f"{float(value):,.6f}"


def render_cdr_producer_linkage_workspace(
    state: dict[str, Any],
    available_years: list[int],
    root_dir: str | Path,
) -> None:
    """Render producer-specific decomposition of each CDR node removal."""
    st.subheader("Producer-specific CDR linkage")
    st.caption(
        "This diagnostic decomposes the existing Carbon Dependency Risk node-removal "
        "counterfactual by the node where emissions are produced. It does not change CDR, "
        "IC, pooled Pearson-CRITIC weights, DLI scores, DLI ranks, or intervention rules."
    )
    st.latex(r"C_j=f_j(Ly)_j,\qquad C_j^{(-k)}=f_j(L^{(-k)}y^{(-k)})_j")
    st.latex(r"\Delta C_{j\mid-k}=C_j-C_j^{(-k)}")
    st.latex(r"\sum_j \Delta C_{j\mid-k}=F-F^{(-k)}=CDR(k)\,F")
    st.warning(
        "Interpretation boundary: this is the full removal of node k used by the existing CDR "
        "equation. It is not the effect of reducing only k's own direct carbon intensity. "
        "An intensity-only change in k does not automatically reduce producer j under fixed A and y."
    )

    if not available_years:
        st.info("Complete the Network/DLI analysis to generate the linkage artifacts.")
        return

    selected_year = int(
        st.selectbox(
            "Linkage year",
            sorted(int(year) for year in available_years),
            index=len(available_years) - 1,
            key="cdr_linkage_year",
        )
    )
    payload = rui.result_payload(state, "network", selected_year)
    linkage = payload.get("cdr_producer_linkage", {})
    if not isinstance(linkage, dict) or not linkage.get("available"):
        st.info(
            "The selected Network/DLI result predates the current linkage method. Re-run the "
            f"Network/DLI request for {selected_year} with this package."
        )
        return

    active_dir = Path(root_dir) / "runtime" / "active_analytics"
    source_cid = _network_result_cid(state, selected_year)
    input_hashes = state.get("active_input_hashes", {})
    try:
        metadata = cdr_link.verify_cdr_linkage_artifacts(
            active_dir,
            selected_year,
            expected_input_hashes=input_hashes,
            expected_source_result_cid=source_cid,
            expected_evidence_cid=str(linkage.get("evidence_cid", "")),
            expected_evidence_basis=linkage,
        )
        artifacts = metadata["artifacts"]
        pair_record = artifacts["pairwise"]
        intervention_record = artifacts["intervention_summary"]
        producer_record = artifacts["producer_baseline"]
        pairwise, intervention_summary, producer_baseline = _read_linkage_tables(
            str(active_dir / pair_record["filename"]),
            str(pair_record["sha256"]),
            str(active_dir / intervention_record["filename"]),
            str(intervention_record["sha256"]),
            str(active_dir / producer_record["filename"]),
            str(producer_record["sha256"]),
        )
        cdr_link.validate_cdr_linkage_frames(
            metadata, pairwise, intervention_summary, producer_baseline
        )
    except Exception as exc:
        st.error(
            "The producer-linkage artifacts are missing, stale, or failed provenance checks. "
            f"Re-run Network/DLI for {selected_year}. Details: {exc}"
        )
        return

    intervention_nodes = intervention_summary["intervention_node"].astype(str).tolist()
    producer_nodes = producer_baseline["producer_node"].astype(str).tolist()
    if not intervention_nodes or not producer_nodes:
        st.error("The verified linkage artifacts contain no nodes.")
        return

    default_intervention = (
        intervention_nodes.index("ARE-cns") if "ARE-cns" in intervention_nodes else 0
    )
    default_producer = producer_nodes.index("ARE-ely") if "ARE-ely" in producer_nodes else 0

    selector_1, selector_2 = st.columns(2)
    intervention_node = selector_1.selectbox(
        "Intervention/removal node k",
        intervention_nodes,
        index=default_intervention,
        key=f"cdr_linkage_intervention_{selected_year}",
        help="The node removed in the established CDR counterfactual.",
    )
    producer_node = selector_2.selectbox(
        "Emissions-producing node j",
        producer_nodes,
        index=default_producer,
        key=f"cdr_linkage_producer_{selected_year}",
        help="The node whose embodied-carbon contribution is compared before and after removal of k.",
    )

    pair = pairwise.loc[
        (pairwise["intervention_node"].astype(str) == str(intervention_node))
        & (pairwise["producer_node"].astype(str) == str(producer_node))
    ]
    intervention = intervention_summary.loc[
        intervention_summary["intervention_node"].astype(str) == str(intervention_node)
    ]
    if len(pair) != 1 or len(intervention) != 1:
        st.error("The selected pair is not uniquely represented in the verified linkage artifacts.")
        return

    pair_row = pair.iloc[0]
    intervention_row = intervention.iloc[0]
    baseline_total = float(intervention_row["baseline_company_footprint_tco2"])
    total_reduction = float(intervention_row["total_footprint_reduction_tco2"])
    cdr_value = float(intervention_row["CDR"])
    baseline_producer = float(pair_row["baseline_producer_footprint_tco2"])
    counterfactual_producer = float(
        pair_row["counterfactual_producer_footprint_tco2"]
    )
    avoided_producer = float(pair_row["avoided_producer_footprint_tco2"])
    producer_fraction = float(pair_row["producer_reduction_fraction"])
    intervention_share = float(pair_row["share_of_intervention_total_reduction"])
    company_share = float(pair_row["share_of_baseline_company_footprint"])

    row_1 = st.columns(3)
    row_1[0].metric(
        f"Baseline {producer_node} footprint ({FOCAL_EMISSIONS_UNIT})",
        _metric_value(baseline_producer),
    )
    row_1[1].metric(
        f"{producer_node} after removal of {intervention_node} ({FOCAL_EMISSIONS_UNIT})",
        _metric_value(counterfactual_producer),
    )
    row_1[2].metric(
        f"Delta C for {producer_node} ({FOCAL_EMISSIONS_UNIT})",
        _metric_value(avoided_producer),
        delta=_percentage(producer_fraction),
        help="Percentage change relative to the selected producer node's baseline contribution.",
    )

    row_2 = st.columns(4)
    row_2[0].metric("CDR(k)", f"{cdr_value:.6f}")
    row_2[1].metric(
        f"Total footprint reduction under removal ({FOCAL_EMISSIONS_UNIT})",
        _metric_value(total_reduction),
    )
    row_2[2].metric(
        "Selected producer share of k's total reduction",
        _percentage(intervention_share),
    )
    row_2[3].metric(
        "Selected pair share of company baseline",
        _percentage(company_share),
    )

    tolerance = max(abs(baseline_total) * 1e-9, 1e-12)
    if avoided_producer > tolerance:
        st.success(
            f"Under the complete node-removal counterfactual, removing {intervention_node} "
            f"reduces the footprint produced at {producer_node} by {avoided_producer:,.6f} "
            f"{FOCAL_EMISSIONS_UNIT}. This equals {producer_fraction:.2%} of the producer's "
            f"baseline contribution and {intervention_share:.2%} of the total footprint reduction "
            f"associated with removing {intervention_node}. This supports a modeled structural "
            "linkage under CDR, not a guarantee that an intensity-only intervention at k will cause the same change."
        )
    elif avoided_producer < -tolerance:
        st.error(
            f"The counterfactual increases the selected producer contribution by "
            f"{-avoided_producer:,.6f} {FOCAL_EMISSIONS_UNIT}. Inspect the input-output structure "
            "and numerical diagnostics before making a managerial claim."
        )
    else:
        st.info(
            f"No material producer-specific linkage is detected from {intervention_node} to "
            f"{producer_node} under the complete CDR node-removal counterfactual. The high DLI of "
            f"{intervention_node}, if present, is therefore explained by effects on other producer nodes "
            "and/or its BC, PageRank, CDR, and IC components."
        )

    selected_breakdown = pairwise.loc[
        pairwise["intervention_node"].astype(str) == str(intervention_node)
    ].copy()
    selected_breakdown = selected_breakdown.sort_values(
        ["avoided_producer_footprint_tco2", "producer_node"],
        ascending=[False, True],
        kind="mergesort",
    )
    top_affected = selected_breakdown.head(20)
    st.markdown(f"### Producer nodes affected by removing {intervention_node}")
    st.dataframe(
        top_affected[
            [
                "producer_node",
                "producer_region",
                "producer_sector",
                "baseline_producer_footprint_tco2",
                "counterfactual_producer_footprint_tco2",
                "avoided_producer_footprint_tco2",
                "producer_reduction_fraction",
                "share_of_intervention_total_reduction",
            ]
        ],
        use_container_width=True,
        hide_index=True,
    )
    positive_top = top_affected.loc[
        top_affected["avoided_producer_footprint_tco2"] > tolerance
    ]
    if not positive_top.empty:
        figure = px.bar(
            positive_top.sort_values("avoided_producer_footprint_tco2"),
            x="avoided_producer_footprint_tco2",
            y="producer_node",
            orientation="h",
            title=f"Top producer-specific footprint reductions under removal of {intervention_node}",
            labels={
                "avoided_producer_footprint_tco2": f"Delta producer footprint ({FOCAL_EMISSIONS_UNIT})",
                "producer_node": "Emissions-producing node",
            },
        )
        style_plotly_axes(figure)
        st.plotly_chart(figure, use_container_width=True)

    producer_influence = pairwise.loc[
        pairwise["producer_node"].astype(str) == str(producer_node)
    ].copy()
    producer_influence = producer_influence.merge(
        intervention_summary[
            ["intervention_node", "intervention_region", "intervention_sector", "CDR"]
        ],
        on=["intervention_node", "intervention_region", "intervention_sector"],
        how="left",
        validate="many_to_one",
    ).sort_values(
        ["avoided_producer_footprint_tco2", "intervention_node"],
        ascending=[False, True],
        kind="mergesort",
    )
    st.markdown(f"### Intervention/removal nodes most strongly linked to {producer_node}")
    st.dataframe(
        producer_influence.head(20)[
            [
                "intervention_node",
                "intervention_region",
                "intervention_sector",
                "CDR",
                "avoided_producer_footprint_tco2",
                "producer_reduction_fraction",
                "share_of_intervention_total_reduction",
            ]
        ],
        use_container_width=True,
        hide_index=True,
    )

    download_1, download_2 = st.columns(2)
    download_1.download_button(
        "Download selected intervention-node producer breakdown (CSV)",
        data=selected_breakdown.to_csv(index=False).encode("utf-8"),
        file_name=f"cdr_producer_breakdown_{selected_year}_{intervention_node}.csv",
        mime="text/csv",
        use_container_width=True,
    )
    pairwise_path = active_dir / metadata["artifacts"]["pairwise"]["filename"]
    download_2.download_button(
        "Download complete 455 x 455 linkage table (CSV.GZ)",
        data=pairwise_path.read_bytes(),
        file_name=pairwise_path.name,
        mime="application/gzip",
        use_container_width=True,
    )

    with st.expander("Method, reconciliation, and provenance"):
        st.write(
            "For every intervention node k, the platform uses the same operation as the existing CDR: "
            "row k and column k of A are zeroed, y_k is set to zero, and the Leontief inverse is "
            "recomputed. The total footprint difference is then decomposed across all producer nodes j."
        )
        st.json(
            {
                "network_result_cid": source_cid,
                "linkage_evidence_cid": linkage.get("evidence_cid"),
                "input_hashes": input_hashes,
                "node_count": metadata.get("node_count"),
                "pair_count": metadata.get("pair_count"),
                "maximum_absolute_reconciliation_residual_tco2": metadata.get(
                    "maximum_absolute_reconciliation_residual_tco2"
                ),
                "artifacts": metadata.get("artifacts"),
                "authority_boundary": metadata.get("dli_authority_boundary"),
                "interpretation_boundary": metadata.get("interpretation_boundary"),
            }
        )
        residual = float(intervention_row["reconciliation_residual_tco2"])
        st.caption(
            f"Selected-row reconciliation residual: {residual:.3e} {FOCAL_EMISSIONS_UNIT}. "
            "The producer-specific deltas must sum to CDR(k) multiplied by the baseline footprint."
        )
