"""Compatibility bridge to the single authoritative U16 module ``intervention_rules.py``.

The executable implementation lives at the deployment root. This small bridge
retains backwards-compatible ``streamlit_app.intervention_rules`` imports without
duplicating analytical or decision logic.
"""
from pathlib import Path as _Path

_SOURCE = _Path(__file__).resolve().parent.parent / 'intervention_rules.py'
globals()["__file__"] = str(_SOURCE)
exec(compile(_SOURCE.read_text(encoding="utf-8"), str(_SOURCE), "exec"), globals(), globals())
