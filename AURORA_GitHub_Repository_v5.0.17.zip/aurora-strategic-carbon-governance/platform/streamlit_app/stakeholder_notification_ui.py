"""Streamlit presentation for role-aware blockchain event notifications."""
from __future__ import annotations

import json
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st

from stakeholder_event_monitor import (
    PRINCIPAL_ROLE_ACCOUNTS,
    StakeholderEventMonitor,
    is_unread,
    load_notifications,
    load_seen_state,
    mark_notifications_seen,
    notification_sort_key,
)


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _heartbeat(runtime_dir: Path, max_age: float = 20.0) -> tuple[str, float | None, dict[str, Any]]:
    payload = _read_json(runtime_dir / "stakeholder_event_monitor_heartbeat.json")
    try:
        stamp = str(payload.get("updated_at_utc", "")).replace("Z", "+00:00")
        parsed = datetime.fromisoformat(stamp)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds()
        if payload.get("status") == "running" and age <= max_age:
            return "running", round(age, 1), payload
        if payload:
            return str(payload.get("status", "stale")), round(age, 1), payload
    except Exception:
        pass
    return "no heartbeat", None, payload


def _recipient_records(
    records: list[dict[str, Any]],
    role_name: str,
    address: str,
) -> list[dict[str, Any]]:
    lowered = str(address or "").lower()
    return [
        item
        for item in records
        if role_name in (item.get("recipient_roles") or [])
        or lowered in {str(value).lower() for value in (item.get("recipient_addresses") or [])}
    ]


def _short_hash(value: Any, width: int = 10) -> str:
    text = str(value or "")
    if len(text) <= width * 2 + 3:
        return text
    return f"{text[:width]}...{text[-width:]}"


def render_stakeholder_notifications(
    deployment: dict[str, Any],
    deployment_path: str | Path,
    runtime_dir: Path,
) -> None:
    """Render the wallet-role notification feed on the Blockchain page."""

    st.subheader("Stakeholder Event & Assurance Center")
    st.caption(
        "The event monitor reads the existing on-chain logs from all four deployed contracts. "
        "Analytical and governance lifecycle events are delivered to the Regulatory Authority, "
        "MRIO Data Provider, and Focal Company. Query Management events remain requester-only by default."
    )

    status, age, heartbeat = _heartbeat(runtime_dir)
    if status == "running":
        st.success(
            f"Stakeholder Event Monitor is running; heartbeat age {age}s; "
            f"{int(heartbeat.get('indexed_notifications', 0) or 0)} event notification(s) indexed."
        )
    elif status == "error":
        st.warning(f"Stakeholder Event Monitor reported an error: {heartbeat.get('error', '')}")
    else:
        st.info(
            "The background notification monitor is not currently reporting a fresh heartbeat. "
            "Use Refresh from chain below or restart start_dapp_lifecycle.ps1."
        )

    accounts = deployment.get("accounts", {}) if isinstance(deployment.get("accounts"), dict) else {}
    role_names = list(PRINCIPAL_ROLE_ACCOUNTS)
    selected_role = st.selectbox(
        "View notifications as stakeholder",
        role_names,
        format_func=lambda value: {
            "RegulatoryAuthority": "Regulatory Authority",
            "MRIODataProvider": "MRIO Data Provider",
            "FocalCompany": "Focal Company",
        }.get(value, value),
        key="stakeholder_notification_role",
    )
    selected_address = str(accounts.get(PRINCIPAL_ROLE_ACCOUNTS[selected_role], "") or "")
    st.caption(f"Active stakeholder address: `{selected_address}`")

    refresh_col, read_col = st.columns(2)
    with refresh_col:
        if st.button("Refresh notifications from chain", use_container_width=True):
            try:
                added = StakeholderEventMonitor(deployment_path).sync_once()
            except Exception as exc:
                st.error(f"Notification refresh failed: {exc}")
            else:
                st.success(f"Notification index refreshed; {added} new event(s) added.")
                st.rerun()

    records = load_notifications(deployment_path)
    visible = _recipient_records(records, selected_role, selected_address)
    visible.sort(key=notification_sort_key, reverse=True)
    seen_state = load_seen_state(deployment_path)
    unread = [item for item in visible if is_unread(item, selected_role, seen_state)]

    with read_col:
        if st.button(
            f"Mark visible as read ({len(unread)} unread)",
            disabled=not visible,
            use_container_width=True,
        ):
            mark_notifications_seen(deployment_path, selected_role, visible)
            st.rerun()

    if not visible:
        st.info(
            "No notification has yet been indexed for this stakeholder. Complete or refresh an on-chain lifecycle transaction."
        )
        return

    c1, c2, c3 = st.columns(3)
    c1.metric("Visible notifications", len(visible))
    c2.metric("Unread", len(unread))
    c3.metric("Latest block", max(int(item.get("block_number", 0) or 0) for item in visible))

    rows = []
    for item in visible[:100]:
        rows.append(
            {
                "unread": "Yes" if is_unread(item, selected_role, seen_state) else "No",
                "time (UTC)": str(item.get("block_timestamp_utc", "")),
                "status": str(item.get("status", "")),
                "event": str(item.get("title", item.get("event", ""))),
                "summary": str(item.get("summary", "")),
                "contract": str(item.get("contract", "")),
                "request": item.get("request_id"),
                "actor": str(item.get("actor_role", "")),
                "block": int(item.get("block_number", 0) or 0),
                "transaction": _short_hash(item.get("transaction_hash")),
            }
        )
    st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)

    with st.expander("Latest notification details", expanded=False):
        for item in visible[:10]:
            unread_label = "UNREAD" if is_unread(item, selected_role, seen_state) else "READ"
            st.markdown(
                f"**{unread_label} — {item.get('title', item.get('event', 'Event'))}**  \n"
                f"{item.get('summary', '')}"
            )
            st.caption(
                f"Contract: {item.get('contract')} | Event: {item.get('event')} | "
                f"Block: {item.get('block_number')} | Visibility: {item.get('visibility')}"
            )
            st.code(str(item.get("transaction_hash", "")), language="text")
            st.json(item.get("args", {}), expanded=False)
            st.divider()

    st.caption(
        "The local read/unread state and JSONL feed can be deleted and rebuilt. The authoritative notification evidence is the Solidity event log itself. "
        "This reference-deployment role selector should be replaced by connected-wallet identity binding in a production deployment."
    )
