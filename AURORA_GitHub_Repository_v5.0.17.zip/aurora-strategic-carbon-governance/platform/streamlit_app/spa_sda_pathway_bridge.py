"""Compatibility bridge to the single authoritative U17 module ``spa_sda_pathway_bridge.py``.

The executable implementation lives at the deployment root. This small bridge
retains backwards-compatible ``streamlit_app.spa_sda_pathway_bridge`` imports without
duplicating analytical or decision logic.
"""
from pathlib import Path as _Path

_SOURCE = _Path(__file__).resolve().parent.parent / 'spa_sda_pathway_bridge.py'
globals()["__file__"] = str(_SOURCE)
exec(compile(_SOURCE.read_text(encoding="utf-8"), str(_SOURCE), "exec"), globals(), globals())
