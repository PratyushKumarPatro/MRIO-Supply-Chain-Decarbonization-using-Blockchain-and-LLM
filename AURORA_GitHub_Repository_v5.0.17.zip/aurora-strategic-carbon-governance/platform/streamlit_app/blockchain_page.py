"""Progressive blockchain-controlled Streamlit deployment and operation page."""
from __future__ import annotations

import json
import math
import os
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Callable

import pandas as pd
import streamlit as st
from web3 import Web3

APP_PATH = Path(__file__).resolve()
APP_DIR = APP_PATH.parent
ROOT_DIR = APP_DIR.parent
if str(ROOT_DIR) not in sys.path:
    sys.path.insert(0, str(ROOT_DIR))

import input_onboarding as onboarding
import intervention_governance as u16_governance
from content_retrieval import ContentRetrievalError, retrieve_content
from dapp_lifecycle import (
    assign_oracle_roles,
    deploy_functional_contract,
    deploy_registration,
    refresh_lifecycle,
    submit_stakeholder_registration,
)
from orchestrator_client import OrchestratorClient
from intervention_control_ui import render_intervention_control_plane
from deployment_support import locate_deployment, load_and_validate_schema, searched_paths_text
from query_result_ui import render_query_result
from transaction_inspector import safe_record_transaction
from transaction_ui import render_transaction_details, render_transaction_explorer
from stakeholder_notification_ui import render_stakeholder_notifications
from ui_units import (
    CARBON_INTENSITY_UNIT,
    FOCAL_DEMAND_UNIT,
    FOCAL_EMISSIONS_UNIT,
    MRIO_EMISSIONS_UNIT,
    MRIO_MONETARY_UNIT,
    unit_convention_text,
)

ROLE_NAMES = {
    0: "None",
    1: "RegulatoryAuthority",
    2: "MRIODataProvider",
    3: "FocalCompany",
    4: "RegistrationOracle",
    5: "UpstreamAnalyticsOracle",
    6: "GovernanceOracle",
    7: "QueryOracle",
}


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _heartbeat_state(path: Path, max_age: float = 20.0) -> tuple[str, float | None, dict[str, Any]]:
    payload = _read_json(path)
    try:
        stamp = str(payload.get("updated_at_utc", "")).replace("Z", "+00:00")
        parsed = datetime.fromisoformat(stamp)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=timezone.utc)
        age = (datetime.now(timezone.utc) - parsed.astimezone(timezone.utc)).total_seconds()
        if payload.get("status") == "running" and age <= max_age:
            return "running", round(age, 1), payload
        if payload:
            return "stale", round(age, 1), payload
    except Exception:
        pass
    return "no heartbeat", None, payload


def _wait_for(getter: Callable[[], Any], status_index: int, timeout: float = 900.0) -> Any:
    deadline = time.time() + timeout
    record = getter()
    while time.time() < deadline and int(record[status_index]) == 0:
        time.sleep(1.0)
        record = getter()
    return record


def _wait_for_lifecycle(path: Path, key: str, timeout: float = 120.0) -> dict[str, Any]:
    deadline = time.time() + timeout
    state = refresh_lifecycle(path)
    while time.time() < deadline and not state.get("lifecycle", {}).get(key, False):
        time.sleep(1.0)
        state = refresh_lifecycle(path)
    return state


def _extract_result(content_hash: str, *, label: str = "result") -> dict[str, Any]:
    """Retrieve and verify a content-addressed result without hiding failures.

    v5.0.12 accidentally passed ``local_roots`` to ``retrieve_content`` even
    though the function accepts ``roots``.  The resulting TypeError was caught
    and replaced with an empty object, which is why the Blockchain page showed
    ``{}`` after a successfully fulfilled query.
    """
    try:
        retrieved = retrieve_content(
            content_hash,
            orchestrator_url=os.getenv("ORCHESTRATOR_URL", "http://127.0.0.1:8765"),
            roots=[ROOT_DIR],
            timeout=15.0,
            retries=6,
            retry_delay=0.75,
        )
    except ContentRetrievalError as exc:
        st.error(
            f"The on-chain {label} CID was recorded, but its verified content package could not be retrieved."
        )
        st.code(str(exc), language="text")
        return {}
    except Exception as exc:
        st.error(f"Unexpected {label} retrieval error: {exc}")
        return {}
    st.caption(
        f"Verified {label} package `{content_hash}` retrieved from {retrieved.source}."
    )
    return retrieved.content


def _format_estimate(value: Any) -> str:
    try:
        number = float(value)
    except (TypeError, ValueError):
        return "Not quantified"
    return f"{number:,.6f} t CO2" if math.isfinite(number) else "Not quantified"


def _clean_display_text(value: Any, fallback: str = "") -> str:
    if value is None:
        return fallback
    try:
        if pd.isna(value):
            return fallback
    except (TypeError, ValueError):
        pass
    rendered = str(value).strip()
    return fallback if rendered.lower() in {"", "nan", "none", "<na>"} else rendered


def render() -> None:
    st.title("Blockchain and LLM-based low-carbon supply chain governance and decision support")
    st.caption(
        "The platform activates each contract, data, analytical and governance stage only after its on-chain prerequisites are complete. "
        "The interface submits stakeholder transactions and displays verified results; specialized Oracle processes alone call fulfilment functions."
    )
    st.caption(unit_convention_text())

    deployment_path, searched = locate_deployment(__file__)
    if deployment_path is None:
        st.warning("No guided deployment state exists yet.")
        with st.expander("Paths checked"):
            st.code(searched_paths_text(searched))
        st.code(
            f'Set-Location -LiteralPath "{ROOT_DIR}"\n'
            '.\\.venv\\Scripts\\python.exe .\\prepare_dapp_lifecycle.py --reset',
            language="powershell",
        )
        st.stop()

    try:
        deployment = load_and_validate_schema(deployment_path, require_complete=False)
    except ValueError as exc:
        st.error(f"Invalid guided deployment state: {exc}")
        st.stop()

    w3 = Web3(
        Web3.HTTPProvider(
            deployment.get("rpc_url", "http://127.0.0.1:8545"),
            request_kwargs={"timeout": 5},
        )
    )
    if not w3.is_connected():
        st.error(f"Ganache is not reachable at `{deployment.get('rpc_url')}`.")
        st.stop()
    if int(deployment.get("chain_id", -1)) != int(w3.eth.chain_id):
        st.error("The guided state belongs to a different Ganache chain. Reset it before continuing.")
        st.stop()

    deployment = refresh_lifecycle(deployment_path)
    lifecycle = deployment.get("lifecycle", {})
    contracts_spec = deployment.get("contracts", {})
    accounts = deployment["accounts"]
    runtime_dir = Path(deployment_path).resolve().parent / "runtime"

    def record_ui_receipt(
        receipt: Any,
        *,
        actor_label: str,
        action: str,
        request_id: int | None = None,
        record_id: int | None = None,
        result_cid: str = "",
        contract_name_hint: str = "",
        function_signature_hint: str = "",
        decoded_inputs_hint: dict[str, Any] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        entry = safe_record_transaction(
            w3,
            deployment_path,
            receipt.transactionHash,
            receipt=receipt,
            actor_label=actor_label,
            action=action,
            source="streamlit-platform",
            request_id=request_id,
            record_id=record_id,
            result_cid=result_cid,
            contract_name_hint=contract_name_hint,
            function_signature_hint=function_signature_hint,
            decoded_inputs_hint=decoded_inputs_hint or {},
            metadata=metadata or {},
        )
        st.session_state["last_transaction_record"] = entry
        if request_id is not None:
            st.session_state["last_request_id"] = request_id
        return entry

    def start_oracle(role: str) -> None:
        state, _, _ = _heartbeat_state(runtime_dir / f"oracle_{role}_heartbeat.json")
        if state == "running":
            return
        command = [
            sys.executable,
            "-u",
            str(ROOT_DIR / "oracle_service.py"),
            "--role",
            role,
            "--deployment",
            str(deployment_path),
            "--orchestrator-url",
            os.getenv("ORCHESTRATOR_URL", "http://127.0.0.1:8765"),
            "--poll-interval",
            "1",
        ]
        log_path = runtime_dir / f"oracle_{role}.log"
        runtime_dir.mkdir(parents=True, exist_ok=True)
        log_handle = log_path.open("a", encoding="utf-8")
        kwargs: dict[str, Any] = {
            "cwd": str(ROOT_DIR),
            "stdout": log_handle,
            "stderr": subprocess.STDOUT,
        }
        if os.name == "nt":
            kwargs["creationflags"] = (
                getattr(subprocess, "CREATE_NO_WINDOW", 0)
                | getattr(subprocess, "CREATE_NEW_PROCESS_GROUP", 0)
            )
        try:
            subprocess.Popen(command, **kwargs)
        finally:
            log_handle.close()

    def receipt_summary(name: str, actor: str) -> None:
        value = deployment.get("deployment_receipts", {}).get(name)
        records = value if isinstance(value, list) else [value]
        for index, receipt in enumerate(records, start=1):
            if not isinstance(receipt, dict):
                continue
            # Older partial states may contain only a minimal receipt summary.
            # Rehydrate it directly from Ganache when possible.
            if receipt.get("transaction_hash") and not receipt.get("decoded_call"):
                receipt = safe_record_transaction(
                    w3,
                    deployment_path,
                    receipt["transaction_hash"],
                    actor_label=actor,
                    action=name,
                    source="streamlit-rehydration",
                )
            suffix = f" #{index}" if len(records) > 1 else ""
            render_transaction_details(
                receipt,
                title=f"{actor} transaction details{suffix}",
                expanded=False,
            )

    def contract(name: str):
        spec = contracts_spec.get(name)
        if not spec:
            return None
        return w3.eth.contract(address=spec["address"], abi=spec["abi"])

    reg = contract("Registration")
    upstream = contract("UpstreamCarbonEmissionsAnalysis")
    governance = contract("HotspotsManagementAndGovernance")
    query = contract("QueryManagement")

    st.success(f"Connected to Ganache chain `{w3.eth.chain_id}` at block `{w3.eth.block_number}`.")
    st.caption(f"Guided deployment state: `{deployment_path}`")
    latest_transaction = st.session_state.get("last_transaction_record")
    if isinstance(latest_transaction, dict) and latest_transaction.get("transaction_hash"):
        render_transaction_details(
            latest_transaction,
            title="Most recent transaction",
            expanded=False,
        )

    with st.container(border=True):
        render_stakeholder_notifications(
            deployment,
            deployment_path,
            runtime_dir,
        )

    temporal_dli_complete = bool(lifecycle.get("temporal_dli_complete", False))
    active_aurora_2017 = (
        deployment.get("active_results", {}).get("aurora", {}).get("2017")
    )
    aurora_2017_complete = bool(
        lifecycle.get(
            "aurora_2017_complete",
            lifecycle.get("aurora_complete", False),
        )
        and active_aurora_2017
    )
    intervention_governance_resolved = bool(
        lifecycle.get(
            "intervention_governance_resolved",
            lifecycle.get(
                "intervention_governance_outcome_complete",
                lifecycle.get("outcome_complete", False),
            ),
        )
    )
    intervention_governance_evidence_verified = bool(
        lifecycle.get("intervention_governance_evidence_verified", False)
    )
    try:
        governance_ready_option_count = int(
            lifecycle.get("governance_ready_option_count", 0) or 0
        )
    except (TypeError, ValueError):
        governance_ready_option_count = 0
    verified_no_governance_ready_intervention = bool(
        lifecycle.get(
            "verified_no_governance_ready_intervention",
            lifecycle.get("no_governance_ready_intervention", False),
        )
    )
    intervention_governance_resolution_basis = str(
        lifecycle.get("intervention_governance_resolution_basis", "") or ""
    )
    query_management_prerequisites_complete = bool(
        lifecycle.get(
            "query_management_ready",
            temporal_dli_complete
            and aurora_2017_complete
            and intervention_governance_resolved,
        )
    )

    def lifecycle_stage_status(stage_number: int, complete: Any) -> str:
        if stage_number == 14:
            if lifecycle.get("query_deployed", False) and query_management_prerequisites_complete:
                return "Available — current verified evidence"
            if lifecycle.get("query_deployed", False):
                return "Paused — refresh analytical evidence"
            return "Pending/locked"
        if bool(complete):
            return "Completed"
        if stage_number == 10 and lifecycle.get("governance_deployed", False):
            return "Available"
        if stage_number == 11 and temporal_dli_complete:
            return "Available — next analytical stage"
        if stage_number == 12:
            if intervention_governance_resolved:
                return "Formal governance resolved"
            if intervention_governance_evidence_verified and aurora_2017_complete:
                return "Evidence ready — governance may continue"
            if aurora_2017_complete:
                return "Available — post-AURORA governance"
        if stage_number == 13 and query_management_prerequisites_complete:
            return "Available — evidence synthesis"
        return "Pending/locked"

    stages = [
        (1, "Regulatory Authority", "Deploy Registration contract (from StrategicCarbonIntelligenceSystem.sol)", lifecycle.get("registration_deployed")),
        (2, "Regulatory Authority", "Appoint four specialized Oracle identities", lifecycle.get("oracle_roles_assigned")),
        (3, "Registration Oracle", "Verify MRIO Data Provider and Focal Company", lifecycle.get("stakeholders_registered")),
        (4, "MRIO Data Provider", "Deploy UpstreamCarbonEmissionsAnalysis contract (from StrategicCarbonIntelligenceSystem.sol)", lifecycle.get("upstream_deployed")),
        (5, "MRIO Data Provider", "Upload and validate MRIO workbook", lifecycle.get("mrio_data_validated")),
        (6, "Focal Company", "Upload and validate focal-company demand workbook", lifecycle.get("focal_demand_validated")),
        (7, "Focal Company + Upstream Oracle", "Complete MRIO 2014 and 2017", lifecycle.get("mrio_2014_complete") and lifecycle.get("mrio_2017_complete")),
        (8, "Focal Company + Upstream Oracle", "Complete SPA 2014/2017 and SDA 2014-2017", lifecycle.get("upstream_baseline_complete")),
        (9, "Focal Company", "Deploy HotspotsManagementAndGovernance contract (from StrategicCarbonIntelligenceSystem.sol)", lifecycle.get("governance_deployed")),
        (10, "Focal Company + Governance Oracle", "Complete Network/DLI 2014/2017 and derive temporal DLI", temporal_dli_complete),
        (11, "Focal Company + Governance Oracle", "Complete the 2017 AURORA regional opportunity assessment after temporal Network/DLI", aurora_2017_complete),
        (12, "Regulator or Focal Company + Governance Oracle", "Review intervention evidence, compare scenario ranges, select an option, and record approval or rejection", intervention_governance_resolved),
        (13, "Focal Company", "Deploy final decision support after the intervention branch is formally resolved", lifecycle.get("query_deployed")),
        (14, "Registered stakeholder + Query Oracle", "Use evidence-grounded blockchain queries while the analytical evidence remains current", False),
    ]
    st.subheader("Lifecycle progress")
    st.dataframe(
        pd.DataFrame(
            [
                {
                    "stage": number,
                    "responsible actor": actor,
                    "business transaction": action,
                    "status": lifecycle_stage_status(number, complete),
                }
                for number, actor, action, complete in stages
            ]
        ),
        use_container_width=True,
        hide_index=True,
    )

    # 1. Registration deployment -------------------------------------------------
    with st.expander(
        "Stage 1 — Regulatory Authority deploys the Registration contract from StrategicCarbonIntelligenceSystem.sol",
        expanded=not lifecycle.get("registration_deployed", False),
    ):
        st.write(f"**Regulatory Authority Ethereum address:** `{accounts['regulator']}`")
        st.write(f"**Initial Registration Oracle address:** `{accounts['registration_oracle']}`")
        st.caption(
            "The constructor establishes the signer as the Regulatory Authority governance root and appoints the initial Registration Oracle."
        )
        if not lifecycle.get("registration_deployed"):
            if st.button("Deploy Registration contract (from StrategicCarbonIntelligenceSystem.sol)", type="primary", use_container_width=True):
                try:
                    updated = deploy_registration(deployment_path)
                    st.session_state["last_transaction_record"] = updated.get("deployment_receipts", {}).get("Registration", {})
                except Exception as exc:
                    st.error(str(exc))
                else:
                    st.rerun()
        else:
            receipt_summary("Registration", "Regulatory Authority")
            if reg is not None:
                actual = int(reg.functions.roleOf(accounts["regulator"]).call())
                st.success(f"Regulatory Authority on-chain role: `{ROLE_NAMES.get(actual, actual)}`")

    # 2. Oracle appointment ------------------------------------------------------
    with st.expander(
        "Stage 2 — Regulatory Authority appoints specialized Oracles",
        expanded=lifecycle.get("registration_deployed", False)
        and not lifecycle.get("oracle_roles_assigned", False),
    ):
        if not lifecycle.get("registration_deployed"):
            st.info("Locked until the Registration contract is deployed.")
        else:
            oracle_rows = []
            for key, spec in deployment["oracle_roles"].items():
                actual = int(reg.functions.roleOf(spec["address"]).call()) if reg else 0
                oracle_rows.append(
                    {
                        "oracle": spec["role_name"],
                        "Ethereum address": spec["address"],
                        "on-chain role": ROLE_NAMES.get(actual, str(actual)),
                    }
                )
            st.dataframe(pd.DataFrame(oracle_rows), use_container_width=True, hide_index=True)
            if not lifecycle.get("oracle_roles_assigned"):
                if st.button("Assign remaining Oracle roles", use_container_width=True):
                    try:
                        updated = assign_oracle_roles(deployment_path)
                        assignments = updated.get("deployment_receipts", {}).get("OracleRoleAssignments", [])
                        if assignments:
                            st.session_state["last_transaction_record"] = assignments[-1]
                        start_oracle("registration")
                        time.sleep(2)
                    except Exception as exc:
                        st.error(str(exc))
                    else:
                        st.rerun()
            else:
                st.success("All four Oracle identities are authorized on-chain.")
                receipt_summary("OracleRoleAssignments", "Regulatory Authority")
                status, age, _ = _heartbeat_state(runtime_dir / "oracle_registration_heartbeat.json")
                if status != "running":
                    if st.button("Start Registration Oracle", use_container_width=True):
                        start_oracle("registration")
                        time.sleep(2)
                        st.rerun()
                else:
                    st.success(f"Registration Oracle process is running; heartbeat age {age}s.")

    # 3. Stakeholder registration ----------------------------------------------
    with st.expander(
        "Stage 3 — Registration Oracle verifies external stakeholders",
        expanded=lifecycle.get("oracle_roles_assigned", False)
        and not lifecycle.get("stakeholders_registered", False),
    ):
        if not lifecycle.get("oracle_roles_assigned"):
            st.info("Locked until Oracle identities are appointed.")
        elif reg is None:
            st.error("Registration contract is unavailable.")
        else:
            st.info(
                "The Regulatory Authority is the constructor-established root. The MRIO Data Provider and Focal Company request registration; the Registration Oracle verifies their evidence through the Data Orchestrator."
            )
            root_role = int(reg.functions.roleOf(accounts["regulator"]).call())
            st.write(
                f"**Regulatory Authority:** `{accounts['regulator']}` — `{ROLE_NAMES.get(root_role, root_role)}`"
            )
            columns = st.columns(2)
            for column, (key, label, role_code) in zip(
                columns,
                [
                    ("mrio_provider", "MRIO Data Provider", 2),
                    ("focal_company", "Focal Company", 3),
                ],
            ):
                with column:
                    address = accounts[key]
                    actual = int(reg.functions.roleOf(address).call())
                    st.markdown(f"### {label}")
                    st.code(address)
                    if actual == role_code:
                        st.success(f"Approved as {ROLE_NAMES[role_code]}")
                        registration_receipts = deployment.get("deployment_receipts", {}).get("StakeholderRegistrationRequests", {})
                        if isinstance(registration_receipts, dict) and isinstance(registration_receipts.get(key), dict):
                            render_transaction_details(
                                registration_receipts[key],
                                title=f"{label} registration-request transaction",
                                expanded=False,
                            )
                    else:
                        request_id = deployment.get("stakeholder_registration_requests", {}).get(key)
                        if request_id is not None:
                            request = reg.functions.getRegistrationRequest(int(request_id)).call()
                            st.info(f"Request `{request_id}`: {['Pending','Approved','Rejected'][int(request[3])]}")
                        if st.button(f"Request {label} registration", key=f"request_{key}", use_container_width=True):
                            try:
                                start_oracle("registration")
                                time.sleep(1)
                                updated = submit_stakeholder_registration(deployment_path, key)
                                registration_receipts = updated.get("deployment_receipts", {}).get("StakeholderRegistrationRequests", {})
                                if isinstance(registration_receipts, dict) and registration_receipts.get(key):
                                    st.session_state["last_transaction_record"] = registration_receipts[key]
                                deadline = time.time() + 45
                                while time.time() < deadline:
                                    if int(reg.functions.roleOf(address).call()) == role_code:
                                        break
                                    time.sleep(1)
                            except Exception as exc:
                                st.error(str(exc))
                            else:
                                st.rerun()
            if st.button("Refresh stakeholder status", use_container_width=True):
                st.rerun()

    # 4. Upstream contract -------------------------------------------------------
    with st.expander(
        "Stage 4 — MRIO Data Provider deploys the UpstreamCarbonEmissionsAnalysis contract from StrategicCarbonIntelligenceSystem.sol",
        expanded=lifecycle.get("stakeholders_registered", False)
        and not lifecycle.get("upstream_deployed", False),
    ):
        if not lifecycle.get("stakeholders_registered"):
            st.info("Locked until the MRIO Data Provider and Focal Company are registered.")
        else:
            st.write(f"**Authorized deployer:** MRIO Data Provider `{accounts['mrio_provider']}`")
            st.write(f"**Constructor input:** Registration `{contracts_spec['Registration']['address']}`")
            if not lifecycle.get("upstream_deployed"):
                if st.button("Deploy Upstream Carbon Emissions Analysis contract", use_container_width=True):
                    try:
                        updated = deploy_functional_contract(deployment_path, "UpstreamCarbonEmissionsAnalysis")
                        st.session_state["last_transaction_record"] = updated.get("deployment_receipts", {}).get("UpstreamCarbonEmissionsAnalysis", {})
                        start_oracle("upstream")
                        time.sleep(2)
                    except Exception as exc:
                        st.error(str(exc))
                    else:
                        st.rerun()
            else:
                receipt_summary("UpstreamCarbonEmissionsAnalysis", "MRIO Data Provider")
                status, age, _ = _heartbeat_state(runtime_dir / "oracle_upstream_heartbeat.json")
                if status != "running":
                    if st.button("Start Upstream Analytics Oracle", use_container_width=True):
                        start_oracle("upstream")
                        time.sleep(2)
                        st.rerun()
                else:
                    st.success(f"Upstream Analytics Oracle is running; heartbeat age {age}s.")

    # Data helper ---------------------------------------------------------------
    def submit_data_request(kind: str, body: bytes, original_name: str, validation: dict[str, Any]) -> None:
        current = refresh_lifecycle(deployment_path)
        spec = current["contracts"]["UpstreamCarbonEmissionsAnalysis"]
        contract_obj = w3.eth.contract(address=spec["address"], abi=spec["abi"])
        if kind == "mrio":
            sender = current["accounts"]["mrio_provider"]
            function = contract_obj.functions.requestMRIODataUpdate
            event_type = contract_obj.events.MRIODataUpdateRequested
        else:
            sender = current["accounts"]["focal_company"]
            function = contract_obj.functions.requestFocalCompanyDemandDataUpdate
            event_type = contract_obj.events.FocalCompanyDemandDataUpdateRequested
        staged = onboarding.stage_upload(
            kind,
            body,
            actor_address=sender,
            original_name=original_name,
            validation=validation,
        )
        tx_hash = function(staged["sha256"]).transact({"from": sender})
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
        event = event_type().process_receipt(receipt)[0]
        request_id = int(event["args"]["requestId"])
        record_ui_receipt(
            receipt,
            actor_label="MRIO Data Provider" if kind == "mrio" else "Focal Company",
            action="Request MRIO data validation" if kind == "mrio" else "Request focal-company demand validation",
            request_id=request_id,
            metadata={
                "input_kind": kind,
                "original_filename": original_name,
                "uploaded_file_sha256": staged["sha256"],
                "local_validation": {k: v for k, v in validation.items() if k != "node_codes"},
            },
        )
        st.success(f"Request `{request_id}` emitted from `{sender}`. Waiting for the Upstream Oracle...")
        record = _wait_for(
            lambda: contract_obj.functions.getDataUpdateRequest(request_id).call(),
            4,
            600,
        )
        if int(record[4]) != 1:
            st.error(f"Data request status: {['Pending','Fulfilled','Rejected','Failed'][int(record[4])]}")
            return
        deadline = time.time() + 90
        while time.time() < deadline:
            if onboarding.active_input_hash(kind).lower() == staged["sha256"].lower():
                break
            time.sleep(1)
        if onboarding.active_input_hash(kind).lower() != staged["sha256"].lower():
            st.warning(
                "The contract accepted the hash, but the post-fulfilment promotion has not completed. Check the Upstream Oracle and Data Orchestrator windows."
            )
        else:
            st.success(
                f"Accepted on-chain and promoted as the active {onboarding.KIND_CONFIG[kind]['actor']} input."
            )

    # 5. MRIO upload ------------------------------------------------------------
    with st.expander(
        "Stage 5 — MRIO Data Provider uploads and validates the MRIO workbook",
        expanded=lifecycle.get("upstream_deployed", False)
        and not lifecycle.get("mrio_data_validated", False),
    ):
        if not lifecycle.get("upstream_deployed"):
            st.info("Locked until the Upstream contract is deployed.")
        else:
            st.write(f"**Authorized uploader Ethereum address:** `{accounts['mrio_provider']}`")
            st.caption("Only this registered MRIO Data Provider account can call requestMRIODataUpdate.")
            if lifecycle.get("mrio_data_validated"):
                st.success(f"Active and on-chain validated MRIO SHA-256: `{deployment.get('active_input_hashes', {}).get('mrio', '')}`")
            else:
                upload = st.file_uploader("Upload MRIO Excel workbook", type=["xlsx"], key="progressive_mrio_upload")
                if upload is not None:
                    body = upload.getvalue()
                    try:
                        validation = onboarding.validate_mrio_bytes(body)
                    except Exception as exc:
                        st.error(f"MRIO validation failed: {exc}")
                    else:
                        st.success(
                            f"Local pre-validation passed: {validation['node_count']} nodes; SHA-256 `{validation['sha256']}`"
                        )
                        with st.expander("MRIO validation details"):
                            st.caption(
                                f"MRIO transaction, output, and economy-wide final-demand values use {MRIO_MONETARY_UNIT}; "
                                f"the direct-emissions extension and economy-wide footprint use {MRIO_EMISSIONS_UNIT}; "
                                f"the resulting direct carbon intensity is expressed as {CARBON_INTENSITY_UNIT}."
                            )
                            st.json({k: v for k, v in validation.items() if k != "node_codes"})
                        if st.button("Stage MRIO workbook and request on-chain validation", type="primary", use_container_width=True):
                            try:
                                start_oracle("upstream")
                                submit_data_request("mrio", body, upload.name, validation)
                            except Exception as exc:
                                st.error(str(exc))
                            else:
                                st.rerun()

    # 6. Focal-demand upload ----------------------------------------------------
    with st.expander(
        "Stage 6 — Focal Company uploads and validates its demand workbook",
        expanded=lifecycle.get("mrio_data_validated", False)
        and not lifecycle.get("focal_demand_validated", False),
    ):
        if not lifecycle.get("mrio_data_validated"):
            st.info("Locked until the MRIO workbook is accepted and active.")
        else:
            st.write(f"**Authorized uploader Ethereum address:** `{accounts['focal_company']}`")
            st.caption("Only this registered Focal Company account can call requestFocalCompanyDemandDataUpdate.")
            if lifecycle.get("focal_demand_validated"):
                st.success(f"Active and on-chain validated demand SHA-256: `{deployment.get('active_input_hashes', {}).get('focal_demand', '')}`")
            else:
                upload = st.file_uploader("Upload focal-company demand Excel workbook", type=["xlsx"], key="progressive_demand_upload")
                if upload is not None:
                    body = upload.getvalue()
                    try:
                        validation = onboarding.validate_focal_demand_bytes(body)
                    except Exception as exc:
                        st.error(f"Focal-demand validation failed: {exc}")
                    else:
                        st.success(
                            f"Local pre-validation passed: {validation['node_count']} nodes; SHA-256 `{validation['sha256']}`"
                        )
                        with st.expander("Focal-demand validation details"):
                            st.caption(
                                f"The Company_<year>_USD vectors and total_demand values are expressed in {FOCAL_DEMAND_UNIT}; focal-company carbon results derived from them are reported in {FOCAL_EMISSIONS_UNIT}. No additional demand scaling is applied by the analytical engine."
                            )
                            st.json({k: v for k, v in validation.items() if k != "node_codes"})
                        if st.button("Stage demand workbook and request on-chain validation", type="primary", use_container_width=True):
                            try:
                                start_oracle("upstream")
                                submit_data_request("focal_demand", body, upload.name, validation)
                            except Exception as exc:
                                st.error(str(exc))
                            else:
                                st.rerun()

    # Analytical request helper -------------------------------------------------
    def submit_compute(kind: str, year: int | None = None) -> None:
        current = refresh_lifecycle(deployment_path)
        spec = current["contracts"]["UpstreamCarbonEmissionsAnalysis"]
        contract_obj = w3.eth.contract(address=spec["address"], abi=spec["abi"])
        sender = current["accounts"]["focal_company"]
        if kind == "mrio":
            tx_hash = contract_obj.functions.computeMRIOCarbonAccounting(int(year)).transact({"from": sender})
            event_type = contract_obj.events.MRIOCarbonAccountingRequested
        elif kind == "spa":
            tx_hash = contract_obj.functions.performStructuralPathAnalysis(int(year)).transact({"from": sender})
            event_type = contract_obj.events.StructuralPathAnalysisRequested
        elif kind == "sda":
            tx_hash = contract_obj.functions.performStructuralDecompositionAnalysis(2014, 2017).transact({"from": sender})
            event_type = contract_obj.events.StructuralDecompositionAnalysisRequested
        else:
            raise ValueError(kind)
        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
        request_id = int(event_type().process_receipt(receipt)[0]["args"]["requestId"])
        action_label = {
            "mrio": f"Request MRIO carbon accounting {year}",
            "spa": f"Request Structural Path Analysis {year}",
            "sda": "Request Structural Decomposition Analysis 2014-2017",
        }[kind]
        record_ui_receipt(
            receipt,
            actor_label="Focal Company",
            action=action_label,
            request_id=request_id,
            metadata={"analytical_kind": kind, "year": year, "base_year": 2014 if kind == "sda" else None, "comparison_year": 2017 if kind == "sda" else None},
        )
        st.success(f"Compute request `{request_id}` emitted. Waiting for the Upstream Analytics Oracle...")
        record = _wait_for(lambda: contract_obj.functions.getComputeRequest(request_id).call(), 7, 1200)
        if int(record[7]) == 1:
            st.success(f"Fulfilled by `{record[10]}`. Result CID `{record[6]}`.")
            content = _extract_result(str(record[6]))
            if content:
                with st.expander("Result package"):
                    st.caption(unit_convention_text())
                    st.json(content)
        else:
            st.error(f"Request ended with status {['Pending','Fulfilled','Rejected','Failed'][int(record[7])]}; CID `{record[6]}`")

    # 7. MRIO computations ------------------------------------------------------
    with st.expander(
        "Stage 7 — Focal Company requests MRIO carbon accounting",
        expanded=lifecycle.get("focal_demand_validated", False)
        and not (lifecycle.get("mrio_2014_complete") and lifecycle.get("mrio_2017_complete")),
    ):
        if not lifecycle.get("focal_demand_validated"):
            st.info("Locked until both uploaded workbooks are accepted and active.")
        else:
            st.write(f"**Requesting stakeholder:** Focal Company `{accounts['focal_company']}`")
            columns = st.columns(3)
            for column, year in zip(columns[:2], [2014, 2017]):
                with column:
                    complete = lifecycle.get(f"mrio_{year}_complete", False)
                    st.markdown(f"### MRIO {year}")
                    if complete:
                        cid = deployment.get("active_results", {}).get("mrio", {}).get(str(year), {}).get("content_hash", "")
                        st.success(f"Completed; CID `{cid}`")
                    elif st.button(f"Run MRIO carbon accounting — {year}", key=f"run_mrio_{year}", use_container_width=True):
                        try:
                            start_oracle("upstream")
                            submit_compute("mrio", year)
                        except Exception as exc:
                            st.error(str(exc))
                        else:
                            st.rerun()

            # Presentation-only placeholder showing that the same workflow can
            # accommodate a later compatible MRIO reference year. This does not
            # change the validated 2014/2017 analytical or governance lifecycle.
            with columns[2]:
                st.markdown("### MRIO ...")
                st.info("Next compatible MRIO reference year")
                st.caption(
                    "A subsequent year can be analysed through the same workflow "
                    "when compatible MRIO and focal-company demand data are available."
                )

    # 8. SPA and SDA ------------------------------------------------------------
    with st.expander(
        "Stage 8 — Complete SPA and SDA",
        expanded=lifecycle.get("mrio_2014_complete", False)
        and lifecycle.get("mrio_2017_complete", False)
        and not lifecycle.get("upstream_baseline_complete", False),
    ):
        if not (lifecycle.get("mrio_2014_complete") and lifecycle.get("mrio_2017_complete")):
            st.info("Locked until MRIO accounting is complete for both reference years.")
        else:
            columns = st.columns(2)
            for column, year in zip(columns, [2014, 2017]):
                with column:
                    complete = lifecycle.get(f"spa_{year}_complete", False)
                    st.markdown(f"### SPA {year}")
                    if complete:
                        cid = deployment.get("active_results", {}).get("spa", {}).get(str(year), {}).get("content_hash", "")
                        st.success(f"Completed; CID `{cid}`")
                    elif st.button(f"Perform SPA — {year}", key=f"run_spa_{year}", use_container_width=True):
                        try:
                            start_oracle("upstream")
                            submit_compute("spa", year)
                        except Exception as exc:
                            st.error(str(exc))
                        else:
                            st.rerun()
            st.markdown("### Structural decomposition 2014 → 2017")
            if lifecycle.get("sda_complete"):
                cid = deployment.get("active_results", {}).get("sda", {}).get("2014-2017", {}).get("content_hash", "")
                st.success(f"Completed; CID `{cid}`")
            elif lifecycle.get("spa_2014_complete") and lifecycle.get("spa_2017_complete"):
                if st.button("Perform SDA — 2014 to 2017", use_container_width=True):
                    try:
                        start_oracle("upstream")
                        submit_compute("sda")
                    except Exception as exc:
                        st.error(str(exc))
                    else:
                        st.rerun()
            else:
                st.info("SDA unlocks after SPA is complete for both reference years.")

    # 9. Governance deployment --------------------------------------------------
    with st.expander(
        "Stage 9 — Focal Company deploys the HotspotsManagementAndGovernance contract from StrategicCarbonIntelligenceSystem.sol",
        expanded=lifecycle.get("upstream_baseline_complete", False)
        and not lifecycle.get("governance_deployed", False),
    ):
        if not lifecycle.get("upstream_baseline_complete"):
            st.info("Locked until MRIO 2014/2017, SPA 2014/2017 and SDA 2014-2017 are complete.")
        else:
            st.write(f"**Authorized deployer:** Focal Company `{accounts['focal_company']}`")
            if not lifecycle.get("governance_deployed"):
                if st.button("Deploy Hotspot Management and Governance contract", use_container_width=True):
                    try:
                        updated = deploy_functional_contract(deployment_path, "HotspotsManagementAndGovernance")
                        st.session_state["last_transaction_record"] = updated.get("deployment_receipts", {}).get("HotspotsManagementAndGovernance", {})
                        start_oracle("governance")
                        time.sleep(2)
                    except Exception as exc:
                        st.error(str(exc))
                    else:
                        st.rerun()
            else:
                receipt_summary("HotspotsManagementAndGovernance", "Focal Company")

    # 10-12 Governance operations ----------------------------------------------
    governance = contract("HotspotsManagementAndGovernance")
    with st.expander(
        "Stages 10–12 — Network/DLI, then AURORA, then intervention governance",
        expanded=lifecycle.get("governance_deployed", False)
        and not query_management_prerequisites_complete,
    ):
        if not lifecycle.get("governance_deployed") or governance is None:
            st.info("Locked until the Governance contract is deployed.")
        else:
            status, age, _ = _heartbeat_state(runtime_dir / "oracle_governance_heartbeat.json")
            if status != "running":
                if st.button("Start Governance Oracle", use_container_width=True):
                    start_oracle("governance")
                    time.sleep(2)
                    st.rerun()
            else:
                st.success(f"Governance Oracle running; heartbeat age {age}s.")

            network_results = deployment.get("active_results", {}).get("network", {})
            network_2014 = network_results.get("2014")
            network_2017 = network_results.get("2017")

            st.markdown("### Annual Network/DLI evidence")
            st.caption(
                "The 2014 request first establishes the required temporal baseline and a provisional annual view. "
                "The 2017 request then applies one pooled two-year normalization and one common Pearson-CRITIC "
                "weight vector to both 2014 and 2017. That pooled result is the authority for temporal comparison."
            )

            if not network_2014:
                if st.button("Run Network/DLI analysis — 2014", use_container_width=True):
                    try:
                        tx_hash = governance.functions.performNetworkAnalysis(2014).transact({"from": accounts["focal_company"]})
                        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
                        request_id = int(governance.events.NetworkAnalysisRequested().process_receipt(receipt)[0]["args"]["requestId"])
                        record_ui_receipt(
                            receipt,
                            actor_label="Focal Company",
                            action="Request Network/DLI analysis 2014",
                            request_id=request_id,
                            metadata={"request_scope": "network", "analysis_year": 2014, "governance_mode": "historical evidence"},
                        )
                        record = _wait_for(lambda: governance.functions.getNetworkRequest(request_id).call(), 3, 1200)
                        if int(record[3]) != 1:
                            raise RuntimeError(f"Network request status {record[3]}; CID {record[2]}")
                        st.success(f"2014 Network/DLI fulfilled by `{record[6]}`; CID `{record[2]}`.")
                    except Exception as exc:
                        st.error(str(exc))
                    else:
                        st.rerun()
            else:
                st.success(f"2014 Network/DLI completed; CID `{network_2014.get('content_hash')}`")

            if network_2014 and not network_2017:
                if st.button("Run Network/DLI analysis — 2017", use_container_width=True):
                    try:
                        tx_hash = governance.functions.performNetworkAnalysis(2017).transact({"from": accounts["focal_company"]})
                        receipt = w3.eth.wait_for_transaction_receipt(tx_hash, timeout=180)
                        request_id = int(governance.events.NetworkAnalysisRequested().process_receipt(receipt)[0]["args"]["requestId"])
                        record_ui_receipt(
                            receipt,
                            actor_label="Focal Company",
                            action="Request Network/DLI analysis 2017",
                            request_id=request_id,
                            metadata={"request_scope": "network", "analysis_year": 2017, "governance_mode": "principal decision year"},
                        )
                        record = _wait_for(lambda: governance.functions.getNetworkRequest(request_id).call(), 3, 1200)
                        if int(record[3]) != 1:
                            raise RuntimeError(f"Network request status {record[3]}; CID {record[2]}")
                        st.success(f"2017 Network/DLI fulfilled by `{record[6]}`; CID `{record[2]}`.")
                    except Exception as exc:
                        st.error(str(exc))
                    else:
                        st.rerun()
            elif network_2017:
                st.success(f"2017 Network/DLI completed; CID `{network_2017.get('content_hash')}`")

            if network_2014 and network_2017:
                st.success(
                    "Temporal DLI evidence is ready. The Network & DLI page compares annual rankings "
                    "using one pooled two-year normalization for BC, PageRank, CDR and IC and one common "
                    "Pearson-CRITIC weight vector. Both annual scores and ranks come from that same pooled "
                    "evidence package. The next analytical stage is the 2017 "
                    "AURORA regional opportunity assessment."
                )
            elif network_2014:
                st.info(
                    "Complete 2017 Network/DLI to unlock temporal DLI and the AURORA regional assessment."
                )

            if network_2017:
                network_id = int(network_2017["request_id"])

                st.markdown("### Stage 11 — AURORA regional opportunity assessment")
                st.caption(
                    "AURORA uses the completed 2017 Network/DLI evidence and can run immediately after temporal DLI. "
                    "It does not depend on selecting, verifying, approving or rejecting an intervention."
                )
                if temporal_dli_complete:
                    if aurora_2017_complete:
                        st.success(
                            f"AURORA completed; CID `{active_aurora_2017.get('content_hash')}`"
                        )
                    else:
                        if active_aurora_2017:
                            st.warning(
                                "The stored AURORA result is not verified as bound to the active 2017 Network/DLI "
                                "evidence. Run a current assessment before final synthesis."
                            )
                        if st.button(
                            "Run AURORA regional opportunity assessment — 2017",
                            use_container_width=True,
                        ):
                            try:
                                tx = governance.functions.performRegionalSourcingOpportunityAnalysis(
                                    2017, network_id
                                ).transact({"from": accounts["focal_company"]})
                                receipt = w3.eth.wait_for_transaction_receipt(tx, timeout=180)
                                request_id = int(
                                    governance.events.RegionalSourcingOpportunityAnalysisRequested()
                                    .process_receipt(receipt)[0]["args"]["requestId"]
                                )
                                record_ui_receipt(
                                    receipt,
                                    actor_label="Focal Company",
                                    action="Request AURORA regional opportunity assessment 2017",
                                    request_id=request_id,
                                    metadata={
                                        "request_scope": "aurora",
                                        "analysis_year": 2017,
                                        "network_request_id": network_id,
                                        "intervention_governance_dependency": "none",
                                    },
                                )
                                record = _wait_for(
                                    lambda: governance.functions.getSourcingOpportunityRequest(request_id).call(),
                                    5,
                                    1200,
                                )
                                if int(record[5]) != 1:
                                    raise RuntimeError(
                                        f"AURORA request status {record[5]}; CID {record[4]}"
                                    )
                                st.success(
                                    f"AURORA fulfilled by `{record[8]}`; CID `{record[4]}`."
                                )
                            except Exception as exc:
                                st.error(str(exc))
                            else:
                                st.rerun()
                else:
                    st.info(
                        "AURORA becomes available as soon as both annual Network/DLI results form the temporal DLI evidence."
                    )

                st.markdown("### Stage 12 — Intervention evidence and formal governance")
                st.caption(
                    "The deterministic intervention register is bound to the active analytical evidence. Formal "
                    "selection, Oracle verification, approval and rejection are accountable stakeholder activities. "
                    "Final LLM decision support opens after this branch is resolved."
                )
                if not aurora_2017_complete:
                    st.info(
                        "Stage 12 formal governance follows the completed AURORA assessment. The evidence preview "
                        "below does not require an intervention decision before AURORA."
                    )
                elif intervention_governance_resolved:
                    if (
                        verified_no_governance_ready_intervention
                        and intervention_governance_evidence_verified
                    ):
                        st.success(
                            "Intervention governance is resolved with a verified no-option outcome: the complete "
                            "actionability review found no governance-ready intervention, so no on-chain selection is required."
                        )
                    else:
                        st.success(
                            "Intervention governance is resolved: every selected, Oracle-verified proposal has received "
                            "an approval or rejection decision."
                        )
                elif not intervention_governance_evidence_verified:
                    st.warning(
                        "Intervention governance is unresolved because its actionability evidence is missing, incomplete "
                        "or unverified. An empty option register alone is not a verified no-option outcome."
                    )
                elif governance_ready_option_count == 0:
                    st.warning(
                        "No governance-ready option is currently reported. Complete the Stage 12 intervention "
                        "evidence and actionability controls below; final decision support remains locked until "
                        "this governance branch is resolved."
                    )
                else:
                    st.info(
                        f"Intervention governance is unresolved: `{governance_ready_option_count}` governance-ready "
                        "option(s) are available for selection and formal decision."
                    )
                if intervention_governance_resolution_basis:
                    st.caption(
                        "Resolution basis: "
                        + intervention_governance_resolution_basis.replace("_", " ").replace("-", " ")
                    )

                # All mutable intervention-governance actions begin here on the
                # Blockchain control plane.  The sidebar workspace is a
                # read-only inspection, charting, provenance and download view.
                if aurora_2017_complete:
                    render_intervention_control_plane(deployment, ROOT_DIR)

                network_envelope = _extract_result(str(network_2017.get("content_hash", "")))
                network_material = network_envelope.get("payload", {}) if isinstance(network_envelope, dict) else {}
                network_payload = (
                    network_material.get("payload", {})
                    if isinstance(network_material, dict)
                    else {}
                )
                active_analytics_dir = ROOT_DIR / "runtime" / "active_analytics"
                u16_metadata = {}
                portfolio = []
                if aurora_2017_complete:
                    try:
                        u16_metadata = u16_governance.verify_intervention_governance_artifacts(
                            active_analytics_dir,
                            expected_input_hashes=deployment.get("active_input_hashes", {}),
                            expected_source_network_result_cid=str(network_2017.get("content_hash", "")),
                            expected_source_aurora_result_cid=str(
                                active_aurora_2017.get("content_hash", "")
                            ),
                        )
                        portfolio = pd.read_csv(
                            active_analytics_dir / u16_governance.GOVERNANCE_OPTIONS_FILENAME
                        ).to_dict(orient="records")
                    except FileNotFoundError:
                        pass
                    except Exception as exc:
                        st.error(f"Governance-ready option register could not be verified: {exc}")
                portfolio = [
                    row for row in portfolio
                    if isinstance(row, dict)
                    and str(row.get("governance_eligibility_status", ""))
                    == u16_governance.ELIGIBLE_STATUS
                    and str(row.get("option_cid", ""))
                ]
                proposal_requests = deployment.get("active_results", {}).get("intervention_requests", {}).get("2017", [])
                onchain_interventions = deployment.get("active_results", {}).get("interventions", {}).get("2017", [])
                request_by_option = {
                    (
                        str(row.get("node_code", "")).strip(),
                        str(row.get("option_cid", "")).strip().lower(),
                    ): row
                    for row in proposal_requests
                }
                intervention_by_request = {
                    int(row.get("proposal_request_id")): row
                    for row in onchain_interventions
                    if row.get("proposal_request_id") is not None
                }

                st.markdown("### Governance-ready 2017 intervention options")
                st.caption(
                    "Only node-level options that have positive hotspot linkage, a deterministic mechanism compatible "
                    "with the hotspot's node-wise SDA driver, documented focal-company actionability, and an explicit "
                    "quantified or accountable non-quantification scenario decision appear here. "
                    "Retired top-DLI rules are historical assurance material only; they are neither current analytical "
                    "authority nor eligible for on-chain proposal."
                )

                status_names = {0: "Requested / awaiting Oracle", 1: "Proposed on-chain", 2: "Verification failed"}
                decision_names = {0: "Proposed", 1: "Approved", 2: "Rejected"}
                portfolio_rows = []
                for row in portfolio:
                    node = str(row.get("node_code", "")).strip()
                    option_cid = str(row.get("option_cid", "")).strip().lower()
                    proposal = request_by_option.get((node, option_cid))
                    governed = intervention_by_request.get(int(proposal.get("proposal_request_id"))) if proposal else None
                    if governed:
                        governance_status = decision_names.get(int(governed.get("status", 0)), "Unknown")
                    elif proposal:
                        governance_status = status_names.get(int(proposal.get("status", 0)), "Unknown")
                    else:
                        governance_status = "Generated — not selected"
                    portfolio_rows.append(
                        {
                            "DLI rank": row.get("dli_rank"),
                            "node": node,
                            "DLI (0–1)": row.get("dli_score"),
                            "category": row.get("category"),
                            "recommended action": row.get("action"),
                            "channel": row.get("channel"),
                            "dominant driver": row.get("driven_by"),
                            "target hotspots": row.get("hotspot_targets"),
                            "intervention route": row.get("intervention_route"),
                            "abatement scenario": row.get("abatement_scenario_status"),
                            "conservative estimate (t CO2)": row.get("scenario_conservative_reduction_tco2"),
                            "expected estimate (t CO2)": row.get("scenario_expected_reduction_tco2"),
                            "ambitious estimate (t CO2)": row.get("scenario_ambitious_reduction_tco2"),
                            "option CID": row.get("option_cid"),
                            "governance status": governance_status,
                        }
                    )
                if portfolio_rows:
                    st.dataframe(pd.DataFrame(portfolio_rows), use_container_width=True, hide_index=True)
                elif (
                    verified_no_governance_ready_intervention
                    and intervention_governance_evidence_verified
                    and intervention_governance_resolved
                ):
                    st.success(
                        "The verified actionability evidence contains no governance-ready option. "
                        "This is a completed no-option governance outcome, not a missing portfolio."
                    )
                elif governance_ready_option_count > 0:
                    st.warning(
                        f"The lifecycle reports `{governance_ready_option_count}` governance-ready option(s), "
                        "but the verified register could not be displayed. Refresh the lifecycle before selecting."
                    )
                else:
                    st.warning(
                        "No governance-ready option is currently displayed, and a completed no-option outcome has "
                        "not been verified. Use the Stage 12 controls above to assess the relevant hotspot–leverage "
                        "pairs and generate the governed portfolio."
                    )

                already_requested = {
                    (
                        str(row.get("node_code", "")).strip(),
                        str(row.get("option_cid", "")).strip().lower(),
                    )
                    for row in proposal_requests
                    if int(row.get("status", 0)) in {0, 1}
                }
                available = [
                    row
                    for row in portfolio
                    if (
                        str(row.get("node_code", "")).strip(),
                        str(row.get("option_cid", "")).strip().lower(),
                    )
                    not in already_requested
                ]
                available.sort(
                    key=lambda row: (
                        int(row.get("portfolio_selection_step", 10**9)),
                        int(row.get("dli_rank", 10**9)),
                        str(row.get("node_code", "")),
                        str(row.get("mechanism_code", "")),
                    )
                )
                labels = {
                    (
                        f"#{int(row.get('dli_rank', 0))} {row.get('node_code')} — "
                        f"{row.get('category')} — {row.get('action')} "
                        f"[{str(row.get('option_cid', ''))[:12]}]"
                    ): row
                    for row in available
                }
                if labels:
                    st.markdown("#### Select and submit")
                    st.caption(
                        "The first available option in the deterministic governance-portfolio order is preselected. "
                        "Review its abatement status and estimates in the table before selection. One click records the "
                        "selection on-chain and submits the immutable evidence package to the Governance Oracle; "
                        "selection is not approval."
                    )
                    selection_actor = st.selectbox(
                        "Stakeholder making the formal selection",
                        ["Focal Company", "Regulatory Authority"],
                        key="intervention_selection_actor",
                    )
                    selected_label = st.selectbox(
                        "Governance-ready intervention",
                        list(labels),
                        key="selected_intervention_option",
                    )
                    if st.button(
                        "Select intervention and submit for verification",
                        use_container_width=True,
                        type="primary",
                        disabled=not selected_label or not aurora_2017_complete,
                    ):
                        sender = accounts["focal_company"] if selection_actor == "Focal Company" else accounts["regulator"]
                        try:
                            start_oracle("governance")
                            option = labels[selected_label]
                            tx = governance.functions.requestInterventionProposal(
                                network_id,
                                str(option["node_code"]),
                                str(option["option_cid"]),
                            ).transact({"from": sender})
                            receipt = w3.eth.wait_for_transaction_receipt(tx, timeout=180)
                            event = governance.events.InterventionProposalRequested().process_receipt(receipt)[0]
                            proposal_request_id = int(event["args"]["requestId"])
                            record_ui_receipt(
                                receipt,
                                actor_label=selection_actor,
                                action="Select and submit intervention",
                                request_id=proposal_request_id,
                                result_cid=str(option["option_cid"]),
                                metadata={
                                    "request_scope": "intervention_proposal",
                                    "network_request_id": network_id,
                                    "node_code": str(option["node_code"]),
                                    "dli_rank": int(option["dli_rank"]),
                                    "option_cid": str(option["option_cid"]),
                                    "workflow": "one_click_selection_then_human_decision",
                                },
                            )
                            proposal_record = _wait_for(
                                lambda rid=proposal_request_id: governance.functions.getInterventionProposalRequest(rid).call(),
                                8,
                                600,
                            )
                            if int(proposal_record[8]) != 1:
                                raise RuntimeError(
                                    f"Intervention proposal request {proposal_request_id} status {proposal_record[8]}; verification CID {proposal_record[5]}"
                                )
                        except Exception as exc:
                            st.error(str(exc))
                        else:
                            st.rerun()
                elif portfolio:
                    st.info(
                        "All currently generated intervention mechanisms have been selected for formal governance. "
                        "AURORA does not close this portfolio; any newly verified option can still be selected later."
                    )
                elif (
                    verified_no_governance_ready_intervention
                    and intervention_governance_evidence_verified
                    and intervention_governance_resolved
                ):
                    st.success(
                        "No intervention selection is required because the complete actionability review produced "
                        "a verified no-governance-ready-option outcome."
                    )
                else:
                    st.info(
                        "No intervention is selectable yet. Complete and verify the actionability review after AURORA; "
                        "final decision support remains locked until an intervention is decided or a complete "
                        "verified review establishes a no-option outcome."
                    )

                st.markdown("### Selected on-chain intervention proposals")
                portfolio_by_option = {
                    (
                        str(row.get("node_code", "")).strip(),
                        str(row.get("option_cid", "")).strip().lower(),
                    ): row
                    for row in portfolio
                }
                if not proposal_requests:
                    if (
                        verified_no_governance_ready_intervention
                        and intervention_governance_evidence_verified
                        and intervention_governance_resolved
                    ):
                        st.success(
                            "No on-chain proposal is required for the verified no-option governance outcome."
                        )
                    elif portfolio:
                        st.info(
                            "No intervention has yet been selected. Select a governance-ready option above, wait for "
                            "Governance Oracle verification, and record an approval or rejection to resolve Stage 12."
                        )
                    else:
                        st.warning(
                            "No intervention has been selected and the actionability review has not established a "
                            "verified no-option outcome. Final LLM decision support remains locked."
                        )
                for proposal in sorted(proposal_requests, key=lambda item: int(item.get("proposal_request_id", 0))):
                    proposal_id = int(proposal.get("proposal_request_id", 0))
                    node = str(proposal.get("node_code", "")).strip()
                    option = portfolio_by_option.get(
                        (node, str(proposal.get("option_cid", "")).strip().lower()),
                        {},
                    )
                    with st.container(border=True):
                        c1, c2, c3 = st.columns([3, 1, 1])
                        c1.markdown(
                            f"**Request {proposal_id}: {node} — {option.get('category', 'Intervention')}**"
                        )
                        c2.metric("DLI rank", option.get("dli_rank", "—"))
                        c3.metric("DLI (0–1)", f"{float(option.get('dli_score', 0.0)):.3f}" if option else "—")
                        if option:
                            st.write(option.get("action", ""))
                            st.caption(
                                f"Channel: {option.get('channel')} | Dominant driver: {option.get('driven_by')} | "
                                f"Selected by: {proposal.get('requester')}"
                            )
                            s1, s2, s3, s4 = st.columns(4)
                            scenario_status = _clean_display_text(
                                option.get("abatement_scenario_status"), "Not quantified"
                            )
                            s1.metric("Scenario status", scenario_status)
                            s2.metric("Conservative", _format_estimate(option.get("scenario_conservative_reduction_tco2")))
                            s3.metric("Expected", _format_estimate(option.get("scenario_expected_reduction_tco2")))
                            s4.metric("Ambitious", _format_estimate(option.get("scenario_ambitious_reduction_tco2")))
                            scenario_summary = _clean_display_text(
                                option.get("scenario_assumption_summary")
                            )
                            if scenario_summary:
                                st.caption(f"Scenario assumptions: {scenario_summary}")
                            else:
                                st.caption("Scenario assumptions: No assumptions recorded.")
                            if scenario_status == "Documented unquantified":
                                st.warning(
                                    "This proposal contains an accountable decision to proceed without a numerical "
                                    "pre-decision reduction estimate. Approval will preserve that limitation on-chain."
                                )
                            st.caption(
                                "These values are pre-decision comparative estimates. They are not structural coverage, "
                                "guaranteed abatement, or post-deployment observed reductions."
                            )
                        request_status = int(proposal.get("status", 0))
                        if request_status == 0:
                            st.warning("Awaiting Governance Oracle verification and proposal fulfilment.")
                            continue
                        if request_status == 2:
                            st.error(f"Oracle verification failed; error CID `{proposal.get('verification_cid')}`")
                            continue
                        governed = intervention_by_request.get(proposal_id)
                        if not governed:
                            st.warning("The request is fulfilled but the local lifecycle index has not yet loaded its intervention record. Refresh the page.")
                            continue
                        decision_status = int(governed.get("status", 0))
                        st.caption(
                            f"Hotspot ID `{governed.get('hotspot_id')}` | Intervention ID `{governed.get('intervention_id')}` | "
                            f"Status `{decision_names.get(decision_status, 'Unknown')}` | Verification CID `{proposal.get('verification_cid')}`"
                        )
                        if decision_status == 0:
                            st.info(
                                "This option has passed the governed eligibility checks. Before deciding, the named "
                                "authority remains responsible for reviewing the supporting actionability, feasibility, "
                                "and documentary evidence."
                            )
                            authority = st.selectbox(
                                "Decision authority",
                                ["Focal Company", "Regulatory Authority"],
                                key=f"decision_authority_{governed.get('intervention_id')}",
                            )
                            evidence_reviewed = st.checkbox(
                                "I have reviewed the intervention mechanism, feasibility evidence, abatement "
                                "status, numerical range (when quantified), assumptions and claim boundary.",
                                key=f"decision_evidence_reviewed_{governed.get('intervention_id')}",
                            )
                            decision_sender = accounts["focal_company"] if authority == "Focal Company" else accounts["regulator"]
                            a, b = st.columns(2)
                            if a.button(
                                "Approve and record on-chain",
                                use_container_width=True,
                                type="primary",
                                disabled=not evidence_reviewed,
                                key=f"approve_intervention_{governed.get('intervention_id')}",
                            ):
                                try:
                                    tx = governance.functions.decideIntervention(
                                        int(governed["intervention_id"]), True
                                    ).transact({"from": decision_sender})
                                    receipt = w3.eth.wait_for_transaction_receipt(tx, timeout=180)
                                    record_ui_receipt(
                                        receipt,
                                        actor_label=authority,
                                        action="Approve and record intervention",
                                        request_id=proposal_id,
                                        record_id=int(governed["intervention_id"]),
                                        metadata={
                                            "request_scope": "intervention_proposal",
                                            "decision": "Approved",
                                            "node_code": node,
                                            "intervention_id": int(governed["intervention_id"]),
                                            "workflow": "one_click_human_approval",
                                        },
                                    )
                                except Exception as exc:
                                    st.error(f"Approval transaction failed: {exc}")
                                else:
                                    st.rerun()
                            if b.button(
                                "Reject and record on-chain",
                                use_container_width=True,
                                disabled=not evidence_reviewed,
                                key=f"reject_intervention_{governed.get('intervention_id')}",
                            ):
                                try:
                                    tx = governance.functions.decideIntervention(
                                        int(governed["intervention_id"]), False
                                    ).transact({"from": decision_sender})
                                    receipt = w3.eth.wait_for_transaction_receipt(tx, timeout=180)
                                    record_ui_receipt(
                                        receipt,
                                        actor_label=authority,
                                        action="Reject and record intervention",
                                        request_id=proposal_id,
                                        record_id=int(governed["intervention_id"]),
                                        metadata={
                                            "request_scope": "intervention_proposal",
                                            "decision": "Rejected",
                                            "node_code": node,
                                            "intervention_id": int(governed["intervention_id"]),
                                            "workflow": "one_click_human_rejection",
                                        },
                                    )
                                except Exception as exc:
                                    st.error(f"Rejection transaction failed: {exc}")
                                else:
                                    st.rerun()
                        else:
                            decision = decision_names.get(decision_status, "Unknown")
                            st.markdown("#### Final intervention decision support")
                            if decision_status == 1:
                                st.success(
                                    "Approved: proceed to implementation planning, assign monitored indicators, and "
                                    "retain evidence for post-deployment comparison."
                                )
                            else:
                                st.error(
                                    "Rejected: do not treat the scenario estimate as an authorized target. Review the "
                                    "recorded evidence, constraints, or an alternative hotspot–leverage mechanism."
                                )
                            st.write(
                                f"**Decision:** {decision}  \n"
                                f"**Target hotspot(s):** {option.get('hotspot_targets', 'Not recorded')}  \n"
                                f"**Dominant driver:** {option.get('driven_by', 'Not recorded')}  \n"
                                f"**Governed action:** {option.get('action', 'Not recorded')}"
                            )
                            st.write(
                                f"**Pre-decision expected reduction:** "
                                f"{_format_estimate(option.get('scenario_expected_reduction_tco2'))} "
                                f"(range {_format_estimate(option.get('scenario_conservative_reduction_tco2'))} to "
                                f"{_format_estimate(option.get('scenario_ambitious_reduction_tco2'))})."
                            )
                            st.caption(
                                "The decision and immutable option CID preserve the analytical evidence and scenario "
                                "assumptions reviewed at approval. Actual reduction remains unreported until monitored "
                                "post-deployment evidence is submitted."
                            )
                            performance_cids = list(governed.get("performance_evidence_cids", []) or [])
                            if performance_cids:
                                st.markdown("**Recorded post-deployment monitoring evidence**")
                                for observation_index, evidence_cid in enumerate(performance_cids, start=1):
                                    st.code(
                                        f"Observation {observation_index}: {evidence_cid}",
                                        language="text",
                                    )
                            if decision_status == 1:
                                baseline_value = float(
                                    option.get("target_baseline_hotspot_footprint_tco2", 0.0) or 0.0
                                )
                                with st.form(
                                    f"performance_form_{governed.get('intervention_id')}",
                                    clear_on_submit=False,
                                ):
                                    st.markdown("##### Record post-deployment observed performance")
                                    st.caption(
                                        f"Governed baseline for the target hotspot set: {baseline_value:,.6f} t CO2. "
                                        "Submit only a like-for-like monitored footprint supported by named evidence."
                                    )
                                    observed_footprint = st.number_input(
                                        "Observed hotspot footprint (t CO2)",
                                        min_value=0.0,
                                        value=baseline_value,
                                        step=0.001,
                                        key=f"observed_footprint_{governed.get('intervention_id')}",
                                    )
                                    period_start = st.date_input(
                                        "Monitoring period start",
                                        key=f"monitoring_start_{governed.get('intervention_id')}",
                                    )
                                    period_end = st.date_input(
                                        "Monitoring period end",
                                        key=f"monitoring_end_{governed.get('intervention_id')}",
                                    )
                                    monitor_name = st.text_input(
                                        "Monitoring assessor name",
                                        key=f"monitor_name_{governed.get('intervention_id')}",
                                    )
                                    monitor_role = st.text_input(
                                        "Monitoring assessor role",
                                        key=f"monitor_role_{governed.get('intervention_id')}",
                                    )
                                    monitor_reference = st.text_input(
                                        "Monitoring evidence reference",
                                        key=f"monitor_reference_{governed.get('intervention_id')}",
                                    )
                                    monitor_notes = st.text_area(
                                        "Monitoring notes and comparability limitations",
                                        key=f"monitor_notes_{governed.get('intervention_id')}",
                                    )
                                    monitor_actor = st.selectbox(
                                        "Account anchoring this monitoring record",
                                        ["Focal Company", "Regulatory Authority"],
                                        key=f"monitor_actor_{governed.get('intervention_id')}",
                                    )
                                    submit_monitoring = st.form_submit_button(
                                        "Verify evidence and record observed performance on-chain",
                                        use_container_width=True,
                                    )
                                if submit_monitoring:
                                    try:
                                        result = OrchestratorClient().record_intervention_performance(
                                            str(network_2017.get("content_hash", "")),
                                            str(option.get("option_cid", "")),
                                            int(governed["intervention_id"]),
                                            {
                                                "observed_hotspot_footprint_tco2": float(observed_footprint),
                                                "monitoring_period_start": str(period_start),
                                                "monitoring_period_end": str(period_end),
                                                "assessor_name": monitor_name,
                                                "assessor_role": monitor_role,
                                                "evidence_reference": monitor_reference,
                                                "monitoring_notes": monitor_notes,
                                            },
                                            request_context={
                                                "source": "blockchain_post_deployment_monitoring",
                                                "intervention_id": int(governed["intervention_id"]),
                                            },
                                        )
                                        payload = result.get("payload", {}) if isinstance(result, dict) else {}
                                        performance_cid = str(payload.get("performance_evidence_cid", ""))
                                        if len(performance_cid) != 64:
                                            raise RuntimeError("The Orchestrator did not return a valid performance evidence CID")
                                        monitor_sender = (
                                            accounts["focal_company"]
                                            if monitor_actor == "Focal Company"
                                            else accounts["regulator"]
                                        )
                                        tx = governance.functions.recordInterventionPerformance(
                                            int(governed["intervention_id"]), performance_cid
                                        ).transact({"from": monitor_sender})
                                        receipt = w3.eth.wait_for_transaction_receipt(tx, timeout=180)
                                        record_ui_receipt(
                                            receipt,
                                            actor_label=monitor_actor,
                                            action="Record observed intervention performance",
                                            record_id=int(governed["intervention_id"]),
                                            result_cid=performance_cid,
                                            metadata={
                                                "request_scope": "intervention_performance",
                                                "option_cid": str(option.get("option_cid", "")),
                                                "observed_hotspot_footprint_tco2": float(observed_footprint),
                                            },
                                        )
                                    except Exception as exc:
                                        st.error(f"Performance evidence was not recorded: {exc}")
                                    else:
                                        st.rerun()

                selected_count = int(lifecycle.get("selected_intervention_count", 0))
                proposed_count = int(lifecycle.get("proposed_intervention_count", 0))
                decided_count = int(lifecycle.get("decided_intervention_count", 0))
                st.caption(
                    f"Formal governance portfolio: selected `{selected_count}`, Oracle-verified/proposed `{proposed_count}`, "
                    f"approved or rejected `{decided_count}`."
                )

    # 13. Query deployment ------------------------------------------------------
    with st.expander(
        "Stage 13 — Final synthesis: deploy QueryManagement from StrategicCarbonIntelligenceSystem.sol",
        expanded=query_management_prerequisites_complete
        and not lifecycle.get("query_deployed", False),
    ):
        st.caption(
            "The LLM/Query layer follows the verified analytical sequence and opens only after intervention governance "
            "has reached an on-chain approval/rejection decision or a verified no-option outcome."
        )
        if not query_management_prerequisites_complete:
            missing_prerequisites = []
            if not temporal_dli_complete:
                missing_prerequisites.append("temporal Network/DLI evidence")
            if not aurora_2017_complete:
                missing_prerequisites.append("active 2017 AURORA result")
            if not intervention_governance_resolved:
                missing_prerequisites.append("resolved intervention governance decision or verified no-option outcome")
            st.info(
                "Final synthesis is locked. Complete: "
                + "; ".join(missing_prerequisites)
                + "."
            )
        else:
            st.write(f"**Authorized deployer:** Focal Company `{accounts['focal_company']}`")
            if not lifecycle.get("query_deployed"):
                if st.button("Deploy Query Management contract", use_container_width=True):
                    try:
                        updated = deploy_functional_contract(deployment_path, "QueryManagement")
                        st.session_state["last_transaction_record"] = updated.get("deployment_receipts", {}).get("QueryManagement", {})
                        start_oracle("query")
                        time.sleep(2)
                    except Exception as exc:
                        st.error(str(exc))
                    else:
                        st.rerun()
            else:
                receipt_summary("QueryManagement", "Focal Company")

    # 14. Query lifecycle -------------------------------------------------------
    query = contract("QueryManagement")
    with st.expander(
        "Stage 14 — Submit strategic/general/hybrid queries on-chain",
        expanded=lifecycle.get("query_deployed", False)
        and query_management_prerequisites_complete,
    ):
        if not lifecycle.get("query_deployed") or query is None:
            st.info("Locked until the QueryManagement contract is deployed.")
        elif not query_management_prerequisites_complete:
            st.warning(
                "Query submission is paused because the active analytical evidence no longer satisfies the current "
                "runtime gate. Restore current temporal Network/DLI and AURORA evidence, then resolve Stage 12 "
                "intervention governance for the current validated inputs. The "
                "deployed contract and historical query records remain available for audit."
            )
        else:
            status, age, _ = _heartbeat_state(runtime_dir / "oracle_query_heartbeat.json")
            if status != "running":
                if st.button("Start Query Oracle", use_container_width=True):
                    start_oracle("query")
                    time.sleep(2)
                    st.rerun()
            else:
                st.success(f"Query Oracle running; heartbeat age {age}s.")

            st.markdown("### Submit a new on-chain query")
            question = st.text_area(
                "Question",
                value="Which node should management prioritize for decarbonization and why?",
                height=100,
                key="blockchain_query_text",
            )
            mode_label = st.selectbox(
                "Assistant mode",
                ["Auto", "Research only", "General chat"],
                key="blockchain_query_mode",
            )
            mode = {"Auto": 0, "Research only": 1, "General chat": 2}[mode_label]
            if st.button("Submit query on-chain", use_container_width=True):
                if not str(question).strip():
                    st.error("Enter a non-empty question.")
                else:
                    try:
                        tx = query.functions.submitQuery(
                            str(question).strip(),
                            "streamlit-conversation",
                            mode,
                        ).transact({"from": accounts["focal_company"]})
                        receipt = w3.eth.wait_for_transaction_receipt(tx, timeout=180)
                        request_id = int(
                            query.events.QueryRequested().process_receipt(receipt)[0]["args"]["requestId"]
                        )
                        record_ui_receipt(
                            receipt,
                            actor_label="Focal Company",
                            action="Submit blockchain query",
                            request_id=request_id,
                            metadata={
                                "assistant_mode": mode_label,
                                "conversation_reference": "streamlit-conversation",
                                "query_text_preview": str(question)[:240],
                            },
                        )
                        st.info(
                            f"Query request `{request_id}` was mined. Waiting for the Query Oracle and Data Orchestrator..."
                        )
                        record = _wait_for(
                            lambda: query.functions.getQuery(request_id).call(),
                            5,
                            1200,
                        )
                        st.session_state["query_request_inspector"] = request_id
                        if int(record[5]) == 0:
                            st.warning(
                                "The wait period ended while the query was still pending. The request remains on-chain; "
                                "use the query-history selector below to refresh it."
                            )
                        elif int(record[5]) == 1:
                            st.success(
                                f"Query `{request_id}` fulfilled by `{record[10]}`; result CID `{record[6]}`."
                            )
                        else:
                            st.error(
                                f"Query `{request_id}` failed; error CID `{record[7]}`."
                            )
                    except Exception as exc:
                        st.error(str(exc))
                    else:
                        st.rerun()

            next_query_id = int(query.functions.nextRequestId().call())
            if next_query_id > 0:
                st.divider()
                st.markdown("### On-chain query history and complete results")
                query_ids = list(range(next_query_id - 1, -1, -1))
                history_rows = []
                for query_id in query_ids[:50]:
                    item = query.functions.getQuery(query_id).call()
                    status_code = int(item[5])
                    mode_code = int(item[3])
                    route_code = int(item[4])
                    history_rows.append(
                        {
                            "request ID": query_id,
                            "status": {0: "Pending", 1: "Fulfilled", 2: "Failed"}.get(status_code, status_code),
                            "mode": {0: "Auto", 1: "Research only", 2: "General chat"}.get(mode_code, mode_code),
                            "route": {0: "Unclassified", 1: "Direct", 2: "Compute", 3: "Retrieval", 4: "Composite"}.get(route_code, route_code),
                            "question": str(item[1])[:140],
                            "result/error CID": str(item[6] or item[7]),
                            "fulfilled by": str(item[10]),
                        }
                    )
                st.dataframe(
                    pd.DataFrame(history_rows),
                    use_container_width=True,
                    hide_index=True,
                )

                selected_default = st.session_state.get("query_request_inspector", query_ids[0])
                if selected_default not in query_ids:
                    selected_default = query_ids[0]
                    st.session_state["query_request_inspector"] = selected_default
                selected_index = query_ids.index(selected_default)
                selected_query_id = st.selectbox(
                    "Inspect query request",
                    query_ids,
                    index=selected_index,
                    key="query_request_inspector",
                    format_func=lambda value: f"Request {value}",
                )
                if st.button("Refresh selected query result", use_container_width=True):
                    st.rerun()
                selected_record = query.functions.getQuery(int(selected_query_id)).call()
                render_query_result(
                    request_id=int(selected_query_id),
                    record=selected_record,
                    deployment_path=deployment_path,
                    root_dir=ROOT_DIR,
                    orchestrator_url=os.getenv(
                        "ORCHESTRATOR_URL",
                        "http://127.0.0.1:8765",
                    ),
                )
            else:
                st.info("No on-chain query has been submitted yet.")

    # Runtime status and event history -----------------------------------------
    st.divider()
    status_tab, timeline_tab, transaction_tab = st.tabs(
        ["Oracle and stakeholder status", "Event timeline", "Blockchain Audit & Transaction Explorer"]
    )
    with status_tab:
        rows = []
        for key, spec in deployment["oracle_roles"].items():
            actual = int(reg.functions.roleOf(spec["address"]).call()) if reg else 0
            status, age, heartbeat = _heartbeat_state(runtime_dir / f"oracle_{key}_heartbeat.json")
            rows.append(
                {
                    "oracle": spec["role_name"],
                    "Ethereum address": spec["address"],
                    "on-chain role": ROLE_NAMES.get(actual, str(actual)),
                    "process": status,
                    "heartbeat age (s)": age,
                    "handled events": heartbeat.get("handled_total", 0),
                }
            )
        st.dataframe(pd.DataFrame(rows), use_container_width=True, hide_index=True)
        if reg is not None:
            stakeholder_rows = []
            for key, label, code in [
                ("regulator", "Regulatory Authority", 1),
                ("mrio_provider", "MRIO Data Provider", 2),
                ("focal_company", "Focal Company", 3),
            ]:
                stakeholder_rows.append(
                    {
                        "stakeholder": label,
                        "Ethereum address": accounts[key],
                        "expected role": ROLE_NAMES[code],
                        "actual role": ROLE_NAMES.get(int(reg.functions.roleOf(accounts[key]).call()), "None"),
                    }
                )
            st.dataframe(pd.DataFrame(stakeholder_rows), use_container_width=True, hide_index=True)

    with timeline_tab:
        event_specs = []
        if reg is not None:
            event_specs.append((reg, "Registration", ["OracleRoleAssigned", "RegistrationRequested", "RegistrationVerified", "EntityRegistered", "EntityRevoked"]))
        if upstream is not None:
            event_specs.append((upstream, "Upstream", [
                "MRIODataUpdateRequested", "FocalCompanyDemandDataUpdateRequested", "DataUpdateValidated", "FocalDemandInvalidated",
                "MRIOCarbonAccountingRequested", "MRIOCarbonAccountingComputed",
                "StructuralPathAnalysisRequested", "StructuralPathAnalysisCompleted",
                "StructuralDecompositionAnalysisRequested", "StructuralDecompositionAnalysisPerformed", "ComputeFailed",
            ]))
        if governance is not None:
            event_specs.append((governance, "Governance", [
                "NetworkAnalysisRequested", "NetworkAnalysisCompleted", "NetworkAnalysisFailed",
                "HotspotRegistered", "InterventionProposed", "InterventionDecided",
                "RegionalSourcingOpportunityAnalysisRequested", "RegionalSourcingOpportunityAnalysisCompleted", "RegionalSourcingOpportunityAnalysisFailed",
            ]))
        if query is not None:
            event_specs.append((query, "Query", ["QueryRequested", "QueryFulfilled", "QueryFailed"]))
        rows = []
        from_block = int(deployment.get("deployment_block") or deployment.get("bootstrap_block") or 0)
        for contract_obj, label, names in event_specs:
            for event_name in names:
                try:
                    logs = getattr(contract_obj.events, event_name)().get_logs(fromBlock=from_block, toBlock="latest")
                except Exception:
                    continue
                for log in logs:
                    rows.append(
                        {
                            "block": int(log["blockNumber"]),
                            "log": int(log["logIndex"]),
                            "contract": label,
                            "event": event_name,
                            "transaction": log["transactionHash"].hex(),
                            "details": ", ".join(f"{key}={value}" for key, value in dict(log["args"]).items())[:500],
                        }
                    )
        if rows:
            st.dataframe(pd.DataFrame(rows).sort_values(["block", "log"]), use_container_width=True, hide_index=True)
        else:
            st.info("No matching events have been emitted yet.")

    with transaction_tab:
        render_transaction_explorer(w3, deployment_path)
