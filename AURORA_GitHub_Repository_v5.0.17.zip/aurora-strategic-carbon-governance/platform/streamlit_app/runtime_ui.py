"""Read current content-addressed analytical results for Streamlit pages."""
from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any

import pandas as pd

APP_DIR = Path(__file__).resolve().parent
ROOT_DIR = APP_DIR.parent
CONTENT_STORE = ROOT_DIR / "content_store"


def load_content(content_hash: str) -> dict[str, Any]:
    value = str(content_hash or "").strip().lower()
    if len(value) != 64:
        raise ValueError("A 64-character SHA-256 content identifier is required.")
    for candidate in (CONTENT_STORE / f"{value}.json", CONTENT_STORE / value):
        if candidate.is_file():
            body = candidate.read_bytes()
            if hashlib.sha256(body).hexdigest() != value:
                raise ValueError(f"Content hash verification failed for {candidate}")
            return json.loads(body.decode("utf-8"))
    raise FileNotFoundError(f"No result package exists for CID {value}")


def material(content_hash: str) -> dict[str, Any]:
    envelope = load_content(content_hash)
    value = envelope.get("payload", {})
    return value if isinstance(value, dict) else {}


def payload(content_hash: str) -> dict[str, Any]:
    value = material(content_hash).get("payload", {})
    return value if isinstance(value, dict) else {}


def auxiliary(content_hash: str) -> dict[str, Any]:
    value = material(content_hash).get("auxiliary", {})
    return value if isinstance(value, dict) else {}


def result_cid(state: dict[str, Any], kind: str, key: str | int) -> str:
    group = state.get("active_results", {}).get(kind, {})
    item = group.get(str(key), {}) if isinstance(group, dict) else {}
    return str(item.get("content_hash", "")) if isinstance(item, dict) else ""


def result_payload(state: dict[str, Any], kind: str, key: str | int) -> dict[str, Any]:
    cid = result_cid(state, kind, key)
    if not cid:
        raise KeyError(f"No active {kind} result exists for {key}")
    return payload(cid)


def result_auxiliary(state: dict[str, Any], kind: str, key: str | int) -> dict[str, Any]:
    cid = result_cid(state, kind, key)
    if not cid:
        raise KeyError(f"No active {kind} result exists for {key}")
    return auxiliary(cid)


def years(state: dict[str, Any], kind: str) -> list[int]:
    group = state.get("active_results", {}).get(kind, {})
    values = []
    if isinstance(group, dict):
        for key in group:
            try:
                values.append(int(key))
            except (TypeError, ValueError):
                continue
    return sorted(set(values))


def mrio_frame(state: dict[str, Any], year: int, *, all_nodes: bool = False) -> pd.DataFrame:
    data = result_payload(state, "mrio", year)
    rows = data.get("all_hotspots" if all_nodes else "hotspots", [])
    return pd.DataFrame(rows)


def spa_frame(state: dict[str, Any], year: int) -> pd.DataFrame:
    data = result_payload(state, "spa", year)
    return pd.DataFrame(data.get("paths", data.get("top_paths", [])))


def dli_frame(state: dict[str, Any], year: int) -> pd.DataFrame:
    data = result_payload(state, "network", year)
    return pd.DataFrame(data.get("dli_ranking", []))


def interventions_frame(state: dict[str, Any], year: int) -> pd.DataFrame:
    data = result_payload(state, "network", year)
    return pd.DataFrame(data.get("interventions", []))


def aurora_payload(state: dict[str, Any], year: int) -> dict[str, Any]:
    return result_payload(state, "aurora", year)
