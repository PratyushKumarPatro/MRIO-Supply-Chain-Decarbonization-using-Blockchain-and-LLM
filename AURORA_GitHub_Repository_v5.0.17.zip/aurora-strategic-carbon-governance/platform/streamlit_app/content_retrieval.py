"""Retrieve content-addressed result packages for the Streamlit client.

The blockchain stores only a SHA-256 content identifier.  The canonical
result package is owned by the off-chain Data Orchestrator, so the primary
retrieval path is its ``/v1/content/get`` API.  A local-file fallback is kept
for resilience and backwards compatibility with earlier single-host builds.
"""
from __future__ import annotations

import hashlib
import json
import re
import time
import urllib.error
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable

_SHA256_RE = re.compile(r"^[0-9a-fA-F]{64}$")


class ContentRetrievalError(RuntimeError):
    """Raised when a content package cannot be retrieved or decoded."""


@dataclass(frozen=True)
class RetrievedContent:
    content_hash: str
    content: dict[str, Any]
    source: str
    checked_paths: tuple[str, ...] = ()
    remote_error: str = ""


def _validate_hash(content_hash: str) -> str:
    normalized = str(content_hash or "").strip()
    if not _SHA256_RE.fullmatch(normalized):
        raise ContentRetrievalError(
            "The on-chain result identifier is not a valid 64-character SHA-256 hash."
        )
    return normalized.lower()


def _canonical_content_hash(content: dict[str, Any]) -> str:
    body = json.dumps(
        content,
        indent=2,
        sort_keys=True,
        ensure_ascii=False,
        allow_nan=False,
        default=str,
    ).encode("utf-8")
    return hashlib.sha256(body).hexdigest()


def _post_json(url: str, payload: dict[str, Any], timeout: float) -> dict[str, Any]:
    body = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=body,
        headers={"Accept": "application/json", "Content-Type": "application/json"},
        method="POST",
    )
    with urllib.request.urlopen(request, timeout=timeout) as response:
        raw = response.read().decode("utf-8")
    parsed = json.loads(raw)
    if not isinstance(parsed, dict):
        raise ContentRetrievalError("The Data Orchestrator returned a non-object JSON response.")
    return parsed


def _remote_retrieve(
    content_hash: str,
    orchestrator_url: str,
    timeout: float,
    retries: int,
    retry_delay: float,
) -> dict[str, Any]:
    endpoint = orchestrator_url.rstrip("/") + "/v1/content/get"
    last_error = ""
    for attempt in range(max(1, retries)):
        try:
            response = _post_json(
                endpoint,
                {"content_hash": content_hash},
                timeout=timeout,
            )
            if response.get("ok") is not True:
                raise ContentRetrievalError(
                    str(response.get("error", "Data Orchestrator content retrieval failed."))
                )
            result = response.get("result")
            if not isinstance(result, dict):
                raise ContentRetrievalError(
                    "The Data Orchestrator response did not contain a result object."
                )
            returned_hash = str(result.get("content_hash", "")).strip().lower()
            if returned_hash and returned_hash != content_hash:
                raise ContentRetrievalError(
                    "The Data Orchestrator returned content for a different hash."
                )
            content = result.get("content")
            if not isinstance(content, dict):
                raise ContentRetrievalError(
                    "The Data Orchestrator response did not contain a JSON content package."
                )
            if _canonical_content_hash(content) != content_hash:
                raise ContentRetrievalError(
                    "The retrieved content does not match the on-chain SHA-256 result identifier."
                )
            return content
        except urllib.error.HTTPError as exc:
            detail = exc.read().decode("utf-8", errors="replace")
            last_error = f"HTTP {exc.code}: {detail}"
        except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as exc:
            last_error = str(exc)
        except ContentRetrievalError as exc:
            last_error = str(exc)
        if attempt + 1 < max(1, retries):
            time.sleep(max(0.0, retry_delay))
    raise ContentRetrievalError(last_error or "Unknown Data Orchestrator retrieval failure.")


def candidate_content_paths(
    content_hash: str,
    roots: Iterable[str | Path],
) -> tuple[Path, ...]:
    """Return de-duplicated local fallback paths for a valid content hash."""
    normalized = _validate_hash(content_hash)
    candidates: list[Path] = []
    seen: set[str] = set()
    for root in roots:
        if root is None:
            continue
        base = Path(root).expanduser().resolve(strict=False)
        for candidate in (
            base / "content_store" / f"{normalized}.json",
            base / "content_store" / normalized,
            base / "results" / f"{normalized}.json",
        ):
            key = str(candidate).casefold()
            if key not in seen:
                seen.add(key)
                candidates.append(candidate)
    return tuple(candidates)


def retrieve_content(
    content_hash: str,
    *,
    orchestrator_url: str | None,
    roots: Iterable[str | Path] = (),
    timeout: float = 8.0,
    retries: int = 4,
    retry_delay: float = 0.5,
) -> RetrievedContent:
    """Retrieve a result package through the orchestrator, then local fallback.

    The remote API is authoritative because it owns the content store.  Local
    fallback makes the single-host research deployment tolerant of a temporary
    HTTP issue and supports historical packages that wrote directly to disk.
    """
    normalized = _validate_hash(content_hash)
    remote_error = ""

    if orchestrator_url:
        try:
            content = _remote_retrieve(
                normalized,
                orchestrator_url,
                timeout=timeout,
                retries=retries,
                retry_delay=retry_delay,
            )
            return RetrievedContent(
                content_hash=normalized,
                content=content,
                source=f"Data Orchestrator API ({orchestrator_url.rstrip('/')})",
            )
        except ContentRetrievalError as exc:
            remote_error = str(exc)

    paths = candidate_content_paths(normalized, roots)
    local_errors: list[str] = []
    for candidate in paths:
        if not candidate.is_file():
            continue
        try:
            raw = candidate.read_bytes()
            if hashlib.sha256(raw).hexdigest() != normalized:
                local_errors.append(f"{candidate}: file SHA-256 does not match the on-chain CID")
                continue
            content = json.loads(raw.decode("utf-8"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            local_errors.append(f"{candidate}: {exc}")
            continue
        if not isinstance(content, dict):
            local_errors.append(f"{candidate}: JSON root is not an object")
            continue
        return RetrievedContent(
            content_hash=normalized,
            content=content,
            source=f"local fallback ({candidate})",
            checked_paths=tuple(str(path) for path in paths),
            remote_error=remote_error,
        )

    details: list[str] = []
    if remote_error:
        details.append(f"Data Orchestrator API: {remote_error}")
    if local_errors:
        details.append("Local decode errors: " + " | ".join(local_errors))
    if paths:
        details.append("Local paths checked: " + " | ".join(str(path) for path in paths))
    raise ContentRetrievalError(
        "The on-chain result hash is valid, but its content package could not be retrieved. "
        + (" ".join(details) if details else "No retrieval locations were configured.")
    )


def extract_assistant_result(content: dict[str, Any]) -> dict[str, Any]:
    """Extract the assistant result from current and historical envelopes."""
    if not isinstance(content, dict):
        return {}

    # Current canonical envelope:
    # envelope.payload -> material.payload -> assistant_result
    current = content.get("payload")
    if isinstance(current, dict):
        material_payload = current.get("payload")
        if isinstance(material_payload, dict):
            assistant = material_payload.get("assistant_result")
            if isinstance(assistant, dict):
                return assistant
        assistant = current.get("assistant_result")
        if isinstance(assistant, dict):
            return assistant

    assistant = content.get("assistant_result")
    if isinstance(assistant, dict):
        return assistant

    # Some API callers may pass the /v1/content/get result wrapper directly.
    wrapped = content.get("content")
    if isinstance(wrapped, dict):
        return extract_assistant_result(wrapped)

    # Backwards-compatible store_result() payloads put answer/route at the root.
    if isinstance(content.get("answer"), str):
        return content
    return {}


def extract_answer(content: dict[str, Any]) -> str:
    assistant = extract_assistant_result(content)
    answer = assistant.get("answer") if isinstance(assistant, dict) else None
    return str(answer).strip() if answer is not None else ""
