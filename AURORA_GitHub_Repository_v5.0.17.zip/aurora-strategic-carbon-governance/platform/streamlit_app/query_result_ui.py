"""Streamlit rendering for content-addressed on-chain query results.

The QueryManagement contract stores only request metadata, route/status, and a
SHA-256 result identifier.  This module retrieves the canonical off-chain
package, verifies its hash, extracts the assistant answer, and exposes the full
routing, evidence, provenance, model and blockchain transaction trail.
"""
from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st

from content_retrieval import (
    ContentRetrievalError,
    extract_answer,
    extract_assistant_result,
    retrieve_content,
)
from transaction_inspector import find_audit_records
from transaction_ui import render_transaction_details

MODE_NAMES = {0: "Auto", 1: "Research only", 2: "General chat"}
ROUTE_NAMES = {
    0: "Unclassified",
    1: "Direct / general",
    2: "Compute",
    3: "Retrieval",
    4: "Composite / hybrid",
}
STATUS_NAMES = {0: "Pending", 1: "Fulfilled", 2: "Failed"}


def _utc_timestamp(value: Any) -> str:
    try:
        stamp = int(value or 0)
    except (TypeError, ValueError):
        return ""
    if stamp <= 0:
        return ""
    return datetime.fromtimestamp(stamp, tz=timezone.utc).isoformat()


def _query_record(record: Any) -> dict[str, Any]:
    values = list(record or [])
    values += [None] * max(0, 11 - len(values))
    mode = int(values[3] or 0)
    route = int(values[4] or 0)
    status = int(values[5] or 0)
    return {
        "requester": str(values[0] or ""),
        "query_text": str(values[1] or ""),
        "data_reference_cid": str(values[2] or ""),
        "assistant_mode_code": mode,
        "assistant_mode": MODE_NAMES.get(mode, str(mode)),
        "route_code": route,
        "route": ROUTE_NAMES.get(route, str(route)),
        "status_code": status,
        "status": STATUS_NAMES.get(status, str(status)),
        "result_cid": str(values[6] or ""),
        "error_cid": str(values[7] or ""),
        "requested_at": int(values[8] or 0),
        "requested_at_utc": _utc_timestamp(values[8]),
        "fulfilled_at": int(values[9] or 0),
        "fulfilled_at_utc": _utc_timestamp(values[9]),
        "fulfilled_by": str(values[10] or ""),
    }


def _envelope_sections(content: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any], dict[str, Any]]:
    material = content.get("payload") if isinstance(content, dict) else {}
    if not isinstance(material, dict):
        material = {}
    query_payload = material.get("payload")
    if not isinstance(query_payload, dict):
        query_payload = {}
    assistant = extract_assistant_result(content)
    return material, query_payload, assistant


def _query_transactions(deployment_path: str | Path, request_id: int) -> list[dict[str, Any]]:
    records = find_audit_records(deployment_path, request_id=request_id)
    filtered: list[dict[str, Any]] = []
    for item in records:
        call = item.get("decoded_call") if isinstance(item.get("decoded_call"), dict) else {}
        events = item.get("events") if isinstance(item.get("events"), list) else []
        if str(call.get("contract", "")) == "QueryManagement" or any(
            str(event.get("contract", "")) == "QueryManagement" for event in events if isinstance(event, dict)
        ):
            filtered.append(item)
    filtered.sort(
        key=lambda item: (
            int(item.get("block_number") or 0),
            int(item.get("transaction_index") or 0),
        )
    )
    return filtered


def render_query_result(
    *,
    request_id: int,
    record: Any,
    deployment_path: str | Path,
    root_dir: str | Path,
    orchestrator_url: str,
) -> None:
    """Render one QueryManagement record and its verified result package."""

    query = _query_record(record)
    st.markdown(f"### Audited Query Request `{request_id}`")

    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Status", query["status"])
    c2.metric("Requested mode", query["assistant_mode"])
    c3.metric("Blockchain route", query["route"])
    c4.metric("Request ID", request_id)

    st.markdown(f"**Question:** {query['query_text']}")
    st.caption(
        f"Requester `{query['requester']}` | conversation/data reference `{query['data_reference_cid']}` | "
        f"requested `{query['requested_at_utc'] or query['requested_at']}`"
    )

    if query["status_code"] == 0:
        st.info("The query is pending. Refresh after the Query Oracle completes the request.")
        return

    content_hash = query["result_cid"] if query["status_code"] == 1 else query["error_cid"]
    if query["status_code"] == 2:
        st.error(f"The Query Oracle recorded a failure. Error CID: `{content_hash}`")

    try:
        retrieved = retrieve_content(
            content_hash,
            orchestrator_url=orchestrator_url,
            roots=[Path(root_dir)],
            timeout=15.0,
            retries=6,
            retry_delay=0.75,
        )
    except ContentRetrievalError as exc:
        st.error("The on-chain CID was recorded, but the corresponding content package could not be retrieved.")
        st.code(str(exc), language="text")
        st.markdown(f"**Recorded CID:** `{content_hash}`")
        st.caption(
            "The blockchain record remains valid. Check the Data Orchestrator and content_store, then use Refresh/retry. "
            "This error is now shown explicitly rather than being replaced by an empty JSON object."
        )
        return
    except Exception as exc:
        st.error(f"Unexpected query-result retrieval error: {exc}")
        return

    content = retrieved.content
    material, query_payload, assistant = _envelope_sections(content)
    answer = extract_answer(content)

    st.success(
        f"Content integrity verified against `{content_hash}`; retrieved from {retrieved.source}."
    )

    if query["status_code"] == 1:
        st.markdown("### Answer")
        if answer:
            st.markdown(answer)
        else:
            st.error(
                "The content package was retrieved and verified, but no assistant answer was found in the expected envelope. "
                "Inspect the complete package below."
            )

    answer_tab, process_tab, evidence_tab, chain_tab, raw_tab = st.tabs(
        [
            "Answer and route",
            "Processing details",
            "Evidence and provenance",
            "Blockchain transactions",
            "Complete result package",
        ]
    )

    with answer_tab:
        rows = [
            ("Request ID", request_id),
            ("On-chain status", query["status"]),
            ("Requested assistant mode", query["assistant_mode"]),
            ("On-chain route", query["route"]),
            ("Internal assistant route", assistant.get("route", "")),
            ("Internal blockchain route", assistant.get("blockchain_route", "")),
            ("Effective question", assistant.get("effective_question", query["query_text"])),
            ("Result CID", query["result_cid"]),
            ("Error CID", query["error_cid"]),
            ("Fulfilled by", query["fulfilled_by"]),
            ("Fulfilled at (UTC)", query["fulfilled_at_utc"]),
            ("Content namespace", content.get("namespace", "")),
            ("Content stored at (UTC)", content.get("stored_at_utc", "")),
            ("Orchestrator generated at (UTC)", material.get("generated_at_utc", "")),
            ("Retrieval source", retrieved.source),
        ]
        st.dataframe(
            pd.DataFrame([{"field": key, "value": value} for key, value in rows]),
            use_container_width=True,
            hide_index=True,
        )
        if assistant.get("research_answer") and assistant.get("general_answer"):
            with st.expander("Validated research answer only"):
                st.markdown(str(assistant.get("research_answer")))
            with st.expander("Broader local-model context only"):
                st.markdown(str(assistant.get("general_answer")))

    with process_tab:
        auxiliary = material.get("auxiliary") if isinstance(material.get("auxiliary"), dict) else {}
        request_context = material.get("request_context") if isinstance(material.get("request_context"), dict) else {}
        st.markdown("**Route/classification record**")
        st.json(
            {
                "requested_mode_on_chain": query["assistant_mode"],
                "route_on_chain": query["route"],
                "orchestrator_auxiliary": auxiliary,
                "assistant_requested_mode": assistant.get("requested_mode"),
                "assistant_route": assistant.get("route"),
                "assistant_blockchain_route": assistant.get("blockchain_route"),
                "effective_question": assistant.get("effective_question"),
            }
        )
        st.markdown("**Validated routing and response plan**")
        plan = assistant.get("plan")
        if isinstance(plan, dict) and plan:
            st.json(plan)
        else:
            st.info("No structured plan was stored for this route.")
        st.markdown("**Model/runtime metrics**")
        metrics = assistant.get("model_metrics")
        st.json(metrics if isinstance(metrics, dict) else {})
        st.markdown("**Structured conversation state**")
        state = assistant.get("state")
        st.json(state if isinstance(state, dict) else {})
        st.markdown("**Originating blockchain event context**")
        st.json(request_context)

    with evidence_tab:
        evidence = assistant.get("evidence")
        if isinstance(evidence, list) and evidence:
            st.caption(
                "Quantitative research claims come from deterministic evidence; system-level claims come from curated deployment evidence. The complete trace is shown below."
            )
            st.json(evidence)
        else:
            st.info("This route did not store a validated research or system-evidence list.")
        st.markdown("**Provenance and claim boundary**")
        provenance = assistant.get("provenance")
        st.json(provenance if isinstance(provenance, dict) else {})
        st.markdown("**Query package metadata**")
        st.json(
            {
                key: value
                for key, value in query_payload.items()
                if key != "assistant_result"
            }
        )

    with chain_tab:
        tx_records = _query_transactions(deployment_path, request_id)
        if not tx_records:
            st.info(
                "No local transaction-index entries were found for this request. The complete ledger record can still be loaded "
                "from the Blockchain Audit & Transaction Explorer using the transaction hash."
            )
        for index, tx_record in enumerate(tx_records, start=1):
            call = tx_record.get("decoded_call") if isinstance(tx_record.get("decoded_call"), dict) else {}
            title = (
                f"{index}. {tx_record.get('actor_label') or 'Blockchain actor'} — "
                f"{call.get('signature') or tx_record.get('action') or 'transaction'}"
            )
            render_transaction_details(tx_record, title=title, expanded=False)

        st.markdown("**On-chain QueryManagement record**")
        st.json(query)

    with raw_tab:
        st.json(content)
