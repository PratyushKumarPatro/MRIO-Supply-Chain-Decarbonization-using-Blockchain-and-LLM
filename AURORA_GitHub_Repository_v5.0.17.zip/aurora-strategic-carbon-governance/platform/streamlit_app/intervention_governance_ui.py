"""Read-only Intervention Governance evidence and results workspace."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd
import plotly.express as px
import streamlit as st

import intervention_governance as governance_method
from plot_style import style_plotly_axes
import runtime_ui as rui


def _load_verified(state: dict[str, Any], root_dir: str):
    active_dir = Path(root_dir) / "runtime" / "active_analytics"
    network_cid = rui.result_cid(state, "network", 2017)
    aurora_cid = rui.result_cid(state, "aurora", 2017)
    if not network_cid or not aurora_cid:
        raise FileNotFoundError(
            "Complete the governed 2017 Network/DLI and AURORA stages on the Blockchain page first."
        )
    metadata = governance_method.verify_intervention_governance_artifacts(
        active_dir,
        expected_input_hashes=state.get("active_input_hashes", {}),
        expected_source_network_result_cid=network_cid,
        expected_source_aurora_result_cid=aurora_cid,
    )
    return active_dir, metadata, governance_method.load_intervention_governance_frames(active_dir)


def _portfolio_panel(frame: pd.DataFrame, summary: dict[str, Any]) -> None:
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Selected leverage nodes", f"{len(frame):,}")
    c2.metric(
        "Coverage of hotspot set",
        f"{float(summary.get('achieved_governance_supported_hotspot_coverage', 0.0)):.2%}",
    )
    c3.metric(
        "Coverage of company footprint",
        f"{float(summary.get('achieved_governance_supported_company_coverage', 0.0)):.2%}",
    )
    c4.metric("Target reached", "Yes" if summary.get("reached_target") else "No")
    st.caption(f"Stop reason: {summary.get('stop_reason', 'not recorded')}")
    if frame.empty:
        st.info("No leverage node currently meets the complete governed evidence threshold.")
        return
    st.dataframe(frame, use_container_width=True, hide_index=True)
    required = {
        "governance_supported_marginal_reduction_tco2",
        "intervention_node",
        "cumulative_governance_supported_hotspot_coverage",
    }
    if required.issubset(frame.columns):
        chart = px.bar(
            frame,
            x="governance_supported_marginal_reduction_tco2",
            y="intervention_node",
            orientation="h",
            text="cumulative_governance_supported_hotspot_coverage",
            title="Structural contribution of governance-ready leverage nodes",
        )
        chart.update_layout(yaxis={"autorange": "reversed"})
        chart.update_traces(texttemplate="%{text:.1%}", textposition="outside")
        style_plotly_axes(chart)
        st.plotly_chart(chart, use_container_width=True)


def render_intervention_governance_workspace(
    state: dict[str, Any],
    root_dir: str,
    *,
    show_title: bool = True,
) -> None:
    """Render verified results without exposing any state-changing control."""

    if show_title:
        st.title("Integrated Intervention Governance")
    st.info(
        "Read-only results workspace. Compute intervention evidence, select the candidate pair, "
        "record actionability and feasibility, generate options, submit the proposal, decide it, "
        "and record post-deployment performance from Stage 12 on the Blockchain page."
    )
    try:
        active_dir, metadata, frames = _load_verified(state, root_dir)
    except FileNotFoundError as exc:
        st.warning(str(exc))
        return
    except Exception as exc:
        st.error(f"Intervention-governance evidence could not be verified: {exc}")
        return

    st.caption(
        "This workspace verifies and explains the joined producer-hotspot, signed node/path SDA, "
        "CRITIC-DLI, producer-linkage, stakeholder evidence, scenario and portfolio results."
    )
    st.warning(
        "Structural coverage is not predicted abatement. Scenario values are assumption-bound estimates, "
        "and monitored values are separate post-deployment observations."
    )

    eligibility = frames["eligibility"]
    summary = metadata.get("portfolio_summary", {})
    c1, c2, c3, c4, c5 = st.columns(5)
    c1.metric("Candidate pairs", f"{int(metadata.get('candidate_pair_count', 0)):,}")
    c2.metric("Dominant hotspots", f"{int(metadata.get('hotspot_count', 0)):,}")
    c3.metric(
        "Governance-eligible pairs",
        f"{int(metadata.get('eligibility_status_counts', {}).get(governance_method.ELIGIBLE_STATUS, 0)):,}",
    )
    c4.metric("Governance options", f"{int(metadata.get('governance_ready_option_count', 0)):,}")
    c5.metric(
        "Hotspot share of company",
        f"{float(metadata.get('hotspot_share_of_company_footprint', 0.0)):.2%}",
    )

    evidence_tab, actionability_tab, scenario_tab, portfolio_tab, options_tab, downloads_tab = st.tabs(
        [
            "Integrated pair evidence",
            "Recorded actionability evidence",
            "Abatement scenarios",
            "Governance-ready portfolio",
            "Formal options",
            "Downloads and provenance",
        ]
    )

    with evidence_tab:
        status = eligibility.copy()
        statuses = sorted(
            status.get("governance_eligibility_status", pd.Series(dtype=str))
            .dropna().astype(str).unique()
        )
        selected_statuses = st.multiselect(
            "Filter by governance status",
            statuses,
            default=[],
            key="intervention_results_status_filter",
        )
        if selected_statuses:
            status = status.loc[
                status["governance_eligibility_status"].astype(str).isin(selected_statuses)
            ]
        display_columns = [
            column for column in [
                "candidate_id", "intervention_node", "hotspot_producer_node",
                "intervention_route", "intervention_DLI", "intervention_dli_rank",
                "baseline_hotspot_footprint_tco2", "avoided_hotspot_footprint_tco2",
                "hotspot_reduction_fraction", "hotspot_primary_adverse_driver",
                "hotspot_primary_adverse_effect_tco2", "hotspot_primary_beneficial_driver",
                "mechanism_code", "mechanism_mapping_status", "represented_path_link_status",
                "represented_path_primary_adverse_driver", "assessment_status",
                "governance_eligibility_status",
            ] if column in status.columns
        ]
        st.dataframe(status[display_columns], use_container_width=True, hide_index=True)
        if not eligibility.empty and "governance_eligibility_status" in eligibility.columns:
            counts = (
                eligibility["governance_eligibility_status"].value_counts()
                .rename_axis("status").reset_index(name="candidate pairs")
            )
            figure = px.bar(
                counts,
                x="candidate pairs",
                y="status",
                orientation="h",
                title="Intervention-governance funnel status",
            )
            style_plotly_axes(figure)
            st.plotly_chart(figure, use_container_width=True)

    with actionability_tab:
        st.caption(
            "These tables reproduce the stakeholder-provided evidence accepted by the control plane; "
            "they do not independently authenticate the free-text assessor identity."
        )
        st.markdown("#### Node-level governance evidence")
        st.dataframe(frames["node_actionability"], use_container_width=True, hide_index=True)
        st.markdown("#### Pair/mechanism feasibility evidence")
        st.dataframe(frames["pair_feasibility"], use_container_width=True, hide_index=True)

    with scenario_tab:
        scenario_columns = [
            column for column in [
                "intervention_node", "hotspot_producer_node", "mechanism_code",
                "baseline_hotspot_footprint_tco2", "avoided_hotspot_footprint_tco2",
                "scenario_addressable_footprint_tco2", "scenario_status",
                "scenario_quantification_decision", "scenario_non_quantification_reason",
                "scenario_conservative_reduction_tco2", "scenario_expected_reduction_tco2",
                "scenario_ambitious_reduction_tco2", "scenario_implementation_coverage_fraction",
                "scenario_adoption_fraction", "scenario_confidence",
                "scenario_evidence_reference", "scenario_claim_boundary",
            ] if column in eligibility.columns
        ]
        quantified = eligibility.loc[
            eligibility.get(
                "scenario_status", pd.Series(index=eligibility.index, dtype=str)
            ).eq("Quantified scenario")
        ].copy()
        documented_unquantified = eligibility.loc[
            eligibility.get(
                "scenario_status", pd.Series(index=eligibility.index, dtype=str)
            ).eq("Documented unquantified")
        ].copy()
        if quantified.empty:
            st.info("No intervention-specific abatement scenario has been quantified.")
        else:
            q1, q2, q3 = st.columns(3)
            q1.metric("Quantified hotspot pairs", f"{len(quantified):,}")
            q2.metric(
                "Expected reduction",
                f"{quantified['scenario_expected_reduction_tco2'].sum():,.6f} t CO2",
            )
            q3.metric(
                "Ambitious-bound reduction",
                f"{quantified['scenario_ambitious_reduction_tco2'].sum():,.6f} t CO2",
            )
            long = quantified.melt(
                id_vars=["hotspot_producer_node"],
                value_vars=[
                    "scenario_conservative_reduction_tco2",
                    "scenario_expected_reduction_tco2",
                    "scenario_ambitious_reduction_tco2",
                ],
                var_name="scenario",
                value_name="estimated reduction (t CO2)",
            )
            figure = px.bar(
                long,
                x="estimated reduction (t CO2)",
                y="hotspot_producer_node",
                color="scenario",
                barmode="group",
                orientation="h",
                title="Evidence-backed intervention-abatement ranges by producer hotspot",
            )
            style_plotly_axes(figure)
            st.plotly_chart(figure, use_container_width=True)
        if not documented_unquantified.empty:
            st.warning(
                f"{len(documented_unquantified):,} hotspot pair(s) have an accountable documented "
                "non-quantification decision. Their reasons and evidence references are shown below; "
                "no numerical reduction is inferred."
            )
        if scenario_columns:
            st.dataframe(eligibility[scenario_columns], use_container_width=True, hide_index=True)

    with portfolio_tab:
        _portfolio_panel(frames["governance_ready"], summary)
        st.caption(
            "Candidates failing a gate are excluded and the remaining eligible nodes are recomputed. "
            "DLI is a deterministic tie-break for equal marginal structural effects."
        )

    with options_tab:
        options = frames["governance_options"]
        if options.empty:
            st.info("No governance-ready formal option is currently recorded.")
        else:
            st.dataframe(options, use_container_width=True, hide_index=True)

    with downloads_tab:
        files = [
            (governance_method.PAIR_CANDIDATES_FILENAME, "Integrated pair candidates", "text/csv"),
            (governance_method.ACTIONABILITY_FILENAME, "Complete assessment register", "text/csv"),
            (governance_method.NODE_ACTIONABILITY_FILENAME, "Node-level actionability", "text/csv"),
            (governance_method.PAIR_FEASIBILITY_FILENAME, "Pair/mechanism feasibility", "text/csv"),
            (governance_method.ELIGIBILITY_FILENAME, "Eligibility register", "text/csv"),
            (governance_method.GOVERNANCE_PORTFOLIO_FILENAME, "Governance-ready portfolio", "text/csv"),
            (governance_method.GOVERNANCE_OPTIONS_FILENAME, "Governance-ready options", "text/csv"),
            (governance_method.WORKBOOK_FILENAME, "Complete governance workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
            (governance_method.METADATA_FILENAME, "Verified governance metadata", "application/json"),
        ]
        for filename, label, mime in files:
            path = active_dir / filename
            if path.is_file():
                st.download_button(
                    f"Download {label}",
                    path.read_bytes(),
                    file_name=filename,
                    mime=mime,
                    use_container_width=True,
                )
        with st.expander("Verified provenance, decision boundaries and coverage denominators"):
            st.json(metadata)


__all__ = ("render_intervention_governance_workspace",)
