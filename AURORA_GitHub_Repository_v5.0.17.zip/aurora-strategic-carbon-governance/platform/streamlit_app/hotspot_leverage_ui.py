"""Streamlit workspace for U16 route diagnostics and hotspot-leverage evidence."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
import plotly.express as px
import streamlit as st

import hotspot_leverage as hotspot_link
from plot_style import style_plotly_axes


@st.cache_data(show_spinner=False)
def _load_hotspot_leverage(active_dir_text: str, input_hashes_json: str):
    active_dir = Path(active_dir_text)
    input_hashes = json.loads(input_hashes_json) if input_hashes_json else None
    metadata = hotspot_link.verify_hotspot_leverage_artifacts(
        active_dir,
        expected_input_hashes=input_hashes,
    )
    frames = {
        "node_summary": pd.read_csv(active_dir / hotspot_link.NODE_SUMMARY_FILENAME),
        "pair_evidence": pd.read_csv(active_dir / hotspot_link.PAIR_EVIDENCE_FILENAME),
        "direct": pd.read_csv(active_dir / hotspot_link.DIRECT_PORTFOLIO_FILENAME),
        "governance_mediated": pd.read_csv(active_dir / hotspot_link.MEDIATED_PORTFOLIO_FILENAME),
        "hybrid": pd.read_csv(active_dir / hotspot_link.HYBRID_PORTFOLIO_FILENAME),
    }
    return metadata, frames


def _portfolio_panel(frame: pd.DataFrame, title: str, summary: dict[str, Any]) -> None:
    st.subheader(title)
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Selected nodes", f"{len(frame):,}")
    c2.metric("Hotspot-set structural coverage", f"{float(summary.get('achieved_hotspot_structural_coverage', 0.0)):.2%}")
    c3.metric("Complete-company structural coverage", f"{float(summary.get('achieved_company_structural_coverage', 0.0)):.2%}")
    c4.metric("Hotspot target reached", "Yes" if bool(summary.get("reached_target", False)) else "No")
    st.caption(str(summary.get("candidate_policy", "")))
    st.caption(f"Stop reason: {summary.get('stop_reason', 'not recorded')}")
    if frame.empty:
        st.info("No candidate in this route produced a positive marginal structural reduction under the joint counterfactual.")
        return
    st.dataframe(frame, use_container_width=True, hide_index=True)
    fig = px.bar(
        frame,
        x="marginal_hotspot_structural_reduction_tco2",
        y="intervention_node",
        orientation="h",
        text="cumulative_hotspot_structural_coverage",
        title=f"Exact marginal top-80% hotspot structural coverage: {title}",
    )
    fig.update_layout(yaxis={"autorange": "reversed"})
    fig.update_traces(texttemplate="%{text:.1%}", textposition="outside")
    style_plotly_axes(fig)
    st.plotly_chart(fig, use_container_width=True)


def render_hotspot_leverage_workspace(state: dict[str, Any], root_dir: str) -> None:
    active_dir = Path(root_dir) / "runtime" / "active_analytics"
    input_hashes = state.get("active_input_hashes", {}) if isinstance(state, dict) else {}
    try:
        metadata, frames = _load_hotspot_leverage(
            str(active_dir), json.dumps(input_hashes, sort_keys=True)
        )
    except FileNotFoundError:
        st.info(
            "Complete the governed 2014-2017 node-wise SDA, SPA for both years, Network 2014, and then Network 2017 to generate hotspot-leverage evidence."
        )
        return
    except Exception as exc:
        st.error(f"Hotspot-leverage evidence could not be verified: {exc}")
        return

    st.markdown("### Hotspot-leverage evidence and route diagnostics")
    st.caption(
        "DLI screens systemic leverage; producer-resolved CDR linkage checks whether that leverage connects to the "
        "comparison-year top-80% emissions hotspots. Exact joint marginal recomputation prevents double counting. "
        "These direct, mediated, and hybrid views are route diagnostics only; the single actionability-gated governance funnel is the formal portfolio authority. "
        "No new DLI-HSI composite score is created."
    )
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Top-80% hotspots", f"{int(metadata.get('hotspot_count', 0)):,}")
    c2.metric("Achieved hotspot-set share", f"{float(metadata.get('hotspot_share_of_company_footprint', 0.0)):.2%}")
    c3.metric("High-DLI threshold", f"{float(metadata.get('high_dli_threshold', 0.0)):.6f}")
    c4.metric("Portfolio target", f"{float(metadata.get('portfolio_target_hotspot_structural_coverage', 0.80)):.0%}")
    st.warning(
        "Structural coverage is based on complete node removal. It identifies strategic concentration and overlap; it is "
        "not predicted or guaranteed real-world abatement and does not establish feasibility. Focal-company actionability and realistic intervention magnitudes must be assessed separately."
    )

    summary_lookup = {
        str(row.get("portfolio")): row for row in metadata.get("portfolio_summaries", [])
    }
    overview_tab, direct_tab, mediated_tab, hybrid_tab, pair_tab, download_tab = st.tabs(
        [
            "Leverage-node overview",
            "Direct hotspot route diagnostic",
            "Governance-mediated route diagnostic",
            "Hybrid route diagnostic",
            "Node-to-hotspot evidence",
            "Downloads & provenance",
        ]
    )

    with overview_tab:
        summary = frames["node_summary"]
        display_columns = [
            column for column in [
                "hsi_rank", "intervention_node", "intervention_region", "intervention_sector",
                "DLI", "dli_rank", "is_high_dli_upper_quartile", "is_direct_hotspot_node",
                "hotspot_structural_influence_tco2", "hotspot_structural_influence_fraction",
                "affected_hotspot_count", "top_structurally_linked_hotspots", "intervention_route",
            ] if column in summary.columns
        ]
        st.dataframe(summary[display_columns], use_container_width=True, hide_index=True)
        top = summary.head(30)
        fig = px.scatter(
            top,
            x="DLI",
            y="hotspot_structural_influence_fraction",
            size="affected_hotspot_count",
            hover_name="intervention_node",
            symbol="is_direct_hotspot_node",
            title="Systemic leverage versus top-80% hotspot structural influence",
            labels={"hotspot_structural_influence_fraction": "Hotspot structural influence (fraction)"},
        )
        style_plotly_axes(fig)
        st.plotly_chart(fig, use_container_width=True)

    with direct_tab:
        _portfolio_panel(frames["direct"], "Direct hotspot route diagnostic", summary_lookup.get("direct", {}))

    with mediated_tab:
        _portfolio_panel(
            frames["governance_mediated"],
            "Governance-mediated route diagnostic",
            summary_lookup.get("governance_mediated", {}),
        )

    with hybrid_tab:
        _portfolio_panel(frames["hybrid"], "Hybrid route diagnostic", summary_lookup.get("hybrid", {}))

    with pair_tab:
        pair = frames["pair_evidence"]
        intervention_nodes = pair["intervention_node"].dropna().astype(str).drop_duplicates().tolist()
        hotspot_nodes = pair["hotspot_producer_node"].dropna().astype(str).drop_duplicates().tolist()
        c1, c2 = st.columns(2)
        selected_intervention = c1.selectbox("Leverage/intervention node", intervention_nodes, key="u16_pair_k")
        selected_hotspot = c2.selectbox("Producer hotspot", hotspot_nodes, key="u16_pair_j")
        selected = pair.loc[
            (pair["intervention_node"].astype(str) == selected_intervention)
            & (pair["hotspot_producer_node"].astype(str) == selected_hotspot)
        ]
        if not selected.empty:
            st.dataframe(selected, use_container_width=True, hide_index=True)
        st.markdown("#### All top-80% hotspots linked to the selected intervention node")
        linked = pair.loc[pair["intervention_node"].astype(str) == selected_intervention].sort_values(
            "avoided_hotspot_footprint_tco2", ascending=False
        )
        st.dataframe(linked, use_container_width=True, hide_index=True)

    with download_tab:
        downloads = [
            (hotspot_link.NODE_SUMMARY_FILENAME, "Download leverage-node summary", "text/csv"),
            (hotspot_link.PAIR_EVIDENCE_FILENAME, "Download node-to-hotspot evidence", "text/csv"),
            (hotspot_link.DIRECT_PORTFOLIO_FILENAME, "Download direct portfolio", "text/csv"),
            (hotspot_link.MEDIATED_PORTFOLIO_FILENAME, "Download governance-mediated portfolio", "text/csv"),
            (hotspot_link.HYBRID_PORTFOLIO_FILENAME, "Download hybrid portfolio", "text/csv"),
            (hotspot_link.WORKBOOK_FILENAME, "Download hotspot-leverage workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
            (hotspot_link.METADATA_FILENAME, "Download hotspot-leverage metadata", "application/json"),
        ]
        for filename, label, mime in downloads:
            path = active_dir / filename
            if path.is_file():
                st.download_button(label, path.read_bytes(), file_name=filename, mime=mime, use_container_width=True)
        with st.expander("Verified provenance and method boundaries"):
            st.json(metadata)
