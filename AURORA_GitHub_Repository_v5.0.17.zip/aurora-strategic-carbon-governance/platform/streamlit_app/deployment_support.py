"""Deployment discovery and validation helpers for the Streamlit blockchain page."""
from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Iterable

REQUIRED_CONTRACTS = {
    "Registration",
    "UpstreamCarbonEmissionsAnalysis",
    "HotspotsManagementAndGovernance",
    "QueryManagement",
}
REQUIRED_ACCOUNTS = {
    "registration_oracle",
    "upstream_oracle",
    "governance_oracle",
    "query_oracle",
    "regulator",
    "mrio_provider",
    "focal_company",
}


def candidate_paths(app_file: str | Path) -> list[Path]:
    app_path = Path(app_file).resolve()
    app_dir = app_path.parent
    root_dir = app_dir.parent
    candidates: list[Path] = []

    explicit = os.getenv("DEPLOYMENT_JSON", "").strip()
    if explicit:
        candidates.append(Path(explicit).expanduser())

    candidates.extend(
        [
            root_dir / "deployment.json",
            Path.cwd() / "deployment.json",
            app_dir / "deployment.json",
            Path.cwd().parent / "deployment.json",
        ]
    )

    unique: list[Path] = []
    seen: set[str] = set()
    for item in candidates:
        try:
            normalized = item.resolve(strict=False)
        except OSError:
            normalized = item.absolute()
        key = os.path.normcase(str(normalized))
        if key not in seen:
            seen.add(key)
            unique.append(normalized)
    return unique


def locate_deployment(app_file: str | Path) -> tuple[Path | None, list[Path]]:
    searched = candidate_paths(app_file)
    for path in searched:
        if path.is_file():
            return path, searched
    return None, searched


def load_and_validate_schema(path: Path, require_complete: bool = True) -> dict[str, Any]:
    try:
        deployment = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise ValueError(f"Cannot read deployment JSON at {path}: {exc}") from exc
    if not isinstance(deployment, dict):
        raise ValueError("deployment.json must contain one JSON object")

    contracts = deployment.get("contracts")
    if not isinstance(contracts, dict):
        raise ValueError("deployment.json has no contracts object")
    missing_contracts = sorted(REQUIRED_CONTRACTS.difference(contracts))
    if require_complete and missing_contracts:
        raise ValueError(f"deployment.json is missing contracts: {missing_contracts}")

    accounts = deployment.get("accounts")
    if not isinstance(accounts, dict):
        raise ValueError("deployment.json has no accounts object")
    missing_accounts = sorted(name for name in REQUIRED_ACCOUNTS if not accounts.get(name))
    if missing_accounts:
        raise ValueError(f"deployment.json is missing accounts: {missing_accounts}")

    if not deployment.get("rpc_url"):
        deployment["rpc_url"] = "http://127.0.0.1:8545"
    return deployment


def searched_paths_text(paths: Iterable[Path]) -> str:
    return "\n".join(str(path) for path in paths)
