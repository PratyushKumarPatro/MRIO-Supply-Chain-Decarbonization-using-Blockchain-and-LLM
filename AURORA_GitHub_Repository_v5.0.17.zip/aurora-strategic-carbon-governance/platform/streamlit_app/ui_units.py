"""Fixed, context-specific presentation units for the validated case study.

The operational data contract is deliberately mixed-scale but dimensionally
consistent:

* MRIO transactions, output, and economy-wide final demand: million USD;
* MRIO direct-emissions extension and economy-wide emissions: Mt CO2;
* focal-company demand: USD;
* focal-company footprint, hotspots, SPA, company SDA, interventions,
  scenarios, and AURORA carbon opportunities: t CO2.

Mt CO2 per million USD is numerically equivalent to t CO2 per USD.  The
analytical engine therefore uses the uploaded focal-company USD vector directly.
These constants are intentionally fixed for this release: environment variables
cannot silently relabel focal-company tonnes as million tonnes.  This module
changes presentation only and performs no numerical rescaling.
"""
from __future__ import annotations

MRIO_MONETARY_UNIT = "million USD"
MRIO_EMISSIONS_UNIT = "Mt CO₂"
FOCAL_DEMAND_UNIT = "USD"
FOCAL_EMISSIONS_UNIT = "t CO₂"
CARBON_INTENSITY_UNIT = "t CO₂/USD"
NORMALIZED_UNIT = "dimensionless (0–1)"
PERCENT_UNIT = "%"
UNIT_RELEASE_ID = "v5.0.17-U3"


def unit_convention_text() -> str:
    return (
        f"{UNIT_RELEASE_ID} unit contract: focal-company demand is in {FOCAL_DEMAND_UNIT} and focal-company carbon results are in {FOCAL_EMISSIONS_UNIT}; "
        f"MRIO transactions/output are in {MRIO_MONETARY_UNIT} and economy-wide emissions are in {MRIO_EMISSIONS_UNIT}. "
        f"Carbon intensity is {CARBON_INTENSITY_UNIT}. No numerical rescaling is applied."
    )
