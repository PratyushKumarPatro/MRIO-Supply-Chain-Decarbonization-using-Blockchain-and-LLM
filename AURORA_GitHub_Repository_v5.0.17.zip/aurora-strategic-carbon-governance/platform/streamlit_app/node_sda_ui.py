"""Streamlit workspace for authoritative U16 signed producer-node SDA."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import pandas as pd
import plotly.express as px
import streamlit as st

import node_sda_engine as node_sda
from plot_style import style_plotly_axes


@st.cache_data(show_spinner=False)
def _load_node_sda(active_dir_text: str, input_hashes_json: str):
    active_dir = Path(active_dir_text)
    input_hashes = json.loads(input_hashes_json) if input_hashes_json else None
    metadata = node_sda.verify_node_sda_artifacts(
        active_dir,
        expected_input_hashes=input_hashes,
    )
    all_nodes = pd.read_csv(active_dir / node_sda.ALL_NODES_FILENAME)
    hotspots = pd.read_csv(active_dir / node_sda.HOTSPOTS_FILENAME)
    return metadata, all_nodes, hotspots


def render_node_sda_workspace(state: dict[str, Any], root_dir: str) -> None:
    active_dir = Path(root_dir) / "runtime" / "active_analytics"
    input_hashes = state.get("active_input_hashes", {}) if isinstance(state, dict) else {}
    try:
        metadata, all_nodes, hotspots = _load_node_sda(
            str(active_dir), json.dumps(input_hashes, sort_keys=True)
        )
    except FileNotFoundError:
        st.info("Complete the governed 2014-2017 SDA request to generate producer-node SDA evidence.")
        return
    except Exception as exc:
        st.error(f"Node-wise SDA evidence could not be verified: {exc}")
        return

    st.markdown("### Producer-node temporal driver intelligence")
    st.caption(
        "Every producer-origin node is decomposed with the unchanged intensity, technology, composition and scale "
        "24-permutation average. The governed result retains all signed effects, distinguishes the largest adverse positive effect "
        "from the largest beneficial negative effect, and uses the adverse result only for downstream mechanism mapping. "
        "The top-80% set is a reporting and carbon-target set only; it does not restrict network-wide DLI."
    )
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Producer nodes", f"{int(metadata.get('node_count', len(all_nodes))):,}")
    c2.metric("2017 top-80% hotspots", f"{int(metadata.get('comparison_hotspot_count', len(hotspots))):,}")
    c3.metric("Achieved hotspot coverage", f"{float(metadata.get('comparison_hotspot_coverage', 0.0)):.2%}")
    c4.metric(
        "Maximum SDA reconciliation residual",
        f"{max(float(metadata.get('maximum_row_reconciliation_residual_tco2', 0.0)), float(metadata.get('maximum_column_reconciliation_residual_tco2', 0.0))):.3e} t CO2",
    )

    hotspot_tab, all_tab, reconciliation_tab, download_tab = st.tabs(
        ["Top-80% hotspot node SDA", "All producer nodes", "Reconciliation", "Downloads & provenance"]
    )
    effect_columns = [
        "node_delta_intensity",
        "node_delta_technology",
        "node_delta_composition",
        "node_delta_scale",
    ]

    with hotspot_tab:
        if hotspots.empty:
            st.warning("No comparison-year hotspot nodes were identified.")
        else:
            display = hotspots.copy()
            selected_columns = [
                column
                for column in [
                    "comparison_hotspot_rank", "node_code", "region", "sector",
                    "comparison_footprint_contribution_tco2", "comparison_share_of_company_footprint",
                    "node_footprint_change_tco2", *effect_columns, "node_dominant_driver",
                    "node_primary_adverse_driver", "node_primary_adverse_effect_tco2",
                    "node_secondary_adverse_drivers", "node_adverse_driver_concentration",
                    "node_primary_beneficial_driver", "node_primary_beneficial_effect_tco2",
                    "node_secondary_beneficial_drivers", "node_driver_pattern",
                    "node_dominant_driver_family", "node_temporal_status",
                    "node_has_offsetting_drivers", "node_sda_reconciliation_residual_tco2",
                ]
                if column in display.columns
            ]
            st.dataframe(display[selected_columns], use_container_width=True, hide_index=True)
            chart_data = display.head(25).melt(
                id_vars=["node_code"],
                value_vars=[column for column in effect_columns if column in display.columns],
                var_name="SDA effect",
                value_name="Contribution (t CO2)",
            )
            fig = px.bar(
                chart_data,
                x="Contribution (t CO2)",
                y="node_code",
                color="SDA effect",
                orientation="h",
                title="Signed node-wise SDA effects for leading 2017 producer hotspots",
            )
            fig.update_layout(yaxis={"autorange": "reversed"}, height=max(480, 24 * min(25, len(display))))
            style_plotly_axes(fig)
            st.plotly_chart(fig, use_container_width=True)
            st.info(
                "The dominant-driver label remains a descriptive largest-absolute-effect summary. Intervention priority follows "
                "the largest positive adverse effect, while negative beneficial effects are preserved or strengthened. All signed "
                "effects remain authoritative, especially where drivers offset one another."
            )

    with all_tab:
        query = st.text_input("Filter node code, region or sector", key="node_sda_filter").strip().lower()
        display = all_nodes
        if query:
            mask = (
                display["node_code"].astype(str).str.lower().str.contains(query, regex=False)
                | display["region"].astype(str).str.lower().str.contains(query, regex=False)
                | display["sector"].astype(str).str.lower().str.contains(query, regex=False)
            )
            display = display.loc[mask]
        st.dataframe(display, use_container_width=True, hide_index=True)

    with reconciliation_tab:
        company_rows = []
        for factor in node_sda.FACTOR_NAMES:
            company_rows.append(
                {
                    "effect": factor,
                    "sum of node effects (t CO2)": float(metadata.get(f"company_{factor}_effect_tco2", 0.0)),
                }
            )
        st.dataframe(pd.DataFrame(company_rows), use_container_width=True, hide_index=True)
        st.json(
            {
                "company_base_footprint_tco2": metadata.get("company_base_footprint_tco2"),
                "company_comparison_footprint_tco2": metadata.get("company_comparison_footprint_tco2"),
                "company_change_tco2": metadata.get("company_change_tco2"),
                "maximum_row_reconciliation_residual_tco2": metadata.get("maximum_row_reconciliation_residual_tco2"),
                "maximum_column_reconciliation_residual_tco2": metadata.get("maximum_column_reconciliation_residual_tco2"),
                "identity": metadata.get("identity"),
            }
        )

    with download_tab:
        for filename, label, mime in [
            (node_sda.ALL_NODES_FILENAME, "Download all producer-node SDA rows", "text/csv"),
            (node_sda.HOTSPOTS_FILENAME, "Download top-80% hotspot node SDA", "text/csv"),
            (node_sda.WORKBOOK_FILENAME, "Download node-wise SDA workbook", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"),
            (node_sda.METADATA_FILENAME, "Download node-wise SDA metadata", "application/json"),
        ]:
            path = active_dir / filename
            if path.is_file():
                st.download_button(label, path.read_bytes(), file_name=filename, mime=mime, use_container_width=True)
        with st.expander("Verified provenance and authority boundaries"):
            st.json(metadata)
