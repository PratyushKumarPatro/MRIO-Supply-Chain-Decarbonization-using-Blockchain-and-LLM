"""Streamlit rendering helpers for complete blockchain transaction details."""
from __future__ import annotations

from pathlib import Path
from typing import Any

import pandas as pd
import streamlit as st

from transaction_inspector import (
    load_audit_records,
    record_transaction,
)


def _short(value: Any, width: int = 12) -> str:
    text = str(value or "")
    if len(text) <= width * 2 + 3:
        return text
    return f"{text[:width]}...{text[-width:]}"


def _call_name(record: dict[str, Any]) -> str:
    call = record.get("decoded_call", {}) if isinstance(record, dict) else {}
    if not isinstance(call, dict):
        call = {}
    return str(call.get("signature") or call.get("function") or record.get("action") or "Transaction")


def render_transaction_details(
    record: dict[str, Any],
    *,
    title: str = "Complete transaction details",
    expanded: bool = False,
) -> None:
    if not isinstance(record, dict) or not record:
        return
    tx_hash = str(record.get("transaction_hash", ""))
    status = record.get("status")
    with st.expander(title, expanded=expanded):
        if status == 1:
            st.success("Transaction mined and execution completed successfully.")
        elif status == 0:
            st.error("Transaction was mined but reverted/failed.")
        else:
            st.warning(str(record.get("status_label", "Transaction inspection unavailable")))
            if record.get("inspection_error"):
                st.code(str(record["inspection_error"]))

        call = record.get("decoded_call", {}) if isinstance(record.get("decoded_call"), dict) else {}
        c1, c2, c3, c4 = st.columns(4)
        c1.metric("Block", record.get("block_number", ""))
        c2.metric("Gas used (gas units)", f"{int(record.get('gas_used') or 0):,}" if record.get("gas_used") is not None else "")
        utilization = record.get("gas_utilization_pct")
        c3.metric("Gas utilization", f"{float(utilization):.2f}%" if utilization is not None else "")
        fee = record.get("transaction_fee_eth")
        c4.metric("Reference implementation fee", f"{fee} ETH" if fee not in (None, "") else "")

        st.markdown(f"**Function/constructor:** `{call.get('signature') or call.get('function') or record.get('action', '')}`")
        st.markdown(f"**Actor:** {record.get('actor_label') or 'Unlabelled'}")
        st.code(
            "transaction hash  " + str(record.get("transaction_hash", "")) + "\n"
            "block hash        " + str(record.get("block_hash", "")) + "\n"
            "from              " + str(record.get("from", "")) + "\n"
            "to                " + str(record.get("to") or "Contract creation") + "\n"
            "created contract  " + str(record.get("created_contract_address", "")),
            language="text",
        )
        if record.get("request_id") is not None:
            st.markdown(f"**Event-derived request ID:** `{record.get('request_id')}`")
        if record.get("record_id") is not None:
            st.markdown(f"**Event-derived record ID:** `{record.get('record_id')}`")
        if record.get("result_cid"):
            st.markdown(f"**Result/evidence CID:** `{record.get('result_cid')}`")

        summary_tab, call_tab, events_tab, raw_tab = st.tabs(
            ["Summary", "Decoded call", "Events and logs", "Raw blockchain data"]
        )
        with summary_tab:
            rows = [
                ("Status", record.get("status_label", "")),
                ("Transaction hash", tx_hash),
                ("Block hash", record.get("block_hash", "")),
                ("Block number", record.get("block_number", "")),
                ("Transaction index", record.get("transaction_index", "")),
                ("Mined at (UTC)", record.get("block_timestamp_utc", "")),
                ("From", record.get("from", "")),
                ("To", record.get("to") or "Contract creation"),
                ("Created contract", record.get("created_contract_address", "")),
                ("Contract", call.get("contract", "")),
                ("Action", record.get("action", "")),
                ("Nonce", record.get("nonce", "")),
                ("Transaction type", record.get("transaction_type", "")),
                ("Value (ETH)", record.get("value_eth", "")),
                ("Gas limit (gas units)", record.get("gas_limit", "")),
                ("Gas used (gas units)", record.get("gas_used", "")),
                ("Cumulative gas used (gas units)", record.get("cumulative_gas_used", "")),
                ("Effective gas price (Wei)", record.get("effective_gas_price_wei", "")),
                ("Transaction fee (Wei)", record.get("transaction_fee_wei", "")),
                ("Transaction fee (ETH)", record.get("transaction_fee_eth", "")),
                ("Source process", record.get("source", "")),
            ]
            st.dataframe(
                pd.DataFrame([{"field": key, "value": value} for key, value in rows]),
                use_container_width=True,
                hide_index=True,
            )
        with call_tab:
            st.markdown(f"**Transaction type:** `{call.get('transaction_type', '')}`")
            st.markdown(f"**Contract:** `{call.get('contract', '')}`")
            st.markdown(f"**Contract address:** `{call.get('contract_address', '')}`")
            st.markdown(f"**Signature:** `{call.get('signature', '')}`")
            if call.get("decode_error"):
                st.warning(f"ABI decoding warning: {call.get('decode_error')}")
            st.markdown("**Decoded inputs**")
            st.json(call.get("inputs", {}))
        with events_tab:
            events = record.get("events", []) if isinstance(record.get("events"), list) else []
            if not events:
                st.info("No Solidity event logs were emitted by this transaction.")
            for index, event in enumerate(events, start=1):
                st.markdown(
                    f"**{index}. `{event.get('event', 'Unknown')}`** — "
                    f"contract `{event.get('contract', '')}`, log index `{event.get('log_index', '')}`"
                )
                if event.get("signature"):
                    st.caption(event.get("signature"))
                st.json(event.get("args", {}))
                with st.expander(f"Raw log {index}"):
                    st.json(event)
        with raw_tab:
            st.markdown("**Raw transaction**")
            st.json(record.get("raw_transaction", {}))
            st.markdown("**Raw receipt**")
            st.json(record.get("raw_receipt", {}))
            st.markdown("**Block header**")
            st.json(record.get("block_header", {}))
            if record.get("metadata"):
                st.markdown("**Application metadata**")
                st.json(record.get("metadata", {}))


def render_transaction_explorer(
    w3: Any,
    deployment_path: str | Path,
) -> None:
    st.subheader("Blockchain Audit & Transaction Explorer")
    st.caption(
        "The ledger is authoritative. This local index collects stakeholder and Oracle transaction receipts so they can be filtered and decoded quickly."
    )

    manual_hash = st.text_input(
        "Inspect any transaction hash",
        placeholder="0x...",
        key="manual_transaction_hash",
    )
    if st.button("Load transaction from Ganache", key="inspect_manual_transaction"):
        try:
            entry = record_transaction(
                w3,
                deployment_path,
                manual_hash.strip(),
                actor_label="Manual inspection",
                action="Manual transaction inspection",
                source="streamlit-manual",
            )
        except Exception as exc:
            st.error(str(exc))
        else:
            st.session_state["selected_transaction_hash"] = entry.get("transaction_hash", "")
            st.rerun()

    records = load_audit_records(deployment_path)
    if not records:
        st.info("No indexed transaction records are available yet. Complete a deployment or business transaction, or enter a transaction hash above.")
        return

    actors = sorted({str(item.get("actor_label", "")) for item in records if item.get("actor_label")})
    contracts = sorted(
        {
            str((item.get("decoded_call") or {}).get("contract", ""))
            for item in records
            if isinstance(item.get("decoded_call"), dict) and (item.get("decoded_call") or {}).get("contract")
        }
    )
    request_ids = sorted({int(item["request_id"]) for item in records if item.get("request_id") is not None})
    c1, c2, c3, c4 = st.columns(4)
    actor_filter = c1.selectbox("Actor", ["All"] + actors, key="tx_actor_filter")
    contract_filter = c2.selectbox("Contract", ["All"] + contracts, key="tx_contract_filter")
    status_filter = c3.selectbox("Status", ["All", "Success", "Failed/Reverted"], key="tx_status_filter")
    request_filter = c4.selectbox("Request ID", ["All"] + request_ids, key="tx_request_filter")

    filtered: list[dict[str, Any]] = []
    for item in records:
        call = item.get("decoded_call", {}) if isinstance(item.get("decoded_call"), dict) else {}
        if actor_filter != "All" and str(item.get("actor_label", "")) != actor_filter:
            continue
        if contract_filter != "All" and str(call.get("contract", "")) != contract_filter:
            continue
        if status_filter != "All" and str(item.get("status_label", "")) != status_filter:
            continue
        if request_filter != "All" and item.get("request_id") != request_filter:
            continue
        filtered.append(item)

    rows = []
    for item in filtered:
        call = item.get("decoded_call", {}) if isinstance(item.get("decoded_call"), dict) else {}
        rows.append(
            {
                "status": "Success" if item.get("status") == 1 else "Failed",
                "block": item.get("block_number"),
                "actor": item.get("actor_label"),
                "contract": call.get("contract"),
                "function": call.get("signature") or call.get("function") or item.get("action"),
                "request ID": item.get("request_id"),
                "request type": (item.get("metadata") or {}).get("request_scope", "") if isinstance(item.get("metadata"), dict) else "",
                "gas used (gas units)": item.get("gas_used"),
                "fee (ETH)": item.get("transaction_fee_eth"),
                "transaction": item.get("transaction_hash"),
            }
        )
    st.dataframe(
        pd.DataFrame(rows).sort_values(["block"], ascending=False) if rows else pd.DataFrame(),
        use_container_width=True,
        hide_index=True,
    )

    options = {
        f"Block {item.get('block_number')} | {item.get('actor_label') or 'Actor'} | {_call_name(item)} | {_short(item.get('transaction_hash'))}": item
        for item in reversed(filtered)
    }
    if not options:
        return
    labels = list(options)
    selected_hash = st.session_state.get("selected_transaction_hash", "")
    default_index = 0
    if selected_hash:
        for idx, label in enumerate(labels):
            if str(options[label].get("transaction_hash", "")).lower() == str(selected_hash).lower():
                default_index = idx
                break
    selected = st.selectbox("Select a transaction", labels, index=default_index, key="tx_record_selector")
    selected_record = options[selected]
    request_id = selected_record.get("request_id")
    selected_call = selected_record.get("decoded_call", {}) if isinstance(selected_record.get("decoded_call"), dict) else {}
    selected_contract = selected_call.get("contract")
    selected_metadata = selected_record.get("metadata", {}) if isinstance(selected_record.get("metadata"), dict) else {}
    selected_scope = str(selected_metadata.get("request_scope", ""))
    if request_id is not None:
        related = []
        for item in records:
            call = item.get("decoded_call", {}) if isinstance(item.get("decoded_call"), dict) else {}
            item_metadata = item.get("metadata", {}) if isinstance(item.get("metadata"), dict) else {}
            item_scope = str(item_metadata.get("request_scope", ""))
            same_scope = (not selected_scope and not item_scope) or item_scope == selected_scope
            if item.get("request_id") == request_id and call.get("contract") == selected_contract and same_scope:
                related.append(
                    {
                        "block": item.get("block_number"),
                        "actor": item.get("actor_label"),
                        "action": item.get("action"),
                        "source": item.get("source"),
                        "status": item.get("status_label"),
                        "gas used (gas units)": item.get("gas_used"),
                        "transaction": item.get("transaction_hash"),
                    }
                )
        if len(related) > 1:
            st.markdown(f"**Related request/fulfilment transactions for request `{request_id}`**")
            st.dataframe(
                pd.DataFrame(related).sort_values("block"),
                use_container_width=True,
                hide_index=True,
            )
    render_transaction_details(selected_record, title="Selected transaction details", expanded=True)
