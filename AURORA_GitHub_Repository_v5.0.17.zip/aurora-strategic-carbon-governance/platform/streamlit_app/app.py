"""Streamlit interface for the deterministic and blockchain deployment.

The dashboard provides stakeholder-controlled data onboarding, deterministic MRIO,
SPA, node/path SDA, network/DLI, producer linkage, optional direct-intensity
sensitivity, post-temporal-DLI AURORA, and subsequent intervention governance.
Operational MRIO and
focal-company demand workbooks are not bundled; they must be uploaded and
validated through the Governance & Audit Control workspace. The local LLM never
generates authoritative numerical or actionability results.

The Blockchain page is a stakeholder client: it submits requests and reads state,
but all oracle-only fulfilment, failure, hotspot-registration, and intervention-
proposal transactions are performed by role-specific ``oracle_service.py``
processes through the separate Data Orchestrator.
"""

import json
import os
import sys
from pathlib import Path

# Ensure the package root precedes ``streamlit_app`` on sys.path. U19 preserves
# one authoritative shared analytical core; UI files must never shadow it with
# stale copied modules.
APP_PATH = Path(__file__).resolve()
APP_DIR = str(APP_PATH.parent)
ROOT_DIR = str(APP_PATH.parent.parent)
DATA = os.path.join(APP_DIR, "data")
if ROOT_DIR in sys.path:
    sys.path.remove(ROOT_DIR)
sys.path.insert(0, ROOT_DIR)

import numpy as np
import pandas as pd
import plotly.graph_objects as go
import plotly.express as px
import streamlit as st

import analytics_engine as ae
import scenario_engine as sce
import sourcing_opportunity_engine as aurora
import network_engine as net
import aurora_reporting as aurora_report
import input_onboarding as onboarding
import runtime_ui as rui
from plot_style import style_plotly_axes
from cdr_linkage_ui import render_cdr_producer_linkage_workspace
from node_sda_ui import render_node_sda_workspace
from hotspot_leverage_ui import render_hotspot_leverage_workspace
from intervention_governance_ui import render_intervention_governance_workspace
from deployment_support import locate_deployment, load_and_validate_schema, searched_paths_text
from content_retrieval import ContentRetrievalError, extract_assistant_result, retrieve_content
from orchestrator_client import OrchestratorClient
from dapp_lifecycle import (
    assign_oracle_roles,
    available_sidebar_sections,
    deploy_functional_contract,
    deploy_registration,
    refresh_lifecycle,
    submit_stakeholder_registration,
)
from ui_units import (
    FOCAL_DEMAND_UNIT,
    FOCAL_EMISSIONS_UNIT,
    MRIO_MONETARY_UNIT,
    MRIO_EMISSIONS_UNIT,
    CARBON_INTENSITY_UNIT,
    NORMALIZED_UNIT,
    UNIT_RELEASE_ID,
    unit_convention_text,
)


@st.cache_resource
def load_mrio_year(year: int, mrio_hash: str, focal_demand_hash: str):
    """Load the active analytical inputs and cache by their validated hashes.

    The hash parameters deliberately participate in Streamlit's cache key so a
    newly promoted workbook can never reuse an MRIOYear object created from an
    earlier input version.
    """
    if not mrio_hash or not focal_demand_hash:
        raise RuntimeError("Both active input hashes are required before loading the MRIO model.")
    my = ae.load_year("input_mrio_completed.xlsx", year)
    Yc = ae.load_company_Y("Focal_Company_Demand_Converted.xlsx", year)
    return my, Yc


st.set_page_config(page_title="AURORA Platform", page_icon="🌐", layout="wide")

PLATFORM_NAME = "Strategic Carbon Intelligence & Governance Platform"


def _discover_progressive_state():
    deployment_path, searched = locate_deployment(__file__)
    if deployment_path is None:
        return None, {}, searched
    try:
        deployment = load_and_validate_schema(deployment_path, require_complete=False)
        from web3 import Web3
        w3 = Web3(Web3.HTTPProvider(deployment.get("rpc_url", "http://127.0.0.1:8545"), request_kwargs={"timeout": 3}))
        if not w3.is_connected():
            raise RuntimeError("The configured governed chain is unavailable")
        if int(deployment.get("chain_id", -1)) != int(w3.eth.chain_id):
            raise RuntimeError("The persisted deployment belongs to a different chain")
        deployment = refresh_lifecycle(deployment_path)
        return deployment_path, deployment, searched
    except Exception:
        # Fail closed when live-chain reconstruction is unavailable. Persisted
        # lifecycle flags are audit history, not authority to expose current
        # analytical workspaces after a chain, CID, or input-verification error.
        return deployment_path, {}, searched


UI_DEPLOYMENT_PATH, UI_STATE, UI_SEARCH_PATHS = _discover_progressive_state()
AVAILABLE_SECTIONS = available_sidebar_sections(UI_STATE) if UI_STATE else ["Governance & Audit Control"]
SIDEBAR_DISPLAY_LABELS = {
    "Governance & Audit Control": "Blockchain and LLM-based System",
}

st.sidebar.title("AURORA")
st.sidebar.caption("Auditable Upstream Reasoning Orchestration Resilience Architecture")
if st.session_state.get("main_section") not in AVAILABLE_SECTIONS:
    st.session_state["main_section"] = "Governance & Audit Control"
page = st.sidebar.radio(
    "Workspace",
    AVAILABLE_SECTIONS,
    key="main_section",
    format_func=lambda section: SIDEBAR_DISPLAY_LABELS.get(section, section),
)
st.sidebar.divider()
st.sidebar.caption(
    "Governed lifecycle: temporal Network/DLI → AURORA → intervention "
    "scenario and formal decision → final Query/LLM support"
)
st.sidebar.caption(unit_convention_text())
completed = max(0, len(AVAILABLE_SECTIONS) - 1)
st.sidebar.caption(
    f"Governance lifecycle: {completed} analytical or decision workspace(s) unlocked. "
    "Workspaces appear only after the corresponding on-chain request is fulfilled for the active validated inputs."
)


def _require_ui_state():
    if not UI_STATE:
        st.error("No active guided deployment state is available.")
        st.stop()
    return UI_STATE


def _network_dli_frame(state: dict, year: int) -> tuple[pd.DataFrame, str]:
    """Return the pooled slice after 2017, never a mixed temporal basis."""
    reference_year = int(year)
    network_years = set(rui.years(state, "network"))
    if 2017 in network_years:
        decision_payload = rui.result_payload(state, "network", 2017)
        authority = decision_payload.get("temporal_dli_authority", {})
        slices = decision_payload.get("authoritative_dli_slices", {})
        if (
            bool(decision_payload.get("pooled_critic_ready", False))
            and isinstance(authority, dict)
            and authority.get("method") == "one pooled two-year Pearson-CRITIC calculation"
            and authority.get("years") == [2014, 2017]
            and isinstance(slices, dict)
            and isinstance(slices.get(str(reference_year)), list)
            and bool(slices.get(str(reference_year)))
        ):
            return (
                pd.DataFrame(slices[str(reference_year)]),
                "authoritative pooled 2014–2017 Pearson-CRITIC",
            )
        raise RuntimeError(
            "The fulfilled 2017 Network result lacks a complete authoritative pooled DLI pair."
        )
    if reference_year in network_years:
        payload = rui.result_payload(state, "network", reference_year)
        return pd.DataFrame(payload.get("dli_ranking", [])), "annual provisional CRITIC"
    return pd.DataFrame(), "unavailable"


def _select_available_year(kind: str, key: str, default: int = 2017) -> int:
    years = rui.years(_require_ui_state(), kind)
    if not years:
        st.error(f"No active {kind} result is available.")
        st.stop()
    index = years.index(default) if default in years else len(years) - 1
    return int(st.radio("Year", years, index=index, horizontal=True, key=key))

# ----------------------------------------------------------------- Overview
if page == "Carbon Footprint Intelligence":
    state = _require_ui_state()
    p14 = rui.result_payload(state, "mrio", 2014)
    p17 = rui.result_payload(state, "mrio", 2017)
    st.title("Focal-Company Carbon Footprint Intelligence")
    st.caption(
        "Results shown here are retrieved from the current content-addressed MRIO packages. "
        "They correspond to the active MRIO and focal-company demand workbooks validated on-chain. "
        f"Focal-company footprints are reported in {FOCAL_EMISSIONS_UNIT}; the separate economy-wide context is reported in {MRIO_EMISSIONS_UNIT}. "
        "No company-share parameter or additional demand scaling is applied to the uploaded focal-company demand vectors."
    )
    f14 = float(p14["company_footprint"])
    f17 = float(p17["company_footprint"])
    change = f17 - f14
    c1, c2, c3 = st.columns(3)
    c1.metric(f"2014 focal-company footprint ({FOCAL_EMISSIONS_UNIT})", f"{f14:,.6f}")
    c2.metric(f"2017 focal-company footprint ({FOCAL_EMISSIONS_UNIT})", f"{f17:,.6f}")
    c3.metric(
        f"Change, 2014–2017 ({FOCAL_EMISSIONS_UNIT})",
        f"{change:+,.6f}",
    )
    st.info(
        f"Unit contract ({UNIT_RELEASE_ID}): the focal-company values above are tonnes of CO₂ ({FOCAL_EMISSIONS_UNIT}), not million tonnes. "
        f"For context only, the 2017 economy-wide MRIO footprint is {float(p17.get('economy_wide_footprint', 0.0)):,.6f} {MRIO_EMISSIONS_UNIT}."
    )
    fig = go.Figure(
        go.Bar(
            x=["2014", "2017"],
            y=[f14, f17],
            text=[f"{f14:,.6f} {FOCAL_EMISSIONS_UNIT}", f"{f17:,.6f} {FOCAL_EMISSIONS_UNIT}"],
            textposition="auto",
        )
    )
    fig.update_layout(
        title="Company embodied-carbon footprint by reference year",
        yaxis_title=f"Embodied-carbon footprint ({FOCAL_EMISSIONS_UNIT})",
        height=380,
    )
    style_plotly_axes(fig)
    st.plotly_chart(fig, use_container_width=True)
    with st.expander("Active input provenance"):
        st.json({"2014": p14.get("input_hashes", {}), "2017": p17.get("input_hashes", {})})

# ----------------------------------------------------------- Hotspots
elif page == "Emissions Hotspot Intelligence":
    state = _require_ui_state()

    # Display the active reference-year selector together with a
    # presentation-only notice showing that the framework is extensible
    # to additional compatible MRIO reference years.
    year_col, future_year_col, _spacer = st.columns([1.55, 2.75, 5.70])

    with year_col:
        year = _select_available_year("mrio", "hotspot_year")

    with future_year_col:
        with st.container(border=True):
            st.markdown("**Additional compatible reference years …**")
            st.caption(
                "The framework is extensible beyond 2014 and 2017. "
                "Another reference year can be displayed after compatible MRIO "
                "and focal-company demand data are validated and the corresponding "
                "governed MRIO result is fulfilled."
            )

    payload = rui.result_payload(state, "mrio", year)
    hotspots = pd.DataFrame(payload.get("hotspots", []))
    st.title("Supply-Chain Emissions Hotspots")
    st.caption(
        "Node contributions are f_i × (L y)_i for the active focal-company demand vector. "
        f"Contributions are reported in {FOCAL_EMISSIONS_UNIT}; shares are percentages. "
        "The page appears only after the corresponding on-chain MRIO request is fulfilled."
    )
    if hotspots.empty:
        st.warning("The active MRIO result did not contain hotspot rows.")
        st.stop()
    fig = px.bar(
        hotspots.head(15),
        x="footprint_contribution",
        y="node_code",
        orientation="h",
        color="region",
        labels={
            "footprint_contribution": f"Embodied-carbon contribution ({FOCAL_EMISSIONS_UNIT})",
            "node_code": "Country-sector node",
            "region": "Region",
        },
        title=f"Top embodied-carbon nodes, {year}",
    )
    fig.update_layout(
        yaxis=dict(autorange="reversed", title="Country-sector node"),
        xaxis_title=f"Embodied-carbon contribution ({FOCAL_EMISSIONS_UNIT})",
        height=500,
    )
    style_plotly_axes(fig)
    st.plotly_chart(fig, use_container_width=True)
    hotspots_display = hotspots.copy()
    if "share_of_total" in hotspots_display.columns:
        hotspots_display["share_of_total"] = 100.0 * pd.to_numeric(
            hotspots_display["share_of_total"], errors="coerce"
        )
    hotspots_display = hotspots_display.rename(
        columns={
            "footprint_contribution": f"footprint_contribution ({FOCAL_EMISSIONS_UNIT})",
            "share_of_total": "share_of_total (%)",
        }
    )
    st.dataframe(hotspots_display, use_container_width=True, hide_index=True)
    split = payload.get("domestic_vs_imported", {})
    c1, c2 = st.columns(2)
    c1.metric("Domestic UAE share", f"{float(split.get('ARE_share', 0.0)):.2%}")
    c2.metric("Imported/other-region share", f"{float(split.get('ROW_share', 0.0)):.2%}")
    fig2 = px.pie(
        names=["Domestic UAE", "Imported/other regions"],
        values=[float(split.get("ARE_domestic", 0.0)), float(split.get("ROW_imported", 0.0))],
        hole=0.5,
    )
    fig2.update_traces(
        hovertemplate=f"%{{label}}: %{{value:.6f}} {FOCAL_EMISSIONS_UNIT} (%{{percent}})<extra></extra>"
    )
    fig2.update_layout(
        title=f"Domestic and imported origin of the focal footprint ({FOCAL_EMISSIONS_UNIT})",
        height=320,
    )
    style_plotly_axes(fig2)
    st.plotly_chart(fig2, use_container_width=True)

# ----------------------------------------------------------- SPA
elif page == "Structural Pathway Intelligence":
    state = _require_ui_state()
    year = _select_available_year("spa", "spa_year")
    payload = rui.result_payload(state, "spa", year)
    paths = pd.DataFrame(payload.get("paths", payload.get("top_paths", [])))
    st.title("Structural Pathway Intelligence")
    st.caption(
        f"Individual path contributions are reported in {FOCAL_EMISSIONS_UNIT}; cumulative coverage is a percentage; "
        "path depth is the number of upstream production tiers. The governed method reports the minimum number of complete ranked "
        "paths required to reach at least 87% of the complete focal-company footprint; there is no fixed 50-row display limit."
    )
    st.caption(
        "For each ordered path, the right-most node is the emissions-producing node whose direct intensity generates "
        "that path contribution; earlier nodes are focal-demand gateways or transmission stages."
    )
    target_share = float(payload.get("cumulative_target", 0.87))
    reported_share = float(payload.get("reported_cumulative_share", payload.get("cumulative_share", 0.0)))
    reported_footprint = float(
        payload.get(
            "reported_path_footprint",
            pd.to_numeric(paths.get("contribution", pd.Series(dtype=float)), errors="coerce").fillna(0.0).sum(),
        )
    )
    total_footprint = float(payload.get("total_footprint", 0.0))
    target_footprint = float(
        payload.get("target_footprint", target_share * total_footprint)
    )
    hotspot_alignment = payload.get("hotspot_alignment", {})
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Paths required", int(payload.get("reported_path_count", payload.get("paths_to_threshold", len(paths)))))
    c2.metric("Target coverage", f"{target_share:.2%}")
    c3.metric("Achieved path coverage", f"{reported_share:.2%}")
    c4.metric(f"Selected path footprint ({FOCAL_EMISSIONS_UNIT})", f"{reported_footprint:,.6f}")
    c5, c6, c7, c8 = st.columns(4)
    c5.metric(
        f"Top-{int(hotspot_alignment.get('leading_node_count', 15))} hotspot coverage",
        f"{float(hotspot_alignment.get('leading_node_share_of_total', 0.0)):.2%}",
    )
    c6.metric("Screened path coverage", f"{float(payload.get('screened_cumulative_share', reported_share)):.2%}")
    c7.metric(f"Shortfall to target ({FOCAL_EMISSIONS_UNIT})", f"{float(payload.get('target_shortfall', 0.0)):,.6f}")
    c8.metric("Maximum individual-path depth (tiers)", int(payload.get("max_depth", 0)))
    c9, c10, c11, c12 = st.columns(4)
    c9.metric(f"Complete footprint ({FOCAL_EMISSIONS_UNIT})", f"{total_footprint:,.6f}")
    c10.metric(f"87% target footprint ({FOCAL_EMISSIONS_UNIT})", f"{target_footprint:,.6f}")
    c11.metric(f"Whole-path overshoot ({FOCAL_EMISSIONS_UNIT})", f"{float(payload.get('target_overshoot', 0.0)):,.6f}")
    c12.metric("Complete screened paths", int(payload.get("screened_path_count", len(paths))))
    if not bool(payload.get("threshold_reached", False)):
        st.error(
            "This SPA package does not satisfy the governed 87% coverage gate. It is diagnostic only; "
            "the request is not eligible for fulfillment and every downstream stage remains locked."
        )
    else:
        st.success(
            f"The minimum complete-path set reaches {reported_share:.2%} of the focal-company footprint. "
            "The final path is kept intact, so coverage may slightly exceed the 87% target."
        )
    st.caption(
        "The 87% threshold follows the study's approximately 87% leading-15 producer-hotspot benchmark; "
        "the exact top-15 share for the selected year is shown separately. It is not a terminal-node filter: "
        "pathways are ranked globally by their complete contribution."
    )
    reconciliation = payload.get("coverage_reconciliation", {})
    if reconciliation:
        with st.expander("Coverage reconciliation and residuals"):
            st.json(reconciliation)
            st.caption(
                "Reported paths + screened-but-unreported paths + screening/pruning residual through the traced depth "
                "+ the exact deeper-tier tail reconcile to the complete focal-company footprint."
            )
    if not paths.empty and "depth" in paths:
        depth_counts = paths["depth"].value_counts().sort_index()
        fig = px.bar(
            x=depth_counts.index.astype(str),
            y=depth_counts.values,
            labels={"x": "Path depth", "y": "Number of retained paths"},
            title=f"Retained paths by depth, {year}",
        )
        style_plotly_axes(fig)
        st.plotly_chart(fig, use_container_width=True)
        if {"path_rank", "cumulative_share"}.issubset(paths.columns):
            coverage_curve = paths[["path_rank", "cumulative_share"]].copy()
            coverage_curve["cumulative_share"] = pd.to_numeric(
                coverage_curve["cumulative_share"], errors="coerce"
            )
            coverage_figure = px.line(
                coverage_curve,
                x="path_rank",
                y="cumulative_share",
                title=f"Cumulative explicit-path coverage by ranked path, {year}",
            )
            coverage_figure.add_hline(
                y=target_share,
                line_dash="dash",
                annotation_text=f"{target_share:.0%} target",
            )
            coverage_figure.update_xaxes(title="Contribution-ranked path")
            coverage_figure.update_yaxes(title="Share of complete focal-company footprint", tickformat=".0%")
            style_plotly_axes(coverage_figure)
            st.plotly_chart(coverage_figure, use_container_width=True)
        columns = [
            c
            for c in [
                "path_rank",
                "depth",
                "path_codes",
                "terminal_emitter_node",
                "terminal_emitter_hotspot_rank",
                "terminal_emitter_in_top15",
                "contribution",
                "individual_share_of_company_footprint",
                "cumulative_share",
            ]
            if c in paths.columns
        ]
        path_display = paths[columns].copy()
        for percentage_column in (
            "individual_share_of_company_footprint",
            "cumulative_share",
        ):
            if percentage_column in path_display.columns:
                path_display[percentage_column] = 100.0 * pd.to_numeric(
                    path_display[percentage_column], errors="coerce"
                )
        path_display = path_display.rename(
            columns={
                "path_rank": "rank",
                "depth": "depth (tiers)",
                "terminal_emitter_node": "right-most emissions-producing node",
                "terminal_emitter_hotspot_rank": "producer-hotspot rank",
                "terminal_emitter_in_top15": "terminal emitter in top 15",
                "contribution": f"contribution ({FOCAL_EMISSIONS_UNIT})",
                "individual_share_of_company_footprint": "individual share of total (%)",
                "cumulative_share": "cumulative_share (%)",
            }
        )
        st.dataframe(path_display, use_container_width=True, hide_index=True)
        st.download_button(
            "Download all selected SPA paths",
            paths.to_csv(index=False).encode("utf-8"),
            file_name=f"spa_paths_minimum_87pct_{year}.csv",
            mime="text/csv",
            use_container_width=True,
        )
        selection_metadata = {
            key: payload.get(key)
            for key in (
                "year",
                "total_footprint",
                "cumulative_target",
                "target_footprint",
                "coverage_target_basis",
                "reported_path_count",
                "reported_path_footprint",
                "reported_cumulative_share",
                "target_shortfall",
                "target_overshoot",
                "threshold_reached",
                "coverage_enforcement",
                "adaptive_expansion_attempts",
                "selection_rule",
                "final_path_policy",
                "hotspot_alignment",
                "coverage_reconciliation",
            )
        }
        st.download_button(
            "Download SPA coverage metadata",
            json.dumps(selection_metadata, indent=2, sort_keys=True).encode("utf-8"),
            file_name=f"spa_coverage_metadata_{year}.json",
            mime="application/json",
            use_container_width=True,
        )
    convergence = pd.DataFrame(payload.get("convergence", []))
    if not convergence.empty:
        st.caption(
            "Exact matrix-power tier coverage is a separate aggregate convergence diagnostic; "
            "it is not the sum of the explicitly enumerated path rows."
        )
        fig2 = px.line(
            convergence,
            x="depth",
            y="share",
            markers=True,
            title="Exact matrix-power coverage by depth",
        )
        fig2.update_xaxes(title="Path depth (tiers)")
        fig2.update_yaxes(title="Cumulative share of exact footprint (%)", tickformat=".0%")
        style_plotly_axes(fig2)
        st.plotly_chart(fig2, use_container_width=True)

# ----------------------------------------------------------- SDA
elif page == "Carbon-Change Decomposition":
    state = _require_ui_state()
    payload = rui.result_payload(state, "sda", "2014-2017")
    st.title("Carbon-Change Driver Decomposition, 2014–2017")
    st.caption(
        "The four effects are the complete 24-permutation/Shapley-style decomposition stored in the fulfilled SDA result package. "
        f"Focal-company effects are reported in {FOCAL_EMISSIONS_UNIT}; economy-wide contextual effects are reported in {MRIO_EMISSIONS_UNIT}."
    )

    def _render_sda_block(title: str, block: dict, unit: str, number_format: str = "+.6f"):
        st.subheader(title)
        order = ["intensity", "technology", "composition", "scale"]
        effects = block.get("effects", {})
        frame = pd.DataFrame(
            [{"effect": key, "contribution": float(effects.get(key, 0.0))} for key in order]
        )
        net = float(block.get("net_change", frame["contribution"].sum()))
        fig = go.Figure(
            go.Waterfall(
                measure=["relative"] * len(frame) + ["total"],
                x=list(frame["effect"]) + ["Net change"],
                y=list(frame["contribution"]) + [0],
                connector={"line": {"color": "#999999"}},
                texttemplate=f"%{{y:{number_format}}}",
            )
        )
        fig.update_layout(
            title=f"Net change = {net:+,.6f} {unit}",
            yaxis_title=f"Footprint change ({unit})",
            height=420,
        )
        style_plotly_axes(fig)
        st.plotly_chart(fig, use_container_width=True)
        frame_display = frame.rename(
            columns={"contribution": f"contribution ({unit})"}
        )
        st.dataframe(frame_display, use_container_width=True, hide_index=True)
        st.caption(
            f"Reconciliation residual: {float(block.get('reconciliation_residual', 0.0)):.3e} {unit}"
        )

    _render_sda_block(
        "Primary: focal-company footprint",
        payload.get("company_primary", {}),
        FOCAL_EMISSIONS_UNIT,
    )
    with st.expander("Secondary: economy-wide context"):
        _render_sda_block(
            "Economy-wide final demand",
            payload.get("economy_wide_context", {}),
            MRIO_EMISSIONS_UNIT,
            "+.2f",
        )
    st.divider()
    render_node_sda_workspace(state, ROOT_DIR)

# ----------------------------------------------------------- Network & DLI
elif page == "Network Leverage & DLI":
    st.title("Network Leverage & CRITIC-DLI")
    st.caption(
        "BC, PageRank, Carbon Dependency Risk, and Intervention Criticality are computed for the complete 455-node network. "
        "Their authoritative DLI weights are derived from one pooled 2014–2017 Pearson-CRITIC evaluation matrix; no fixed researcher-assigned weights are used."
    )
    state = _require_ui_state()
    available_years = sorted(int(year) for year in state.get("active_results", {}).get("network", {}))
    annual_tab, critic_tab, robustness_tab, temporal_tab, linkage_tab, hotspot_leverage_tab, intervention_governance_tab = st.tabs(
        [
            "Annual CRITIC-DLI",
            "Pooled CRITIC construction",
            "Weight robustness",
            "Two-period comparison",
            "CDR producer linkage",
            "Hotspot-leverage portfolios",
            "Driver/actionability governance",
        ]
    )

    with annual_tab:
        if not available_years:
            st.info("Complete a Network analysis request to display its results.")
        else:
            selected_year = st.selectbox("Network year", available_years, index=len(available_years)-1)
            payload = rui.result_payload(state, "network", selected_year)
            ranking, ranking_authority = _network_dli_frame(state, selected_year)
            st.info(f"DLI authority: {ranking_authority}.")
            if ranking.empty:
                st.warning("The fulfilled result contains no DLI ranking records.")
            else:
                display_columns = [c for c in [
                    "dli_rank", "node_code", "region", "sector", "DLI",
                    "dominant_dli_component", "BC", "PR", "CDR", "IC",
                    "BC_norm_critic", "PR_norm_critic", "CDR_norm_critic", "IC_norm_critic",
                    "weight_BC", "weight_PR", "weight_CDR", "weight_IC",
                ] if c in ranking.columns]
                st.dataframe(ranking[display_columns], use_container_width=True, hide_index=True)
                if {"node_code", "DLI"}.issubset(ranking.columns):
                    top = ranking.nsmallest(20, "dli_rank") if "dli_rank" in ranking else ranking.nlargest(20, "DLI")
                    fig = px.bar(top, x="DLI", y="node_code", orientation="h", color="dominant_dli_component" if "dominant_dli_component" in top else None,
                                 title=f"Leading {selected_year} pooled-CRITIC DLI nodes")
                    fig.update_layout(yaxis={"autorange": "reversed"})
                    style_plotly_axes(fig)
                    st.plotly_chart(fig, use_container_width=True)

    with critic_tab:
        active_dir = Path(ROOT_DIR) / "runtime" / "active_analytics"
        weights_path = active_dir / "critic_authoritative_weights.csv"
        corr_path = active_dir / "critic_authoritative_correlation.csv"
        meta_path = active_dir / "critic_authoritative_dli.json"
        if not weights_path.is_file():
            st.info("Complete Network analysis for both 2014 and 2017 to construct the authoritative pooled CRITIC weights.")
        else:
            weights = pd.read_csv(weights_path)
            st.subheader("Objective CRITIC weights")
            st.dataframe(weights, use_container_width=True, hide_index=True)
            if {"criterion", "critic_weight"}.issubset(weights.columns):
                weights_figure = px.bar(
                    weights,
                    x="criterion",
                    y="critic_weight",
                    title="Pooled Pearson-CRITIC weights",
                )
                style_plotly_axes(weights_figure)
                st.plotly_chart(weights_figure, use_container_width=True)
            if corr_path.is_file():
                st.subheader("Inter-criterion correlation matrix")
                st.dataframe(pd.read_csv(corr_path), use_container_width=True, hide_index=True)
            if meta_path.is_file():
                with st.expander("CRITIC provenance and authority boundary"):
                    st.json(json.loads(meta_path.read_text(encoding="utf-8")))

    with robustness_tab:
        st.write(
            "One-way and Dirichlet Monte Carlo scenarios vary only the CRITIC-derived weights. The MRIO-derived BC, PR, CDR, and IC values remain fixed."
        )
        r1, r2, r3 = st.columns(3)
        samples = r1.number_input("Monte Carlo samples", min_value=100, max_value=50000, value=5000, step=100)
        concentration = r2.number_input("Dirichlet concentration", min_value=1.0, max_value=1000.0, value=80.0, step=5.0)
        seed = r3.number_input("Random seed", min_value=0, max_value=2147483647, value=20260903, step=1)
        if st.button("Run / refresh CRITIC-DLI robustness", type="primary", use_container_width=True):
            try:
                with st.spinner("Running one-way and CRITIC-centred Monte Carlo robustness analysis..."):
                    OrchestratorClient(timeout=max(900.0, float(samples)/3.0)).post(
                        "/v1/governance/dli-robustness",
                        {"year": 2017, "top_k": 15, "samples": int(samples), "concentration": float(concentration),
                         "seed": int(seed), "critic_correlation": "pearson", "request_context": {"trigger": "streamlit_u11"}},
                    )
                st.success("CRITIC-DLI robustness evidence generated.")
                st.rerun()
            except Exception as exc:
                st.error(f"Robustness analysis failed: {exc}")
        active_dir = Path(ROOT_DIR) / "runtime" / "active_analytics"
        summary_path = active_dir / "critic_dli_robustness_summary.json"
        if summary_path.is_file():
            summary = json.loads(summary_path.read_text(encoding="utf-8"))
            st.json(summary)
            for filename, title in [
                ("critic_one_way_weight_scenarios.csv", "One-way scenarios"),
                ("critic_node_rank_stability.csv", "Node rank stability"),
            ]:
                fp = active_dir / filename
                if fp.is_file():
                    st.subheader(title)
                    st.dataframe(pd.read_csv(fp), use_container_width=True, hide_index=True)
        else:
            st.info("Run the analysis after pooled CRITIC-DLI becomes available.")

    with temporal_tab:
        if not {2014, 2017}.issubset(set(available_years)):
            st.info("Complete Network analysis for both years.")
        else:
            df14, authority14 = _network_dli_frame(state, 2014)
            df17, authority17 = _network_dli_frame(state, 2017)
            if df14.empty or df17.empty:
                st.warning("One annual ranking is unavailable.")
            else:
                if authority14 != authority17 or "pooled" not in authority14:
                    st.error("Temporal DLI is unavailable until both slices share one pooled CRITIC authority.")
                else:
                    temporal = net.compute_temporal_dli(
                        df14, df17, base_year=2014, comparison_year=2017
                    )
                    display_columns = [
                        column for column in [
                            "node_code", "region", "sector", "DLI_2014",
                            "dli_rank_2014", "DLI_2017", "dli_rank_2017",
                            "delta_DLI", "rank_change", "two_period_status",
                        ] if column in temporal.columns
                    ]
                    st.caption(
                        "Both annual ranks and the score change use one pooled 2014–2017 normalization and one Pearson-CRITIC weight vector."
                    )
                    st.dataframe(
                        temporal.sort_values("dli_rank_2017")[display_columns].head(100),
                        use_container_width=True,
                        hide_index=True,
                    )

    with linkage_tab:
        render_cdr_producer_linkage_workspace(state, available_years, ROOT_DIR)

    with hotspot_leverage_tab:
        render_hotspot_leverage_workspace(state, ROOT_DIR)

    with intervention_governance_tab:
        render_intervention_governance_workspace(state, ROOT_DIR, show_title=False)

elif page == "Integrated SPA–SDA & CRITIC-DLI":
    from final_methodology_ui import render_integrated_methodology_workspace
    render_integrated_methodology_workspace()

elif page == "Intervention Governance":
    state = _require_ui_state()
    render_intervention_governance_workspace(state, ROOT_DIR, show_title=True)

# -------------------------------------------------- Optional direct intensity sensitivity
elif page == "Strategic Scenario Analysis":
    state = _require_ui_state()
    year = _select_available_year("mrio", "scenario_year")
    st.title("Optional Direct Carbon-Intensity Sensitivity")
    st.caption(
        "This side module changes only one selected producer node's own carbon intensity while holding the validated "
        "Leontief structure and focal-company demand fixed. It is not the formal intervention authority, does not simulate "
        "technology, composition, scale, or governance-mediated interventions, and is not predicted or guaranteed abatement. "
        f"Values are reported in {FOCAL_EMISSIONS_UNIT}."
    )
    hashes = state.get("active_input_hashes", {})
    my, company_y = load_mrio_year(
        int(year),
        str(hashes.get("mrio", "")),
        str(hashes.get("focal_demand", "")),
    )
    node_codes = [str(code) for code in my.node_codes]
    node_labels = {
        f"{code} — {str(region)} / {str(sector)}": code
        for code, region, sector in zip(my.node_codes, my.regions, my.sectors)
    }
    sourced_nodes = [code for code in sce.SCENARIO_LIBRARY if code in set(node_codes)]
    basis_options = ["Illustrative direct intensity sensitivity"]
    if sourced_nodes:
        basis_options.insert(0, "Literature-sourced direct intensity scenario")
    scenario_basis = st.radio(
        "Sensitivity basis",
        basis_options,
        horizontal=True,
        key="scenario_basis",
    )

    if scenario_basis == "Literature-sourced direct intensity scenario":
        sourced_labels = {label: code for label, code in node_labels.items() if code in sourced_nodes}
        selected_node_label = st.selectbox(
            "Producer node with a packaged sourced intensity scenario",
            list(sourced_labels),
        )
        node_code = sourced_labels[selected_node_label]
        sourced_scenarios = sce.run_scenario_library(my, company_y, node_code)
        scenario_labels = {item["label"]: item for item in sourced_scenarios}
        selected_label = st.selectbox("Scenario", list(scenario_labels))
        result = scenario_labels[selected_label]
        scenario_note = str(result.get("citation", ""))
    else:
        selected_node_label = st.selectbox(
            "Producer node for illustrative direct intensity sensitivity",
            list(node_labels),
        )
        node_code = node_labels[selected_node_label]
        cut_pct = st.select_slider(
            "Illustrative reduction in the selected node's carbon intensity",
            options=[10, 20, 30, 50],
            value=20,
            key="scenario_reduction_pct",
        )
        result = sce.counterfactual_footprint(
            my,
            company_y,
            node_code,
            float(cut_pct) / 100.0,
        )
        scenario_note = (
            "The percentage is a user-selected direct-intensity sensitivity. It is not a formal intervention recommendation, "
            "not an estimate of governance-mediated action, and not a replacement for node/path SDA, producer linkage, "
            "actionability verification, or tactical scenario optimization."
        )

    ranking, _ranking_authority = _network_dli_frame(state, year)
    if not ranking.empty and "node_code" in ranking.columns:
        context = ranking.loc[ranking["node_code"].astype(str).eq(node_code)]
        if not context.empty:
            record = context.iloc[0]
            st.caption(
                f"Context only — DLI rank: {int(record.get('dli_rank', 0))}; DLI: {float(record.get('DLI', 0.0)):.6f}. "
                "DLI does not authorize this sensitivity as an intervention."
            )

    c1, c2, c3 = st.columns(3)
    c1.metric(
        f"Baseline footprint ({FOCAL_EMISSIONS_UNIT})",
        f"{float(result['baseline_footprint']):,.6f}",
    )
    c2.metric(
        f"Sensitivity footprint ({FOCAL_EMISSIONS_UNIT})",
        f"{float(result['scenario_footprint']):,.6f}",
    )
    c3.metric(
        f"Modeled difference ({FOCAL_EMISSIONS_UNIT})",
        f"{float(result['absolute_saving']):,.6f}",
        delta=f"{float(result['pct_of_total_footprint_saved']):.2%} of baseline",
    )
    st.caption(
        f"Selected-node intensity reduction: {float(result['reduction_pct']):.1%}. "
        "Only the selected intensity entry is changed; A, L, and y remain fixed."
    )
    st.info(scenario_note)

# ------------------------------------------ Regional sourcing opportunities
elif page == "AURORA Opportunity Intelligence":
    state = _require_ui_state()
    year = _select_available_year("aurora", "aurora_year")
    source_cid = rui.result_cid(state, "aurora", year)
    payload = aurora_report.enrich_aurora_result(rui.aurora_payload(state, year))

    st.title("AURORA Regional Opportunity & Resilience Intelligence")
    st.caption(
        "AURORA — Analogue-based Upstream Regional Opportunity and Resilience Assessment — "
        "uses exact bin-free Otsu thresholds calibrated from the complete 2014 same-sector candidate universe, then "
        "screens regional analogues using production structure, market structure, "
        "observed linkages, embodied-carbon multipliers, Pareto efficiency, DLI evidence and cross-year stability. "
        f"Similarity and DLI values are {NORMALIZED_UNIT}; carbon opportunities are in {FOCAL_EMISSIONS_UNIT}; "
        f"company-demand values, where shown, are in {FOCAL_DEMAND_UNIT}; MRIO transaction-flow values are in {MRIO_MONETARY_UNIT}."
    )
    st.caption(f"AURORA decision-trace and complete-export extension: `{aurora_report.REPORTING_RELEASE_ID}`.")
    if source_cid:
        st.caption(f"Authoritative content-addressed AURORA result CID: `{source_cid}`")

    threshold_calibration = dict(payload.get("threshold_calibration", {}) or {})
    if threshold_calibration:
        production_calibration = dict(threshold_calibration.get("production", {}) or {})
        market_calibration = dict(threshold_calibration.get("market", {}) or {})
        tc1, tc2, tc3, tc4 = st.columns(4)
        tc1.metric(
            "Production threshold",
            f"{float(production_calibration.get('threshold', 0.0)):.4f}",
        )
        tc2.metric(
            "Market threshold",
            f"{float(market_calibration.get('threshold', 0.0)):.4f}",
        )
        tc3.metric("Calibration year", int(threshold_calibration.get("calibration_year", 0)))
        tc4.metric(
            "Calibration candidates",
            int(threshold_calibration.get("candidate_universe_count", 0)),
        )
        st.caption(
            "The thresholds were obtained by evaluating every split between consecutive distinct calibration-year "
            "similarity values and selecting the split with maximum Otsu between-class variance. No histogram bins "
            "or downstream carbon, linkage, Pareto, DLI, or recommendation outcomes were used in calibration."
        )
    else:
        st.warning(
            "This appears to be a legacy AURORA result without exact bin-free Otsu calibration metadata. "
            "Rerun the AURORA governance request with the current release."
        )

    all_candidates = pd.DataFrame(payload.get("all_candidates", payload.get("candidates", [])))
    eligible_candidates = pd.DataFrame(payload.get("eligible_candidates", []))
    pareto_candidates = pd.DataFrame(payload.get("pareto_efficient_candidates", []))
    recommended = pd.DataFrame(payload.get("recommended_opportunities", []))
    decision_funnel = pd.DataFrame(payload.get("decision_funnel", []))
    sector_funnel = pd.DataFrame(payload.get("sector_summaries", []))
    cross_year = pd.DataFrame(payload.get("cross_year_evidence", []))

    # Compatibility label retained for unit-regression validation.
    legacy_full_reallocation_unit_label = f"modelled_full_reallocation_opportunity ({FOCAL_EMISSIONS_UNIT})"

    def _aurora_display_frame(frame: pd.DataFrame, columns: list[str] | None = None) -> pd.DataFrame:
        if frame.empty:
            return frame.copy()
        display = frame.copy()
        if columns:
            display = display[[column for column in columns if column in display.columns]].copy()
        for column in [
            "share_of_sector_demand",
            "relative_multiplier_reduction",
            "opportunity_share_of_company_footprint",
            "focal_consumer_intermediate_sales_share",
            "focal_region_intermediate_sales_share",
            "gcc_intermediate_sales_share",
            "comparison_relative_multiplier_reduction",
            "comparison_focal_region_intermediate_sales_share",
        ]:
            if column in display.columns:
                display[column] = 100.0 * pd.to_numeric(display[column], errors="coerce")
        rename = {
            "sector": "Sector",
            "current_nodes": "Current node(s)",
            "node_code": "Candidate node",
            "region": "Region",
            "sector_demand": f"Sector demand ({FOCAL_DEMAND_UNIT})",
            "baseline_embodied_multiplier": f"Current-mix multiplier ({CARBON_INTENSITY_UNIT})",
            "candidate_embodied_multiplier": f"Candidate multiplier ({CARBON_INTENSITY_UNIT})",
            "production_sector_similarity": "Production similarity (0–1)",
            "production_similarity_threshold_used": "Production threshold used (0–1)",
            "market_sector_similarity": "Market similarity (0–1)",
            "market_similarity_threshold_used": "Market threshold used (0–1)",
            "similarity_threshold_method": "Threshold calibration method",
            "similarity_threshold_calibration_year": "Threshold calibration year",
            "relative_multiplier_reduction": "Relative multiplier reduction (%)",
            "focal_region_intermediate_sales_share": "UAE intermediate-sales share (%)",
            "direct_flow_to_focal_region_construction": f"Direct flow to UAE construction ({MRIO_MONETARY_UNIT})",
            "intermediate_sales_to_focal_region": f"Intermediate sales to UAE ({MRIO_MONETARY_UNIT})",
            "observed_linkage_tier": "Observed linkage",
            "eligible_for_regional_investigation": "All eligibility gates passed",
            "pareto_efficient": "Pareto efficient",
            "selected_within_display_cap": "Selected within display cap",
            "recommended_for_investigation": "Recommended",
            "modelled_full_reallocation_opportunity": f"Full-reallocation screening envelope ({FOCAL_EMISSIONS_UNIT})",
            "opportunity_share_of_company_footprint": "Opportunity share of focal footprint (%)",
            "DLI": "DLI (0–1)",
            "dli_rank": "DLI rank",
            "dominant_dli_component": "Dominant DLI component",
            "stable_reference_year_signal": "Two-period stable signal",
            "recommendation_rank_within_sector": "Recommendation rank within sector",
            "recommendation": "Management interpretation",
            "production_similarity_gate_passed": "Production gate passed",
            "market_similarity_gate_passed": "Market gate passed",
            "carbon_improvement_gate_passed": "Carbon gate passed",
            "linkage_gate_passed": "Linkage gate passed",
            "decision_status": "Decision stage",
            "exclusion_reason": "Decision rationale / exclusion reason",
            "decision_trace": "Decision trace",
            "comparison_year": "Comparison year",
            "comparison_year_available": "Comparison evidence available",
            "comparison_production_sector_similarity": "Comparison production similarity (0–1)",
            "comparison_market_sector_similarity": "Comparison market similarity (0–1)",
            "comparison_relative_multiplier_reduction": "Comparison multiplier reduction (%)",
            "comparison_focal_region_intermediate_sales_share": "Comparison UAE intermediate-sales share (%)",
            "comparison_observed_linkage_tier": "Comparison observed linkage",
            "structural_analogue_in_both_reference_years": "Structural analogue in both years",
            "lower_carbon_in_both_reference_years": "Lower carbon in both years",
            "comparison_eligible_for_regional_investigation": "Eligible in comparison year",
        }
        return display.rename(columns=rename)

    summary = payload.get("decision_funnel_summary", {})
    metric_cols = st.columns(6)
    metric_cols[0].metric("Demanded sectors", int(payload.get("demanded_sector_count", 0)))
    metric_cols[1].metric("Same-sector candidates", int(summary.get("same_sector_candidates", len(all_candidates))))
    metric_cols[2].metric("Eligible candidates", int(summary.get("all_eligibility_gates_passed", len(eligible_candidates))))
    metric_cols[3].metric("Pareto-efficient", int(summary.get("pareto_efficient_candidates", len(pareto_candidates))))
    metric_cols[4].metric("Displayed recommendations", int(summary.get("displayed_recommendations", len(recommended))))
    metric_cols[5].metric("Two-period stable", int(summary.get("stable_displayed_recommendations", 0)))

    overview_tab, shortlist_tab, trace_tab, comparison_tab, download_tab = st.tabs(
        [
            "Decision funnel",
            "Recommended shortlist",
            "Pareto and complete candidates",
            "Cross-year evidence",
            "Downloads and provenance",
        ]
    )

    with overview_tab:
        if not recommended.empty:
            plot_df = recommended.copy()
            plot_df["relative_multiplier_reduction_pct"] = 100.0 * pd.to_numeric(
                plot_df["relative_multiplier_reduction"], errors="coerce"
            )
            plot_df["focal_region_intermediate_sales_share_pct"] = 100.0 * pd.to_numeric(
                plot_df.get("focal_region_intermediate_sales_share", 0.0), errors="coerce"
            )
            fig = px.scatter(
                plot_df,
                x="production_sector_similarity",
                y="relative_multiplier_reduction_pct",
                size="market_sector_similarity",
                color="region",
                hover_name="node_code",
                hover_data={
                    "sector": True,
                    "focal_region_intermediate_sales_share_pct": ":.2f",
                    "pareto_efficient": True,
                    "stable_reference_year_signal": True,
                    "DLI": ":.4f",
                    "modelled_full_reallocation_opportunity": ":.6f",
                },
                labels={
                    "production_sector_similarity": "Production similarity (dimensionless, 0–1)",
                    "relative_multiplier_reduction_pct": "Relative carbon-multiplier reduction (%)",
                    "market_sector_similarity": "Market similarity (dimensionless, 0–1)",
                    "focal_region_intermediate_sales_share_pct": "UAE intermediate-sales share (%)",
                    "modelled_full_reallocation_opportunity": f"Full-reallocation screening envelope ({FOCAL_EMISSIONS_UNIT})",
                },
                title=f"Recommended same-sector regional analogues, {year}",
            )
            fig.add_hline(y=0.0, line_dash="dash")
            style_plotly_axes(fig)
            st.plotly_chart(fig, use_container_width=True)
        else:
            st.warning("No candidate was selected for the displayed AURORA shortlist under the current configuration.")

        st.markdown("### Candidate decision funnel")
        if not decision_funnel.empty:
            funnel_plot = decision_funnel.sort_values("stage_order").copy()
            funnel_fig = px.bar(
                funnel_plot,
                x="count",
                y="stage",
                orientation="h",
                text="count",
                hover_data={"condition": True, "stage_order": False},
                labels={"count": "Candidate count", "stage": "Decision stage"},
            )
            funnel_fig.update_layout(yaxis={"categoryorder": "array", "categoryarray": list(reversed(funnel_plot["stage"].tolist()))})
            style_plotly_axes(funnel_fig)
            st.plotly_chart(funnel_fig, use_container_width=True)
            st.dataframe(
                decision_funnel[[column for column in ["stage_order", "stage", "count", "condition"] if column in decision_funnel.columns]],
                use_container_width=True,
                hide_index=True,
            )
        else:
            st.info("Decision-funnel metadata is unavailable for this legacy result package. Rerun AURORA with this release to generate it.")

        st.markdown("### Sector-level propagation")
        sector_columns = [
            "sector",
            "sector_demand",
            "candidate_count",
            "production_similarity_pass_count",
            "structural_analogue_count",
            "lower_carbon_structural_analogue_count",
            "eligible_candidate_count",
            "pareto_efficient_count",
            "recommended_count",
            "stable_recommended_count",
        ]
        sector_display = _aurora_display_frame(sector_funnel, sector_columns)
        if not sector_display.empty:
            st.dataframe(sector_display, use_container_width=True, hide_index=True)
        with st.expander("AURORA selection logic and interpretation rules"):
            st.json(payload.get("selection_logic", {}))
            st.info(payload.get("display_cap_note", ""))

    with shortlist_tab:
        st.markdown("### Final management-facing recommendations")
        shortlist_columns = [
            "sector",
            "current_nodes",
            "node_code",
            "region",
            "sector_demand",
            "baseline_embodied_multiplier",
            "candidate_embodied_multiplier",
            "production_sector_similarity",
            "market_sector_similarity",
            "relative_multiplier_reduction",
            "focal_region_intermediate_sales_share",
            "observed_linkage_tier",
            "eligible_for_regional_investigation",
            "pareto_efficient",
            "selected_within_display_cap",
            "modelled_full_reallocation_opportunity",
            "opportunity_share_of_company_footprint",
            "DLI",
            "dli_rank",
            "dominant_dli_component",
            "stable_reference_year_signal",
            "recommendation_rank_within_sector",
            "recommendation",
        ]
        shortlist_display = _aurora_display_frame(recommended, shortlist_columns)
        if shortlist_display.empty:
            st.warning("No recommendations are available for the selected year.")
        else:
            st.dataframe(shortlist_display, use_container_width=True, hide_index=True)
        st.warning(payload.get("non_additivity_note", ""))
        st.info(payload.get("claim_boundary", "Regional opportunities require supplier-level due diligence."))
        st.caption(payload.get("dli_rule", ""))

    with trace_tab:
        st.markdown("### Pareto-efficient candidates")
        st.caption(
            "This table includes every eligible non-dominated candidate, including candidates omitted only by the per-sector display cap."
        )
        pareto_columns = [
            "sector",
            "node_code",
            "region",
            "production_sector_similarity",
            "market_sector_similarity",
            "focal_region_intermediate_sales_share",
            "relative_multiplier_reduction",
            "observed_linkage_tier",
            "pareto_rank_within_sector",
            "recommended_for_investigation",
            "modelled_full_reallocation_opportunity",
            "DLI",
            "dominant_dli_component",
            "recommendation",
        ]
        pareto_display = _aurora_display_frame(pareto_candidates, pareto_columns)
        if pareto_display.empty:
            st.info("No Pareto-efficient candidates are available.")
        else:
            st.dataframe(pareto_display, use_container_width=True, hide_index=True)

        st.markdown("### Candidate-level gate propagation")
        if all_candidates.empty:
            st.info("No complete candidate table is available.")
        else:
            sectors = ["All sectors"] + sorted(all_candidates["sector"].dropna().astype(str).unique().tolist())
            statuses = ["All decision stages"] + sorted(all_candidates["decision_status"].dropna().astype(str).unique().tolist())
            filter_col1, filter_col2 = st.columns(2)
            selected_sector = filter_col1.selectbox("Filter by demanded sector", sectors, key="aurora_candidate_sector_filter")
            selected_status = filter_col2.selectbox("Filter by decision stage", statuses, key="aurora_candidate_status_filter")
            filtered = all_candidates.copy()
            if selected_sector != "All sectors":
                filtered = filtered[filtered["sector"].astype(str) == selected_sector]
            if selected_status != "All decision stages":
                filtered = filtered[filtered["decision_status"].astype(str) == selected_status]
            trace_columns = [
                "sector",
                "node_code",
                "region",
                "production_similarity_gate_passed",
                "market_similarity_gate_passed",
                "carbon_improvement_gate_passed",
                "linkage_gate_passed",
                "eligible_for_regional_investigation",
                "pareto_efficient",
                "selected_within_display_cap",
                "recommended_for_investigation",
                "decision_status",
                "exclusion_reason",
                "decision_trace",
            ]
            st.dataframe(
                _aurora_display_frame(filtered, trace_columns),
                use_container_width=True,
                hide_index=True,
            )
            with st.expander("Complete candidate evidence table"):
                st.dataframe(_aurora_display_frame(filtered), use_container_width=True, hide_index=True)

    with comparison_tab:
        st.markdown("### Two-period stability evidence")
        st.caption(
            "The stable signal means a primary-year recommendation remains fully eligible in the comparison year; it does not require the same Pareto rank in both years and is not a forecast."
        )
        if cross_year.empty:
            st.info("Detailed comparison-year evidence is unavailable for this legacy result package. Rerun AURORA with this release to populate it.")
        else:
            show_all_comparison = st.checkbox(
                "Show comparison evidence for all candidates",
                value=False,
                key="aurora_show_all_cross_year",
            )
            comparison_frame = cross_year if show_all_comparison else cross_year[cross_year["recommended_for_investigation"].fillna(False)]
            comparison_columns = [
                "sector",
                "node_code",
                "region",
                "recommended_for_investigation",
                "stable_reference_year_signal",
                "comparison_year",
                "comparison_year_available",
                "production_sector_similarity",
                "comparison_production_sector_similarity",
                "market_sector_similarity",
                "comparison_market_sector_similarity",
                "relative_multiplier_reduction",
                "comparison_relative_multiplier_reduction",
                "focal_region_intermediate_sales_share",
                "comparison_focal_region_intermediate_sales_share",
                "observed_linkage_tier",
                "comparison_observed_linkage_tier",
                "structural_analogue_in_both_reference_years",
                "lower_carbon_in_both_reference_years",
                "comparison_eligible_for_regional_investigation",
            ]
            st.dataframe(
                _aurora_display_frame(comparison_frame, comparison_columns),
                use_container_width=True,
                hide_index=True,
            )

    with download_tab:
        st.markdown("### Complete AURORA results export")
        st.caption(
            "The JSON package identified by the on-chain CID remains authoritative. These CSV and Excel files are audit-friendly convenience exports of the same evidence."
        )
        export_frames = aurora_report.build_export_frames(payload)
        workbook_bytes = aurora_report.build_excel_workbook_bytes(payload, source_result_cid=source_cid)
        st.download_button(
            "Download complete AURORA workbook",
            data=workbook_bytes,
            file_name=f"AURORA_complete_results_{int(year)}.xlsx",
            mime="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
            use_container_width=True,
        )
        download_col1, download_col2 = st.columns(2)
        download_col1.download_button(
            "Download recommended shortlist (CSV)",
            data=export_frames["Recommended"].to_csv(index=False).encode("utf-8-sig"),
            file_name=f"AURORA_recommended_{int(year)}.csv",
            mime="text/csv",
            use_container_width=True,
        )
        download_col2.download_button(
            "Download complete candidate table (CSV)",
            data=export_frames["All_Candidates"].to_csv(index=False).encode("utf-8-sig"),
            file_name=f"AURORA_all_candidates_{int(year)}.csv",
            mime="text/csv",
            use_container_width=True,
        )
        download_col3, download_col4 = st.columns(2)
        download_col3.download_button(
            "Download Pareto candidates (CSV)",
            data=export_frames["Pareto_Candidates"].to_csv(index=False).encode("utf-8-sig"),
            file_name=f"AURORA_pareto_candidates_{int(year)}.csv",
            mime="text/csv",
            use_container_width=True,
        )
        download_col4.download_button(
            "Download decision funnel (CSV)",
            data=export_frames["Decision_Funnel"].to_csv(index=False).encode("utf-8-sig"),
            file_name=f"AURORA_decision_funnel_{int(year)}.csv",
            mime="text/csv",
            use_container_width=True,
        )
        st.json(
            {
                "source_result_cid": source_cid,
                "reporting_schema_version": payload.get("reporting_schema_version"),
                "network_result_hash": payload.get("network_result_hash"),
                "input_hashes": payload.get("input_hashes", {}),
                "units": payload.get("units", {}),
                "selection_logic": payload.get("selection_logic", {}),
                "threshold_calibration": payload.get("threshold_calibration", {}),
            }
        )
        st.warning(payload.get("non_additivity_note", ""))

elif page == "AI Decision Intelligence":
    import dual_capability_assistant as ca
    import strategic_assistant as sa

    st.title("Strategic Carbon Decision Intelligence")
    st.caption(
        "A query-adaptive local agent connected to the same Ollama service used by Ollama Desktop. "
        "Research questions retain the validated deterministic MRIO, SPA, SDA, network/DLI, intervention, "
        "scenario and AURORA architecture. Questions about this deployment use a separate curated system-knowledge "
        "route, ordinary questions use local Ollama, and mixed questions preserve explicit provenance."
    )

    @st.cache_data(ttl=20, show_spinner=False)
    def discover_local_models(base_url: str):
        try:
            discovery_client = sa.make_client(base_url=base_url)
            return discovery_client.model_details(), ""
        except Exception as exc:
            return [], str(exc)

    if "dual_chat_messages" not in st.session_state:
        st.session_state.dual_chat_messages = []
    if "dual_chat_state" not in st.session_state:
        st.session_state.dual_chat_state = {}

    config_col1, config_col2, config_col3 = st.columns([1.15, 1.05, 1])
    with config_col1:
        ollama_url = st.text_input(
            "Ollama server",
            value=os.getenv("OLLAMA_BASE_URL", "http://127.0.0.1:11434"),
            key="dual_ollama_url",
            help="The standard local Ollama Desktop service listens on this address.",
        )

    model_details, model_error = discover_local_models(ollama_url)
    model_names = [str(item.get("name", "")) for item in model_details if item.get("name")]
    default_model = os.getenv("OLLAMA_MODEL", "qwen3:4b")

    with config_col2:
        if model_names:
            if st.session_state.get("dual_model_select") not in model_names:
                st.session_state.pop("dual_model_select", None)
            default_index = model_names.index(default_model) if default_model in model_names else 0
            ollama_model = st.selectbox(
                "Installed Ollama model",
                options=model_names,
                index=default_index,
                key="dual_model_select",
                help="Discovered directly from the local Ollama /api/tags endpoint.",
            )
        else:
            ollama_model = st.text_input(
                "Ollama model",
                value=default_model,
                key="dual_model_manual",
                help="Type a locally installed model name, for example qwen3:4b.",
            )

    with config_col3:
        mode_label = st.radio(
            "Assistant mode",
            ["Auto", "Research only", "General chat"],
            horizontal=True,
            key="dual_assistant_mode",
            help=(
                "Auto uses the local LLM as the primary task interpreter and reasoner, then invokes validated project tools only when exact evidence is required or useful. Research only preserves the validated evidence boundary. General chat bypasses project tools."
            ),
        )

    mode_map = {"Auto": "auto", "Research only": "research", "General chat": "general"}
    selected_mode = mode_map[mode_label]

    status_col1, status_col2, status_col3 = st.columns([1.5, 1, 1])
    with status_col1:
        if model_names and ollama_model in model_names:
            selected_detail = next(
                (item for item in model_details if item.get("name") == ollama_model),
                {},
            )
            detail = selected_detail.get("details", {}) or {}
            parameter_size = detail.get("parameter_size", "unknown size")
            quantisation = detail.get("quantization_level", "unknown quantisation")
            st.success(
                f"Ollama connected: `{ollama_model}` ({parameter_size}, {quantisation}).",
                icon="✅",
            )
        else:
            st.warning(
                "Ollama is not currently available for LLM-first interpretation or general reasoning. Explicit deterministic project results and curated system fallbacks remain available. "
                + (f"Details: {model_error}" if model_error else ""),
                icon="⚠️",
            )
    with status_col2:
        if st.button("Refresh models", use_container_width=True):
            discover_local_models.clear()
            st.rerun()
    with status_col3:
        if st.button("New conversation", use_container_width=True):
            st.session_state.dual_chat_messages = []
            st.session_state.dual_chat_state = {}
            st.rerun()

    mode_explanations = {
        "auto": (
            "**Auto:** the selected local Ollama model first understands the task and requested output. It answers ordinary, strategic, critical, hypothetical and writing questions directly, while validated MRIO, SPA, SDA, DLI, hotspot, intervention, scenario and AURORA tools are invoked only when exact project evidence is genuinely needed or explicitly selected as supporting context."
        ),
        "research": (
            "**Research only:** answers are restricted to curated AURORA analytical or system-architecture evidence; ordinary general chat is disabled."
        ),
        "general": (
            "**General chat:** behaves like a normal local Ollama conversation. Responses are not represented as computed AURORA finidings."
        ),
    }
    st.info(mode_explanations[selected_mode])

    if not st.session_state.dual_chat_messages:
        st.caption(
            "Try: `Give ten suggestions to decarbonize the complete focal-company supply chain.` | `Why might a single-node strategy fail?` | `Which node should management prioritize and why?` | `What are the deployment challenges of this entire system?`"
        )

    def render_assistant_metadata(meta: dict):
        route = str(meta.get("route", ""))
        provenance = meta.get("provenance", {}) or {}
        metrics = meta.get("model_metrics", {}) or {}
        route_label = {
            "research": "Validated exact project evidence",
            "general": "LLM-first direct reasoning",
            "hybrid": "LLM reasoning + validated project evidence",
            "system_meta": "LLM reasoning + curated system evidence",
        }.get(route, route or "Assistant")
        model_name = metrics.get("model") or ollama_model
        duration = metrics.get("total_duration")
        duration_text = ""
        try:
            if duration:
                duration_text = f" | local generation {float(duration) / 1_000_000_000:.1f}s"
        except (TypeError, ValueError):
            duration_text = ""
        st.caption(
            f"Route: {route_label} | model layer: {model_name or 'deterministic-only'}{duration_text}"
        )
        notice = provenance.get("notice")
        if notice:
            st.caption(str(notice))

        plan = meta.get("plan") or {}
        evidence = meta.get("evidence") or []
        if plan:
            with st.expander("Validated route and response plan", expanded=False):
                st.json(plan)
        if evidence:
            with st.expander("Validated evidence trace", expanded=False):
                st.caption(
                    "Quantitative claims remain tied to deterministic modules; system-level claims are tied to the curated deployment evidence shown here."
                )
                st.json(evidence)

    for message in st.session_state.dual_chat_messages:
        with st.chat_message(message.get("role", "assistant")):
            st.markdown(message.get("content", ""))
            if message.get("role") == "assistant":
                render_assistant_metadata(message.get("meta", {}))

    prompt = st.chat_input(
        "Ask an analytical, strategic, system, methodological, writing, or general question"
    )
    if prompt:
        prior_history = [
            {"role": item.get("role", ""), "content": item.get("content", "")}
            for item in st.session_state.dual_chat_messages
        ]
        st.session_state.dual_chat_messages.append({"role": "user", "content": prompt})
        with st.chat_message("user"):
            st.markdown(prompt)

        if model_names and ollama_model in model_names:
            client = sa.make_client(base_url=ollama_url, model=ollama_model)
        else:
            client = sa.make_deterministic_client()

        with st.chat_message("assistant"):
            try:
                with st.spinner("Understanding the task, selecting any necessary evidence, and validating the response..."):
                    result = ca.answer_turn(
                        client,
                        prompt,
                        mode=selected_mode,
                        history=prior_history,
                        state=st.session_state.dual_chat_state,
                    )
                st.markdown(result.answer)
                meta = {
                    "route": result.route,
                    "blockchain_route": result.blockchain_route,
                    "plan": result.plan,
                    "evidence": result.evidence,
                    "provenance": result.provenance,
                    "model_metrics": result.model_metrics,
                    "effective_question": result.effective_question,
                }
                render_assistant_metadata(meta)
                st.session_state.dual_chat_messages.append(
                    {"role": "assistant", "content": result.answer, "meta": meta}
                )
                st.session_state.dual_chat_state = result.state
            except Exception as exc:
                error_text = f"The assistant could not complete this turn: {exc}"
                st.error(error_text)
                st.session_state.dual_chat_messages.append(
                    {
                        "role": "assistant",
                        "content": error_text,
                        "meta": {
                            "route": "error",
                            "provenance": {"notice": "No analytical result was produced."},
                        },
                    }
                )

# ----------------------------------------------------------- Blockchain
elif page == "Governance & Audit Control":
    from blockchain_page import render as render_blockchain_page

    render_blockchain_page()
