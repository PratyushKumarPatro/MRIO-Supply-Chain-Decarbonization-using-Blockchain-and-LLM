Historical release guides, ready-status files, validation reports, release
notes, and manifests are retained here for traceability. They are not current
U20 operating authorities. See README_START_HERE.txt and the U20 files at the
deployment root for current instructions. U17_BUILD_MANIFEST_SHA256.txt,
U18_BUILD_MANIFEST_SHA256.txt, and U19_BUILD_MANIFEST_SHA256.txt preserve their
respective package inventories for historical checksum and file-inventory
traceability.
