# U16 logic-consolidation report

U16 is the consolidation release following the U15 redundancy audit.

## Consolidations completed

1. **One formal intervention funnel.** The U15 structural, automatically compatible,
   and actionable portfolio sequence is replaced by one actionability-verified,
   overlap-aware governance-ready portfolio.
2. **No tautological compatibility gate.** A mechanism is deterministically mapped
   from the hotspot's primary adverse node-SDA driver. Pair/mechanism feasibility is
   assessed separately and can fail.
3. **Legacy top-15 DLI authority retired.** The legacy intervention module is
   fail-closed and archived under `assurance_history/legacy_modules`.
4. **Direct intensity scenarios isolated.** The scenario page is explicitly an
   optional direct-intensity sensitivity and cannot authorize a formal intervention.
5. **Dual 80-percent claims corrected.** Structural portfolios report coverage of
   both the hotspot set and the complete focal-company footprint.
6. **CDR family labelled correctly.** Producer linkage and HSI are explicitly
   CDR-derived explanatory evidence, not independent scores.
7. **Authoritative node SDA separated from path allocation.** The path-derived output
   is named `represented_path_effect_allocation_by_node.csv` and is not used as a
   competing node-SDA authority.
8. **Actionability normalized.** Reusable organizational authority is stored at the
   leverage-node level; hotspot/mechanism technical feasibility remains pair-specific.
9. **Governance options split by mechanism.** Options are grouped by leverage node and
   mechanism family rather than leverage node alone.
10. **AURORA positioned as parallel.** It remains regional sourcing intelligence and
    is not presented as a universal screen for every intervention.
11. **Single shared code authority.** Streamlit analytical modules are small bridges
    to root implementations, eliminating divergent duplicate logic.
12. **Repeated MRIO work reduced.** File-fingerprint-aware process caches reuse annual
    MRIO states and focal-demand vectors until an input promotion invalidates them.
13. **Import-time patching disabled.** Evidence joins occur explicitly in the
    orchestration/integration service.
14. **Robustness authority clarified.** `critic_robustness.py` is the active runtime
    engine; the older DLI sensitivity implementation is retained in validation tools.
15. **Historical release assertions archived.** Superseded tests and legacy modules
    are preserved under `assurance_history` but excluded from current discovery.

## New integration completed

- all signed node-SDA and path-SDA effects are retained;
- the largest positive effect is the primary adverse intervention driver;
- negative effects are treated as beneficial/offsetting evidence;
- exact complete ordered path identity is used across years;
- the union of annual path identities is evaluated under both MRIO states;
- common nodes may follow different paths;
- persistent, emerging, disappearing, and reconfigured routes are reported;
- bounded-SPA beam membership is reported separately from physical path evaluation;
- node SDA is the primary producer-driver authority and path SDA is the mechanism
  drill-down used in downstream evidence synthesis.

## Preserved authorities

MRIO carbon accounting, bounded SPA, four-factor 24-permutation SDA, BC, PR, CDR,
IC, pooled Pearson-CRITIC weighting, DLI, producer-resolved linkage, exact Otsu,
Pareto logic, Solidity contracts, Oracle authority, blockchain role controls, and
LLM numerical-authority boundaries remain preserved.
