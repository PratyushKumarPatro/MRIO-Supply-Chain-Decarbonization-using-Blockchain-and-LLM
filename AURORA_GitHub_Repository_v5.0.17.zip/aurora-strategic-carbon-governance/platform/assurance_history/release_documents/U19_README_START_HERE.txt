STRATEGIC CARBON INTELLIGENCE & GOVERNANCE PLATFORM v5.0.17-U19
================================================================

This is the complete U19 Windows deployment package. It implements the agreed
methodological order and is not an in-place patch. U19 changes the deployed
Solidity lifecycle, so extract it into a clean directory, start a clean Ganache
session, compile the included contract source, and launch with -Reset.

Formal platform name: Strategic Carbon Intelligence & Governance Platform.
The deployable Solidity source is contracts\StrategicCarbonIntelligenceSystem.sol,
and the stakeholder event monitor is included in the governed runtime.
AURORA means Analogue-based Upstream Regional Opportunity and Resilience Assessment.

Use the exact installation sequence in:

    U19_WINDOWS_DEPLOYMENT_COMMANDS_UNCHANGED.txt

Do not copy deployment.json, contract_build, runtime, .venv, node_modules, or
contract addresses from U18 or any earlier package. Earlier bytecode does not
enforce the U19 sequence.

U19 methodological sequence
----------------------------
1. Register the focal company, authorized Oracles, and stakeholder roles.
2. Upload, validate, and promote the MRIO workbook.
3. Upload, validate, and promote the focal-company demand workbook.
4. Calculate MRIO footprint and producer-origin evidence for 2014 and 2017.
5. Run bounded Structural Path Analysis for each year. Report the minimum
   contribution-ranked prefix of whole paths that reaches at least 87% of the
   complete focal-company footprint. The number of displayed paths is an output,
   not a fixed limit.
6. Run company and all-node Structural Decomposition Analysis, and calculate
   exact union-path SDA from the complete bounded annual path artifacts.
7. Integrate annual SPA and SDA evidence using exact path identities, route
   transitions, producer hotspots, and signed drivers without creating another
   composite score. Operationally, the final union-path and integrated artifacts
   are materialized during the 2017 pooled Network fulfillment because they
   consume the completed pooled CRITIC evidence; their calculations remain
   deterministic and pre-AURORA.
8. Construct the directed carbon-governance network from the MRIO transaction
   structure.
9. Calculate BC, PageRank, CDR, IC, and producer-resolved dependency evidence for
   the complete node universe.
10. Complete Network analysis for 2014 before 2017. Pool both annual criterion
    tables, apply common normalization, derive one authoritative Pearson-CRITIC
    weight vector, and rank both years on that common basis.
11. Produce temporal DLI evidence and retain 2017 as the decision year.
12. Run and fulfill AURORA immediately after the temporal Network/DLI evidence is
    complete and current. AURORA does not require an intervention selection,
    Oracle verification, approval, or rejection.
13. After AURORA fulfillment, perform stakeholder actionability assessment,
    deterministic mechanism mapping, portfolio preparation, and optional formal
    intervention preparation.
14. Optionally propose, Oracle-verify, approve, or reject governance-ready
    mechanism-specific interventions on-chain.
15. Deploy QueryManagement after current temporal DLI and the active 2017 AURORA
    result are verified. Intervention selection and intervention decisions do not
    gate QueryManagement.
16. Use the LLM only to retrieve, explain, and synthesize verified governed
    evidence. It cannot recalculate authoritative results or change lifecycle
    state.
17. Monitor implementation and rerun the governed evidence chain whenever inputs
    change.

What U19 corrects
-----------------
- AURORA is a mandatory post-temporal-DLI regional evidence stage rather than a
  branch running in parallel with intervention governance.
- Formal intervention proposals are opened after a fulfilled active AURORA result.
- QueryManagement requires current temporal DLI and AURORA evidence only; an empty,
  selected, pending, approved, or rejected intervention portfolio cannot lock it.
- A failed AURORA request may be retried. Pending and fulfilled requests cannot be
  duplicated.
- If AURORA is fulfilled but intervention-evidence materialization fails, the
  dedicated post-AURORA retry rebuilds only the CID-bound intervention register.
  It preserves the verified Network/DLI result, AURORA result, and any valid
  QueryManagement state; the optional register cannot become a Query gate.
- Governed 2017 Network/DLI requires a fulfilled 2014 result, and AURORA is bound
  to the corresponding fulfilled two-year evidence.
- Multiple mechanism-specific options may be retained for one node while an exact
  node-plus-option duplicate remains prohibited.
- Query submission pauses when its analytical inputs become stale.
- The assistant retrieves the fulfilled CID-verified AURORA result instead of
  silently recomputing regional opportunity evidence.
- The guided Streamlit lifecycle and Data Orchestrator enforce the analytical
  readiness boundary for QueryManagement. The QueryManagement Solidity contract
  records and audits query transactions but has no standalone evidence gate.

Preserved methodology
---------------------
- U17 dynamic 87%-of-total SPA reporting and complete bounded-path downstream
  authority.
- U16 signed node/path-SDA interpretation, producer linkage, deterministic
  mechanism mapping, actionability, and overlap-aware intervention governance.
- U11 pooled Pearson-CRITIC DLI. Legacy fixed DLI weights are not authoritative
  and are not used to create governed results.
- Existing AURORA eligibility, exact Otsu similarity calibration, Pareto logic,
  stability logic, and decision-trace reporting.

Methodological boundaries
-------------------------
- The 87% SPA target uses the complete focal-company footprint as denominator.
  The final path is kept whole, so achieved coverage may slightly exceed 87%.
- If the initial bounded path universe cannot reach the target, U19 expands the
  screen deterministically within fixed resource bounds. If the final attempt
  still falls short, the SPA request fails and downstream stages remain locked;
  no below-target or synthetic path result is governed.
- The active-year top-15 hotspot share motivates the 87% reporting target but is
  reported separately and is not a terminal-node filter for path eligibility.
- AURORA supplies mandatory regional investigation evidence before formal
  governance. Its scores do not numerically generate the current deterministic
  intervention mechanisms, which remain based on signed SDA, linkage, leverage,
  and documented actionability.
- Structural coverage is not predicted or guaranteed real-world abatement.
- CRITIC captures contrast and non-redundancy in the observed pooled criterion
  matrix; it does not prove universal managerial importance.

Conceptual and operational stage numbering
------------------------------------------
The methodology has 17 conceptual stages; the Streamlit deployment workspace
has 14 operational stages. The operational interface separates contract and
role transactions and groups related calculations, so the counts are not meant
to match one-for-one:

    conceptual 1       -> Streamlit 1-4
    conceptual 2       -> Streamlit 5
    conceptual 3       -> Streamlit 6
    conceptual 4       -> Streamlit 7
    conceptual 5       -> Streamlit 8
    conceptual 6       -> Streamlit 8, with union-path materialization in 10
    conceptual 7       -> Streamlit 10
    conceptual 8-11    -> Streamlit 9-10
    conceptual 12      -> Streamlit 11
    conceptual 13-14   -> Streamlit 12
    conceptual 15      -> Streamlit 13-14
    conceptual 16      -> Streamlit 14
    conceptual 17      -> Streamlit 14 and continuous Governance & Audit monitoring

Validation after deployment
---------------------------
With Ganache and the U19 services running and QueryManagement deployed, run:

    .\.venv\Scripts\python.exe .\validate_u19_runtime_methodology.py --output .\u19_runtime_methodology_validation.json

This live audit checks the deployed methodology, including ordered Network/DLI,
active AURORA binding, Query readiness, and post-AURORA recovery behavior. An
empty or undecided intervention portfolio is informational, not a failure. The
standalone analytical validator does not by itself validate AURORA.

Current U19 documents
---------------------
- U19_COHERENT_METHODOLOGY_LIFECYCLE_GUIDE.txt
- U19_FINAL_METHODOLOGICAL_DIAGRAM.txt
- U19_METHODOLOGY_DEPLOYMENT_CROSSWALK.json
- U19_WINDOWS_DEPLOYMENT_COMMANDS_UNCHANGED.txt
- VALIDATION_EXPANSION_U19_RELEASE_NOTES.txt
- PLATFORM_IDENTITY_AND_AURORA_GUIDE.txt
- VALIDATION_PROTOCOL_ANALYTICAL_COMPUTATIONAL_DECISION_SUPPORT.txt
- DLI_WEIGHT_SENSITIVITY_GUIDE.txt
- OTSU_AND_IN_APP_DLI_ROBUSTNESS_GUIDE.txt
- INTERVENTION_PORTFOLIO_GUIDE.txt
- QUERY_RESULT_AUDIT_GUIDE.txt

Release identities
------------------
The U19 lifecycle is identified by:

    methodology_lifecycle_extension_id=v5.0.17-U19

The preserved analytical and governance identities remain:

    spa_reporting_extension_id=v5.0.17-U17
    intervention_governance_extension_id=v5.0.17-U16
    dli_objective_weighting_extension_id=v5.0.17-U11-pooled-critic-only
    aurora_lifecycle_extension_id=v5.0.17-U18

U18 and earlier release-specific records are retained only under
assurance_history\release_documents.

Native Windows boundary
-----------------------
This package is validated offline and through clean-extraction checks. The final
combination of Windows PowerShell, online Python and npm installation, Ganache,
Web3 deployment, Streamlit, Oracle services, and Ollama must execute on the
target Windows computer.
