Historical regression suites preserved for release-audit purposes.

These suites assert byte identity and release identifiers for superseded U13-U15 or
pre-U16 UI patch surfaces. They are intentionally outside current unittest/pytest
discovery because U16 consolidates duplicate modules into root-authoritative
implementations with Streamlit compatibility bridges, retires the top-15 DLI
intervention authority, and replaces the U15 multi-portfolio funnel with one U16
governance-ready portfolio. Current release behavior is covered by
../../tests/test_u16_final_integrated_methodology.py and the retained generic tests.
