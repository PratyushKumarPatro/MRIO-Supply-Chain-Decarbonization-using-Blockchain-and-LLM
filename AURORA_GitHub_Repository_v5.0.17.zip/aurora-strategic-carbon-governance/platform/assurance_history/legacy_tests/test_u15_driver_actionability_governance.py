"""Numerical, evidence-control, UI, and release tests for v5.0.17-U15."""
from __future__ import annotations

import hashlib
import json
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace
from typing import Any

import numpy as np
import pandas as pd

import cdr_producer_linkage as cdr_linkage
import hotspot_leverage as hotspot
import intervention_governance as u15
import node_sda_engine as node_sda
from critic_dli_core import CRITERIA
from tests.test_u14_node_sda_hotspot_leverage import (
    _fixture,
    _joint_counterfactual_hotspot_reduction,
)

ROOT = Path(__file__).resolve().parents[1]


def _evidence():
    base, y0, comparison, y1, ranking = _fixture()
    node_result = node_sda.compute_node_wise_sda(
        base, y0, comparison, y1, hotspot_threshold=0.80
    )
    linkage = cdr_linkage.compute_cdr_producer_linkage(comparison, y1)
    hotspot_result = hotspot.compute_hotspot_leverage(
        comparison,
        y1,
        linkage,
        node_result.frame,
        ranking,
        hotspot_threshold=0.80,
        high_dli_quantile=0.75,
        target_coverage=0.80,
    )
    return base, y0, comparison, y1, ranking, node_result, linkage, hotspot_result


def _verified_assessment(reference: str = "DOC-001") -> dict[str, str]:
    record = {field: "Yes" for field in u15.ACTIONABILITY_FIELDS}
    record.update(
        {
            "assessor_name": "Named sustainability manager",
            "assessor_role": "Focal-company accountable owner",
            "evidence_reference": reference,
            "assessment_notes": "Documented for release testing.",
        }
    )
    return record


def _content_store():
    stored: dict[str, dict[str, Any]] = {}

    def store(payload: Any, namespace: str) -> str:
        body = json.dumps(
            {"namespace": namespace, "payload": payload},
            sort_keys=True,
            separators=(",", ":"),
            default=str,
        ).encode("utf-8")
        cid = hashlib.sha256(body).hexdigest()
        stored[cid] = {"namespace": namespace, "payload": payload}
        return cid

    return stored, store


class U15DriverActionabilityGovernanceTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        (
            cls.base,
            cls.y0,
            cls.comparison,
            cls.y1,
            cls.ranking,
            cls.node_result,
            cls.linkage,
            cls.hotspot_result,
        ) = _evidence()
        cls.hashes = {"mrio": "a" * 64, "focal_demand": "b" * 64}

    def _initial(self):
        return u15.compute_intervention_governance(
            self.comparison,
            self.y1,
            self.hotspot_result.pair_evidence,
            target_coverage=0.80,
            source_network_result_cid="c" * 64,
            input_hashes=self.hashes,
        )

    def test_candidate_universe_is_direct_hotspots_plus_high_dli_mediated_positive_links(self):
        result = self._initial()
        candidates = result.candidates
        self.assertFalse(candidates.empty)
        for row in candidates.itertuples():
            self.assertGreater(float(row.avoided_hotspot_footprint_tco2), 0.0)
            if row.intervention_route == "direct":
                self.assertEqual(row.intervention_node, row.hotspot_producer_node)
            else:
                self.assertEqual(row.intervention_route, "governance-mediated")
                self.assertTrue(bool(row.intervention_is_high_dli))
                self.assertNotEqual(row.intervention_node, row.hotspot_producer_node)
        low_dli_nonhotspot = self.hotspot_result.pair_evidence.loc[
            ~self.hotspot_result.pair_evidence["intervention_is_high_dli"].astype(bool)
            & ~self.hotspot_result.pair_evidence["intervention_is_direct_hotspot"].astype(bool),
            "intervention_node",
        ].astype(str)
        self.assertTrue(set(candidates["intervention_node"]).isdisjoint(set(low_dli_nonhotspot)))

    def test_csv_boolean_false_is_not_treated_as_true(self):
        frame = self.hotspot_result.pair_evidence.copy()
        frame["intervention_is_high_dli"] = frame["intervention_is_high_dli"].map(
            {True: "True", False: "False"}
        )
        candidates = u15.build_pair_candidates(frame)
        for row in candidates.loc[candidates["intervention_route"].eq("governance-mediated")].itertuples():
            source = frame.loc[
                frame["intervention_node"].astype(str).eq(str(row.intervention_node))
                & frame["hotspot_producer_node"].astype(str).eq(str(row.hotspot_producer_node))
            ].iloc[0]
            self.assertEqual(str(source["intervention_is_high_dli"]), "True")

    def test_hotspot_sda_driver_controls_the_deterministic_mechanism(self):
        candidates = self._initial().candidates
        for row in candidates.itertuples():
            driver = str(row.hotspot_dominant_driver).lower()
            self.assertIn(driver, u15.MECHANISM_LIBRARY)
            expected = u15.MECHANISM_LIBRARY[driver]
            self.assertEqual(row.mechanism_code, expected["mechanism_code"])
            self.assertEqual(row.driver_compatibility_status, "Compatible")
            self.assertIn(driver, row.driver_compatibility_basis)

    def test_unknown_driver_is_retained_as_insufficient_evidence_not_invented(self):
        frame = self.hotspot_result.pair_evidence.copy()
        frame["hotspot_dominant_driver"] = "unknown"
        candidates = u15.build_pair_candidates(frame)
        self.assertTrue(candidates["driver_compatibility_status"].eq("Insufficient evidence").all())
        result = u15.compute_intervention_governance(
            self.comparison, self.y1, frame, input_hashes=self.hashes
        )
        self.assertTrue(result.portfolios["driver_compatible"].frame.empty)
        self.assertTrue(result.governance_options.empty)

    def test_no_positive_pair_candidates_is_a_safe_empty_result(self):
        frame = self.hotspot_result.pair_evidence.copy()
        frame["avoided_hotspot_footprint_tco2"] = 0.0
        frame["hotspot_reduction_fraction"] = 0.0
        result = u15.compute_intervention_governance(
            self.comparison, self.y1, frame, input_hashes=self.hashes
        )
        self.assertTrue(result.candidates.empty)
        self.assertTrue(result.eligibility.empty)
        self.assertTrue(result.governance_options.empty)
        for portfolio in result.portfolios.values():
            self.assertTrue(portfolio.frame.empty)

    def test_initial_state_never_assumes_actionability(self):
        result = self._initial()
        self.assertTrue(result.assessments["assessment_status"].eq("Not yet assessed").all())
        self.assertTrue(result.eligibility["governance_eligibility_status"].eq("Not yet eligible").all())
        self.assertTrue(result.portfolios["actionability_verified"].frame.empty)
        self.assertTrue(result.governance_options.empty)

    def test_actionability_status_requires_feasibility_owner_resources_influence_assurance_and_evidence(self):
        verified = _verified_assessment()
        status, _ = u15.assess_actionability(verified)
        self.assertEqual(status, "Verified actionable")
        for required in (
            "technical_feasibility_confirmed",
            "implementation_owner_identified",
            "resource_or_budget_path_identified",
        ):
            failed = dict(verified)
            failed[required] = "No"
            self.assertEqual(u15.assess_actionability(failed)[0], "Not actionable")
        missing_evidence = dict(verified)
        missing_evidence["evidence_reference"] = ""
        self.assertEqual(u15.assess_actionability(missing_evidence)[0], "Conditionally actionable")
        no_assurance = dict(verified)
        no_assurance["emissions_disclosure_right"] = "No"
        no_assurance["audit_or_verification_right"] = "No"
        self.assertNotEqual(u15.assess_actionability(no_assurance)[0], "Verified actionable")

    def test_nan_text_is_not_treated_as_documentary_evidence(self):
        record = {field: "Yes" for field in u15.ACTIONABILITY_FIELDS}
        record.update({field: np.nan for field in u15.ASSESSMENT_TEXT_FIELDS})
        self.assertNotEqual(u15.assess_actionability(record)[0], "Verified actionable")

    def test_only_verified_linked_and_driver_compatible_pair_is_formally_eligible(self):
        initial = self._initial()
        candidate_id = str(initial.candidates.iloc[0]["candidate_id"])
        assessments = u15.upsert_actionability_assessment(
            initial.candidates,
            initial.assessments,
            candidate_id,
            _verified_assessment(),
        )
        result = u15.compute_intervention_governance(
            self.comparison,
            self.y1,
            self.hotspot_result.pair_evidence,
            assessments=assessments,
            source_network_result_cid="c" * 64,
            input_hashes=self.hashes,
        )
        selected = result.eligibility.set_index("candidate_id").loc[candidate_id]
        self.assertEqual(selected["linkage_gate_status"], "Pass")
        self.assertEqual(selected["driver_compatibility_status"], "Compatible")
        self.assertEqual(selected["assessment_status"], "Verified actionable")
        self.assertEqual(selected["governance_eligibility_status"], u15.ELIGIBLE_STATUS)
        self.assertEqual(
            int(result.eligibility["governance_eligibility_status"].eq(u15.ELIGIBLE_STATUS).sum()),
            1,
        )

    def test_failed_or_unassessed_structural_candidate_is_excluded_and_remaining_eligible_node_is_recomputed(self):
        initial = self._initial()
        structural = initial.portfolios["structural"].frame
        self.assertGreaterEqual(len(structural), 2)
        first_structural = str(structural.iloc[0]["intervention_node"])
        alternatives = initial.candidates.loc[
            ~initial.candidates["intervention_node"].astype(str).eq(first_structural)
        ]
        self.assertFalse(alternatives.empty)
        candidate_id = str(alternatives.iloc[0]["candidate_id"])
        assessed_node = str(alternatives.iloc[0]["intervention_node"])
        assessments = u15.upsert_actionability_assessment(
            initial.candidates, initial.assessments, candidate_id, _verified_assessment("DOC-ALT")
        )
        result = u15.compute_intervention_governance(
            self.comparison,
            self.y1,
            self.hotspot_result.pair_evidence,
            assessments=assessments,
            source_network_result_cid="c" * 64,
            input_hashes=self.hashes,
        )
        actionable = result.portfolios["actionability_verified"].frame
        self.assertFalse(actionable.empty)
        self.assertEqual(str(actionable.iloc[0]["intervention_node"]), assessed_node)
        self.assertNotIn(first_structural, set(actionable["intervention_node"].astype(str)))

    def test_each_actionability_portfolio_row_matches_independent_joint_counterfactual(self):
        initial = self._initial()
        assessments = initial.assessments
        for index, candidate_id in enumerate(initial.candidates["candidate_id"].astype(str)):
            assessments = u15.upsert_actionability_assessment(
                initial.candidates,
                assessments,
                candidate_id,
                _verified_assessment(f"DOC-{index:03d}"),
            )
        result = u15.compute_intervention_governance(
            self.comparison,
            self.y1,
            self.hotspot_result.pair_evidence,
            assessments=assessments,
            source_network_result_cid="c" * 64,
            input_hashes=self.hashes,
        )
        hotspot_codes = self.hotspot_result.hotspot_nodes["node_code"].astype(str).tolist()
        selected: list[str] = []
        for _, row in result.portfolios["actionability_verified"].frame.iterrows():
            selected.append(str(row["intervention_node"]))
            reduction, baseline = _joint_counterfactual_hotspot_reduction(
                self.comparison, self.y1, selected, hotspot_codes
            )
            self.assertAlmostEqual(
                float(row["cumulative_full_hotspot_structural_reduction_tco2"]),
                reduction,
                places=9,
            )
            self.assertAlmostEqual(
                float(row["cumulative_full_hotspot_structural_coverage"]),
                reduction / baseline if baseline else 0.0,
                places=9,
            )

    def test_dli_is_tie_break_only_and_u15_does_not_create_a_fifth_criterion(self):
        self.assertEqual(tuple(CRITERIA), ("BC", "PR", "CDR", "IC"))
        critic_source = (ROOT / "critic_dli_core.py").read_text(encoding="utf-8")
        u15_source = (ROOT / "intervention_governance.py").read_text(encoding="utf-8")
        self.assertNotIn("node_delta_intensity", critic_source)
        self.assertNotIn("actionability", critic_source.lower())
        self.assertIn("DLI is tie-break only", u15_source)
        self.assertNotIn("weight_actionability", u15_source.lower())
        self.assertNotIn("weight_hsi", u15_source.lower())

    def test_governance_options_are_one_per_selected_node_and_bound_to_exact_evidence(self):
        initial = self._initial()
        first_node = str(initial.candidates.iloc[0]["intervention_node"])
        assessments = initial.assessments
        for index, row in initial.candidates.loc[
            initial.candidates["intervention_node"].astype(str).eq(first_node)
        ].iterrows():
            assessments = u15.upsert_actionability_assessment(
                initial.candidates,
                assessments,
                str(row["candidate_id"]),
                _verified_assessment(f"DOC-{index}"),
            )
        stored, store = _content_store()
        result = u15.compute_intervention_governance(
            self.comparison,
            self.y1,
            self.hotspot_result.pair_evidence,
            assessments=assessments,
            source_network_result_cid="c" * 64,
            input_hashes=self.hashes,
            store_content_fn=store,
        )
        options = result.governance_options
        self.assertEqual(len(options), options["node_code"].nunique())
        for row in options.itertuples():
            self.assertEqual(len(str(row.option_cid)), 64)
            payload = stored[str(row.option_cid)]["payload"]
            self.assertEqual(payload["extension_id"], "v5.0.17-U15")
            self.assertEqual(payload["source_network_result_cid"], "c" * 64)
            self.assertEqual(payload["input_hashes"], self.hashes)
            self.assertEqual(payload["option_fingerprint"], row.option_fingerprint)
            self.assertEqual(payload["intervention"]["governance_eligibility_status"], u15.ELIGIBLE_STATUS)

    def test_artifacts_are_hash_verified_and_tamper_evident(self):
        initial = self._initial()
        with tempfile.TemporaryDirectory() as directory:
            stored, store = _content_store()
            metadata = u15.write_intervention_governance_artifacts(
                directory,
                initial,
                input_hashes=self.hashes,
                source_network_result_cid="c" * 64,
                hotspot_leverage_evidence_cid="d" * 64,
                node_sda_evidence_cid="e" * 64,
                critic_evidence_cid="f" * 64,
                store_content_fn=store,
            )
            verified = u15.verify_intervention_governance_artifacts(
                directory,
                expected_input_hashes=self.hashes,
                expected_source_network_result_cid="c" * 64,
            )
            self.assertEqual(verified["extension_id"], "v5.0.17-U15")
            self.assertEqual(verified["governance_ready_option_count"], 0)
            self.assertEqual(len(verified["intervention_governance_evidence_cid"]), 64)
            target = Path(directory) / metadata["artifacts"]["eligibility"]["filename"]
            target.write_text(target.read_text(encoding="utf-8") + "\n", encoding="utf-8")
            with self.assertRaises(RuntimeError):
                u15.verify_intervention_governance_artifacts(directory, expected_input_hashes=self.hashes)

    def test_455_node_downstream_smoke_retains_all_nodes_but_only_selected_hotspot_pairs(self):
        n = 455
        codes = np.asarray([f"R{i:03d}-S" for i in range(n)])
        model = SimpleNamespace(
            year=2017,
            node_codes=codes,
            regions=np.asarray([f"R{i:03d}" for i in range(n)]),
            sectors=np.asarray(["S"] * n),
            fE=np.linspace(0.001, 0.003, n),
            L=np.diag(np.linspace(1.01, 1.05, n)),
        )
        demand = np.linspace(1.0, 455.0, n)
        pair_rows = []
        hotspots = [(codes[-1], 1, 20.0, "intensity"), (codes[-2], 2, 15.0, "technology")]
        for k, dli, rank, high in [(codes[0], 0.9, 1, True), (codes[-1], 0.5, 2, False), (codes[-2], 0.4, 3, False)]:
            for hotspot_code, h_rank, baseline, driver in hotspots:
                direct = k == hotspot_code
                avoided = 2.0 if (direct or high) else 0.0
                pair_rows.append({
                    "year": 2017,
                    "intervention_node": k,
                    "intervention_region": str(k).split("-")[0],
                    "intervention_sector": "S",
                    "intervention_DLI": dli,
                    "intervention_dli_rank": rank,
                    "intervention_is_high_dli": high,
                    "intervention_is_direct_hotspot": direct,
                    "hotspot_producer_node": hotspot_code,
                    "hotspot_producer_region": str(hotspot_code).split("-")[0],
                    "hotspot_producer_sector": "S",
                    "hotspot_rank": h_rank,
                    "baseline_hotspot_footprint_tco2": baseline,
                    "avoided_hotspot_footprint_tco2": avoided,
                    "hotspot_reduction_fraction": avoided / baseline,
                    "share_of_top80_hotspot_footprint": baseline / 35.0,
                    "hotspot_node_change_tco2": 1.0,
                    "hotspot_intensity_effect_tco2": 1.0 if driver == "intensity" else 0.0,
                    "hotspot_technology_effect_tco2": 1.0 if driver == "technology" else 0.0,
                    "hotspot_composition_effect_tco2": 0.0,
                    "hotspot_scale_effect_tco2": 0.0,
                    "hotspot_dominant_driver": driver,
                    "hotspot_dominant_driver_family": "production_structure" if driver == "technology" else driver,
                    "hotspot_temporal_status": "increased",
                })
        result = u15.compute_intervention_governance(
            model, demand, pd.DataFrame(pair_rows), input_hashes=self.hashes
        )
        self.assertEqual(result.hotspot_count, 2)
        self.assertGreater(len(result.candidates), 0)
        self.assertTrue(result.governance_options.empty)
        self.assertTrue(set(result.candidates["intervention_node"]).issubset(set(codes)))

    def test_release_ui_blockchain_server_and_llm_expose_u15_with_authority_boundaries(self):
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8-sig")
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        ui = (ROOT / "streamlit_app" / "intervention_governance_ui.py").read_text(encoding="utf-8")
        blockchain = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        assistant = (ROOT / "strategic_assistant.py").read_text(encoding="utf-8")
        llm = (ROOT / "llm_first_orchestrator.py").read_text(encoding="utf-8")
        self.assertIn("release_patch=u15-driver-actionability-governance", version)
        self.assertIn('"intervention_governance_extension": "v5.0.17-U15"', server)
        self.assertIn('elif path == "/v1/governance/intervention-actionability"', server)
        self.assertIn('$candidate.intervention_governance_extension -eq "v5.0.17-U15"', launcher)
        self.assertIn("render_intervention_governance_workspace", app)
        self.assertIn("Actionability assessment", ui)
        self.assertIn("Only node-level options", blockchain)
        self.assertIn('"intervention_governance"', assistant)
        self.assertIn("must never infer or assign actionability", llm.lower())

    def test_root_and_streamlit_u15_modules_are_byte_identical(self):
        for filename in (
            "intervention_governance.py",
            "strategic_assistant.py",
            "llm_first_orchestrator.py",
        ):
            self.assertEqual(
                (ROOT / filename).read_bytes(),
                (ROOT / "streamlit_app" / filename).read_bytes(),
                filename,
            )


if __name__ == "__main__":
    unittest.main(verbosity=2)
