"""Deployment stability and analytical-method preservation tests for v5.0.17-U15.

The historical filename is retained so older release tooling still discovers the
suite.  U15 is a downstream driver/actionability governance extension of U14;
it does not replace the U11 analytical-method authority, U13 producer linkage,
or U14 node-SDA/hotspot-leverage calculations.
"""
from __future__ import annotations

import ast
import hashlib
import json
import re
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _version_values() -> dict[str, str]:
    lines = (ROOT / "VERSION.txt").read_text(encoding="utf-8-sig").splitlines()
    values = {"version": lines[0].strip(), "package_name": lines[1].strip()}
    for line in lines[2:]:
        if "=" in line:
            key, value = line.split("=", 1)
            values[key.strip()] = value.strip()
    return values


def _dispatch_paths(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8-sig"))
    values: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Compare):
            for comparator in node.comparators:
                if (
                    isinstance(comparator, ast.Constant)
                    and isinstance(comparator.value, str)
                    and comparator.value.startswith("/v1/")
                ):
                    values.add(comparator.value)
    return values


class U15DeploymentAndMethodPreservationTests(unittest.TestCase):
    def test_u15_retains_u14_u13_u12_and_u11_authorities(self):
        values = _version_values()
        self.assertEqual(values["release_patch"], "u15-driver-actionability-governance")
        self.assertEqual(values["deployment_runtime_extension_id"], "v5.0.17-U12")
        self.assertEqual(values["methodology_release_id"], "v5.0.17-U11")
        self.assertEqual(values["integrated_methodology_extension_id"], "v5.0.17-U15")
        self.assertEqual(values["spa_pathway_relevance_extension_id"], "v5.0.17-U11")
        self.assertEqual(values["dli_objective_weighting_extension_id"], "v5.0.17-U11-pooled-critic-only")
        self.assertEqual(values["aurora_similarity_threshold_extension_id"], "v5.0.17-U11-exact-bin-free-otsu")
        self.assertEqual(values["dli_in_app_execution_extension_id"], "v5.0.17-U11")
        self.assertEqual(values["cdr_producer_linkage_extension_id"], "v5.0.17-U13")
        self.assertEqual(values["node_wise_sda_extension_id"], "v5.0.17-U14")
        self.assertEqual(values["hotspot_leverage_extension_id"], "v5.0.17-U14")
        self.assertEqual(values["intervention_governance_extension_id"], "v5.0.17-U15")
        self.assertEqual(values["node_wise_sda_role"], "primary-producer-temporal-attribution")
        self.assertEqual(values["path_sda_role"], "secondary-bounded-path-mechanism-drilldown")
        self.assertEqual(values["hotspot_leverage_role"], "structural-diagnostic-not-realized-abatement")
        self.assertEqual(values["intervention_governance_role"], "downstream-decision-control-not-a-dli-criterion")
        self.assertEqual(values["formal_intervention_source"], "u15-driver-compatible-actionability-verified-options-only")
        self.assertEqual(values["actionability_authority"], "stakeholder-attested-not-llm-inferred")
        self.assertEqual(values["additional_composite_score_created"], "false")

    def test_release_patch_has_one_authoritative_source(self):
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8-sig")
        self.assertEqual(len(re.findall(r"(?m)^release_patch=", version)), 1)
        release_identity = (ROOT / "release_identity.py").read_text(encoding="utf-8")
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        self.assertIn('RELEASE_PATCH = RELEASE_IDENTITY["release_patch"]', release_identity)
        self.assertIn('from release_identity import RELEASE_PATCH', server)
        self.assertIn('"release_patch": RELEASE_PATCH', server)
        self.assertIn('function Get-RqExpectedReleasePatch', launcher)
        self.assertIn('$candidate.release_patch -eq $ExpectedReleasePatch', launcher)
        self.assertNotIn('final-unit-ui-bounded-spa-1', launcher)

    def test_launcher_health_contract_covers_all_authoritative_extensions(self):
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        pairs = (
            ('"integrated_methodology_extension": "v5.0.17-U15"', '$candidate.integrated_methodology_extension -eq "v5.0.17-U15"'),
            ('"spa_pathway_relevance_extension": "v5.0.17-U11"', '$candidate.spa_pathway_relevance_extension -eq "v5.0.17-U11"'),
            ('"dli_objective_weighting_extension": "v5.0.17-U11-pooled-critic-only"', '$candidate.dli_objective_weighting_extension -eq "v5.0.17-U11-pooled-critic-only"'),
            ('"aurora_similarity_threshold_extension": "v5.0.17-U11-exact-bin-free-otsu"', '$candidate.aurora_similarity_threshold_extension -eq "v5.0.17-U11-exact-bin-free-otsu"'),
            ('"dli_in_app_execution_extension": "v5.0.17-U11"', '$candidate.dli_in_app_execution_extension -eq "v5.0.17-U11"'),
            ('"cdr_producer_linkage_extension": "v5.0.17-U13"', '$candidate.cdr_producer_linkage_extension -eq "v5.0.17-U13"'),
            ('"node_wise_sda_extension": "v5.0.17-U14"', '$candidate.node_wise_sda_extension -eq "v5.0.17-U14"'),
            ('"hotspot_leverage_extension": "v5.0.17-U14"', '$candidate.hotspot_leverage_extension -eq "v5.0.17-U14"'),
            ('"intervention_governance_extension": "v5.0.17-U15"', '$candidate.intervention_governance_extension -eq "v5.0.17-U15"'),
        )
        for server_text, launcher_text in pairs:
            with self.subTest(server_text=server_text):
                self.assertIn(server_text, server)
                self.assertIn(launcher_text, launcher)

    def test_launcher_forces_local_ports_used_by_the_unchanged_commands(self):
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        self.assertIn('$env:RPC_URL = "http://127.0.0.1:8545"', launcher)
        self.assertIn('$env:ORCHESTRATOR_URL = "http://127.0.0.1:8765"', launcher)
        self.assertIn('$env:ARTIFACT_DIR = $PSScriptRoot', launcher)
        self.assertNotIn('if (-not $env:ORCHESTRATOR_URL)', launcher)

    def test_launcher_waits_for_slow_imports_and_prints_failure_logs(self):
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        self.assertIn('for ($attempt = 0; $attempt -lt 90; $attempt++)', launcher)
        self.assertIn('-PassThru', launcher)
        self.assertIn('Get-Content -LiteralPath $logPath -Tail 80', launcher)
        self.assertIn('Invoke-RqNativeCommand', launcher)

    def test_project_local_python_is_authoritative(self):
        runtime = (ROOT / "python_runtime.ps1").read_text(encoding="utf-8")
        block = runtime.split('function Get-RqPythonPath', 1)[1].split('function Ensure-RqApplicationPython', 1)[0]
        self.assertIn('if (Test-RqVirtualEnvironment)', block)
        self.assertNotIn('$env:SCIG_PLATFORM_PYTHON -and', block)
        self.assertIn('matplotlib, requests', runtime)

    def test_npm_lock_is_clean_and_cross_platform_policy_is_local(self):
        package = json.loads((ROOT / "package.json").read_text(encoding="utf-8"))
        lock = json.loads((ROOT / "package-lock.json").read_text(encoding="utf-8"))
        self.assertEqual(lock["lockfileVersion"], 3)
        self.assertEqual(package["dependencies"], {"ganache": "7.9.2", "solc": "0.8.19"})
        self.assertEqual(lock["packages"][""]["dependencies"], package["dependencies"])
        self.assertFalse(any("fsevents" in key.lower() for key in lock.get("packages", {})))
        self.assertFalse(any(bool(value.get("extraneous")) for value in lock.get("packages", {}).values()))
        npmrc = {
            line.split("=", 1)[0].strip(): line.split("=", 1)[1].strip()
            for line in (ROOT / ".npmrc").read_text(encoding="utf-8").splitlines()
            if "=" in line
        }
        self.assertEqual(npmrc.get("omit"), "optional")
        self.assertEqual(npmrc.get("audit"), "false")
        self.assertEqual(npmrc.get("fund"), "false")

    def test_immutable_manifest_excludes_mutables_and_includes_u15_sources(self):
        manifest = (ROOT / "BUILD_MANIFEST_SHA256.txt").read_text(encoding="utf-8")
        listed = {
            line.split(maxsplit=1)[1].strip()
            for line in manifest.splitlines()
            if line and not line.startswith("#")
        }
        for mutable in (
            "package-lock.json", "deployment.json", "contract_build.json",
            "contracts/build/contract_build.json",
            "StrategicCarbonIntelligenceSystem_sol_Registration.abi",
            "StrategicCarbonIntelligenceSystem_sol_Registration.bin",
        ):
            self.assertNotIn(mutable, listed)
        for immutable in (
            ".npmrc", "package.json", "VERSION.txt", "release_identity.py",
            "start_dapp_lifecycle.ps1", "contracts/StrategicCarbonIntelligenceSystem.sol",
            "critic_dli_core.py", "spa_sda_pathway_bridge.py", "cdr_producer_linkage.py",
            "node_sda_engine.py", "hotspot_leverage.py", "intervention_governance.py",
            "streamlit_app/intervention_governance.py",
            "streamlit_app/intervention_governance_ui.py",
            "U15_DRIVER_ACTIONABILITY_GOVERNANCE_GUIDE.txt",
            "U14_SOURCE_BASELINE_SHA256.json", "U11_METHOD_BASELINE_SHA256.json",
            "tests/test_u15_driver_actionability_governance.py",
        ):
            self.assertIn(immutable, listed)

    def test_u14_source_changes_are_exactly_the_authorised_u15_surface(self):
        baseline = json.loads((ROOT / "U14_SOURCE_BASELINE_SHA256.json").read_text(encoding="utf-8"))
        self.assertEqual(int(baseline["file_count"]), len(baseline["files"]))
        self.assertEqual(
            baseline["source_archive_sha256"],
            "c5c0533ceb93b8a34ecdf212307219134cf9c4788e216f2383bfd32a36385ab8",
        )
        authorised_changes = {
            "BUILD_MANIFEST_SHA256.txt",
            "PLATFORM_DEPLOYMENT_COMMANDS.txt",
            "README_START_HERE.txt",
            "VERSION.txt",
            "data_orchestrator.py",
            "domain_knowledge.json",
            "llm_first_orchestrator.py",
            "orchestrator_server.py",
            "rag_documents.json",
            "release_identity.py",
            "start_dapp_lifecycle.ps1",
            "strategic_assistant.py",
            "streamlit_app/app.py",
            "streamlit_app/blockchain_page.py",
            "streamlit_app/data/domain_knowledge.json",
            "streamlit_app/data/rag_documents.json",
            "streamlit_app/data/system_knowledge.json",
            "streamlit_app/llm_first_orchestrator.py",
            "streamlit_app/strategic_assistant.py",
            "streamlit_app/system_knowledge.json",
            "system_knowledge.json",
            "test_aurora_decision_trace_reporting.py",
            "tests/test_u13_deployment_and_method_preservation.py",
        }
        observed_changes = set()
        for relative, expected in baseline["files"].items():
            path = ROOT / relative
            self.assertTrue(path.is_file(), relative)
            if _sha256(path) != expected:
                observed_changes.add(relative)
        self.assertEqual(observed_changes, authorised_changes)

    def test_u11_core_protected_files_remain_unchanged_except_declared_integration_files(self):
        baseline = json.loads((ROOT / "U11_METHOD_BASELINE_SHA256.json").read_text(encoding="utf-8"))
        authorised_changes = {
            "data_orchestrator.py", "domain_knowledge.json", "final_methodology_service.py",
            "final_methodology_ui.py", "llm_first_orchestrator.py", "network_engine.py",
            "rag_documents.json", "strategic_assistant.py", "streamlit_app/app.py",
            "streamlit_app/blockchain_page.py", "streamlit_app/data/domain_knowledge.json",
            "streamlit_app/data/rag_documents.json", "streamlit_app/data/system_knowledge.json",
            "streamlit_app/final_methodology_service.py", "streamlit_app/final_methodology_ui.py",
            "streamlit_app/llm_first_orchestrator.py", "streamlit_app/network_engine.py",
            "streamlit_app/strategic_assistant.py", "system_knowledge.json",
        }
        observed = {
            relative for relative, expected in baseline["files"].items()
            if _sha256(ROOT / relative) != expected
        }
        self.assertEqual(observed, authorised_changes)

    def test_u15_server_adds_only_the_actionability_endpoint_to_u14_endpoint_set(self):
        expected_u14 = {
            "/v1/content/get", "/v1/error", "/v1/governance/dli-robustness",
            "/v1/governance/final-methodology", "/v1/governance/intervention-proposal",
            "/v1/governance/network", "/v1/governance/sourcing-opportunities", "/v1/query",
            "/v1/registration/verify", "/v1/upstream/data-promote", "/v1/upstream/data-validate",
            "/v1/upstream/mrio", "/v1/upstream/sda", "/v1/upstream/spa",
        }
        observed = _dispatch_paths(ROOT / "orchestrator_server.py")
        self.assertEqual(observed - {"/v1/governance/intervention-actionability"}, expected_u14)
        self.assertEqual(observed - expected_u14, {"/v1/governance/intervention-actionability"})

    def test_core_analytical_and_solidity_sources_are_byte_identical_to_u14(self):
        baseline = json.loads((ROOT / "U14_SOURCE_BASELINE_SHA256.json").read_text(encoding="utf-8"))["files"]
        protected = (
            "analytics_engine.py", "cdr_producer_linkage.py", "critic_dli_core.py",
            "critic_robustness.py", "dli_weight_sensitivity.py", "hotspot_leverage.py",
            "network_engine.py", "node_sda_engine.py", "sda_engine.py", "spa_engine.py",
            "spa_sda_pathway_bridge.py", "sourcing_opportunity_engine.py",
            "contracts/StrategicCarbonIntelligenceSystem.sol",
        )
        for relative in protected:
            with self.subTest(relative=relative):
                self.assertEqual(_sha256(ROOT / relative), baseline[relative])

    def test_source_release_contains_no_stale_generated_deployment_state(self):
        self.assertFalse((ROOT / "deployment.json").exists())
        self.assertFalse((ROOT / "contract_build.json").exists())
        self.assertFalse((ROOT / "contracts" / "build").exists())
        self.assertFalse(any(ROOT.glob("*.abi")))
        self.assertFalse(any(ROOT.glob("*.bin")))

    def test_start_process_arguments_are_space_safe_and_stale_heartbeat_is_removed(self):
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        self.assertIn('"orchestrator_server.py"', launcher)
        self.assertIn('"--deployment", "deployment.json"', launcher)
        self.assertIn('"stakeholder_event_monitor.py"', launcher)
        self.assertIn('Remove-Item -LiteralPath $notificationHeartbeat', launcher)
        self.assertNotIn('(Join-Path $PSScriptRoot "orchestrator_server.py")', launcher)

    def test_exact_user_command_format_is_shipped_without_hotfix_step(self):
        guide = (ROOT / "U15_WINDOWS_DEPLOYMENT_COMMANDS_UNCHANGED.txt").read_text(encoding="utf-8")
        required = (
            'python -m venv .venv',
            r'.\.venv\Scripts\python.exe -m pip install -r .\requirements.txt -r .\streamlit_app\requirements.txt',
            'npm install', 'npm install solc@0.8.19 --save-exact', 'npm run compile',
            'npx ganache -p 8545 --wallet.totalAccounts 10',
            r'powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File .\start_dapp_lifecycle.ps1 -Reset',
        )
        for command in required:
            self.assertIn(command, guide)
        self.assertIn("U15_DRIVER_ACTIONABILITY_GOVERNANCE_FINAL_DEPLOYABLE.zip", guide)
        self.assertNotIn('PATCH_ORIGINAL', guide)
        self.assertNotIn('MAKE_FIXED', guide)

    def test_u15_release_files_are_present(self):
        required = (
            "intervention_governance.py",
            "streamlit_app/intervention_governance.py",
            "streamlit_app/intervention_governance_ui.py",
            "U15_WINDOWS_DEPLOYMENT_COMMANDS_UNCHANGED.txt",
            "U15_DRIVER_ACTIONABILITY_GOVERNANCE_GUIDE.txt",
            "U15_WINDOWS_DEPLOYMENT_VALIDATION_REPORT.txt",
            "U15_FINAL_READY_STATUS.json",
            "VALIDATION_EXPANSION_U15_RELEASE_NOTES.txt",
            "tests/test_u15_driver_actionability_governance.py",
        )
        for relative in required:
            with self.subTest(relative=relative):
                self.assertTrue((ROOT / relative).is_file())


if __name__ == "__main__":
    unittest.main(verbosity=2)
