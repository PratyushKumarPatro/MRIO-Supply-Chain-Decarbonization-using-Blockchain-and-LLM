"""Validation for the inherited future-MRIO placeholder and preserved v5.0.17 core."""
from __future__ import annotations

import hashlib
import json
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent


class FutureMRIOPlaceholderUIPatchTests(unittest.TestCase):
    def test_stage_7_preserves_v17_cards_and_adds_future_placeholder(self):
        source = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        self.assertIn('"Stage 7 — Focal Company requests MRIO carbon accounting"', source)
        self.assertIn("columns = st.columns(3)", source)
        self.assertIn("for column, year in zip(columns[:2], [2014, 2017])", source)
        self.assertIn('st.markdown("### MRIO ...")', source)
        self.assertIn('st.info("Next compatible MRIO reference year")', source)
        self.assertIn("presentation-only placeholder", source.casefold())

    def test_critical_technical_sources_match_unmodified_v5_0_17_baseline(self):
        baseline = json.loads(
            (ROOT / "V5_0_17_UI_PATCH_TECHNICAL_BASELINE_SHA256.json").read_text(
                encoding="utf-8"
            )
        )
        approved_unit_context_changes = {
            "analytics_engine.py",
            "data_orchestrator.py",
            "streamlit_app/analytics_engine.py",
            "strategic_assistant.py",
            "streamlit_app/strategic_assistant.py",
            "sda_engine.py",
            "streamlit_app/sda_engine.py",
            "llm_first_orchestrator.py",
            "streamlit_app/llm_first_orchestrator.py",
            "orchestrator_server.py",
            "spa_engine.py",
            "streamlit_app/spa_engine.py",
            # U9 intentionally replaces the legacy fixed AURORA similarity
            # thresholds with exact bin-free Otsu calibration.
            "sourcing_opportunity_engine.py",
            "streamlit_app/sourcing_opportunity_engine.py",
            # U11 intentionally replaces the network and intervention logic with
            # pooled CRITIC-DLI and integrated SPA-SDA pathway relevance.
            "network_engine.py",
            "streamlit_app/network_engine.py",
            "intervention_rules.py",
            "streamlit_app/intervention_rules.py",
            "dapp_lifecycle.py",
        }
        approved_u6_validation_changes = {
            # Derived DLI robustness reports are removed whenever the accepted
            # analytical inputs change, so stale sensitivity evidence cannot
            # appear beside a newer governed Network/DLI result.
            "input_onboarding.py",
        }
        for relative_path, expected_hash in baseline["sha256"].items():
            if relative_path in approved_unit_context_changes | approved_u6_validation_changes:
                continue
            data = (ROOT / relative_path).read_bytes()
            actual_hash = hashlib.sha256(data).hexdigest()
            self.assertEqual(
                actual_hash,
                expected_hash,
                msg=f"Technical source changed unexpectedly: {relative_path}",
            )

    def test_patch_identity_preserves_v5_0_17_architecture(self):
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8")
        self.assertIn("5.0.17", version)
        self.assertIn("release_patch=u12-windows-deployment-stable", version)
        self.assertIn("aurora_similarity_threshold_extension_id=v5.0.17-U11-exact-bin-free-otsu", version)
        self.assertIn("dli_in_app_execution_extension_id=v5.0.17-U11", version)
        self.assertIn(
            "architecture_version=5.0.17-professional-identity-aurora-unified-solidity-stakeholder-notifications",
            version,
        )


if __name__ == "__main__":
    unittest.main(verbosity=2)
