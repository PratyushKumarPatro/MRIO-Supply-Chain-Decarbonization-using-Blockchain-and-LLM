"""Compatibility entry point for the validation-only DLI sensitivity utility.

The active in-application robustness authority is :mod:`critic_robustness`.
The larger historical sensitivity implementation is retained once under
``validation_tools`` for analytical assurance and backwards-compatible command
line use; it is not imported by the production Streamlit/orchestrator path.
"""
from pathlib import Path as _Path

_SOURCE = _Path(__file__).resolve().parent / "validation_tools" / "dli_weight_sensitivity_impl.py"
globals()["__file__"] = str(_Path(__file__).resolve())
exec(compile(_SOURCE.read_text(encoding="utf-8"), str(_SOURCE), "exec"), globals(), globals())
