"""Regression tests for the standalone DLI weight-sensitivity workflow."""
from __future__ import annotations

import json
import hashlib
import tempfile
import unittest
from contextlib import contextmanager
from pathlib import Path
from unittest import mock

import numpy as np
import pandas as pd

import dli_weight_sensitivity as sensitivity
import input_onboarding as onboarding


def fixture_frame() -> pd.DataFrame:
    frame = pd.DataFrame(
        [
            {"node_code": "ARE-a", "BC_norm": 0.95, "PR_norm": 0.30, "CDR_norm": 0.70, "IC_norm": 0.85},
            {"node_code": "BRA-b", "BC_norm": 0.20, "PR_norm": 0.95, "CDR_norm": 0.90, "IC_norm": 0.40},
            {"node_code": "CHN-c", "BC_norm": 0.65, "PR_norm": 0.80, "CDR_norm": 0.50, "IC_norm": 0.75},
            {"node_code": "DEU-d", "BC_norm": 0.40, "PR_norm": 0.55, "CDR_norm": 0.98, "IC_norm": 0.25},
            {"node_code": "EGY-e", "BC_norm": 0.10, "PR_norm": 0.20, "CDR_norm": 0.30, "IC_norm": 0.95},
            {"node_code": "FRA-f", "BC_norm": 0.50, "PR_norm": 0.45, "CDR_norm": 0.60, "IC_norm": 0.60},
        ]
    )
    weights = sensitivity.DECLARED_BASELINE_WEIGHTS
    frame["DLI"] = sum(weights[key] * frame[sensitivity.COMPONENT_COLUMNS[key]] for key in sensitivity.COMPONENTS)
    return frame


def _sha256(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


@contextmanager
def isolated_sensitivity_runtime(root: Path, expected_nodes: int):
    old = {
        "PACKAGE_ROOT": sensitivity.PACKAGE_ROOT,
        "RUNTIME_DIR": sensitivity.RUNTIME_DIR,
        "CONTENT_STORE_DIR": sensitivity.CONTENT_STORE_DIR,
        "SENSITIVITY_RUNTIME_DIR": sensitivity.SENSITIVITY_RUNTIME_DIR,
        "EXPECTED_RUNTIME_NODE_COUNT": sensitivity.EXPECTED_RUNTIME_NODE_COUNT,
    }
    try:
        sensitivity.PACKAGE_ROOT = root
        sensitivity.RUNTIME_DIR = root / "runtime"
        sensitivity.CONTENT_STORE_DIR = root / "content_store"
        sensitivity.SENSITIVITY_RUNTIME_DIR = sensitivity.RUNTIME_DIR / "dli_sensitivity"
        sensitivity.EXPECTED_RUNTIME_NODE_COUNT = expected_nodes
        yield
    finally:
        for name, value in old.items():
            setattr(sensitivity, name, value)


def write_runtime_fixture(
    root: Path,
    frame: pd.DataFrame,
    *,
    payload_year: int = 2017,
    payload_hashes: dict[str, str] | None = None,
    cid_name: str | None = None,
    update_csv_metadata_hash: bool = True,
) -> tuple[str, dict[str, str]]:
    """Create a minimal active runtime backed by a content-addressed response."""
    hashes = {
        "mrio": _sha256(b"accepted mrio workbook"),
        "focal_demand": _sha256(b"accepted focal workbook"),
    }
    for key, filename, body in (
        ("mrio", "input_mrio_completed.xlsx", b"accepted mrio workbook"),
        ("focal_demand", "Focal_Company_Demand_Converted.xlsx", b"accepted focal workbook"),
    ):
        (root / filename).write_bytes(body)
    runtime = root / "runtime"
    active_inputs = runtime / "active_inputs"
    active_inputs.mkdir(parents=True)
    active_inputs.joinpath("active_inputs.json").write_text(
        json.dumps(
            {
                key: {"status": "active", "sha256": value, "activated_at_utc": "2026-08-31T00:00:00Z"}
                for key, value in hashes.items()
            }
        ),
        encoding="utf-8",
    )
    payload = {
        "year": int(payload_year),
        "input_hashes": dict(payload_hashes or hashes),
        "dli_ranking": json.loads(frame.to_json(orient="records")),
    }
    envelope = {
        "namespace": "network_and_dli_analysis",
        "stored_at_utc": "2026-08-31T00:00:00Z",
        "payload": {
            "operation": "network_and_dli_analysis",
            "generated_at_utc": "2026-08-31T00:00:00Z",
            "payload": payload,
        },
    }
    body = json.dumps(envelope, indent=2, sort_keys=True).encode("utf-8")
    cid = cid_name or _sha256(body)
    content_store = root / "content_store"
    content_store.mkdir()
    (content_store / f"{cid}.json").write_bytes(body)
    (content_store / cid).write_bytes(body)
    active = runtime / "active_analytics"
    active.mkdir()
    csv_path = active / "dli_2017.csv"
    frame.to_csv(csv_path, index=False)
    metadata = {
        "kind": "dli",
        "year": 2017,
        "input_hashes": hashes,
        "frame_sha256": _sha256(csv_path.read_bytes()) if update_csv_metadata_hash else "0" * 64,
        "source_result_cid": cid,
        "generated_at_utc": "2026-08-31T00:00:00Z",
    }
    csv_path.with_suffix(".json").write_text(json.dumps(metadata), encoding="utf-8")
    runtime.joinpath("result_index.json").write_text(
        json.dumps(
            {
                "results": {
                    "network:2017": {
                        "content_hash": cid,
                        "input_hashes": hashes,
                        "generated_at_utc": "2026-08-31T00:00:00Z",
                    }
                }
            }
        ),
        encoding="utf-8",
    )
    return cid, hashes


class DLIWeightSensitivityTests(unittest.TestCase):
    def setUp(self) -> None:
        self.frame = fixture_frame()

    def test_baseline_reconstructs_and_does_not_mutate_input(self):
        original = self.frame.copy(deep=True)
        result = sensitivity.analyse_weight_sensitivity(
            self.frame,
            baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
            top_k=3,
            monte_carlo_samples=12,
            random_seed=7,
        )
        self.assertTrue(self.frame.equals(original))
        self.assertLess(result["baseline_integrity"]["existing_dli_max_abs_difference"], 1e-12)
        ranked = result["baseline_ranking"]
        self.assertEqual(set(ranked["node_code"]), set(self.frame["node_code"]))
        self.assertTrue(np.allclose(ranked["DLI_sensitivity"].to_numpy(), ranked["DLI"].to_numpy()))

    def test_rebalance_preserves_sum_and_other_weight_ratios(self):
        base = sensitivity.DECLARED_BASELINE_WEIGHTS
        changed = sensitivity.rebalanced_weights(base, "CDR", 0.40)
        self.assertAlmostEqual(sum(changed.values()), 1.0)
        self.assertAlmostEqual(changed["CDR"], 0.40)
        self.assertAlmostEqual(changed["BC"] / changed["PR"], base["BC"] / base["PR"])
        self.assertAlmostEqual(changed["PR"] / changed["IC"], base["PR"] / base["IC"])

    def test_one_way_design_has_baseline_and_sixteen_unique_perturbations(self):
        scenarios = sensitivity.one_way_weight_scenarios(sensitivity.DECLARED_BASELINE_WEIGHTS)
        self.assertEqual(len(scenarios), 17)
        self.assertEqual(scenarios[0][0], "baseline")
        self.assertTrue(all(abs(sum(weights.values()) - 1.0) < 1e-10 for _, _, weights in scenarios))

    def test_monte_carlo_sampling_is_reproducible_and_feasible(self):
        first = sensitivity.dirichlet_weight_scenarios(
            sensitivity.DECLARED_BASELINE_WEIGHTS, samples=20, concentration=80.0, seed=42
        )
        second = sensitivity.dirichlet_weight_scenarios(
            sensitivity.DECLARED_BASELINE_WEIGHTS, samples=20, concentration=80.0, seed=42
        )
        self.assertEqual(first, second)
        self.assertTrue(all(abs(sum(weights.values()) - 1.0) < 1e-9 for weights in first))
        self.assertTrue(all(all(value >= 0 for value in weights.values()) for weights in first))

    def test_ties_break_by_node_code(self):
        tied = pd.DataFrame(
            [
                {"node_code": "ZZZ-z", "BC_norm": 1.0, "PR_norm": 0.0, "CDR_norm": 0.0, "IC_norm": 0.0, "DLI": 0.25},
                {"node_code": "AAA-a", "BC_norm": 1.0, "PR_norm": 0.0, "CDR_norm": 0.0, "IC_norm": 0.0, "DLI": 0.25},
            ]
        )
        ranked = sensitivity.score_ranking(tied, sensitivity.DECLARED_BASELINE_WEIGHTS)
        self.assertEqual(ranked["node_code"].tolist(), ["AAA-a", "ZZZ-z"])

    def test_malformed_or_mismatched_input_is_rejected(self):
        missing = self.frame.drop(columns=["IC_norm"])
        with self.assertRaises(sensitivity.DLIWeightSensitivityError):
            sensitivity.validate_ranking(missing)
        broken = self.frame.copy()
        broken.loc[0, "DLI"] += 0.01
        with self.assertRaises(sensitivity.DLIWeightSensitivityError):
            sensitivity.analyse_weight_sensitivity(broken, top_k=3, monte_carlo_samples=0)
        nonfinite = self.frame.copy()
        nonfinite.loc[0, "CDR_norm"] = np.nan
        with self.assertRaises(sensitivity.DLIWeightSensitivityError):
            sensitivity.validate_ranking(nonfinite)
        null_node = self.frame.copy()
        null_node.loc[0, "node_code"] = None
        with self.assertRaises(sensitivity.DLIWeightSensitivityError):
            sensitivity.validate_ranking(null_node)
        case_duplicate = self.frame.copy()
        case_duplicate.loc[1, "node_code"] = "are-A"
        with self.assertRaises(sensitivity.DLIWeightSensitivityError):
            sensitivity.validate_ranking(case_duplicate)

    def test_node_stability_has_valid_probabilities_and_rank_ranges(self):
        result = sensitivity.analyse_weight_sensitivity(
            self.frame,
            baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
            top_k=3,
            monte_carlo_samples=30,
            random_seed=12,
        )
        stability = result["node_rank_stability"]
        self.assertEqual(len(stability), len(self.frame))
        self.assertTrue((stability["monte_carlo_rank_min"] <= stability["monte_carlo_rank_max"]).all())
        self.assertTrue(stability["monte_carlo_top3_inclusion_probability"].between(0.0, 1.0).all())
        self.assertTrue(stability["one_way_top3_inclusion_probability"].between(0.0, 1.0).all())

    def test_runtime_ranking_rejects_tampered_csv_even_when_metadata_hash_is_rewritten(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with isolated_sensitivity_runtime(root, len(self.frame)):
                write_runtime_fixture(root, self.frame)
                csv_path = sensitivity.RUNTIME_DIR / "active_analytics" / "dli_2017.csv"
                tampered = self.frame.copy()
                tampered.loc[0, "DLI"] = tampered.loc[0, "DLI"] - 0.01
                tampered.to_csv(csv_path, index=False)
                metadata_path = csv_path.with_suffix(".json")
                metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
                metadata["frame_sha256"] = _sha256(csv_path.read_bytes())
                metadata_path.write_text(json.dumps(metadata), encoding="utf-8")
                with self.assertRaises(sensitivity.DLIWeightSensitivityError):
                    sensitivity.load_active_runtime_ranking(2017)

    def test_runtime_ranking_rejects_invalid_cid_and_mismatched_cid_payload(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with isolated_sensitivity_runtime(root, len(self.frame)):
                write_runtime_fixture(root, self.frame, cid_name="c" * 64)
                with self.assertRaises(sensitivity.DLIWeightSensitivityError):
                    sensitivity.load_active_runtime_ranking(2017)
            root = Path(directory) / "payload_mismatch"
            root.mkdir()
            with isolated_sensitivity_runtime(root, len(self.frame)):
                write_runtime_fixture(root, self.frame, payload_year=2014)
                with self.assertRaises(sensitivity.DLIWeightSensitivityError):
                    sensitivity.load_active_runtime_ranking(2017)

    def test_runtime_result_writes_and_verifies_full_integrity_manifest(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            with isolated_sensitivity_runtime(root, len(self.frame)):
                cid, hashes = write_runtime_fixture(root, self.frame)
                frame, source, provenance = sensitivity.load_active_runtime_ranking(2017)
                result = sensitivity.analyse_weight_sensitivity(
                    frame,
                    baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
                    top_k=3,
                    monte_carlo_samples=4,
                    random_seed=1,
                )
                output = sensitivity.write_analysis_result(
                    result,
                    input_path=source,
                    year=2017,
                    provenance=provenance,
                )
                self.assertTrue((output / "report.md").is_file())
                self.assertTrue((output / "metadata.json").is_file())
                latest = sensitivity.SENSITIVITY_RUNTIME_DIR / "latest_2017.json"
                self.assertTrue(latest.is_file())
                self.assertEqual(json.loads(latest.read_text(encoding="utf-8"))["year"], 2017)
                loaded = sensitivity.load_latest_runtime_analysis(
                    2017,
                    expected_input_hashes=hashes,
                    expected_network_result_cid=cid,
                )
                self.assertEqual(loaded["metadata"]["year"], 2017)
                (output / "report.md").write_text("tampered", encoding="utf-8")
                with self.assertRaises(sensitivity.DLIWeightSensitivityError):
                    sensitivity.load_latest_runtime_analysis(
                        2017,
                        expected_input_hashes=hashes,
                        expected_network_result_cid=cid,
                    )

    def test_write_rejects_source_snapshot_race_and_external_is_not_published(self):
        result = sensitivity.analyse_weight_sensitivity(
            self.frame,
            baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
            top_k=3,
            monte_carlo_samples=0,
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "ranking.csv"
            self.frame.to_csv(source, index=False)
            provenance = {
                "source_type": "unmanaged_external_export",
                "source_snapshot_sha256": _sha256(source.read_bytes()),
                "source_ranking_sha256": sensitivity._ranking_snapshot_sha256(self.frame),
            }
            source.write_text("changed after snapshot", encoding="utf-8")
            with self.assertRaises(sensitivity.DLIWeightSensitivityError):
                sensitivity.write_analysis_result(result, input_path=source, year=2017, output_dir=root / "race", provenance=provenance)
            self.frame.to_csv(source, index=False)
            provenance["source_snapshot_sha256"] = _sha256(source.read_bytes())
            with isolated_sensitivity_runtime(root, len(self.frame)):
                output = sensitivity.write_analysis_result(result, input_path=source, year=2017, provenance=provenance)
                self.assertTrue(output.is_dir())
                self.assertFalse((sensitivity.SENSITIVITY_RUNTIME_DIR / "latest_2017.json").exists())

    def test_baseline_verification_fails_closed_when_network_engine_is_unavailable(self):
        with mock.patch.object(sensitivity.importlib, "import_module", side_effect=ImportError("broken engine")):
            with self.assertRaises(sensitivity.DLIWeightSensitivityError):
                sensitivity.deployment_baseline_weights()

    def test_build_manifest_verifies_every_curated_file(self):
        root = Path(__file__).resolve().parent
        manifest = root / "BUILD_MANIFEST_SHA256.txt"
        for line_number, line in enumerate(manifest.read_text(encoding="utf-8").splitlines(), start=1):
            if not line or line.startswith("#"):
                continue
            expected, relative_path = line.split(maxsplit=1)
            path = root / relative_path.strip()
            self.assertTrue(path.is_file(), f"Manifest line {line_number} references a missing file: {relative_path}")
            self.assertEqual(
                _sha256(path.read_bytes()),
                expected,
                f"Manifest line {line_number} does not match {relative_path}",
            )

    def test_input_change_archives_sensitivity_results_and_clears_active_view(self):
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            old = {
                "RUNTIME_DIR": onboarding.RUNTIME_DIR,
                "RESULT_INDEX": onboarding.RESULT_INDEX,
                "ACTIVE_ANALYTICS_DIR": onboarding.ACTIVE_ANALYTICS_DIR,
                "DLI_SENSITIVITY_DIR": onboarding.DLI_SENSITIVITY_DIR,
                "DLI_SENSITIVITY_HISTORY_DIR": onboarding.DLI_SENSITIVITY_HISTORY_DIR,
            }
            try:
                onboarding.RUNTIME_DIR = root / "runtime"
                onboarding.RESULT_INDEX = onboarding.RUNTIME_DIR / "result_index.json"
                onboarding.ACTIVE_ANALYTICS_DIR = onboarding.RUNTIME_DIR / "active_analytics"
                onboarding.DLI_SENSITIVITY_DIR = onboarding.RUNTIME_DIR / "dli_sensitivity"
                onboarding.DLI_SENSITIVITY_HISTORY_DIR = onboarding.RUNTIME_DIR / "dli_sensitivity_history"
                onboarding.ACTIVE_ANALYTICS_DIR.mkdir(parents=True)
                run = onboarding.DLI_SENSITIVITY_DIR / "20260831T120000Z"
                run.mkdir(parents=True)
                (onboarding.DLI_SENSITIVITY_DIR / "latest_2017.json").write_text("{}", encoding="utf-8")
                (run / "report.md").write_text("historical sensitivity evidence", encoding="utf-8")
                onboarding.invalidate_downstream_runtime("test input change")
                self.assertFalse(onboarding.DLI_SENSITIVITY_DIR.exists())
                archives = list(onboarding.DLI_SENSITIVITY_HISTORY_DIR.iterdir())
                self.assertEqual(len(archives), 1)
                archived = archives[0]
                self.assertTrue((archived / "latest_2017.json").is_file())
                self.assertEqual((archived / "20260831T120000Z" / "report.md").read_text(encoding="utf-8"), "historical sensitivity evidence")
                archive_metadata = json.loads((archived / "archive_metadata.json").read_text(encoding="utf-8"))
                self.assertEqual(archive_metadata["reason"], "test input change")
                self.assertIn("never read by the active Streamlit view", archive_metadata["display_policy"])
                old_sensitivity_runtime = sensitivity.SENSITIVITY_RUNTIME_DIR
                try:
                    sensitivity.SENSITIVITY_RUNTIME_DIR = onboarding.DLI_SENSITIVITY_DIR
                    with self.assertRaises(FileNotFoundError):
                        sensitivity.load_latest_runtime_analysis(2017)
                finally:
                    sensitivity.SENSITIVITY_RUNTIME_DIR = old_sensitivity_runtime
            finally:
                for name, value in old.items():
                    setattr(onboarding, name, value)


if __name__ == "__main__":
    unittest.main(verbosity=2)
