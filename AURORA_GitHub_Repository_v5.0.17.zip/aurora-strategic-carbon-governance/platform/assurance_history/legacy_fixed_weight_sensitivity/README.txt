U19 assurance-history archive — retired fixed-weight sensitivity utility
=======================================================================

These files are preserved only to reproduce historical U6–U10 assurance
checks. They are not imported, executed, or exposed by the U19 production
application.

The archived implementation treats researcher-assigned DLI weights as a
baseline and permits alternative CRITIC correlation choices. That is not the
U19 method. U19 derives one common weight vector from the pooled 2014–2017
evaluation matrix using Pearson-CRITIC only. The active robustness companion
is ../../critic_robustness.py; it perturbs the authoritative pooled CRITIC
vector for diagnostics without replacing the governed DLI definition.

Do not use any file in this directory to produce current rankings,
interventions, governed evidence, or deployment decisions.
