"""Reproducible DLI weight sensitivity and CRITIC objective weighting.

This module does not change the authoritative Network/DLI calculation or its
declared baseline weights.  It re-scores already fulfilled DLI rankings using
their stored, within-year normalised BC, PR, CDR and IC components.  It is
therefore a robustness analysis of the governance-screening rule, not a new
MRIO, network or causal intervention model.

The command-line interface accepts either an exported DLI ranking (CSV or a
Network/DLI JSON result) or the active runtime ranking produced by the Data
Orchestrator.  It writes auditable CSV, JSON and Markdown outputs while leaving
the active blockchain result and deterministic intervention portfolio intact.
The U8 extension additionally calculates a CRITIC objective-weight benchmark
from the complete normalized indicator matrix and compares it with the declared
governance-weight ranking.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib
import json
import math
import re
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable, Mapping

import numpy as np
import pandas as pd
from openpyxl.styles import Alignment, Font, PatternFill
from openpyxl.utils import get_column_letter


COMPONENTS: tuple[str, ...] = ("BC", "PR", "CDR", "IC")
COMPONENT_COLUMNS: dict[str, str] = {
    "BC": "BC_norm",
    "PR": "PR_norm",
    "CDR": "CDR_norm",
    "IC": "IC_norm",
}
# Kept explicit here so this standalone validator does not need to import the
# analytical engine.  validate_deployment_baseline() checks this declaration
# against network_engine.DLI_WEIGHTS when that module is available.
DECLARED_BASELINE_WEIGHTS: dict[str, float] = {
    "BC": 0.25,
    "PR": 0.20,
    "CDR": 0.30,
    "IC": 0.25,
}
DEFAULT_ONE_WAY_DELTAS: tuple[float, ...] = (0.05, 0.10)
DEFAULT_MONTE_CARLO_SAMPLES = 5000
DEFAULT_DIRICHLET_CONCENTRATION = 80.0
DEFAULT_RANDOM_SEED = 20260831
DEFAULT_CRITIC_CORRELATION = "pearson"
SUPPORTED_CRITIC_CORRELATIONS: tuple[str, ...] = ("pearson", "spearman")
CRITIC_RELEASE_ID = "v5.0.17-U8"
IN_APP_EXECUTION_RELEASE_ID = "v5.0.17-U10"
PACKAGE_ROOT = Path(__file__).resolve().parent
RUNTIME_DIR = PACKAGE_ROOT / "runtime"
SENSITIVITY_RUNTIME_DIR = RUNTIME_DIR / "dli_sensitivity"
CONTENT_STORE_DIR = PACKAGE_ROOT / "content_store"
SENSITIVITY_SCHEMA_VERSION = "dli_weight_sensitivity_v3"
EXPECTED_RUNTIME_NODE_COUNT = 455
_CID_PATTERN = re.compile(r"^[0-9a-f]{64}$")
_RANKING_COMPARISON_COLUMNS = ("node_code", "BC_norm", "PR_norm", "CDR_norm", "IC_norm", "DLI")
_OUTPUT_HASHED_FILES = (
    "baseline_dli_ranking.csv",
    "one_way_weight_scenarios.csv",
    "monte_carlo_weight_scenarios.csv",
    "node_rank_stability.csv",
    "baseline_top_k_stability.csv",
    "critic_criterion_statistics.csv",
    "critic_correlation_matrix.csv",
    "critic_dli_ranking.csv",
    "critic_top_k_comparison.csv",
    "dli_weight_sensitivity_results.xlsx",
    "summary.json",
    "report.md",
)


class DLIWeightSensitivityError(ValueError):
    """Raised when a ranking or a proposed DLI weight vector is invalid."""


def _json_default(value: Any) -> Any:
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    if isinstance(value, Path):
        return str(value)
    raise TypeError(f"Object of type {type(value).__name__} is not JSON serialisable")


def _round(value: float | int | None, digits: int = 6) -> float | int | None:
    if value is None:
        return None
    if isinstance(value, (float, np.floating)):
        return round(float(value), digits)
    return int(value) if isinstance(value, (int, np.integer)) else value


def validate_weights(weights: Mapping[str, float], *, tolerance: float = 1e-10) -> dict[str, float]:
    """Return a validated DLI weight vector without silently renormalising it."""
    received = set(weights)
    expected = set(COMPONENTS)
    missing = sorted(expected.difference(received))
    unexpected = sorted(received.difference(expected))
    if missing or unexpected:
        raise DLIWeightSensitivityError(
            f"DLI weights must contain exactly {list(COMPONENTS)}; "
            f"missing={missing}, unexpected={unexpected}."
        )
    validated: dict[str, float] = {}
    for component in COMPONENTS:
        try:
            value = float(weights[component])
        except (TypeError, ValueError) as exc:
            raise DLIWeightSensitivityError(f"Weight for {component} must be numeric.") from exc
        if not math.isfinite(value) or value < 0.0 or value > 1.0:
            raise DLIWeightSensitivityError(f"Weight for {component} must be finite and in [0, 1].")
        validated[component] = value
    total = sum(validated.values())
    if abs(total - 1.0) > tolerance:
        raise DLIWeightSensitivityError(f"DLI weights must sum to 1.0; received {total:.12f}.")
    return validated


def deployment_baseline_weights() -> dict[str, float]:
    """Read and verify the baseline from this deployment's network engine.

    A sensitivity report must never quietly substitute a hard-coded vector if
    the deployed engine cannot be loaded.  That would make a broken or
    shadowed deployment appear to have passed baseline verification.
    """
    expected = validate_weights(DECLARED_BASELINE_WEIGHTS)
    try:
        network_engine = importlib.import_module("network_engine")
    except Exception as exc:
        raise DLIWeightSensitivityError(
            "Cannot import the deployed network_engine for baseline-weight verification. "
            "Run this command from an intact DEPLOY_FINAL package."
        ) from exc
    engine_path = Path(getattr(network_engine, "__file__", "")).resolve()
    expected_path = (PACKAGE_ROOT / "network_engine.py").resolve()
    if engine_path != expected_path:
        raise DLIWeightSensitivityError(
            "Baseline verification resolved a network_engine outside this deployment package."
        )
    deployed = validate_weights(getattr(network_engine, "DLI_WEIGHTS", {}))
    if any(abs(deployed[key] - expected[key]) > 1e-12 for key in COMPONENTS):
        raise DLIWeightSensitivityError(
            "network_engine.DLI_WEIGHTS does not match the sensitivity module's declared "
            "baseline. Update the validation protocol before running a new analysis."
        )
    return deployed


def validate_ranking(frame: pd.DataFrame) -> pd.DataFrame:
    """Validate and return a clean fulfilled DLI ranking frame.

    The analysis requires a fulfilled Network/DLI result: node identifiers,
    the four stored normalised components, and the stored baseline DLI score.
    The stored DLI is retained only for integrity checking; all sensitivity
    scores are re-computed from the components and declared baseline weights.
    """
    required = {"node_code", "DLI", *COMPONENT_COLUMNS.values()}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise DLIWeightSensitivityError(f"DLI ranking is missing required columns: {missing}")
    if frame.empty:
        raise DLIWeightSensitivityError("DLI ranking is empty.")
    clean = frame.copy()
    raw_codes = clean["node_code"]
    if raw_codes.isna().any():
        raise DLIWeightSensitivityError("DLI ranking contains a missing node_code.")
    clean["node_code"] = raw_codes.astype(str).str.strip()
    invalid_codes = clean["node_code"].str.casefold().isin({"", "nan", "none", "null", "nat"})
    if invalid_codes.any():
        raise DLIWeightSensitivityError("DLI ranking contains an empty or reserved node_code.")
    comparison_codes = clean["node_code"].str.casefold()
    duplicates = clean.loc[comparison_codes.duplicated(), "node_code"].tolist()
    if duplicates:
        raise DLIWeightSensitivityError(
            f"DLI ranking contains duplicate case-normalised node codes: {duplicates[:5]}"
        )
    for column in COMPONENT_COLUMNS.values():
        values = pd.to_numeric(clean[column], errors="coerce")
        if not np.isfinite(values.to_numpy(dtype=float)).all():
            raise DLIWeightSensitivityError(f"{column} contains non-finite values.")
        if ((values < -1e-9) | (values > 1.0 + 1e-9)).any():
            raise DLIWeightSensitivityError(f"{column} must contain min-max normalised values in [0, 1].")
        clean[column] = values.clip(lower=0.0, upper=1.0)
    existing = pd.to_numeric(clean["DLI"], errors="coerce")
    if not np.isfinite(existing.to_numpy(dtype=float)).all():
        raise DLIWeightSensitivityError("The existing DLI column contains non-finite values.")
    if ((existing < -1e-9) | (existing > 1.0 + 1e-9)).any():
        raise DLIWeightSensitivityError("The existing DLI column must contain values in [0, 1].")
    clean["DLI"] = existing.clip(lower=0.0, upper=1.0)
    return clean.reset_index(drop=True)


def score_ranking(
    frame: pd.DataFrame,
    weights: Mapping[str, float],
    *,
    score_column: str = "DLI_sensitivity",
    rank_column: str = "sensitivity_rank",
    contribution_suffix: str = "weight_contribution",
) -> pd.DataFrame:
    """Re-score a ranking with a valid weight vector and deterministic tie-breaking.

    The optional output-column names allow the same validated scoring routine to
    create a CRITIC benchmark without overwriting or mislabelling the declared
    governance-weight result.
    """
    clean = validate_ranking(frame)
    vector = validate_weights(weights)
    scored = clean.copy()
    score = np.zeros(len(scored), dtype=float)
    for component in COMPONENTS:
        contribution_column = f"{component}_{contribution_suffix}"
        contribution = vector[component] * scored[COMPONENT_COLUMNS[component]].to_numpy(dtype=float)
        scored[contribution_column] = contribution
        score += contribution
    scored[score_column] = score
    scored = scored.sort_values(
        [score_column, "node_code"], ascending=[False, True], kind="mergesort"
    ).reset_index(drop=True)
    scored[rank_column] = np.arange(1, len(scored) + 1, dtype=int)
    return scored


def _validate_critic_correlation(method: str) -> str:
    value = str(method).strip().lower()
    if value not in SUPPORTED_CRITIC_CORRELATIONS:
        raise DLIWeightSensitivityError(
            f"CRITIC correlation must be one of {list(SUPPORTED_CRITIC_CORRELATIONS)}; received {method!r}."
        )
    return value


def calculate_critic_weights(
    frame: pd.DataFrame,
    *,
    correlation_method: str = DEFAULT_CRITIC_CORRELATION,
    baseline_weights: Mapping[str, float] | None = None,
) -> dict[str, Any]:
    """Calculate objective CRITIC weights from the four normalized DLI criteria.

    Standard CRITIC combines criterion contrast (population standard deviation)
    and inter-criterion conflict (one minus pairwise correlation).  The result
    quantifies information content in the observed 455-node indicator matrix;
    it does not estimate stakeholder preference or replace the declared DLI
    governance weights.
    """
    clean = validate_ranking(frame)
    method = _validate_critic_correlation(correlation_method)
    matrix = clean[[COMPONENT_COLUMNS[component] for component in COMPONENTS]].astype(float)
    matrix.columns = list(COMPONENTS)

    standard_deviation = matrix.std(axis=0, ddof=0)
    correlation = matrix.corr(method=method)
    correlation = correlation.reindex(index=COMPONENTS, columns=COMPONENTS)
    correlation_values = correlation.to_numpy(dtype=float)

    # Correlations involving a constant criterion are undefined.  Setting those
    # off-diagonal values to zero is neutral for the constant criterion because
    # its standard deviation is zero, while preserving the information carried
    # by non-constant criteria.  Diagonal self-correlation is always one.
    for row in range(len(COMPONENTS)):
        for column in range(len(COMPONENTS)):
            if row == column:
                correlation_values[row, column] = 1.0
            elif not math.isfinite(float(correlation_values[row, column])):
                correlation_values[row, column] = 0.0
    correlation = pd.DataFrame(correlation_values, index=COMPONENTS, columns=COMPONENTS)

    conflict = (1.0 - correlation).sum(axis=1)
    information = standard_deviation.reindex(COMPONENTS) * conflict
    information_total = float(information.sum())
    if not math.isfinite(information_total) or information_total <= 1e-15:
        raise DLIWeightSensitivityError(
            "CRITIC cannot derive objective weights because the normalized criteria contain no usable contrast."
        )
    weights = validate_weights(
        {component: float(information.loc[component] / information_total) for component in COMPONENTS},
        tolerance=1e-9,
    )
    baseline = validate_weights(baseline_weights or DECLARED_BASELINE_WEIGHTS)
    statistics = pd.DataFrame(
        [
            {
                "criterion": component,
                "normalized_column": COMPONENT_COLUMNS[component],
                "population_standard_deviation": float(standard_deviation.loc[component]),
                "conflict_sum": float(conflict.loc[component]),
                "information_content": float(information.loc[component]),
                "critic_weight": float(weights[component]),
                "baseline_governance_weight": float(baseline[component]),
                "weight_difference_critic_minus_baseline": float(weights[component] - baseline[component]),
            }
            for component in COMPONENTS
        ]
    )
    return {
        "release_id": CRITIC_RELEASE_ID,
        "method": "CRITIC",
        "correlation_method": method,
        "weights": weights,
        "criterion_statistics": statistics,
        "correlation_matrix": correlation,
        "claim_boundary": (
            "CRITIC weights quantify statistical contrast and non-redundancy in the normalized DLI criteria. "
            "They are an objective robustness benchmark, not an empirical estimate of governance preferences."
        ),
    }


def build_critic_benchmark(
    frame: pd.DataFrame,
    baseline_ranked: pd.DataFrame,
    *,
    top_k: int,
    correlation_method: str = DEFAULT_CRITIC_CORRELATION,
    baseline_weights: Mapping[str, float] | None = None,
) -> dict[str, Any]:
    """Return the CRITIC weights, ranking, and comparison with the baseline DLI."""
    objective = calculate_critic_weights(
        frame,
        correlation_method=correlation_method,
        baseline_weights=baseline_weights,
    )
    critic_ranked = score_ranking(
        frame,
        objective["weights"],
        score_column="DLI_CRITIC",
        rank_column="critic_rank",
        contribution_suffix="critic_contribution",
    )
    baseline_lookup = baseline_ranked[
        ["node_code", "sensitivity_rank", "DLI_sensitivity"]
    ].rename(
        columns={
            "sensitivity_rank": "baseline_rank",
            "DLI_sensitivity": "baseline_DLI",
        }
    )
    critic_ranked = critic_ranked.drop(
        columns=["baseline_rank", "baseline_DLI", "rank_change_vs_baseline", "baseline_top_k", "critic_top_k"],
        errors="ignore",
    )
    critic_ranked = critic_ranked.merge(baseline_lookup, on="node_code", how="left", validate="one_to_one")
    critic_ranked["rank_change_vs_baseline"] = (
        critic_ranked["baseline_rank"].astype(int) - critic_ranked["critic_rank"].astype(int)
    )
    baseline_top = set(baseline_ranked.head(int(top_k))["node_code"].astype(str))
    critic_top = set(critic_ranked.head(int(top_k))["node_code"].astype(str))
    critic_ranked["baseline_top_k"] = critic_ranked["node_code"].astype(str).isin(baseline_top)
    critic_ranked["critic_top_k"] = critic_ranked["node_code"].astype(str).isin(critic_top)

    metrics_frame = critic_ranked[["node_code", "critic_rank"]].rename(
        columns={"critic_rank": "sensitivity_rank"}
    )
    metrics = _ranking_metrics(baseline_ranked, metrics_frame, top_k=int(top_k))

    comparison = critic_ranked[
        [
            "node_code",
            "baseline_rank",
            "critic_rank",
            "rank_change_vs_baseline",
            "baseline_DLI",
            "DLI_CRITIC",
            "baseline_top_k",
            "critic_top_k",
        ]
    ].copy()
    comparison = comparison[
        comparison["baseline_top_k"] | comparison["critic_top_k"]
    ].sort_values(["critic_rank", "baseline_rank", "node_code"], kind="mergesort")

    return {
        **objective,
        "ranking": critic_ranked,
        "top_k_comparison": comparison.reset_index(drop=True),
        "comparison_metrics": metrics,
    }


def rebalanced_weights(
    baseline: Mapping[str, float],
    varied_component: str,
    target_weight: float,
) -> dict[str, float]:
    """Change one component and proportionally rebalance the remaining weights."""
    base = validate_weights(baseline)
    if varied_component not in COMPONENTS:
        raise DLIWeightSensitivityError(f"Unknown DLI component: {varied_component}")
    target = float(target_weight)
    if not math.isfinite(target) or target < 0.0 or target > 1.0:
        raise DLIWeightSensitivityError("Target weight must be finite and in [0, 1].")
    other_components = [component for component in COMPONENTS if component != varied_component]
    remaining = 1.0 - target
    base_other_total = sum(base[component] for component in other_components)
    if base_other_total <= 0.0:
        raise DLIWeightSensitivityError("Cannot proportionally rebalance when all other baseline weights are zero.")
    result = {
        component: (target if component == varied_component else base[component] * remaining / base_other_total)
        for component in COMPONENTS
    }
    return validate_weights(result, tolerance=1e-9)


def one_way_weight_scenarios(
    baseline: Mapping[str, float],
    deltas: Iterable[float] = DEFAULT_ONE_WAY_DELTAS,
) -> list[tuple[str, str, dict[str, float]]]:
    """Return baseline plus feasible +/- percentage-point one-way scenarios."""
    base = validate_weights(baseline)
    result: list[tuple[str, str, dict[str, float]]] = [("baseline", "baseline", base)]
    observed: set[tuple[float, ...]] = {tuple(base[component] for component in COMPONENTS)}
    for component in COMPONENTS:
        for delta in deltas:
            magnitude = float(delta)
            if not math.isfinite(magnitude) or magnitude <= 0.0:
                raise DLIWeightSensitivityError("One-way deltas must be positive finite values.")
            for direction, signed_delta in (("minus", -magnitude), ("plus", magnitude)):
                target = base[component] + signed_delta
                if target < -1e-12 or target > 1.0 + 1e-12:
                    continue
                weights = rebalanced_weights(base, component, min(1.0, max(0.0, target)))
                fingerprint = tuple(round(weights[key], 14) for key in COMPONENTS)
                if fingerprint in observed:
                    continue
                observed.add(fingerprint)
                label = f"{component}_{direction}_{magnitude:.2f}".replace(".", "p")
                result.append((label, "one_way", weights))
    return result


def dirichlet_weight_scenarios(
    baseline: Mapping[str, float],
    *,
    samples: int = DEFAULT_MONTE_CARLO_SAMPLES,
    concentration: float = DEFAULT_DIRICHLET_CONCENTRATION,
    seed: int = DEFAULT_RANDOM_SEED,
) -> list[dict[str, float]]:
    """Sample reproducible feasible multi-weight scenarios around the baseline.

    The Dirichlet design is an exploratory mathematical robustness analysis.
    It does not by itself establish that sampled governance preferences are
    empirically plausible; the paper must state any expert-derived bounds or
    rationale used to interpret the results.
    """
    base = validate_weights(baseline)
    if int(samples) < 0:
        raise DLIWeightSensitivityError("Monte Carlo samples cannot be negative.")
    if int(samples) == 0:
        return []
    if not math.isfinite(float(concentration)) or float(concentration) <= 0.0:
        raise DLIWeightSensitivityError("Dirichlet concentration must be positive and finite.")
    alpha = np.array([base[component] * float(concentration) for component in COMPONENTS], dtype=float)
    if (alpha <= 0.0).any():
        raise DLIWeightSensitivityError("Dirichlet sampling requires strictly positive baseline weights.")
    rng = np.random.default_rng(int(seed))
    samples_array = rng.dirichlet(alpha, size=int(samples))
    return [
        validate_weights({component: float(row[index]) for index, component in enumerate(COMPONENTS)}, tolerance=1e-9)
        for row in samples_array
    ]


def _ranking_metrics(
    baseline_ranked: pd.DataFrame,
    scenario_ranked: pd.DataFrame,
    *,
    top_k: int,
) -> dict[str, Any]:
    baseline = baseline_ranked.set_index("node_code")["sensitivity_rank"]
    scenario = scenario_ranked.set_index("node_code")["sensitivity_rank"].reindex(baseline.index)
    spearman = baseline.corr(scenario, method="spearman")
    baseline_top = set(baseline_ranked.head(top_k)["node_code"].astype(str))
    scenario_top = set(scenario_ranked.head(top_k)["node_code"].astype(str))
    overlap = len(baseline_top.intersection(scenario_top))
    union = len(baseline_top.union(scenario_top))
    rank_delta = (scenario - baseline).abs()
    return {
        "spearman_rank_correlation": float(spearman) if pd.notna(spearman) else None,
        "top_k_overlap_count": int(overlap),
        "top_k_overlap_proportion": float(overlap / top_k) if top_k else None,
        "top_k_jaccard": float(overlap / union) if union else None,
        "max_abs_rank_change": int(rank_delta.max()),
        "mean_abs_rank_change": float(rank_delta.mean()),
        "top_k_node_codes": " | ".join(scenario_ranked.head(top_k)["node_code"].astype(str)),
    }


def _fast_rank_arrays(
    component_matrix: np.ndarray,
    node_codes: np.ndarray,
    weights: Mapping[str, float],
) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Return scores, 1-based ranks aligned to input order, and sorted indices."""
    vector = validate_weights(weights)
    weight_array = np.array([vector[component] for component in COMPONENTS], dtype=float)
    scores = np.asarray(component_matrix, dtype=float) @ weight_array
    # np.lexsort uses the last key as primary: descending score, then node code.
    order = np.lexsort((node_codes.astype(str), -scores))
    ranks = np.empty(len(order), dtype=int)
    ranks[order] = np.arange(1, len(order) + 1, dtype=int)
    return scores, ranks, order


def _new_fast_statistics(node_count: int) -> dict[str, np.ndarray | int]:
    return {
        "scenario_count": 0,
        "rank_min": np.full(node_count, node_count + 1, dtype=int),
        "rank_max": np.zeros(node_count, dtype=int),
        "rank_sum": np.zeros(node_count, dtype=float),
        "score_min": np.full(node_count, np.inf, dtype=float),
        "score_max": np.full(node_count, -np.inf, dtype=float),
        "top5_count": np.zeros(node_count, dtype=int),
        "top_k_count": np.zeros(node_count, dtype=int),
    }


def _accumulate_fast_statistics(
    statistics: dict[str, np.ndarray | int],
    scores: np.ndarray,
    ranks: np.ndarray,
    order: np.ndarray,
    *,
    top_k: int,
) -> None:
    statistics["scenario_count"] = int(statistics["scenario_count"]) + 1
    statistics["rank_min"] = np.minimum(np.asarray(statistics["rank_min"]), ranks)
    statistics["rank_max"] = np.maximum(np.asarray(statistics["rank_max"]), ranks)
    statistics["rank_sum"] = np.asarray(statistics["rank_sum"]) + ranks
    statistics["score_min"] = np.minimum(np.asarray(statistics["score_min"]), scores)
    statistics["score_max"] = np.maximum(np.asarray(statistics["score_max"]), scores)
    top5_mask = np.zeros(len(scores), dtype=int)
    top5_mask[order[: min(5, len(order))]] = 1
    top_k_mask = np.zeros(len(scores), dtype=int)
    top_k_mask[order[: int(top_k)]] = 1
    statistics["top5_count"] = np.asarray(statistics["top5_count"]) + top5_mask
    statistics["top_k_count"] = np.asarray(statistics["top_k_count"]) + top_k_mask


def _fast_scenario_metrics(
    baseline_ranks: np.ndarray,
    baseline_top_indices: set[int],
    ranks: np.ndarray,
    order: np.ndarray,
    node_codes: np.ndarray,
    *,
    top_k: int,
) -> dict[str, Any]:
    spearman = float(np.corrcoef(baseline_ranks.astype(float), ranks.astype(float))[0, 1])
    scenario_top_indices = set(int(index) for index in order[: int(top_k)])
    overlap = len(baseline_top_indices.intersection(scenario_top_indices))
    union = len(baseline_top_indices.union(scenario_top_indices))
    rank_delta = np.abs(ranks - baseline_ranks)
    return {
        "spearman_rank_correlation": spearman,
        "top_k_overlap_count": int(overlap),
        "top_k_overlap_proportion": float(overlap / top_k) if top_k else None,
        "top_k_jaccard": float(overlap / union) if union else None,
        "max_abs_rank_change": int(rank_delta.max()),
        "mean_abs_rank_change": float(rank_delta.mean()),
        "top_k_node_codes": " | ".join(node_codes[order[: int(top_k)]].astype(str)),
    }


def _finalise_fast_statistics(
    node_codes: np.ndarray,
    baseline_scores: np.ndarray,
    baseline_ranks: np.ndarray,
    one_way: Mapping[str, np.ndarray | int],
    monte_carlo: Mapping[str, np.ndarray | int],
    *,
    top_k: int,
) -> pd.DataFrame:
    output = pd.DataFrame(
        {
            "node_code": node_codes.astype(str),
            "baseline_rank": baseline_ranks.astype(int),
            "baseline_dli": baseline_scores.astype(float),
        }
    )
    for prefix, values in (("one_way", one_way), ("monte_carlo", monte_carlo)):
        count = int(values["scenario_count"])
        output[f"{prefix}_scenario_count"] = count
        if count:
            output[f"{prefix}_rank_min"] = np.asarray(values["rank_min"], dtype=int)
            output[f"{prefix}_rank_max"] = np.asarray(values["rank_max"], dtype=int)
            output[f"{prefix}_score_min"] = np.asarray(values["score_min"], dtype=float)
            output[f"{prefix}_score_max"] = np.asarray(values["score_max"], dtype=float)
            output[f"{prefix}_mean_rank"] = np.asarray(values["rank_sum"], dtype=float) / count
            output[f"{prefix}_top5_inclusion_probability"] = (
                np.asarray(values["top5_count"], dtype=float) / count
            )
            output[f"{prefix}_top{top_k}_inclusion_probability"] = (
                np.asarray(values["top_k_count"], dtype=float) / count
            )
        else:
            for suffix in (
                "rank_min",
                "rank_max",
                "score_min",
                "score_max",
                "mean_rank",
                "top5_inclusion_probability",
                f"top{top_k}_inclusion_probability",
            ):
                output[f"{prefix}_{suffix}"] = None
    return output.sort_values(["baseline_rank", "node_code"], kind="mergesort").reset_index(drop=True)


def _initial_node_statistics(baseline_ranked: pd.DataFrame) -> dict[str, dict[str, Any]]:
    return {
        str(row.node_code): {
            "baseline_rank": int(row.sensitivity_rank),
            "baseline_dli": float(row.DLI_sensitivity),
        }
        for row in baseline_ranked[["node_code", "sensitivity_rank", "DLI_sensitivity"]].itertuples(index=False)
    }


def _accumulate_node_statistics(
    statistics: dict[str, dict[str, Any]],
    ranked: pd.DataFrame,
    *,
    prefix: str,
    top_k: int,
) -> None:
    top5 = set(ranked.head(min(5, len(ranked)))["node_code"].astype(str))
    top_nodes = set(ranked.head(top_k)["node_code"].astype(str))
    for row in ranked[["node_code", "sensitivity_rank", "DLI_sensitivity"]].itertuples(index=False):
        code = str(row.node_code)
        values = statistics[code]
        count_key = f"{prefix}_scenario_count"
        values[count_key] = int(values.get(count_key, 0)) + 1
        rank = int(row.sensitivity_rank)
        score = float(row.DLI_sensitivity)
        values[f"{prefix}_rank_min"] = min(rank, int(values.get(f"{prefix}_rank_min", rank)))
        values[f"{prefix}_rank_max"] = max(rank, int(values.get(f"{prefix}_rank_max", rank)))
        values[f"{prefix}_rank_sum"] = float(values.get(f"{prefix}_rank_sum", 0.0)) + rank
        values[f"{prefix}_score_min"] = min(score, float(values.get(f"{prefix}_score_min", score)))
        values[f"{prefix}_score_max"] = max(score, float(values.get(f"{prefix}_score_max", score)))
        values[f"{prefix}_top5_count"] = int(values.get(f"{prefix}_top5_count", 0)) + int(code in top5)
        values[f"{prefix}_top_k_count"] = int(values.get(f"{prefix}_top_k_count", 0)) + int(code in top_nodes)


def _finalise_node_statistics(statistics: dict[str, dict[str, Any]], *, top_k: int) -> pd.DataFrame:
    rows: list[dict[str, Any]] = []
    for code, values in statistics.items():
        row = {"node_code": code, **values}
        for prefix in ("one_way", "monte_carlo"):
            total = int(row.get(f"{prefix}_scenario_count", 0))
            if total:
                row[f"{prefix}_mean_rank"] = float(row[f"{prefix}_rank_sum"]) / total
                row[f"{prefix}_top5_inclusion_probability"] = float(row[f"{prefix}_top5_count"]) / total
                row[f"{prefix}_top{top_k}_inclusion_probability"] = float(row[f"{prefix}_top_k_count"]) / total
            else:
                row[f"{prefix}_mean_rank"] = None
                row[f"{prefix}_top5_inclusion_probability"] = None
                row[f"{prefix}_top{top_k}_inclusion_probability"] = None
            row.pop(f"{prefix}_rank_sum", None)
            row.pop(f"{prefix}_top5_count", None)
            row.pop(f"{prefix}_top_k_count", None)
        rows.append(row)
    output = pd.DataFrame(rows)
    return output.sort_values(["baseline_rank", "node_code"], kind="mergesort").reset_index(drop=True)


def analyse_weight_sensitivity(
    frame: pd.DataFrame,
    *,
    baseline_weights: Mapping[str, float] | None = None,
    top_k: int = 15,
    one_way_deltas: Iterable[float] = DEFAULT_ONE_WAY_DELTAS,
    monte_carlo_samples: int = DEFAULT_MONTE_CARLO_SAMPLES,
    dirichlet_concentration: float = DEFAULT_DIRICHLET_CONCENTRATION,
    random_seed: int = DEFAULT_RANDOM_SEED,
    critic_correlation_method: str = DEFAULT_CRITIC_CORRELATION,
) -> dict[str, Any]:
    """Run scenario sensitivity and the objective CRITIC DLI benchmark."""
    clean = validate_ranking(frame)
    deltas = tuple(float(value) for value in one_way_deltas)
    if not 1 <= int(top_k) <= len(clean):
        raise DLIWeightSensitivityError(f"top_k must be between 1 and {len(clean)}.")
    weights = validate_weights(baseline_weights or deployment_baseline_weights())
    baseline_ranked = score_ranking(clean, weights)
    joined = baseline_ranked.set_index("node_code")["DLI_sensitivity"].reindex(clean["node_code"])
    diff = np.abs(joined.to_numpy(dtype=float) - clean["DLI"].to_numpy(dtype=float))
    baseline_integrity: dict[str, Any] = {"existing_dli_max_abs_difference": float(np.max(diff))}
    if baseline_integrity["existing_dli_max_abs_difference"] > 1e-8:
        raise DLIWeightSensitivityError(
            "The stored DLI does not reconstruct from the declared baseline weights and normalised components; "
            f"maximum absolute difference={baseline_integrity['existing_dli_max_abs_difference']:.3e}."
        )

    critic = build_critic_benchmark(
        clean,
        baseline_ranked,
        top_k=int(top_k),
        correlation_method=critic_correlation_method,
        baseline_weights=weights,
    )

    node_codes = clean["node_code"].astype(str).to_numpy()
    component_matrix = clean[[COMPONENT_COLUMNS[component] for component in COMPONENTS]].to_numpy(dtype=float)
    baseline_scores, baseline_ranks, baseline_order = _fast_rank_arrays(
        component_matrix,
        node_codes,
        weights,
    )
    baseline_top_indices = set(int(index) for index in baseline_order[: int(top_k)])
    one_way_statistics = _new_fast_statistics(len(clean))
    monte_carlo_statistics = _new_fast_statistics(len(clean))
    one_way_rows: list[dict[str, Any]] = []
    for label, mode, scenario_weights in one_way_weight_scenarios(weights, deltas):
        scores, ranks, order = _fast_rank_arrays(component_matrix, node_codes, scenario_weights)
        _accumulate_fast_statistics(one_way_statistics, scores, ranks, order, top_k=int(top_k))
        metrics = _fast_scenario_metrics(
            baseline_ranks,
            baseline_top_indices,
            ranks,
            order,
            node_codes,
            top_k=int(top_k),
        )
        one_way_rows.append(
            {
                "scenario_id": label,
                "analysis_mode": mode,
                **{f"weight_{component}": scenario_weights[component] for component in COMPONENTS},
                **metrics,
            }
        )

    monte_carlo_rows: list[dict[str, Any]] = []
    sampled_weights = dirichlet_weight_scenarios(
        weights,
        samples=int(monte_carlo_samples),
        concentration=float(dirichlet_concentration),
        seed=int(random_seed),
    )
    for index, scenario_weights in enumerate(sampled_weights, start=1):
        scores, ranks, order = _fast_rank_arrays(component_matrix, node_codes, scenario_weights)
        _accumulate_fast_statistics(monte_carlo_statistics, scores, ranks, order, top_k=int(top_k))
        metrics = _fast_scenario_metrics(
            baseline_ranks,
            baseline_top_indices,
            ranks,
            order,
            node_codes,
            top_k=int(top_k),
        )
        monte_carlo_rows.append(
            {
                "scenario_id": f"monte_carlo_{index:05d}",
                "analysis_mode": "monte_carlo",
                **{f"weight_{component}": scenario_weights[component] for component in COMPONENTS},
                **metrics,
            }
        )

    one_way = pd.DataFrame(one_way_rows)
    monte_carlo = pd.DataFrame(monte_carlo_rows)
    node_stability = _finalise_fast_statistics(
        node_codes,
        baseline_scores,
        baseline_ranks,
        one_way_statistics,
        monte_carlo_statistics,
        top_k=int(top_k),
    )
    baseline_top = baseline_ranked.head(int(top_k))["node_code"].astype(str).tolist()
    top_stability = node_stability[node_stability["node_code"].isin(baseline_top)].copy()

    return {
        "baseline_weights": weights,
        "top_k": int(top_k),
        "baseline_ranking": baseline_ranked,
        "baseline_integrity": baseline_integrity,
        "critic": critic,
        "one_way_scenarios": one_way,
        "monte_carlo_scenarios": monte_carlo,
        "node_rank_stability": node_stability,
        "baseline_top_k_stability": top_stability,
        "run_configuration": {
            "one_way_deltas": list(deltas),
            "monte_carlo_samples": int(monte_carlo_samples),
            "dirichlet_concentration": float(dirichlet_concentration),
            "random_seed": int(random_seed),
            "critic_correlation_method": critic["correlation_method"],
        },
    }


def _find_dli_ranking(value: Any) -> list[dict[str, Any]] | None:
    """Find a Network/DLI ranking in a content-addressed result JSON envelope."""
    pending: list[Any] = [value]
    seen: set[int] = set()
    while pending:
        current = pending.pop(0)
        if isinstance(current, (dict, list)):
            identity = id(current)
            if identity in seen:
                continue
            seen.add(identity)
        if isinstance(current, dict):
            ranking = current.get("dli_ranking")
            if isinstance(ranking, list) and ranking and all(isinstance(row, dict) for row in ranking):
                return ranking
            pending.extend(current.values())
        elif isinstance(current, list):
            pending.extend(current)
    return None


def load_dli_ranking(path: Path) -> pd.DataFrame:
    """Load a ranking CSV or a JSON response/content envelope."""
    source = Path(path)
    if not source.is_file():
        raise FileNotFoundError(f"DLI ranking input does not exist: {source}")
    suffix = source.suffix.casefold()
    if suffix == ".csv":
        return validate_ranking(pd.read_csv(source))
    if suffix == ".json":
        value = json.loads(source.read_text(encoding="utf-8"))
        ranking = _find_dli_ranking(value)
        if ranking is None:
            raise DLIWeightSensitivityError("JSON input does not contain a non-empty dli_ranking list.")
        return validate_ranking(pd.DataFrame(ranking))
    raise DLIWeightSensitivityError("DLI sensitivity input must be a .csv or .json file.")


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with Path(path).open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _read_json(path: Path, default: Any = None) -> Any:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return default


def _validate_input_hashes(value: Any, *, label: str) -> dict[str, str]:
    """Return the complete active-input hash pair or reject it explicitly."""
    if not isinstance(value, Mapping):
        raise DLIWeightSensitivityError(f"{label} is missing its input-hash object.")
    result = {key: str(value.get(key, "")).strip().lower() for key in ("mrio", "focal_demand")}
    if not all(_CID_PATTERN.fullmatch(item) for item in result.values()):
        raise DLIWeightSensitivityError(
            f"{label} must contain 64-character SHA-256 values for MRIO and focal demand."
        )
    return result


def _active_deployment_input_hashes() -> dict[str, str]:
    """Verify that active-manifest hashes still match canonical workbook bytes."""
    manifest_path = RUNTIME_DIR / "active_inputs" / "active_inputs.json"
    manifest = _read_json(manifest_path, {})
    if not isinstance(manifest, Mapping):
        raise DLIWeightSensitivityError("The active-input manifest is unreadable; revalidate and promote the inputs.")
    records = {key: manifest.get(key) for key in ("mrio", "focal_demand")}
    if not all(isinstance(record, Mapping) and record.get("status") == "active" for record in records.values()):
        raise DLIWeightSensitivityError(
            "Both MRIO and focal-demand workbooks must be validated and active before a runtime DLI sensitivity run."
        )
    hashes = _validate_input_hashes(
        {key: records[key].get("sha256") for key in records}, label="Active-input manifest"
    )
    paths = {
        "mrio": PACKAGE_ROOT / "input_mrio_completed.xlsx",
        "focal_demand": PACKAGE_ROOT / "Focal_Company_Demand_Converted.xlsx",
    }
    for key, path in paths.items():
        if not path.is_file() or _sha256_file(path) != hashes[key]:
            raise DLIWeightSensitivityError(
                f"The active {key.replace('_', '-')} workbook bytes do not match the accepted manifest. "
                "Revalidate and promote the inputs before analysis."
            )
    return hashes


def _ranking_snapshot_sha256(frame: pd.DataFrame) -> str:
    """Create a stable hash of the exact DLI fields used by the sensitivity run."""
    clean = validate_ranking(frame)
    table = clean.loc[:, list(_RANKING_COMPARISON_COLUMNS)].copy()
    table = table.sort_values("node_code", kind="mergesort").reset_index(drop=True)
    records: list[dict[str, Any]] = []
    for row in table.itertuples(index=False):
        records.append(
            {
                "node_code": str(row.node_code),
                "BC_norm": float(row.BC_norm),
                "PR_norm": float(row.PR_norm),
                "CDR_norm": float(row.CDR_norm),
                "IC_norm": float(row.IC_norm),
                "DLI": float(row.DLI),
            }
        )
    body = json.dumps(records, sort_keys=True, separators=(",", ":"), ensure_ascii=False, allow_nan=False)
    return hashlib.sha256(body.encode("utf-8")).hexdigest()


def _ranking_mirror_matches(authoritative: pd.DataFrame, mirror: pd.DataFrame, *, tolerance: float = 1e-10) -> bool:
    """Compare only the fields that define a DLI score, with explicit tolerance."""
    left = validate_ranking(authoritative).loc[:, list(_RANKING_COMPARISON_COLUMNS)]
    right = validate_ranking(mirror).loc[:, list(_RANKING_COMPARISON_COLUMNS)]
    left = left.sort_values("node_code", kind="mergesort").reset_index(drop=True)
    right = right.sort_values("node_code", kind="mergesort").reset_index(drop=True)
    if len(left) != len(right) or left["node_code"].tolist() != right["node_code"].tolist():
        return False
    for column in _RANKING_COMPARISON_COLUMNS[1:]:
        if not np.allclose(
            left[column].to_numpy(dtype=float),
            right[column].to_numpy(dtype=float),
            rtol=tolerance,
            atol=tolerance,
            equal_nan=False,
        ):
            return False
    return True


def _load_verified_network_content(
    cid: str,
    *,
    year: int,
    expected_input_hashes: Mapping[str, str],
) -> tuple[pd.DataFrame, Path]:
    """Load and cryptographically verify the immutable Network/DLI response."""
    normalized_cid = str(cid or "").strip().lower()
    if not _CID_PATTERN.fullmatch(normalized_cid):
        raise DLIWeightSensitivityError("The active Network/DLI result does not have a valid SHA-256 CID.")
    candidates = [
        CONTENT_STORE_DIR / f"{normalized_cid}.json",
        CONTENT_STORE_DIR / normalized_cid,
    ]
    present = [path for path in candidates if path.is_file()]
    if not present:
        raise DLIWeightSensitivityError(
            "The content-addressed Network/DLI result is unavailable locally. Re-run the governed Network/DLI request."
        )
    bodies: dict[Path, bytes] = {path: path.read_bytes() for path in present}
    for path, body in bodies.items():
        if hashlib.sha256(body).hexdigest() != normalized_cid:
            raise DLIWeightSensitivityError(
                f"Network/DLI CID verification failed for {path.name}; do not use modified runtime content."
            )
    try:
        envelope = json.loads(next(iter(bodies.values())).decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise DLIWeightSensitivityError("Verified Network/DLI content is not valid JSON.") from exc
    if not isinstance(envelope, Mapping) or envelope.get("namespace") != "network_and_dli_analysis":
        raise DLIWeightSensitivityError("The CID does not identify a Network/DLI content envelope.")
    material = envelope.get("payload")
    if not isinstance(material, Mapping) or material.get("operation") != "network_and_dli_analysis":
        raise DLIWeightSensitivityError("The CID envelope does not contain the expected Network/DLI operation.")
    payload = material.get("payload")
    if not isinstance(payload, Mapping) or int(payload.get("year", -1)) != int(year):
        raise DLIWeightSensitivityError("The CID Network/DLI payload does not match the requested year.")
    payload_hashes = _validate_input_hashes(payload.get("input_hashes"), label="CID Network/DLI payload")
    if payload_hashes != dict(expected_input_hashes):
        raise DLIWeightSensitivityError(
            "The CID Network/DLI payload input hashes do not match the active analytical inputs."
        )
    ranking = payload.get("dli_ranking")
    if not isinstance(ranking, list) or not ranking:
        raise DLIWeightSensitivityError("The CID Network/DLI payload has no complete DLI ranking.")
    return validate_ranking(pd.DataFrame(ranking)), present[0]


def load_active_runtime_ranking(year: int) -> tuple[pd.DataFrame, Path, dict[str, Any]]:
    """Load a provenance-checked active DLI ranking from the deployment runtime.

    The Data Orchestrator writes the complete ranking and matching input hashes
    under ``runtime/active_analytics``.  The active result index provides the
    matching content-addressed Network/DLI result CID.  A mismatch is treated
    as stale or out-of-band data and is rejected.
    """
    numeric_year = int(year)
    source = RUNTIME_DIR / "active_analytics" / f"dli_{numeric_year}.csv"
    metadata_path = source.with_suffix(".json")
    metadata = _read_json(metadata_path, {})
    if not isinstance(metadata, dict):
        raise DLIWeightSensitivityError(f"Runtime metadata is not a JSON object: {metadata_path}")
    if metadata.get("kind") != "dli" or int(metadata.get("year", -1)) != numeric_year:
        raise DLIWeightSensitivityError(
            "Runtime DLI metadata does not match the requested year. Re-run the governed Network/DLI request."
        )
    input_hashes = _validate_input_hashes(metadata.get("input_hashes"), label="Runtime DLI metadata")
    if input_hashes != _active_deployment_input_hashes():
        raise DLIWeightSensitivityError(
            "Runtime DLI metadata does not match the currently active validated workbooks. Re-run Network/DLI."
        )
    if not source.is_file():
        raise DLIWeightSensitivityError("The active DLI CSV mirror is missing. Re-run the governed Network/DLI request.")
    frame_sha256 = str(metadata.get("frame_sha256", "")).strip().lower()
    if not _CID_PATTERN.fullmatch(frame_sha256) or _sha256_file(source) != frame_sha256:
        raise DLIWeightSensitivityError(
            "The active DLI CSV mirror hash is missing or does not match its metadata. Re-run Network/DLI."
        )
    index = _read_json(RUNTIME_DIR / "result_index.json", {})
    records = index.get("results", {}) if isinstance(index, dict) else {}
    network_record = records.get(f"network:{numeric_year}", {}) if isinstance(records, dict) else {}
    if not isinstance(network_record, dict) or not network_record.get("content_hash"):
        raise DLIWeightSensitivityError(
            "No active content-addressed Network/DLI result matches this runtime ranking. Re-run Network/DLI first."
        )
    if _validate_input_hashes(network_record.get("input_hashes"), label="Active Network/DLI result index") != input_hashes:
        raise DLIWeightSensitivityError(
            "Runtime DLI ranking input hashes do not match the active Network/DLI result. "
            "Do not analyse stale data; re-run Network/DLI."
        )
    cid = str(network_record["content_hash"]).strip().lower()
    if str(metadata.get("source_result_cid", "")).strip().lower() != cid:
        raise DLIWeightSensitivityError(
            "The active DLI CSV mirror is not bound to the current Network/DLI CID. Re-run Network/DLI."
        )
    authoritative, content_path = _load_verified_network_content(
        cid,
        year=numeric_year,
        expected_input_hashes=input_hashes,
    )
    if len(authoritative) != int(EXPECTED_RUNTIME_NODE_COUNT):
        raise DLIWeightSensitivityError(
            f"The CID Network/DLI ranking contains {len(authoritative)} nodes; expected {EXPECTED_RUNTIME_NODE_COUNT}."
        )
    mirror = load_dli_ranking(source)
    if not _ranking_mirror_matches(authoritative, mirror):
        raise DLIWeightSensitivityError(
            "The active DLI CSV mirror does not match the verified Network/DLI CID ranking. Re-run Network/DLI."
        )
    provenance = {
        "source_type": "active_runtime",
        "runtime_metadata_path": str(metadata_path.resolve()),
        "runtime_generated_at_utc": metadata.get("generated_at_utc"),
        "input_hashes": input_hashes,
        "source_network_result_cid": cid,
        "network_result_generated_at_utc": network_record.get("generated_at_utc"),
        "source_content_path": str(content_path.resolve()),
        "source_snapshot_sha256": _sha256_file(content_path),
        "source_ranking_sha256": _ranking_snapshot_sha256(authoritative),
        "runtime_csv_path": str(source.resolve()),
        "runtime_csv_sha256": frame_sha256,
        "runtime_ranking_sha256": _ranking_snapshot_sha256(mirror),
    }
    # Analyse the verified CID snapshot, not the mutable convenience CSV.
    return authoritative, content_path, provenance


def _metric_summary(frame: pd.DataFrame) -> dict[str, Any]:
    if frame.empty:
        return {"scenario_count": 0}
    columns = [
        "spearman_rank_correlation",
        "top_k_overlap_count",
        "top_k_overlap_proportion",
        "top_k_jaccard",
        "max_abs_rank_change",
        "mean_abs_rank_change",
    ]
    output: dict[str, Any] = {"scenario_count": int(len(frame))}
    for column in columns:
        values = pd.to_numeric(frame[column], errors="coerce").dropna()
        output[column] = {
            "min": _round(float(values.min())) if not values.empty else None,
            "median": _round(float(values.median())) if not values.empty else None,
            "mean": _round(float(values.mean())) if not values.empty else None,
            "max": _round(float(values.max())) if not values.empty else None,
        }
    return output


def build_markdown_report(
    result: Mapping[str, Any],
    *,
    input_path: Path,
    input_sha256: str,
    year: int | None,
    provenance: Mapping[str, Any] | None = None,
) -> str:
    """Build a concise, paper-auditable DLI weight-sensitivity report."""
    baseline = result["baseline_weights"]
    top_k = int(result["top_k"])
    baseline_top = result["baseline_ranking"].head(top_k)
    top_stability = result["baseline_top_k_stability"].copy()
    inclusion_column = f"monte_carlo_top{top_k}_inclusion_probability"
    if inclusion_column in top_stability.columns:
        top_stability = top_stability.sort_values("baseline_rank", kind="mergesort")

    lines = [
        "# DLI weight-sensitivity validation report",
        "",
        "## Scope and boundary",
        "",
        "This report re-scores the fulfilled DLI ranking using stored normalised BC, PR, CDR and IC components. "
        "It does not change the authoritative DLI baseline, blockchain result, deterministic intervention portfolio, "
        "MRIO coefficients, focal demand, or causal scenario assumptions.",
        "",
        "The exercise tests robustness of the declared strategic governance-screening weights. It does not prove that "
        "a DLI-ranked intervention causes a quantified carbon reduction.",
        "",
        "## Input provenance",
        "",
        f"- Input: `{input_path}`",
        f"- SHA-256: `{input_sha256}`",
        f"- Reference year: `{year if year is not None else 'not supplied'}`",
        f"- Nodes: `{len(result['baseline_ranking'])}`",
    ]
    if provenance:
        cid = provenance.get("source_network_result_cid")
        input_hashes = provenance.get("input_hashes")
        if cid:
            lines.append(f"- Source Network/DLI result CID: `{cid}`")
        if isinstance(input_hashes, Mapping):
            lines.append(f"- MRIO input SHA-256: `{input_hashes.get('mrio', 'not recorded')}`")
            lines.append(f"- Focal-demand input SHA-256: `{input_hashes.get('focal_demand', 'not recorded')}`")
    lines.extend(
        [
            "",
            "## Declared baseline",
            "",
            "| Component | BC | PR | CDR | IC |",
            "|---|---:|---:|---:|---:|",
            f"| Weight | {baseline['BC']:.4f} | {baseline['PR']:.4f} | {baseline['CDR']:.4f} | {baseline['IC']:.4f} |",
            "",
        ]
    )
    integrity = result["baseline_integrity"].get("existing_dli_max_abs_difference")
    if integrity is not None:
        lines.extend(
            [
                "The maximum difference between the stored DLI and the re-computed declared baseline was "
                f"`{float(integrity):.3e}`.",
                "",
            ]
        )
    lines.extend(
        [
            f"## Baseline top {top_k}",
            "",
            "| Rank | Node | DLI |",
            "|---:|---|---:|",
        ]
    )
    for row in baseline_top[["sensitivity_rank", "node_code", "DLI_sensitivity"]].itertuples(index=False):
        lines.append(f"| {int(row.sensitivity_rank)} | {row.node_code} | {float(row.DLI_sensitivity):.6f} |")

    critic = result["critic"]
    critic_metrics = critic["comparison_metrics"]
    lines.extend(
        [
            "",
            "## CRITIC objective-weight benchmark",
            "",
            "CRITIC (CRiteria Importance Through Intercriteria Correlation) assigns objective weights from the "
            "contrast and non-redundancy of the normalized BC, PR, CDR and IC values. These weights describe the "
            "information carried by this observed node matrix; they do not estimate stakeholder preferences and do "
            "not replace the declared governance-weight DLI used by the platform.",
            "",
            f"- Correlation method: `{critic['correlation_method']}`",
            f"- Baseline--CRITIC Spearman rank correlation: `{float(critic_metrics['spearman_rank_correlation']):.6f}`",
            f"- Baseline top-{top_k} overlap: `{int(critic_metrics['top_k_overlap_count'])}` nodes",
            f"- Baseline top-{top_k} Jaccard similarity: `{float(critic_metrics['top_k_jaccard']):.6f}`",
            "",
            "| Criterion | Population SD | Conflict sum | Information content | Baseline weight | CRITIC weight |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for row in critic["criterion_statistics"].itertuples(index=False):
        lines.append(
            f"| {row.criterion} | {float(row.population_standard_deviation):.6f} | "
            f"{float(row.conflict_sum):.6f} | {float(row.information_content):.6f} | "
            f"{float(row.baseline_governance_weight):.6f} | {float(row.critic_weight):.6f} |"
        )
    lines.extend(
        [
            "",
            f"### Baseline and CRITIC top-{top_k} comparison",
            "",
            "Positive rank change means that a node moves upward under CRITIC relative to the declared baseline.",
            "",
            "| Node | Baseline rank | CRITIC rank | Rank change | Baseline DLI | CRITIC DLI |",
            "|---|---:|---:|---:|---:|---:|",
        ]
    )
    for row in critic["top_k_comparison"].itertuples(index=False):
        lines.append(
            f"| {row.node_code} | {int(row.baseline_rank)} | {int(row.critic_rank)} | "
            f"{int(row.rank_change_vs_baseline)} | {float(row.baseline_DLI):.6f} | "
            f"{float(row.DLI_CRITIC):.6f} |"
        )

    one_way_summary = _metric_summary(result["one_way_scenarios"])
    monte_carlo_summary = _metric_summary(result["monte_carlo_scenarios"])
    lines.extend(
        [
            "",
            "## One-way weight perturbations",
            "",
            "Each component was varied by the stated percentage-point deltas while the remaining three weights were "
            "rebalanced proportionally, preserving non-negativity and a total weight of one.",
            "",
            f"- Scenarios: `{one_way_summary['scenario_count']}`",
        ]
    )
    if one_way_summary["scenario_count"]:
        lines.append(
            "- Spearman rank correlation range: "
            f"`{one_way_summary['spearman_rank_correlation']['min']:.6f}` to "
            f"`{one_way_summary['spearman_rank_correlation']['max']:.6f}`"
        )
        lines.append(
            f"- Minimum top-{top_k} overlap: `{one_way_summary['top_k_overlap_count']['min']:.0f}` nodes"
        )

    lines.extend(
        [
            "",
            "## Multi-weight Monte Carlo exploration",
            "",
            "Feasible weight vectors were sampled from a Dirichlet distribution centred on the declared baseline. "
            "This is a reproducible mathematical robustness exploration; it is not a substitute for documented expert "
            "elicitation of plausible weight ranges.",
            "",
            f"- Samples: `{monte_carlo_summary['scenario_count']}`",
            f"- Dirichlet concentration: `{result['run_configuration']['dirichlet_concentration']}`",
            f"- Random seed: `{result['run_configuration']['random_seed']}`",
        ]
    )
    if monte_carlo_summary["scenario_count"]:
        lines.extend(
            [
                "- Spearman rank correlation (min / median / max): "
                f"`{monte_carlo_summary['spearman_rank_correlation']['min']:.6f}` / "
                f"`{monte_carlo_summary['spearman_rank_correlation']['median']:.6f}` / "
                f"`{monte_carlo_summary['spearman_rank_correlation']['max']:.6f}`",
                "- Top-"
                f"{top_k} overlap (min / median / max): "
                f"`{monte_carlo_summary['top_k_overlap_count']['min']:.0f}` / "
                f"`{monte_carlo_summary['top_k_overlap_count']['median']:.0f}` / "
                f"`{monte_carlo_summary['top_k_overlap_count']['max']:.0f}` nodes",
            ]
        )

    lines.extend(
        [
            "",
            f"## Baseline top-{top_k} stability",
            "",
            "| Baseline rank | Node | Minimum rank | Maximum rank | Monte Carlo top-"
            f"{top_k} inclusion |",
            "|---:|---|---:|---:|---:|",
        ]
    )
    for row in top_stability.itertuples(index=False):
        probability = getattr(row, inclusion_column, None)
        probability_text = "n/a" if probability is None or pd.isna(probability) else f"{float(probability):.2%}"

        monte_carlo_rank_min = getattr(row, "monte_carlo_rank_min", None)
        if monte_carlo_rank_min is None or pd.isna(monte_carlo_rank_min):
            monte_carlo_rank_min = row.one_way_rank_min

        monte_carlo_rank_max = getattr(row, "monte_carlo_rank_max", None)
        if monte_carlo_rank_max is None or pd.isna(monte_carlo_rank_max):
            monte_carlo_rank_max = row.one_way_rank_max

        lines.append(
            f"| {int(row.baseline_rank)} | {row.node_code} | "
            f"{int(monte_carlo_rank_min)} | {int(monte_carlo_rank_max)} | {probability_text} |"
        )
    lines.extend(
        [
            "",
            "## Interpretation",
            "",
            "Use the node-level inclusion probabilities, rank ranges and top-k overlaps to distinguish robust governance "
            "screening priorities from weight-sensitive priorities. Retain the declared baseline as the authoritative "
            "platform ranking unless the study formally revises and justifies its governance-weight policy.",
            "",
        ]
    )
    return "\n".join(lines)


def _excel_safe(value: Any) -> Any:
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, sort_keys=True, default=_json_default)
    if isinstance(value, (np.integer,)):
        return int(value)
    if isinstance(value, (np.floating,)):
        return float(value)
    return value


def _write_analysis_workbook(path: Path, result: Mapping[str, Any], summary: Mapping[str, Any]) -> None:
    """Write a formatted workbook containing the complete robustness evidence."""
    critic = result["critic"]
    critic_metrics = critic["comparison_metrics"]
    critic_summary = pd.DataFrame(
        [
            {
                "metric": "Reference year",
                "value": summary.get("year"),
                "interpretation": "Network/DLI result year used for this analysis.",
            },
            {
                "metric": "Node count",
                "value": len(result["baseline_ranking"]),
                "interpretation": "Complete country-sector node universe evaluated.",
            },
            {
                "metric": "Authoritative weighting",
                "value": "Declared governance weights",
                "interpretation": "The blockchain-bound DLI and intervention portfolio remain unchanged.",
            },
            {
                "metric": "CRITIC correlation method",
                "value": critic["correlation_method"],
                "interpretation": "Correlation specification used for objective information weighting.",
            },
            {
                "metric": "Baseline--CRITIC Spearman correlation",
                "value": critic_metrics.get("spearman_rank_correlation"),
                "interpretation": "Agreement between the complete baseline and CRITIC rankings.",
            },
            {
                "metric": f"Baseline--CRITIC top-{int(result['top_k'])} overlap",
                "value": critic_metrics.get("top_k_overlap_count"),
                "interpretation": "Number of baseline priority nodes retained by CRITIC.",
            },
            {
                "metric": "One-way scenarios",
                "value": len(result["one_way_scenarios"]),
                "interpretation": "Baseline plus feasible one-at-a-time weight perturbations.",
            },
            {
                "metric": "Monte Carlo scenarios",
                "value": len(result["monte_carlo_scenarios"]),
                "interpretation": "Reproducible Dirichlet weight samples.",
            },
            {
                "metric": "Claim boundary",
                "value": critic["claim_boundary"],
                "interpretation": "CRITIC measures statistical information, not stakeholder preference.",
            },
        ]
    )
    provenance_rows = []
    for key, value in summary.items():
        if key in {"one_way_summary", "monte_carlo_summary", "critic_summary"}:
            continue
        provenance_rows.append({"field": key, "value": _excel_safe(value)})
    provenance = pd.DataFrame(provenance_rows)

    correlation = critic["correlation_matrix"].copy()
    correlation.insert(0, "criterion", correlation.index)

    with pd.ExcelWriter(path, engine="openpyxl") as writer:
        critic_summary.to_excel(writer, sheet_name="Summary", index=False)
        critic["criterion_statistics"].to_excel(writer, sheet_name="CRITIC_Weights", index=False)
        correlation.to_excel(writer, sheet_name="CRITIC_Correlation", index=False)
        critic["ranking"].to_excel(writer, sheet_name="CRITIC_Ranking", index=False)
        critic["top_k_comparison"].to_excel(writer, sheet_name="TopK_Comparison", index=False)
        result["baseline_ranking"].to_excel(writer, sheet_name="Baseline_Ranking", index=False)
        result["one_way_scenarios"].to_excel(writer, sheet_name="One_Way_Scenarios", index=False)
        result["monte_carlo_scenarios"].to_excel(writer, sheet_name="Monte_Carlo", index=False)
        result["node_rank_stability"].to_excel(writer, sheet_name="Node_Stability", index=False)
        result["baseline_top_k_stability"].to_excel(writer, sheet_name="Baseline_TopK", index=False)
        provenance.to_excel(writer, sheet_name="Provenance", index=False)

        workbook = writer.book
        header_fill = PatternFill("solid", fgColor="1F4E78")
        header_font = Font(color="FFFFFF", bold=True)
        caution_fill = PatternFill("solid", fgColor="FCE4D6")
        for worksheet in workbook.worksheets:
            worksheet.freeze_panes = "A2"
            worksheet.sheet_view.showGridLines = False
            if worksheet.max_row >= 1 and worksheet.max_column >= 1:
                for cell in worksheet[1]:
                    cell.fill = header_fill
                    cell.font = header_font
                    cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
                worksheet.auto_filter.ref = worksheet.dimensions
            for column_index in range(1, worksheet.max_column + 1):
                letter = get_column_letter(column_index)
                longest = 0
                for cell in worksheet[letter][: min(worksheet.max_row, 250)]:
                    text = "" if cell.value is None else str(cell.value)
                    longest = max(longest, len(text))
                worksheet.column_dimensions[letter].width = min(max(longest + 2, 11), 42)
            for row in worksheet.iter_rows(min_row=2):
                for cell in row:
                    cell.alignment = Alignment(vertical="top", wrap_text=False)
                    if isinstance(cell.value, float):
                        cell.number_format = "0.000000"
        summary_sheet = workbook["Summary"]
        for cell in summary_sheet[summary_sheet.max_row]:
            cell.fill = caution_fill
        summary_sheet.column_dimensions["A"].width = 42
        summary_sheet.column_dimensions["B"].width = 48
        summary_sheet.column_dimensions["C"].width = 72
        workbook.calculation.fullCalcOnLoad = True
        workbook.calculation.forceFullCalc = True


def write_analysis_result(
    result: Mapping[str, Any],
    *,
    input_path: Path,
    year: int | None,
    output_dir: Path | None = None,
    provenance: Mapping[str, Any] | None = None,
) -> Path:
    """Write auditable sensitivity outputs and return their directory."""
    source = Path(input_path).resolve()
    if output_dir is None:
        stamp = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S%fZ")
        output_dir = SENSITIVITY_RUNTIME_DIR / stamp
    output = Path(output_dir).resolve()
    if output.exists() and any(output.iterdir()):
        raise FileExistsError(f"Refusing to overwrite non-empty sensitivity output directory: {output}")
    output.mkdir(parents=True, exist_ok=True)
    input_sha256 = _sha256_file(source)
    expected_snapshot = str((provenance or {}).get("source_snapshot_sha256", "")).strip().lower()
    if expected_snapshot and input_sha256 != expected_snapshot:
        raise DLIWeightSensitivityError(
            "The sensitivity source changed after it was loaded. No report was published; run the analysis again."
        )
    result["baseline_ranking"].to_csv(output / "baseline_dli_ranking.csv", index=False)
    result["one_way_scenarios"].to_csv(output / "one_way_weight_scenarios.csv", index=False)
    result["monte_carlo_scenarios"].to_csv(output / "monte_carlo_weight_scenarios.csv", index=False)
    result["node_rank_stability"].to_csv(output / "node_rank_stability.csv", index=False)
    result["baseline_top_k_stability"].to_csv(output / "baseline_top_k_stability.csv", index=False)
    result["critic"]["criterion_statistics"].to_csv(
        output / "critic_criterion_statistics.csv", index=False
    )
    critic_correlation = result["critic"]["correlation_matrix"].copy()
    critic_correlation.insert(0, "criterion", critic_correlation.index)
    critic_correlation.to_csv(output / "critic_correlation_matrix.csv", index=False)
    result["critic"]["ranking"].to_csv(output / "critic_dli_ranking.csv", index=False)
    result["critic"]["top_k_comparison"].to_csv(
        output / "critic_top_k_comparison.csv", index=False
    )
    critic_metrics = result["critic"]["comparison_metrics"]
    summary = {
        "schema_version": SENSITIVITY_SCHEMA_VERSION,
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "input_path": str(source),
        "input_sha256": input_sha256,
        "year": int(year) if year is not None else None,
        "provenance": dict(provenance or {}),
        "baseline_weights": result["baseline_weights"],
        "top_k": int(result["top_k"]),
        "baseline_integrity": result["baseline_integrity"],
        "run_configuration": result["run_configuration"],
        "critic_summary": {
            "release_id": result["critic"]["release_id"],
            "method": result["critic"]["method"],
            "correlation_method": result["critic"]["correlation_method"],
            "weights": result["critic"]["weights"],
            "comparison_metrics": critic_metrics,
            "claim_boundary": result["critic"]["claim_boundary"],
        },
        "one_way_summary": _metric_summary(result["one_way_scenarios"]),
        "monte_carlo_summary": _metric_summary(result["monte_carlo_scenarios"]),
        "claim_boundary": (
            "This report assesses DLI weight robustness and CRITIC objective information weighting only. "
            "It does not alter the official DLI result, estimate stakeholder preferences, prove causal "
            "intervention effectiveness, or validate the underlying MRIO data."
        ),
    }
    (output / "summary.json").write_text(
        json.dumps(summary, indent=2, ensure_ascii=False, default=_json_default) + "\n",
        encoding="utf-8",
    )
    (output / "report.md").write_text(
        build_markdown_report(
            result,
            input_path=source,
            input_sha256=input_sha256,
            year=year,
            provenance=provenance,
        ),
        encoding="utf-8",
    )
    _write_analysis_workbook(output / "dli_weight_sensitivity_results.xlsx", result, summary)
    output_hashes = {
        filename: _sha256_file(output / filename)
        for filename in _OUTPUT_HASHED_FILES
    }
    metadata = {
        **summary,
        "output_file_sha256": output_hashes,
    }
    (output / "metadata.json").write_text(
        json.dumps(metadata, indent=2, ensure_ascii=False, default=_json_default) + "\n",
        encoding="utf-8",
    )
    if (
        year is not None
        and output.parent == SENSITIVITY_RUNTIME_DIR.resolve()
        and (provenance or {}).get("source_type") == "active_runtime"
    ):
        latest = {
            "schema_version": SENSITIVITY_SCHEMA_VERSION,
            "year": int(year),
            "run_id": output.name,
            "generated_at_utc": summary["generated_at_utc"],
            "input_hashes": dict((provenance or {}).get("input_hashes", {})),
            "source_network_result_cid": (provenance or {}).get("source_network_result_cid"),
            "metadata_path": str((output / "metadata.json").resolve()),
            "metadata_sha256": _sha256_file(output / "metadata.json"),
        }
        SENSITIVITY_RUNTIME_DIR.mkdir(parents=True, exist_ok=True)
        latest_path = SENSITIVITY_RUNTIME_DIR / f"latest_{int(year)}.json"
        temporary = latest_path.with_name(f".{latest_path.name}.tmp")
        temporary.write_text(json.dumps(latest, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
        temporary.replace(latest_path)
    return output


def run_runtime_analysis(
    year: int,
    *,
    top_k: int = 15,
    one_way_deltas: Iterable[float] = DEFAULT_ONE_WAY_DELTAS,
    monte_carlo_samples: int = DEFAULT_MONTE_CARLO_SAMPLES,
    dirichlet_concentration: float = DEFAULT_DIRICHLET_CONCENTRATION,
    random_seed: int = DEFAULT_RANDOM_SEED,
    critic_correlation_method: str = DEFAULT_CRITIC_CORRELATION,
    trigger_source: str = "in_app",
) -> dict[str, Any]:
    """Run and publish a provenance-matched analysis for an active DLI result.

    This callable is shared by the Data Orchestrator's automatic post-Network
    execution and the Streamlit refresh control.  It performs the same checks as
    the command-line runtime route, writes the complete audited output bundle,
    updates the latest pointer, and returns the verified published analysis.
    """

    numeric_year = int(year)
    frame, input_path, provenance = load_active_runtime_ranking(numeric_year)
    provenance = dict(provenance)
    provenance["analysis_trigger"] = str(trigger_source)
    provenance["in_app_execution_release_id"] = IN_APP_EXECUTION_RELEASE_ID
    baseline = deployment_baseline_weights()
    result = analyse_weight_sensitivity(
        frame,
        baseline_weights=baseline,
        top_k=int(top_k),
        one_way_deltas=tuple(float(value) for value in one_way_deltas),
        monte_carlo_samples=int(monte_carlo_samples),
        dirichlet_concentration=float(dirichlet_concentration),
        random_seed=int(random_seed),
        critic_correlation_method=str(critic_correlation_method),
    )
    output = write_analysis_result(
        result,
        input_path=input_path,
        year=numeric_year,
        output_dir=None,
        provenance=provenance,
    )
    published = load_latest_runtime_analysis(
        numeric_year,
        expected_input_hashes=provenance.get("input_hashes"),
        expected_network_result_cid=provenance.get("source_network_result_cid"),
    )
    published["output_dir"] = output
    return published


def load_latest_runtime_analysis(
    year: int,
    *,
    expected_input_hashes: Mapping[str, str] | None = None,
    expected_network_result_cid: str | None = None,
) -> dict[str, Any]:
    """Load a current, provenance-matching sensitivity result for the UI.

    A sensitivity result is displayable only when it was generated from the
    same active validated inputs and the same fulfilled Network/DLI result as
    the current page.  This prevents a stale robustness report being presented
    beside a newer DLI ranking.
    """
    numeric_year = int(year)
    latest_path = SENSITIVITY_RUNTIME_DIR / f"latest_{numeric_year}.json"
    latest = _read_json(latest_path, {})
    if (
        not isinstance(latest, dict)
        or latest.get("year") != numeric_year
        or latest.get("schema_version") != SENSITIVITY_SCHEMA_VERSION
    ):
        raise FileNotFoundError(f"No latest DLI sensitivity result exists for {numeric_year}.")
    run_id = str(latest.get("run_id", "")).strip()
    if not run_id or Path(run_id).name != run_id:
        raise DLIWeightSensitivityError("The latest DLI sensitivity pointer has an invalid run identifier.")
    output_dir = (SENSITIVITY_RUNTIME_DIR / run_id).resolve()
    root = SENSITIVITY_RUNTIME_DIR.resolve()
    if root not in output_dir.parents:
        raise DLIWeightSensitivityError("The latest DLI sensitivity pointer resolves outside the deployment runtime.")
    metadata = _read_json(output_dir / "metadata.json", {})
    if (
        not isinstance(metadata, dict)
        or metadata.get("schema_version") != SENSITIVITY_SCHEMA_VERSION
        or metadata.get("year") != numeric_year
    ):
        raise DLIWeightSensitivityError("DLI sensitivity metadata is unreadable.")
    if _sha256_file(output_dir / "metadata.json") != str(latest.get("metadata_sha256", "")).strip().lower():
        raise DLIWeightSensitivityError("DLI sensitivity metadata does not match the latest-pointer checksum.")
    provenance = metadata.get("provenance", {})
    if not isinstance(provenance, dict) or provenance.get("source_type") != "active_runtime":
        raise DLIWeightSensitivityError("DLI sensitivity provenance is missing.")
    metadata_hashes = _validate_input_hashes(provenance.get("input_hashes"), label="DLI sensitivity provenance")
    if latest.get("input_hashes") != metadata_hashes:
        raise DLIWeightSensitivityError("The latest-pointer input hashes do not match DLI sensitivity metadata.")
    metadata_cid = str(provenance.get("source_network_result_cid", "")).strip().lower()
    if latest.get("source_network_result_cid") != metadata_cid:
        raise DLIWeightSensitivityError("The latest-pointer Network/DLI CID does not match sensitivity metadata.")
    if _active_deployment_input_hashes() != metadata_hashes:
        raise DLIWeightSensitivityError(
            "The sensitivity report does not match the currently active workbook bytes. Re-run Network/DLI and the analysis."
        )
    if expected_input_hashes is not None:
        expected_hashes = _validate_input_hashes(expected_input_hashes, label="Displayed active inputs")
        if metadata_hashes != expected_hashes:
            raise DLIWeightSensitivityError(
                "The displayed sensitivity result was generated from different input workbooks. Re-run the analysis."
            )
    if expected_network_result_cid is not None:
        expected_cid = str(expected_network_result_cid).strip().lower()
        if not _CID_PATTERN.fullmatch(expected_cid) or metadata_cid != expected_cid:
            raise DLIWeightSensitivityError(
                "The displayed sensitivity result was generated from a different Network/DLI result. Re-run the analysis."
            )
    file_hashes = metadata.get("output_file_sha256")
    if not isinstance(file_hashes, Mapping):
        raise DLIWeightSensitivityError("DLI sensitivity output checksums are missing.")
    for filename in _OUTPUT_HASHED_FILES:
        path = output_dir / filename
        expected_hash = str(file_hashes.get(filename, "")).strip().lower()
        if not path.is_file() or not _CID_PATTERN.fullmatch(expected_hash) or _sha256_file(path) != expected_hash:
            raise DLIWeightSensitivityError(
                f"DLI sensitivity output integrity check failed for {filename}. Re-run the analysis."
            )
    snapshot_hash = str(provenance.get("source_snapshot_sha256", "")).strip().lower()
    if not _CID_PATTERN.fullmatch(snapshot_hash) or metadata.get("input_sha256") != snapshot_hash:
        raise DLIWeightSensitivityError("DLI sensitivity source snapshot metadata is invalid.")
    source_path = Path(str(metadata.get("input_path", ""))).resolve()
    content_root = CONTENT_STORE_DIR.resolve()
    if content_root not in source_path.parents or not source_path.is_file() or _sha256_file(source_path) != snapshot_hash:
        raise DLIWeightSensitivityError("The verified Network/DLI source snapshot is unavailable or modified.")
    authoritative, _ = _load_verified_network_content(
        metadata_cid,
        year=numeric_year,
        expected_input_hashes=metadata_hashes,
    )
    if _ranking_snapshot_sha256(authoritative) != str(provenance.get("source_ranking_sha256", "")).strip().lower():
        raise DLIWeightSensitivityError("The verified Network/DLI ranking no longer matches the sensitivity snapshot.")
    report_path = output_dir / "report.md"
    stability_path = output_dir / "baseline_top_k_stability.csv"
    return {
        "output_dir": output_dir,
        "metadata": metadata,
        "report_path": report_path,
        "top_stability_path": stability_path,
        "one_way_path": output_dir / "one_way_weight_scenarios.csv",
        "monte_carlo_path": output_dir / "monte_carlo_weight_scenarios.csv",
        "critic_statistics_path": output_dir / "critic_criterion_statistics.csv",
        "critic_correlation_path": output_dir / "critic_correlation_matrix.csv",
        "critic_ranking_path": output_dir / "critic_dli_ranking.csv",
        "critic_top_k_path": output_dir / "critic_top_k_comparison.csv",
        "workbook_path": output_dir / "dli_weight_sensitivity_results.xlsx",
    }


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(
        description=(
            "Assess DLI ranking robustness using one-way, Monte Carlo and CRITIC objective weighting "
            "without changing the authoritative baseline DLI model."
        )
    )
    source_group = parser.add_mutually_exclusive_group(required=True)
    source_group.add_argument("--input", type=Path, help="DLI ranking CSV or fulfilled Network/DLI JSON result.")
    source_group.add_argument(
        "--runtime-year",
        type=int,
        help="Use the verified content-addressed Network/DLI result for the active deployment year.",
    )
    parser.add_argument(
        "--allow-unmanaged-export",
        action="store_true",
        help=(
            "Allow --input for an explicitly unverified external/export analysis. "
            "Such output is not published to Streamlit as a governed active result."
        ),
    )
    parser.add_argument("--year", type=int, default=None, help="Reference year to record in the report.")
    parser.add_argument("--top-k", type=int, default=15, help="Priority cutoff used for stability metrics (default: 15).")
    parser.add_argument(
        "--one-way-deltas",
        nargs="+",
        type=float,
        default=list(DEFAULT_ONE_WAY_DELTAS),
        help="Positive absolute weight changes, e.g. 0.05 0.10 (default: 0.05 0.10).",
    )
    parser.add_argument(
        "--samples",
        type=int,
        default=DEFAULT_MONTE_CARLO_SAMPLES,
        help=f"Dirichlet Monte Carlo samples (default: {DEFAULT_MONTE_CARLO_SAMPLES}; use 0 to omit).",
    )
    parser.add_argument(
        "--concentration",
        type=float,
        default=DEFAULT_DIRICHLET_CONCENTRATION,
        help=f"Dirichlet concentration around the baseline (default: {DEFAULT_DIRICHLET_CONCENTRATION}).",
    )
    parser.add_argument("--seed", type=int, default=DEFAULT_RANDOM_SEED, help="Reproducible Monte Carlo seed.")
    parser.add_argument(
        "--critic-correlation",
        choices=list(SUPPORTED_CRITIC_CORRELATIONS),
        default=DEFAULT_CRITIC_CORRELATION,
        help=(
            "Correlation used by CRITIC objective weighting "
            f"(default: {DEFAULT_CRITIC_CORRELATION})."
        ),
    )
    parser.add_argument("--output-dir", type=Path, default=None, help="Empty output directory to create.")
    parser.add_argument("--dry-run", action="store_true", help="Validate inputs and print the planned run without writing results.")
    args = parser.parse_args(argv)

    if args.runtime_year is not None:
        frame, input_path, provenance = load_active_runtime_ranking(int(args.runtime_year))
    else:
        if not args.allow_unmanaged_export:
            parser.error(
                "--input is an unverified external/export mode. Add --allow-unmanaged-export "
                "or use --runtime-year after fulfilling Network/DLI."
            )
        input_path = Path(args.input)
        frame = load_dli_ranking(input_path)
        provenance = {
            "source_type": "unmanaged_external_export",
            "source_snapshot_sha256": _sha256_file(input_path),
            "source_ranking_sha256": _ranking_snapshot_sha256(frame),
            "claim_boundary": (
                "Unverified external/export analysis only; it is not bound to active workbooks, "
                "a fulfilled Network/DLI CID, or the Streamlit governed-results view."
            ),
        }
    year = int(args.year) if args.year is not None else (int(args.runtime_year) if args.runtime_year is not None else None)
    baseline = deployment_baseline_weights()
    if args.dry_run:
        print(
            f"Validated {len(frame)} DLI nodes from {input_path}. "
            f"Baseline={baseline}; top_k={args.top_k}; samples={args.samples}; year={year}; "
            f"CRITIC correlation={args.critic_correlation}."
        )
        return 0
    result = analyse_weight_sensitivity(
        frame,
        baseline_weights=baseline,
        top_k=int(args.top_k),
        one_way_deltas=args.one_way_deltas,
        monte_carlo_samples=int(args.samples),
        dirichlet_concentration=float(args.concentration),
        random_seed=int(args.seed),
        critic_correlation_method=str(args.critic_correlation),
    )
    output = write_analysis_result(
        result,
        input_path=input_path,
        year=year,
        output_dir=args.output_dir,
        provenance=provenance,
    )
    print(f"DLI weight-sensitivity results written to {output}")
    critic = result["critic"]
    print(
        "CRITIC weights: "
        + ", ".join(f"{component}={critic['weights'][component]:.6f}" for component in COMPONENTS)
    )
    print(
        "Baseline-to-CRITIC Spearman correlation: "
        f"{float(critic['comparison_metrics']['spearman_rank_correlation']):.6f}; "
        f"top-{int(result['top_k'])} overlap: "
        f"{int(critic['comparison_metrics']['top_k_overlap_count'])}/{int(result['top_k'])}."
    )
    print(f"Read {output / 'report.md'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
