"""Regression tests for the U8 CRITIC objective-weighting extension."""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

import numpy as np
from openpyxl import load_workbook

import dli_weight_sensitivity as sensitivity
from test_dli_weight_sensitivity import fixture_frame


ROOT = Path(__file__).resolve().parent


class CriticObjectiveWeightingTests(unittest.TestCase):
    def setUp(self) -> None:
        self.frame = fixture_frame()

    def test_critic_matches_standard_contrast_conflict_formula(self):
        result = sensitivity.calculate_critic_weights(
            self.frame,
            correlation_method="pearson",
            baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
        )
        matrix = self.frame[["BC_norm", "PR_norm", "CDR_norm", "IC_norm"]].copy()
        matrix.columns = list(sensitivity.COMPONENTS)
        expected_std = matrix.std(ddof=0)
        expected_corr = matrix.corr(method="pearson")
        expected_information = expected_std * (1.0 - expected_corr).sum(axis=1)
        expected_weights = expected_information / expected_information.sum()
        observed = np.array([result["weights"][key] for key in sensitivity.COMPONENTS])
        expected = expected_weights.reindex(sensitivity.COMPONENTS).to_numpy(dtype=float)
        self.assertTrue(np.allclose(observed, expected, atol=1e-12))
        self.assertAlmostEqual(float(observed.sum()), 1.0, places=12)
        self.assertEqual(result["release_id"], "v5.0.17-U8")

    def test_constant_criterion_receives_zero_weight_and_all_constant_is_rejected(self):
        frame = self.frame.copy()
        frame["BC_norm"] = 0.5
        frame["DLI"] = sum(
            sensitivity.DECLARED_BASELINE_WEIGHTS[key] * frame[sensitivity.COMPONENT_COLUMNS[key]]
            for key in sensitivity.COMPONENTS
        )
        result = sensitivity.calculate_critic_weights(
            frame,
            baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
        )
        self.assertAlmostEqual(result["weights"]["BC"], 0.0, places=12)

        constant = frame.copy()
        for column in sensitivity.COMPONENT_COLUMNS.values():
            constant[column] = 0.5
        constant["DLI"] = 0.5
        with self.assertRaises(sensitivity.DLIWeightSensitivityError):
            sensitivity.calculate_critic_weights(constant)

    def test_critic_benchmark_retains_baseline_and_reports_rank_comparison(self):
        result = sensitivity.analyse_weight_sensitivity(
            self.frame,
            baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
            top_k=3,
            monte_carlo_samples=0,
        )
        critic = result["critic"]
        self.assertIn("DLI_CRITIC", critic["ranking"].columns)
        self.assertIn("critic_rank", critic["ranking"].columns)
        self.assertIn("rank_change_vs_baseline", critic["ranking"].columns)
        self.assertEqual(len(critic["ranking"]), len(self.frame))
        self.assertEqual(critic["comparison_metrics"]["top_k_overlap_count"], 3)
        self.assertEqual(set(critic["top_k_comparison"]["node_code"]), {"ARE-a", "BRA-b", "CHN-c"})
        self.assertEqual(result["baseline_weights"], sensitivity.DECLARED_BASELINE_WEIGHTS)

    def test_critic_outputs_and_workbook_are_complete(self):
        result = sensitivity.analyse_weight_sensitivity(
            self.frame,
            baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
            top_k=3,
            monte_carlo_samples=4,
            random_seed=11,
        )
        with tempfile.TemporaryDirectory() as directory:
            root = Path(directory)
            source = root / "ranking.csv"
            self.frame.to_csv(source, index=False)
            output = sensitivity.write_analysis_result(
                result,
                input_path=source,
                year=2017,
                output_dir=root / "results",
                provenance={
                    "source_type": "unmanaged_external_export",
                    "source_snapshot_sha256": sensitivity._sha256_file(source),
                    "source_ranking_sha256": sensitivity._ranking_snapshot_sha256(self.frame),
                },
            )
            for filename in (
                "critic_criterion_statistics.csv",
                "critic_correlation_matrix.csv",
                "critic_dli_ranking.csv",
                "critic_top_k_comparison.csv",
                "dli_weight_sensitivity_results.xlsx",
            ):
                self.assertTrue((output / filename).is_file(), filename)
            metadata = json.loads((output / "metadata.json").read_text(encoding="utf-8"))
            self.assertEqual(metadata["schema_version"], "dli_weight_sensitivity_v3")
            self.assertEqual(metadata["critic_summary"]["release_id"], "v5.0.17-U8")
            self.assertEqual(metadata["critic_summary"]["correlation_method"], "pearson")
            workbook = load_workbook(output / "dli_weight_sensitivity_results.xlsx", read_only=True)
            self.assertEqual(
                workbook.sheetnames,
                [
                    "Summary",
                    "CRITIC_Weights",
                    "CRITIC_Correlation",
                    "CRITIC_Ranking",
                    "TopK_Comparison",
                    "Baseline_Ranking",
                    "One_Way_Scenarios",
                    "Monte_Carlo",
                    "Node_Stability",
                    "Baseline_TopK",
                    "Provenance",
                ],
            )

    def test_optional_spearman_critic_is_reproducible(self):
        first = sensitivity.calculate_critic_weights(
            self.frame,
            correlation_method="spearman",
            baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
        )
        second = sensitivity.calculate_critic_weights(
            self.frame,
            correlation_method="spearman",
            baseline_weights=sensitivity.DECLARED_BASELINE_WEIGHTS,
        )
        self.assertEqual(first["weights"], second["weights"])
        with self.assertRaises(sensitivity.DLIWeightSensitivityError):
            sensitivity.calculate_critic_weights(self.frame, correlation_method="kendall")

    def test_u11_uses_pooled_critic_as_authoritative_dli(self):
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        server = (ROOT / "orchestrator_server.py").read_text(encoding="utf-8")
        launcher = (ROOT / "start_dapp_lifecycle.ps1").read_text(encoding="utf-8")
        version = (ROOT / "VERSION.txt").read_text(encoding="utf-8")
        network = (ROOT / "network_engine.py").read_text(encoding="utf-8")
        self.assertIn("Pooled CRITIC construction", app)
        self.assertIn("no fixed researcher-assigned weights are used", app)
        self.assertIn('RELEASE_IDENTITY["dli_objective_weighting_extension_id"]', server)
        self.assertIn('$ExpectedDliWeighting = Get-RqVersionValue -Key "dli_objective_weighting_extension_id"', launcher)
        self.assertIn('$candidate.dli_objective_weighting_extension -eq $ExpectedDliWeighting', launcher)
        self.assertIn("dli_objective_weighting_extension_id=v5.0.17-U11-pooled-critic-only", version)
        self.assertIn("This module contains no fixed", network)


if __name__ == "__main__":
    unittest.main(verbosity=2)
