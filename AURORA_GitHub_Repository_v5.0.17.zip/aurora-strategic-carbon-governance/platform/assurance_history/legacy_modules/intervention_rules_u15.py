"""Deterministic intervention rule library for the integrated U11 method.

Interventions are generated from the authoritative CRITIC-DLI ranking and,
when available, the SPA-SDA node evidence.  The same validated evidence always
produces the same intervention option.  No language model is called here.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Mapping

import pandas as pd

SECTOR_RULES = {
    "nmm": (
        "Material and process decarbonization",
        "Evaluate lower-carbon or blended cement and aggregate mixes, supplementary cementitious materials, process-energy improvements, and verified supplier intensities.",
    ),
    "i_s": (
        "Material and process decarbonization",
        "Prioritize recycled-content or electric-arc-furnace steel, verified process intensities, and supplier green-steel transition evidence.",
    ),
    "nfm": (
        "Material and process decarbonization",
        "Assess recycled-content non-ferrous metals and lower-carbon smelting sources with verified primary emissions evidence.",
    ),
    "fmp": (
        "Material and process decarbonization",
        "Assess material efficiency, recycled inputs, lower-carbon fabrication energy, and supplier-specific process evidence.",
    ),
    "rpp": (
        "Material substitution",
        "Assess recycled-content plastics and rubber, specification changes, and reduced-material alternatives.",
    ),
    "ppp": (
        "Material substitution",
        "Evaluate recycled-content paper products, demand reduction, certified sourcing, and supplier energy performance.",
    ),
    "ely": (
        "Energy sourcing",
        "Evaluate renewable, certified low-carbon, or efficiency-based electricity interventions associated with this node.",
    ),
    "ele": (
        "Energy sourcing",
        "Evaluate electricity efficiency, renewable procurement, and supplier-level energy-transition requirements.",
    ),
    "gdt": (
        "Energy sourcing",
        "Evaluate lower-carbon gas supply contracts and reduced reliance on gas-derived inputs where technically feasible.",
    ),
    "p_c": (
        "Fuel switching",
        "Evaluate fuel switching away from petroleum and coal-derived inputs toward lower-carbon energy carriers.",
    ),
    "coa": (
        "Fuel switching",
        "Phase down coal-derived inputs and investigate substitute energy sources.",
    ),
    "mvh": (
        "Fleet and equipment",
        "Evaluate fleet electrification, equipment efficiency, utilization, maintenance, and low-carbon procurement requirements.",
    ),
    "ome": (
        "Fleet and equipment",
        "Prioritize energy-efficient machinery, utilization improvements, and supplier technology-transition evidence.",
    ),
    "otn": (
        "Fleet and equipment",
        "Assess lower-carbon transport-equipment alternatives and utilization efficiency.",
    ),
    "chm": (
        "Supplier engagement",
        "Engage chemical-input suppliers on process-emission reduction and lower-carbon formulation alternatives.",
    ),
    "oxt": (
        "Upstream production restructuring",
        "Investigate extraction-related energy, technology, and supplier-network changes affecting the focal-company pathways.",
    ),
    "trd": (
        "Supply-chain governance",
        "Prioritize supplier disclosure, Scope 3 data requirements, and contractual carbon-performance requirements across the trade and distribution layer.",
    ),
    "cns": (
        "Demand and specification governance",
        "Evaluate procurement-volume management, low-carbon specifications, subcontractor disclosure, and production-method requirements.",
    ),
    "obs": (
        "Supply-chain governance",
        "Engage business-services providers on disclosure and decarbonization commitments where the node's structural reach is material.",
    ),
    "otp": (
        "Supply-chain governance",
        "Engage logistics and transport-service providers on route efficiency, fleet decarbonization, and emissions disclosure.",
    ),
    "ofd": (
        "Monitoring and engagement",
        "Monitor relevance to the focal-company procurement mix and request emissions evidence where exposure is material.",
    ),
}
DEFAULT_RULE = (
    "Supplier engagement",
    "Request verified emissions data, reduction commitments, and technology-transition evidence from suppliers represented by this country-sector node.",
)


@dataclass
class Intervention:
    node_code: str
    region: str
    sector: str
    dli_rank: int
    dli_score: float
    category: str
    action: str
    channel: str
    driven_by: str
    spa_relevance_level: str = "Not available"
    temporal_status: str = "Not available"
    dominant_pathway_driver: str = "Not available"
    strategic_classification: str = "CRITIC-DLI priority"
    pathway_participation_share: float = 0.0


def _dominant_metric(row: pd.Series) -> str:
    explicit = str(row.get("dominant_dli_component", "")).strip()
    if explicit:
        descriptions = {
            "BC": "betweenness / network position",
            "PR": "PageRank / recursive structural importance",
            "CDR": "carbon dependency risk",
            "IC": "intervention criticality",
        }
        return descriptions.get(explicit, explicit)

    contributions: dict[str, float] = {}
    for criterion in ("BC", "PR", "CDR", "IC"):
        contribution_column = f"{criterion}_critic_weight_contribution"
        if contribution_column in row:
            contributions[criterion] = float(row[contribution_column])
    if not contributions:
        return "CRITIC-DLI composite evidence"
    return _dominant_metric(pd.Series({"dominant_dli_component": max(contributions, key=contributions.get)}))


def _channel(region: str) -> str:
    return (
        "Direct control (domestic UAE operations)"
        if str(region).upper() == "ARE"
        else "Supplier and supply-chain engagement (outside direct operational control)"
    )


def _driver_instruction(context: Mapping[str, object]) -> str:
    driver = str(context.get("node_dominant_driver", "")).strip().lower()
    status = str(context.get("node_temporal_status", "")).strip().lower()
    relevance = str(context.get("spa_relevance_level", "")).strip()

    if status.startswith("stable") and relevance == "High":
        return (
            " The represented pathways form a persistent carbon burden; act even though no material net temporal deterioration is observed."
        )
    if status == "improving":
        return (
            " Preserve and investigate the mechanisms producing the observed improvement while continuing to address the remaining material pathway burden."
        )
    if driver == "intensity" and status == "worsening":
        return (
            " Give particular attention to direct process intensity, energy mix, and verified supplier-emissions performance."
        )
    if driver == "technology" and status == "worsening":
        return (
            " Give particular attention to changing production relationships, process technology, and upstream network restructuring."
        )
    if driver == "scale" and status == "worsening":
        return (
            " Give particular attention to demand scale, specifications, procurement volume, and avoidable consumption."
        )
    if driver == "composition" and status == "worsening":
        return (
            " Give particular attention to the procurement mix and the distribution of demand among sector-region nodes."
        )
    return ""


def generate_interventions(
    dli_df: pd.DataFrame,
    top_n: int = 15,
    node_evidence: pd.DataFrame | None = None,
) -> list[Intervention]:
    """Generate deterministic interventions from CRITIC-DLI and node evidence."""
    if dli_df.empty:
        return []
    ranking = dli_df.sort_values(
        ["dli_rank", "node_code"] if "dli_rank" in dli_df.columns else ["DLI", "node_code"],
        ascending=[True, True] if "dli_rank" in dli_df.columns else [False, True],
        kind="mergesort",
    ).head(int(top_n))
    evidence_lookup: dict[str, dict] = {}
    if node_evidence is not None and not node_evidence.empty:
        evidence_lookup = (
            node_evidence.drop_duplicates("node_code")
            .set_index("node_code")
            .to_dict(orient="index")
        )

    interventions: list[Intervention] = []
    for ordinal, (_, row) in enumerate(ranking.iterrows(), start=1):
        node = str(row["node_code"])
        context = evidence_lookup.get(node, {})
        category, base_action = SECTOR_RULES.get(str(row["sector"]), DEFAULT_RULE)
        action = base_action + _driver_instruction(context)
        interventions.append(
            Intervention(
                node_code=node,
                region=str(row["region"]),
                sector=str(row["sector"]),
                dli_rank=int(row.get("dli_rank", ordinal)),
                dli_score=float(row["DLI"]),
                category=category,
                action=action,
                channel=_channel(str(row["region"])),
                driven_by=_dominant_metric(row),
                spa_relevance_level=str(context.get("spa_relevance_level", "Not available")),
                temporal_status=str(context.get("node_temporal_status", "Not available")),
                dominant_pathway_driver=str(context.get("node_dominant_driver", "Not available")),
                strategic_classification=str(context.get("strategic_classification", "CRITIC-DLI priority")),
                pathway_participation_share=float(
                    context.get("spa_any_role_participation_share_of_represented", 0.0) or 0.0
                ),
            )
        )
    return interventions


if __name__ == "__main__":
    ranking = pd.read_csv("critic_authoritative_dli_ranking.csv")
    ranking = ranking.loc[pd.to_numeric(ranking.get("year"), errors="coerce") == 2017]
    evidence_path = "spa_sda_critic_dli_node_synthesis.csv"
    try:
        evidence = pd.read_csv(evidence_path)
    except FileNotFoundError:
        evidence = None
    for intervention in generate_interventions(ranking, top_n=15, node_evidence=evidence):
        print(intervention)
