"""Offline regression battery for v5.0.17 LLM-first orchestration.

The suite intentionally uses previously unseen question forms. It verifies that
Auto mode is not a keyword-to-deterministic dispatcher, that requested output
shape is enforced, and that exact project claims remain under deterministic
authority. No Ollama server, blockchain, or operational Excel inputs are
required.
"""
from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path
from unittest import mock

import data_orchestrator as orchestrator
import dual_capability_assistant as ca
import llm_first_orchestrator as lfo
import strategic_assistant as sa


TOP_TEN = "What are the top 10 suggestions will you give to decarbonize the complete supply chain of the focal company?"
EXACT_DLI = "What is the DLI of ARE-nmm in 2017?"
CRITIQUE = "Why might focusing only on the highest-DLI node be a bad long-term strategy?"


class GeneralisingClient:
    model = "llm-first-test-model"

    def __init__(self):
        self.planner_calls = 0
        self.answer_calls = 0

    def chat_json(self, system, user, schema, model=None, num_predict=512, temperature=0.0):
        properties = schema.get("properties", {})
        payload = json.loads(user)
        if "task_kind" in properties:
            self.planner_calls += 1
            question = payload["question"]
            lower = question.casefold()
            if "deployment" in lower or "architecture" in lower:
                return {
                    "task_kind": "system_analysis",
                    "project_context": True,
                    "system_context": True,
                    "evidence_policy": "support",
                    "tool_requests": [],
                    "answer_format": "paragraphs",
                    "requested_count": 0,
                    "requires_exact_project_values": False,
                    "needs_current_information": False,
                    "use_conversation_context": False,
                    "user_goal": "Critically assess the deployed system.",
                    "confidence": 0.95,
                }
            if "top 10" in lower:
                return {
                    "task_kind": "recommendation",
                    "project_context": True,
                    "system_context": False,
                    "evidence_policy": "none",
                    "tool_requests": [],
                    "answer_format": "paragraphs",
                    "requested_count": 0,
                    "requires_exact_project_values": False,
                    "needs_current_information": False,
                    "use_conversation_context": False,
                    "user_goal": "Generate a complete supply-chain decarbonization action portfolio.",
                    "confidence": 0.94,
                }
            if "highest-dli" in lower:
                # Deliberately over-call compute. The guard must downgrade this
                # because the user asks for a critique, not an exact result.
                return {
                    "task_kind": "critique",
                    "project_context": True,
                    "system_context": False,
                    "evidence_policy": "compute",
                    "tool_requests": [{"tool": "dli", "purpose": "Provide optional project context."}],
                    "answer_format": "paragraphs",
                    "requested_count": 0,
                    "requires_exact_project_values": False,
                    "needs_current_information": False,
                    "use_conversation_context": False,
                    "user_goal": "Explain the strategic risks of single-node concentration.",
                    "confidence": 0.91,
                }
            if "dli of" in lower:
                # Deliberately under-call. The hard evidence guard must force
                # the deterministic research path.
                return {
                    "task_kind": "direct_answer",
                    "project_context": True,
                    "system_context": False,
                    "evidence_policy": "none",
                    "tool_requests": [],
                    "answer_format": "paragraphs",
                    "requested_count": 0,
                    "requires_exact_project_values": False,
                    "needs_current_information": False,
                    "use_conversation_context": False,
                    "user_goal": "Answer the question.",
                    "confidence": 0.88,
                }
            return {
                "task_kind": "direct_answer",
                "project_context": False,
                "system_context": False,
                "evidence_policy": "none",
                "tool_requests": [],
                "answer_format": "paragraphs",
                "requested_count": 0,
                "requires_exact_project_values": False,
                "needs_current_information": False,
                "use_conversation_context": False,
                "user_goal": "Answer the user's question directly.",
                "confidence": 0.92,
            }

        if "answer" in properties:
            self.answer_calls += 1
            question = payload["question"]
            lower = question.casefold()
            if "top 10" in lower:
                answer = "\n".join(
                    [
                        "1. Set material-specific embodied-carbon targets, beginning with the categories that dominate procurement exposure.",
                        "2. Redesign specifications to reduce material demand before asking suppliers to improve production efficiency.",
                        "3. Require product-level carbon data and progressively replace sector-average estimates with verified supplier information.",
                        "4. Introduce carbon performance into supplier qualification, tender evaluation, and contract-renewal decisions.",
                        "5. Establish joint decarbonization plans with strategic suppliers, including milestones, responsibilities, and escalation rules.",
                        "6. Expand lower-carbon material substitution while testing quality, availability, and technical compatibility.",
                        "7. Use longer-term purchasing commitments to support supplier investment in cleaner electricity, fuels, and production technology.",
                        "8. Screen regional sourcing alternatives where they can reduce embodied emissions without creating unacceptable capacity or logistics risks.",
                        "9. Integrate carbon, cost, resilience, quality, and delivery constraints into one portfolio-level decision process rather than optimizing carbon alone.",
                        "10. Monitor every intervention through auditable governance records, updated baselines, implementation evidence, and periodic management review.",
                    ]
                )
                return {"answer": answer, "evidence_used": [], "material_uncertainties": ["Implementation feasibility requires supplier-specific assessment."]}
            if "dli of" in lower:
                return {
                    "answer": "ARE-nmm has a validated 2017 DLI of 0.449321 and is ranked first in the supplied project evidence. The value is a governance-screening result rather than proof that an intervention is feasible or cost-effective.",
                    "evidence_used": ["dli"],
                    "material_uncertainties": ["Implementation feasibility is assessed separately."],
                }
            if "interest rates" in lower:
                answer = "Interest rates affect construction firms because they change borrowing costs, project financing, property demand, and the discount rate applied to future cash flows. Higher rates can therefore delay projects and weaken demand even when material and labor conditions are unchanged."
            elif "econometrics" in lower:
                answer = "Machine learning usually emphasizes predictive performance and flexible pattern recognition, whereas econometrics emphasizes identification, uncertainty, and defensible causal interpretation. In practice the two overlap, and the appropriate choice depends on whether the main goal is prediction, explanation, or causal inference."
            elif "skeptical board" in lower:
                answer = "Present the framework as a navigation system rather than an autopilot: deterministic analytics identify where exposure and leverage appear greatest, while managers still decide whether an intervention is technically, commercially, and organizationally viable. The blockchain layer then acts as the flight recorder, preserving which evidence and decisions produced each recommendation."
            elif "all calculations are correct" in lower:
                answer = "Correct calculations can still fail to produce change when incentives are misaligned, data ownership is disputed, suppliers lack capability, managers distrust the model, responsibilities are unclear, or procurement rules reward cost and speed while ignoring carbon. Adoption therefore depends as much on governance and organizational design as on analytical accuracy."
            else:
                answer = "The question can be answered through ordinary model reasoning without invoking a deterministic project calculation. The response should follow the user's requested purpose and make any uncertainty or missing context explicit."
            return {"answer": answer, "evidence_used": [], "material_uncertainties": []}

        if properties.get("answer_type", {}).get("enum") == ["system_meta"]:
            ids = [row["id"] for row in payload.get("curated_system_evidence", [])[:4]]
            return {
                "answer_type": "system_meta",
                "narrative_answer": (
                    "The deployment is useful as a research proof of concept, but production use would require stronger key security, service redundancy, confidential query handling, durable evidence storage, model monitoring, and independent operational governance. These issues arise from the deployment architecture rather than from the carbon calculations themselves, so they should be addressed through production hardening and accountable human oversight."
                ),
                "covered_record_ids": ids,
                "material_limitations_included": True,
            }
        raise AssertionError("Unexpected schema")


class RepairingClient(GeneralisingClient):
    def chat_json(self, system, user, schema, model=None, num_predict=512, temperature=0.0):
        properties = schema.get("properties", {})
        if "answer" in properties:
            payload = json.loads(user)
            self.answer_calls += 1
            if self.answer_calls == 1:
                return {
                    "answer": "1. Improve procurement.\n2. Engage suppliers.\n3. Track carbon.",
                    "evidence_used": [],
                    "material_uncertainties": [],
                }
            answer = "\n".join(
                f"{i}. Supply-chain carbon action {i} should be implemented with a clear owner, rationale, milestone, and verification method."
                for i in range(1, 11)
            )
            return {"answer": answer, "evidence_used": [], "material_uncertainties": []}
        return super().chat_json(system, user, schema, model=model, num_predict=num_predict, temperature=temperature)


class SupportEvidenceClient(GeneralisingClient):
    def chat_json(self, system, user, schema, model=None, num_predict=512, temperature=0.0):
        properties = schema.get("properties", {})
        payload = json.loads(user)
        if "task_kind" in properties:
            self.planner_calls += 1
            return {
                "task_kind": "recommendation",
                "project_context": True,
                "system_context": False,
                "evidence_policy": "support",
                "tool_requests": [
                    {"tool": "hotspots", "purpose": "Identify material emissions exposure."},
                    {"tool": "interventions", "purpose": "Provide evidence-backed action channels."},
                ],
                "answer_format": "numbered_list",
                "requested_count": 5,
                "requires_exact_project_values": False,
                "needs_current_information": False,
                "use_conversation_context": False,
                "user_goal": "Recommend five priorities using project evidence as context.",
                "confidence": 0.96,
            }
        if "answer" in properties:
            self.answer_calls += 1
            answer = "\n".join(
                [
                    "1. Prioritize lower-carbon material specifications because validated hotspot evidence shows that material procurement is a major source of upstream exposure.",
                    "2. Convert intervention options into supplier-specific implementation plans with clear technical and commercial owners.",
                    "3. Use contract criteria and longer-term commitments to give strategic suppliers an incentive to invest in lower-carbon production.",
                    "4. Pair material substitution with demand reduction so the company avoids emissions rather than relying only on cleaner production.",
                    "5. Reassess the portfolio periodically because emissions exposure, supplier readiness, and intervention feasibility can change over time.",
                ]
            )
            return {
                "answer": answer,
                "evidence_used": ["hotspots", "interventions"],
                "material_uncertainties": ["Supplier-specific feasibility remains to be verified."],
            }
        return super().chat_json(system, user, schema, model=model, num_predict=num_predict, temperature=temperature)


class LlmFirstOrchestrationTests(unittest.TestCase):
    def test_top_ten_recommendations_are_llm_reasoned_not_deterministic_dump(self):
        client = GeneralisingClient()
        with (
            mock.patch.object(sa, "answer_question", side_effect=AssertionError("deterministic research must not run")),
            mock.patch.object(sa, "execute_plan", side_effect=AssertionError("support tools were not requested")),
        ):
            result = ca.answer_turn(client, TOP_TEN, mode="auto")
        self.assertEqual(result.route, "general")
        self.assertEqual(result.plan["task_kind"], "recommendation")
        self.assertEqual(result.plan["evidence_policy"], "none")
        self.assertEqual(result.plan["requested_count"], 10)
        self.assertEqual(len(lfo._numbered_items(result.answer)), 10)
        self.assertFalse(result.provenance["quantitative_tools_executed"])
        self.assertNotIn("How carbon accounting is implemented", result.answer)
        self.assertNotIn("Top emission hotspots", result.answer)

    def test_task_count_failure_is_repaired_before_return(self):
        client = RepairingClient()
        result = ca.answer_turn(client, TOP_TEN, mode="auto")
        self.assertEqual(len(lfo._numbered_items(result.answer)), 10)
        self.assertEqual(result.model_metrics["answer"]["status"], "repaired")
        self.assertEqual(client.answer_calls, 2)

    def test_hard_guard_forces_exact_project_result_even_when_model_under_calls(self):
        client = GeneralisingClient()
        evidence = [
            {
                "tool": "dli",
                "parameters": {"year": 2017, "node_code": "ARE-nmm", "top_n": 5},
                "source": "network_engine.py",
                "data": {"year": 2017, "node_code": "ARE-nmm", "DLI": 0.449321, "rank": 1},
            }
        ]
        deterministic = sa.AssistantResult(
            question=EXACT_DLI,
            plan={"scope": "in_scope", "response_mode": "analytical", "tool_calls": [{"tool": "dli", "year": "2017"}]},
            route="compute",
            evidence=evidence,
            answer="ARE-nmm has a validated 2017 DLI of 0.449321 and rank 1.",
        )
        with mock.patch.object(sa, "answer_question", return_value=deterministic) as mocked:
            result = ca.answer_turn(client, EXACT_DLI, mode="auto")
        mocked.assert_called_once()
        self.assertEqual(result.route, "research")
        self.assertEqual(result.plan["evidence_policy"], "compute")
        self.assertTrue(result.provenance["quantitative_tools_executed"])
        self.assertIn("0.449321", result.answer)
        self.assertIn("ARE-nmm", result.answer)

    def test_model_over_call_is_downgraded_for_open_ended_critique(self):
        plan = lfo.plan_question(GeneralisingClient(), CRITIQUE, mode="auto")
        self.assertEqual(plan["task_kind"], "critique")
        self.assertEqual(plan["hard_evidence_guard"]["policy"], "none")
        self.assertEqual(plan["evidence_policy"], "none")
        self.assertFalse(plan["requires_exact_project_values"])

    def test_previously_unseen_general_questions_use_model_reasoning_without_tools(self):
        questions = [
            "Why do interest rates affect construction companies?",
            "Explain the difference between machine learning and econometrics.",
            "Explain this framework to a skeptical board member using an analogy.",
            "What could derail adoption even if all calculations are correct?",
        ]
        client = GeneralisingClient()
        for question in questions:
            with self.subTest(question=question):
                result = ca.answer_turn(client, question, mode="auto")
                self.assertEqual(result.route, "general")
                self.assertEqual(result.evidence, [])
                self.assertGreater(len(result.answer), 80)

    def test_llm_unavailability_does_not_substitute_unrelated_deterministic_answer(self):
        client = sa.make_deterministic_client()
        with mock.patch.object(sa, "answer_question", side_effect=AssertionError("must not run")):
            result = ca.answer_turn(client, TOP_TEN, mode="auto")
        self.assertEqual(result.route, "general")
        self.assertEqual(result.evidence, [])
        self.assertTrue(result.provenance["safe_fallback_used"])
        self.assertNotIn("ARE-nmm", result.answer)

    def test_auto_mode_calls_task_planner_for_unseen_question(self):
        client = GeneralisingClient()
        result = ca.answer_turn(client, "Why do interest rates affect construction companies?", mode="auto")
        self.assertEqual(client.planner_calls, 1)
        self.assertEqual(result.plan["source"], "local_llm")

    def test_research_only_mode_preserves_its_evidence_boundary(self):
        client = GeneralisingClient()
        result = ca.answer_turn(client, "Why do interest rates affect construction companies?", mode="research")
        self.assertEqual(result.route, "research")
        self.assertEqual(result.evidence, [])
        self.assertIn("Use Auto or General chat mode", result.answer)

    def test_validated_tools_can_support_reasoning_without_becoming_the_answer(self):
        question = "Using available project evidence, give five priorities for supply-chain decarbonization."
        evidence = [
            {
                "tool": "hotspots",
                "parameters": {"year": 2017, "top_n": 5},
                "source": "analytics_engine.py",
                "data": {"year": 2017, "summary": "Material procurement is a major upstream exposure."},
            },
            {
                "tool": "interventions",
                "parameters": {"year": 2017, "top_n": 5},
                "source": "intervention_rules.py",
                "data": {"year": 2017, "summary": "Validated action channels are available."},
            },
        ]
        with mock.patch.object(sa, "execute_plan", return_value=evidence):
            result = ca.answer_turn(SupportEvidenceClient(), question, mode="auto")
        self.assertEqual(result.route, "hybrid")
        self.assertEqual([item["tool"] for item in result.evidence], ["hotspots", "interventions"])
        self.assertEqual(len(lfo._numbered_items(result.answer)), 5)
        self.assertNotIn("Deterministic evidence", result.answer)
        self.assertTrue(result.provenance["validated_project_evidence_used"])

    def test_unseen_open_ended_project_questions_do_not_trigger_hard_computation(self):
        questions = [
            "How could incentives undermine supplier decarbonization even when data quality is high?",
            "Write a board-level explanation of why governance matters after the analytics are complete.",
            "Suppose cement is no longer the largest hotspot in the future; how should the strategy adapt?",
            "What organizational capabilities would make the framework easier to adopt?",
            "Compare a portfolio approach with concentrating all effort on one supplier category.",
            "How could procurement teams communicate the model's uncertainty to suppliers?",
        ]
        for question in questions:
            with self.subTest(question=question):
                self.assertEqual(lfo._hard_evidence_requirement(question)["policy"], "none")


    def test_query_orchestrator_stores_llm_first_general_answer_without_deterministic_substitution(self):
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with (
                mock.patch.object(orchestrator, "CONTENT_STORE", root / "content_store"),
                mock.patch.object(orchestrator, "RESULTS_DIR", root / "results"),
                mock.patch.object(orchestrator, "RESULT_INDEX_PATH", root / "runtime" / "result_index.json"),
                mock.patch.object(
                    orchestrator.DataOrchestrator,
                    "_require_current_query_methodology_gate",
                    return_value={
                        "network_2014_cid": "a" * 64,
                        "network_2017_cid": "b" * 64,
                        "aurora_2017_cid": "c" * 64,
                        "input_hashes": {
                            "mrio": "d" * 64,
                            "focal_demand": "e" * 64,
                        },
                    },
                ),
            ):
                service = orchestrator.DataOrchestrator(
                    deployment_path=root / "deployment.json",
                    client=GeneralisingClient(),
                )
                response = service.process_query(
                    requester="0x0000000000000000000000000000000000000001",
                    query_text=TOP_TEN,
                    mode="auto",
                    request_context={"event": "QueryRequested", "request_id": 15},
                )
                self.assertEqual(response.auxiliary["assistant_route"], "general")
                self.assertEqual(response.auxiliary["route_enum"], 1)
                stored = orchestrator.load_content(response.content_hash)
                assistant = stored["payload"]["payload"]["assistant_result"]
                self.assertEqual(assistant["route"], "general")
                self.assertEqual(assistant["plan"]["requested_count"], 10)
                self.assertEqual(len(lfo._numbered_items(assistant["answer"])), 10)
                self.assertFalse(assistant["provenance"]["quantitative_tools_executed"])

    def test_exact_result_guard_covers_unyearred_hotspot_and_footprint_requests(self):
        questions = [
            "Show me the top 10 emissions hotspots.",
            "What is the focal company's upstream footprint?",
            "List the DLI ranking for the focal company.",
            "What intervention is recommended for ARE-nmm?",
            "What was the rank for ARE-nmm?",
        ]
        for question in questions:
            with self.subTest(question=question):
                self.assertEqual(lfo._hard_evidence_requirement(question)["policy"], "compute")

    def test_open_ended_intervention_reasoning_is_not_forced_into_computation(self):
        questions = [
            "What interventions could help cement suppliers decarbonize?",
            "Give ten creative supply-chain carbon ideas for management to evaluate.",
            "How should procurement teams think about supplier incentives?",
            "How should management prioritize decarbonization across the complete supply chain?",
            "Why might the highest DLI node be a bad long-term strategy?",
        ]
        for question in questions:
            with self.subTest(question=question):
                self.assertEqual(lfo._hard_evidence_requirement(question)["policy"], "none")


if __name__ == "__main__":
    unittest.main()
