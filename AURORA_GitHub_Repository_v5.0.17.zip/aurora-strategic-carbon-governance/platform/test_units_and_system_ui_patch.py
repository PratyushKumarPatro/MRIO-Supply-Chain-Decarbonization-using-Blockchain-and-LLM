"""Regression checks for the context-specific unit and public-label patch."""
from __future__ import annotations

import hashlib
import json
import os
import subprocess
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parent
SOLIDITY_SHA256 = json.loads(
    (ROOT / "U19_CONTRACT_LOGIC_DELTA_SHA256.json").read_text(encoding="utf-8")
)["u19_solidity_source_sha256"]


class UnitsAndSystemUIPatchTests(unittest.TestCase):
    def test_sidebar_uses_new_public_label_without_changing_internal_key(self):
        source = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        self.assertIn('"Governance & Audit Control": "Blockchain and LLM-based System"', source)
        self.assertIn("format_func=lambda section: SIDEBAR_DISPLAY_LABELS.get(section, section)", source)
        self.assertIn('elif page == "Governance & Audit Control"', source)

    def test_governance_page_uses_requested_heading(self):
        source = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        self.assertIn(
            'st.title("Blockchain and LLM-based low-carbon supply chain governance and decision support")',
            source,
        )

    def test_context_specific_unit_convention_is_fixed_and_cannot_be_overridden(self):
        source = (ROOT / "streamlit_app" / "ui_units.py").read_text(encoding="utf-8")
        for marker in [
            'MRIO_MONETARY_UNIT = "million USD"',
            'MRIO_EMISSIONS_UNIT = "Mt CO₂"',
            'FOCAL_DEMAND_UNIT = "USD"',
            'FOCAL_EMISSIONS_UNIT = "t CO₂"',
            'CARBON_INTENSITY_UNIT = "t CO₂/USD"',
            'UNIT_RELEASE_ID = "v5.0.17-U3"',
            'performs no numerical rescaling',
        ]:
            self.assertIn(marker, source)
        self.assertNotIn('os.getenv', source)
        env = dict(os.environ)
        env.update(
            {
                "SCIG_MRIO_EMISSIONS_UNIT": "WRONG",
                "SCIG_FOCAL_EMISSIONS_UNIT": "WRONG",
            }
        )
        output = subprocess.check_output(
            [
                sys.executable,
                "-c",
                "import sys; sys.path.insert(0, 'streamlit_app'); import ui_units; print('|'.join([ui_units.MRIO_MONETARY_UNIT, ui_units.MRIO_EMISSIONS_UNIT, ui_units.FOCAL_DEMAND_UNIT, ui_units.FOCAL_EMISSIONS_UNIT]))",
            ],
            cwd=ROOT,
            env=env,
            text=True,
        ).strip()
        self.assertEqual(output, "million USD|Mt CO₂|USD|t CO₂")

    def test_values_tables_and_plots_expose_correct_context_units(self):
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        blockchain = (ROOT / "streamlit_app" / "blockchain_page.py").read_text(encoding="utf-8")
        transaction = (ROOT / "streamlit_app" / "transaction_ui.py").read_text(encoding="utf-8")
        for marker in [
            'Focal-company footprints are reported in {FOCAL_EMISSIONS_UNIT}',
            'Change, 2014–2017 ({FOCAL_EMISSIONS_UNIT})',
            'the focal-company values above are tonnes of CO₂',
            'yaxis_title=f"Embodied-carbon footprint ({FOCAL_EMISSIONS_UNIT})"',
            'xaxis_title=f"Embodied-carbon contribution ({FOCAL_EMISSIONS_UNIT})"',
            'payload.get("economy_wide_context", {})',
            'MRIO_EMISSIONS_UNIT,',
            'f"modelled_full_reallocation_opportunity ({FOCAL_EMISSIONS_UNIT})"',
            'company-demand values, where shown, are in {FOCAL_DEMAND_UNIT}',
            'No company-share parameter or additional demand scaling is applied',
        ]:
            self.assertIn(marker, app)
        self.assertIn('economy-wide final-demand values use {MRIO_MONETARY_UNIT}', blockchain)
        self.assertIn('Company_<year>_USD vectors and total_demand values are expressed in {FOCAL_DEMAND_UNIT}', blockchain)
        self.assertIn('No additional demand scaling is applied by the analytical engine', blockchain)
        self.assertIn('"gas used (gas units)"', transaction)
        self.assertIn('"fee (ETH)"', transaction)

    def test_baseline_footprint_path_uses_uploaded_demand_without_rescaling(self):
        source = (ROOT / "analytics_engine.py").read_text(encoding="utf-8")
        self.assertIn('return float(self.fE @ (self.L @ Y))', source)
        self.assertIn('values = df[col].to_numpy(dtype=float)', source)
        self.assertIn('return tuple(float(value) for value in values)', source)
        footprint_body = source.split('def footprint(self, Y: np.ndarray) -> float:', 1)[1].split('def footprint_by_node', 1)[0]
        loader_body = source.split('def _load_company_y_cached', 1)[1].split('def clear_input_cache', 1)[0]
        for forbidden in ['1_000_000', '1000000', '10 ** 6', '10**6']:
            self.assertNotIn(forbidden, footprint_body)
            self.assertNotIn(forbidden, loader_body)

    def test_obsolete_economy_share_is_not_displayed(self):
        source = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        self.assertNotIn('Share of economy-wide footprint (2017)', source)
        self.assertNotIn("company_share_of_economy_footprint", source)


    def test_company_share_theta_scaling_is_disabled(self):
        assistant = (ROOT / "strategic_assistant.py").read_text(encoding="utf-8")
        app = (ROOT / "streamlit_app" / "app.py").read_text(encoding="utf-8")
        self.assertNotIn("BASELINE_THETA =", assistant)
        self.assertNotIn("scenario_y = company_y *", assistant)
        self.assertIn("Company-share/theta scaling is disabled", assistant)
        self.assertIn("No company-share parameter or additional demand scaling is applied", app)
        self.assertIn("sce.run_scenario_library", app)
        self.assertIn("not a formal intervention recommendation", app)

    def test_runtime_payload_avoids_invalid_mixed_scale_share(self):
        orchestrator = (ROOT / "data_orchestrator.py").read_text(encoding="utf-8")
        engine = (ROOT / "analytics_engine.py").read_text(encoding="utf-8")
        self.assertNotIn('"company_share_of_economy_footprint"', orchestrator)
        self.assertNotIn('"company_share_of_economy_footprint"', engine)
        self.assertIn('"company_demand_total": float(company_y.sum())', orchestrator)
        self.assertIn('"focal_company_footprint": "t CO2"', orchestrator)
        self.assertIn('"economy_wide_footprint": "Mt CO2"', orchestrator)

    def test_solidity_source_matches_reviewed_u19_lifecycle_delta(self):
        data = (ROOT / "assurance_history" / "release_documents" / "U19_StrategicCarbonIntelligenceSystem.sol").read_bytes()
        self.assertEqual(hashlib.sha256(data).hexdigest(), SOLIDITY_SHA256)


if __name__ == "__main__":
    unittest.main(verbosity=2)
