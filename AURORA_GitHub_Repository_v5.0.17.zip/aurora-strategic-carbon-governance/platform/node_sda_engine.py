"""Authoritative producer-node Structural Decomposition Analysis (SDA).

The existing company-level SDA is retained unchanged.  This extension applies
exactly the same four-factor, full 4! permutation-average (Shapley-equivalent)
decomposition to every producer-origin footprint contribution:

    C_j = f_j [L (s * y_total)]_j

For every producer node j:

    Delta C_j = phi_intensity,j + phi_technology,j
                + phi_composition,j + phi_scale,j

The node effects reconcile both row-wise to each node's observed change and
column-wise to the existing company-level SDA effects.  The top-80-percent
hotspot flags are reporting/screening attributes only; they do not alter the
SDA or the network-wide DLI calculation.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import itertools
import json
from pathlib import Path
from typing import Any, Mapping

import numpy as np
import pandas as pd

import sda_engine as sda

NODE_SDA_EXTENSION_ID = "v5.0.17-U16"
NODE_SDA_ALGORITHM_ID = "v5.0.17-U14-four-factor-24-permutation"
FACTOR_NAMES = tuple(sda.FACTOR_NAMES)
ALL_NODES_FILENAME = "node_wise_sda_2014_2017.csv"
HOTSPOTS_FILENAME = "node_wise_sda_hotspots_2014_2017.csv"
WORKBOOK_FILENAME = "NODE_WISE_SDA_2014_2017_RESULTS.xlsx"
METADATA_FILENAME = "node_wise_sda_2014_2017.json"


def _utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def _sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _node_evaluate(base: sda.SDAInputs, comparison: sda.SDAInputs, at_comparison: frozenset[str]) -> np.ndarray:
    f_e = comparison.fE if "intensity" in at_comparison else base.fE
    leontief = comparison.L if "technology" in at_comparison else base.L
    composition = comparison.s if "composition" in at_comparison else base.s
    scale = comparison.y_total if "scale" in at_comparison else base.y_total
    return np.asarray(f_e, dtype=float) * (
        np.asarray(leontief, dtype=float) @ (np.asarray(composition, dtype=float) * float(scale))
    )


def node_sda_decompose(base: sda.SDAInputs, comparison: sda.SDAInputs) -> dict[str, np.ndarray]:
    """Return exact four-factor permutation-average SDA vectors for all nodes."""
    n = len(np.asarray(base.fE))
    for name, values in (
        ("comparison fE", comparison.fE),
        ("base s", base.s),
        ("comparison s", comparison.s),
    ):
        if len(np.asarray(values)) != n:
            raise ValueError(f"{name} length does not match the base node count")
    if np.asarray(base.L).shape != (n, n) or np.asarray(comparison.L).shape != (n, n):
        raise ValueError("SDA Leontief matrices must be square and aligned")

    cache: dict[frozenset[str], np.ndarray] = {}

    def evaluate(coalition: frozenset[str]) -> np.ndarray:
        if coalition not in cache:
            cache[coalition] = _node_evaluate(base, comparison, coalition)
        return cache[coalition]

    totals = {factor: np.zeros(n, dtype=float) for factor in FACTOR_NAMES}
    counts = {factor: 0 for factor in FACTOR_NAMES}
    for permutation in itertools.permutations(FACTOR_NAMES):
        coalition: frozenset[str] = frozenset()
        previous = evaluate(coalition)
        for factor in permutation:
            next_coalition = coalition | {factor}
            current = evaluate(next_coalition)
            totals[factor] += current - previous
            counts[factor] += 1
            coalition = next_coalition
            previous = current

    return {factor: totals[factor] / float(counts[factor]) for factor in FACTOR_NAMES}


def _hotspot_attributes(values: np.ndarray, node_codes: np.ndarray, threshold: float) -> dict[str, np.ndarray | float | int]:
    values = np.asarray(values, dtype=float)
    codes = np.asarray(node_codes).astype(str)
    if len(values) != len(codes):
        raise ValueError("Hotspot values and node codes are not aligned")
    if not np.isfinite(values).all():
        raise ValueError("Hotspot contributions contain non-finite values")
    total = float(values.sum())
    if total <= 0.0:
        shares = np.zeros_like(values)
        ranks = np.arange(1, len(values) + 1, dtype=int)
        cumulative = np.zeros_like(values)
        flags = np.zeros(len(values), dtype=bool)
        return {
            "share": shares,
            "rank": ranks,
            "cumulative_share": cumulative,
            "in_set": flags,
            "set_count": 0,
            "achieved_share": 0.0,
        }

    # Stable deterministic ranking: contribution descending, node code ascending.
    order = np.lexsort((codes, -values))
    sorted_shares = values[order] / total
    sorted_cumulative = np.cumsum(sorted_shares)
    boundary = int(np.searchsorted(sorted_cumulative, float(threshold), side="left"))
    boundary = min(boundary, len(values) - 1)

    shares = values / total
    ranks = np.empty(len(values), dtype=int)
    ranks[order] = np.arange(1, len(values) + 1, dtype=int)
    cumulative = np.empty(len(values), dtype=float)
    cumulative[order] = sorted_cumulative
    flags = np.zeros(len(values), dtype=bool)
    flags[order[: boundary + 1]] = True
    return {
        "share": shares,
        "rank": ranks,
        "cumulative_share": cumulative,
        "in_set": flags,
        "set_count": int(boundary + 1),
        "achieved_share": float(sorted_cumulative[boundary]),
    }


@dataclass(frozen=True)
class NodeSDAResult:
    base_year: int
    comparison_year: int
    threshold: float
    frame: pd.DataFrame
    company_effects: dict[str, float]
    company_base_footprint: float
    company_comparison_footprint: float
    maximum_row_residual: float
    maximum_column_residual: float
    base_hotspot_count: int
    comparison_hotspot_count: int
    base_hotspot_coverage: float
    comparison_hotspot_coverage: float
    company_effect_source: str

    @property
    def node_count(self) -> int:
        return int(len(self.frame))

    @property
    def hotspot_frame(self) -> pd.DataFrame:
        mask = self.frame["in_comparison_top_80_hotspot_set"].astype(bool)
        return self.frame.loc[mask].sort_values(
            ["comparison_hotspot_rank", "node_code"], kind="mergesort"
        ).reset_index(drop=True)


def compute_node_wise_sda(
    base_model: Any,
    base_demand: np.ndarray,
    comparison_model: Any,
    comparison_demand: np.ndarray,
    *,
    hotspot_threshold: float = 0.80,
    authoritative_company_effects: Mapping[str, float] | None = None,
) -> NodeSDAResult:
    """Compute four-factor SDA for every producer-origin footprint node."""
    if not 0.0 < float(hotspot_threshold) <= 1.0:
        raise ValueError("hotspot_threshold must lie in (0, 1]")

    base_codes = np.asarray(base_model.node_codes).astype(str)
    comparison_codes = np.asarray(comparison_model.node_codes).astype(str)
    if not np.array_equal(base_codes, comparison_codes):
        raise ValueError("Base and comparison MRIO node-code order differs")
    base_regions = np.asarray(base_model.regions).astype(str)
    comparison_regions = np.asarray(comparison_model.regions).astype(str)
    base_sectors = np.asarray(base_model.sectors).astype(str)
    comparison_sectors = np.asarray(comparison_model.sectors).astype(str)
    if not np.array_equal(base_regions, comparison_regions) or not np.array_equal(base_sectors, comparison_sectors):
        raise ValueError("Base and comparison MRIO metadata order differs")

    base_inputs = sda.SDAInputs.from_year(base_model, np.asarray(base_demand, dtype=float))
    comparison_inputs = sda.SDAInputs.from_year(
        comparison_model, np.asarray(comparison_demand, dtype=float)
    )
    effects = node_sda_decompose(base_inputs, comparison_inputs)
    base_contribution = _node_evaluate(base_inputs, comparison_inputs, frozenset())
    comparison_contribution = _node_evaluate(
        base_inputs, comparison_inputs, frozenset(FACTOR_NAMES)
    )
    observed_change = comparison_contribution - base_contribution
    effect_matrix = np.column_stack([effects[factor] for factor in FACTOR_NAMES])
    row_residual = effect_matrix.sum(axis=1) - observed_change

    company_effects = {factor: float(effects[factor].sum()) for factor in FACTOR_NAMES}
    if authoritative_company_effects is None:
        comparison_company_effects = {
            factor: float(value)
            for factor, value in sda.sda_decompose(base_inputs, comparison_inputs).items()
        }
        company_effect_source = "independent runtime recomputation"
    else:
        comparison_company_effects = {
            factor: float(authoritative_company_effects[factor])
            for factor in FACTOR_NAMES
        }
        company_effect_source = "authoritative company-level SDA supplied by orchestrator"
    column_residuals = {
        factor: company_effects[factor] - comparison_company_effects[factor]
        for factor in FACTOR_NAMES
    }

    base_footprint = float(base_contribution.sum())
    comparison_footprint = float(comparison_contribution.sum())
    scale = max(abs(base_footprint), abs(comparison_footprint), 1.0)
    tolerance = max(1e-8, scale * 1e-9)
    if float(np.max(np.abs(row_residual))) > tolerance:
        raise RuntimeError("Node-wise SDA does not reconcile row-wise to observed node changes")
    if max(abs(value) for value in column_residuals.values()) > tolerance:
        raise RuntimeError("Node-wise SDA does not reconcile column-wise to company-level SDA")
    if abs(base_footprint - float(base_inputs.footprint())) > tolerance:
        raise RuntimeError("Node-wise SDA base footprint does not reconcile to company footprint")
    if abs(comparison_footprint - float(comparison_inputs.footprint())) > tolerance:
        raise RuntimeError("Node-wise SDA comparison footprint does not reconcile to company footprint")

    base_hotspots = _hotspot_attributes(base_contribution, base_codes, float(hotspot_threshold))
    comparison_hotspots = _hotspot_attributes(
        comparison_contribution, base_codes, float(hotspot_threshold)
    )

    absolute_exposure = np.abs(effect_matrix).sum(axis=1)
    dominant_indices = np.argmax(np.abs(effect_matrix), axis=1)
    dominant_driver = np.asarray([FACTOR_NAMES[index] for index in dominant_indices], dtype=object)
    driver_share = np.divide(
        np.max(np.abs(effect_matrix), axis=1),
        absolute_exposure,
        out=np.full(len(base_codes), np.nan, dtype=float),
        where=absolute_exposure > np.finfo(float).eps,
    )
    node_tolerance = max(1e-12, float(np.max(absolute_exposure)) * 1e-10)
    dominant_driver[absolute_exposure <= node_tolerance] = ""
    dominant_family = np.asarray(
        [
            "intensity"
            if driver == "intensity"
            else "production_structure"
            if driver == "technology"
            else "demand"
            if driver in {"composition", "scale"}
            else ""
            for driver in dominant_driver
        ],
        dtype=object,
    )
    temporal_status = np.select(
        [
            absolute_exposure <= node_tolerance,
            np.abs(observed_change) <= node_tolerance,
            observed_change > node_tolerance,
        ],
        ["stable/no material change", "stable net/offsetting drivers", "worsening"],
        default="improving",
    )
    has_offsetting = (np.min(effect_matrix, axis=1) < -node_tolerance) & (
        np.max(effect_matrix, axis=1) > node_tolerance
    )

    # Decision interpretation retains every signed effect.  The absolute-value
    # dominant driver remains a descriptive temporal statistic, while the
    # primary adverse driver is the largest positive contribution that an
    # intervention would normally seek to reduce.  The primary beneficial
    # driver is the most negative contribution and should normally be preserved.
    positive_matrix = np.where(effect_matrix > node_tolerance, effect_matrix, 0.0)
    negative_matrix = np.where(effect_matrix < -node_tolerance, effect_matrix, 0.0)
    adverse_sum = positive_matrix.sum(axis=1)
    beneficial_sum = negative_matrix.sum(axis=1)
    adverse_indices = np.argmax(positive_matrix, axis=1)
    beneficial_indices = np.argmin(negative_matrix, axis=1)
    primary_adverse_value = positive_matrix[np.arange(len(base_codes)), adverse_indices]
    primary_beneficial_value = negative_matrix[np.arange(len(base_codes)), beneficial_indices]
    primary_adverse_driver = np.asarray(
        [FACTOR_NAMES[index] if primary_adverse_value[row] > node_tolerance else ""
         for row, index in enumerate(adverse_indices)], dtype=object
    )
    primary_beneficial_driver = np.asarray(
        [FACTOR_NAMES[index] if primary_beneficial_value[row] < -node_tolerance else ""
         for row, index in enumerate(beneficial_indices)], dtype=object
    )
    adverse_concentration = np.divide(
        primary_adverse_value, adverse_sum,
        out=np.full(len(base_codes), np.nan, dtype=float),
        where=adverse_sum > node_tolerance,
    )
    beneficial_concentration = np.divide(
        np.abs(primary_beneficial_value), np.abs(beneficial_sum),
        out=np.full(len(base_codes), np.nan, dtype=float),
        where=np.abs(beneficial_sum) > node_tolerance,
    )
    secondary_adverse_drivers: list[str] = []
    secondary_beneficial_drivers: list[str] = []
    driver_pattern: list[str] = []
    for row in range(len(base_codes)):
        positives = [
            (FACTOR_NAMES[index], float(effect_matrix[row, index]))
            for index in range(len(FACTOR_NAMES))
            if effect_matrix[row, index] > node_tolerance
        ]
        negatives = [
            (FACTOR_NAMES[index], float(effect_matrix[row, index]))
            for index in range(len(FACTOR_NAMES))
            if effect_matrix[row, index] < -node_tolerance
        ]
        positives.sort(key=lambda item: (-item[1], item[0]))
        negatives.sort(key=lambda item: (item[1], item[0]))
        secondary_adverse_drivers.append(
            "; ".join(f"{name}:{value:.12g}" for name, value in positives[1:])
        )
        secondary_beneficial_drivers.append(
            "; ".join(f"{name}:{value:.12g}" for name, value in negatives[1:])
        )
        if not positives and not negatives:
            pattern = "no material driver"
        elif positives and negatives:
            pattern = "offsetting adverse and beneficial drivers"
        elif positives:
            pattern = (
                "concentrated adverse driver"
                if float(adverse_concentration[row]) >= 0.60
                else "multi-driver adverse change"
            )
        else:
            pattern = (
                "concentrated beneficial driver"
                if float(beneficial_concentration[row]) >= 0.60
                else "multi-driver beneficial change"
            )
        driver_pattern.append(pattern)

    frame = pd.DataFrame(
        {
            "node_code": base_codes,
            "region": base_regions,
            "sector": base_sectors,
            "base_year": int(base_model.year),
            "comparison_year": int(comparison_model.year),
            "base_footprint_contribution_tco2": base_contribution,
            "comparison_footprint_contribution_tco2": comparison_contribution,
            "node_footprint_change_tco2": observed_change,
            "base_share_of_company_footprint": base_hotspots["share"],
            "comparison_share_of_company_footprint": comparison_hotspots["share"],
            "base_hotspot_rank": base_hotspots["rank"],
            "comparison_hotspot_rank": comparison_hotspots["rank"],
            "base_cumulative_hotspot_share": base_hotspots["cumulative_share"],
            "comparison_cumulative_hotspot_share": comparison_hotspots["cumulative_share"],
            "in_base_top_80_hotspot_set": base_hotspots["in_set"],
            "in_comparison_top_80_hotspot_set": comparison_hotspots["in_set"],
            **{
                f"node_delta_{factor}": effects[factor] for factor in FACTOR_NAMES
            },
            "node_delta_demand": effects["composition"] + effects["scale"],
            "node_absolute_driver_exposure": absolute_exposure,
            "node_dominant_driver": dominant_driver,
            "node_dominant_driver_family": dominant_family,
            "node_driver_dominance_share": driver_share,
            "node_primary_adverse_driver": primary_adverse_driver,
            "node_primary_adverse_effect_tco2": primary_adverse_value,
            "node_secondary_adverse_drivers": secondary_adverse_drivers,
            "node_total_adverse_effect_tco2": adverse_sum,
            "node_adverse_driver_concentration": adverse_concentration,
            "node_primary_beneficial_driver": primary_beneficial_driver,
            "node_primary_beneficial_effect_tco2": primary_beneficial_value,
            "node_secondary_beneficial_drivers": secondary_beneficial_drivers,
            "node_total_beneficial_effect_tco2": beneficial_sum,
            "node_beneficial_driver_concentration": beneficial_concentration,
            "node_driver_pattern": driver_pattern,
            "node_temporal_status": temporal_status,
            "node_has_offsetting_drivers": has_offsetting,
            "node_sda_reconciliation_residual_tco2": row_residual,
        }
    )
    frame = frame.sort_values(
        ["comparison_hotspot_rank", "node_code"], kind="mergesort"
    ).reset_index(drop=True)

    return NodeSDAResult(
        base_year=int(base_model.year),
        comparison_year=int(comparison_model.year),
        threshold=float(hotspot_threshold),
        frame=frame,
        company_effects=company_effects,
        company_base_footprint=base_footprint,
        company_comparison_footprint=comparison_footprint,
        maximum_row_residual=float(np.max(np.abs(row_residual))),
        maximum_column_residual=float(max(abs(value) for value in column_residuals.values())),
        base_hotspot_count=int(base_hotspots["set_count"]),
        comparison_hotspot_count=int(comparison_hotspots["set_count"]),
        base_hotspot_coverage=float(base_hotspots["achieved_share"]),
        comparison_hotspot_coverage=float(comparison_hotspots["achieved_share"]),
        company_effect_source=company_effect_source,
    )


def _format_workbook(path: Path) -> None:
    from openpyxl import load_workbook
    from openpyxl.styles import Alignment, Font, PatternFill
    from openpyxl.utils import get_column_letter

    workbook = load_workbook(path)
    fill = PatternFill("solid", fgColor="1F4E78")
    font = Font(color="FFFFFF", bold=True)
    for worksheet in workbook.worksheets:
        worksheet.freeze_panes = "A2"
        worksheet.sheet_view.showGridLines = False
        if worksheet.max_row:
            for cell in worksheet[1]:
                cell.fill = fill
                cell.font = font
                cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
            worksheet.auto_filter.ref = worksheet.dimensions
        for index, cells in enumerate(worksheet.columns, start=1):
            width = 10
            for cell in list(cells)[:250]:
                text = "" if cell.value is None else str(cell.value)
                width = max(width, min(44, len(text) + 2))
                if cell.row > 1:
                    cell.alignment = Alignment(vertical="top", wrap_text=True)
            worksheet.column_dimensions[get_column_letter(index)].width = width
    workbook.save(path)


def write_node_sda_artifacts(
    output_dir: str | Path,
    result: NodeSDAResult,
    *,
    input_hashes: Mapping[str, str],
    source_sda_result_cid: str = "",
    node_sda_evidence_cid: str = "",
) -> dict[str, Any]:
    output = Path(output_dir)
    output.mkdir(parents=True, exist_ok=True)
    all_path = output / ALL_NODES_FILENAME
    hotspot_path = output / HOTSPOTS_FILENAME
    workbook_path = output / WORKBOOK_FILENAME
    metadata_path = output / METADATA_FILENAME

    result.frame.to_csv(all_path, index=False)
    result.hotspot_frame.to_csv(hotspot_path, index=False)
    summary = {
        "extension_id": NODE_SDA_EXTENSION_ID,
        "base_year": result.base_year,
        "comparison_year": result.comparison_year,
        "node_count": result.node_count,
        "hotspot_threshold": result.threshold,
        "base_hotspot_count": result.base_hotspot_count,
        "comparison_hotspot_count": result.comparison_hotspot_count,
        "base_hotspot_coverage": result.base_hotspot_coverage,
        "comparison_hotspot_coverage": result.comparison_hotspot_coverage,
        "company_base_footprint_tco2": result.company_base_footprint,
        "company_comparison_footprint_tco2": result.company_comparison_footprint,
        "company_change_tco2": result.company_comparison_footprint - result.company_base_footprint,
        **{f"company_{factor}_effect_tco2": result.company_effects[factor] for factor in FACTOR_NAMES},
        "maximum_row_reconciliation_residual_tco2": result.maximum_row_residual,
        "maximum_column_reconciliation_residual_tco2": result.maximum_column_residual,
        "company_effect_reference": result.company_effect_source,
        "algorithm_id": NODE_SDA_ALGORITHM_ID,
    }
    notes = pd.DataFrame(
        [
            {
                "topic": "Authority",
                "statement": "Node-wise SDA uses the same four-factor, full 24-permutation average as the existing company SDA.",
            },
            {
                "topic": "Reconciliation",
                "statement": "Each node row reconciles to its observed producer-origin footprint change, and each factor column reconciles to the company-level SDA effect.",
            },
            {
                "topic": "Top-80 hotspot set",
                "statement": "The smallest comparison-year producer set reaching at least 80% of the company footprint is a reporting and intervention-target set only; it does not restrict DLI.",
            },
            {
                "topic": "Driver hierarchy",
                "statement": "All signed intensity, technology, composition and scale effects remain authoritative. The largest positive effect is the primary adverse intervention driver; the largest absolute effect remains descriptive only, and negative effects are beneficial/offsetting drivers to preserve.",
            },
        ]
    )
    with pd.ExcelWriter(workbook_path, engine="openpyxl") as writer:
        pd.DataFrame([summary]).to_excel(writer, sheet_name="Summary", index=False)
        result.hotspot_frame.to_excel(writer, sheet_name="Top80_Hotspot_Node_SDA", index=False)
        result.frame.to_excel(writer, sheet_name="All_Node_SDA", index=False)
        notes.to_excel(writer, sheet_name="Methodology_Notes", index=False)
    _format_workbook(workbook_path)

    artifacts = {
        "all_nodes": {
            "filename": all_path.name,
            "sha256": _sha256_file(all_path),
            "row_count": result.node_count,
        },
        "hotspot_nodes": {
            "filename": hotspot_path.name,
            "sha256": _sha256_file(hotspot_path),
            "row_count": int(len(result.hotspot_frame)),
        },
        "workbook": {
            "filename": workbook_path.name,
            "sha256": _sha256_file(workbook_path),
        },
    }
    metadata = {
        **summary,
        "factor_names": list(FACTOR_NAMES),
        "method": "full 4! permutation-average producer-node SDA with signed adverse/beneficial decision interpretation",
        "algorithm_id": NODE_SDA_ALGORITHM_ID,
        "identity": "Delta C_j = sum_g phi_{g,j}; sum_j phi_{g,j} = company phi_g",
        "hotspot_definition": "smallest producer-origin node set reaching at least 80% of the comparison-year focal-company footprint",
        "path_sda_boundary": "Path-level SDA remains a secondary bounded-path mechanism drill-down and is not substituted for this complete node-wise SDA.",
        "dli_boundary": "Node-wise SDA does not enter BC, PR, CDR, IC, CRITIC weights, DLI scores or DLI ranks.",
        "input_hashes": {str(key): str(value) for key, value in input_hashes.items()},
        "source_sda_result_cid": str(source_sda_result_cid),
        "node_sda_evidence_cid": str(node_sda_evidence_cid),
        "generated_at_utc": _utc_now(),
        "artifacts": artifacts,
    }
    temporary = metadata_path.with_name(f".{metadata_path.name}.tmp")
    temporary.write_text(json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    temporary.replace(metadata_path)
    return metadata


def bind_node_sda_metadata(
    output_dir: str | Path,
    source_sda_result_cid: str,
    node_sda_evidence_cid: str,
) -> dict[str, Any]:
    metadata_path = Path(output_dir) / METADATA_FILENAME
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    metadata["source_sda_result_cid"] = str(source_sda_result_cid)
    metadata["node_sda_evidence_cid"] = str(node_sda_evidence_cid)
    temporary = metadata_path.with_name(f".{metadata_path.name}.tmp")
    temporary.write_text(json.dumps(metadata, indent=2, sort_keys=True, allow_nan=False), encoding="utf-8")
    temporary.replace(metadata_path)
    return metadata


def verify_node_sda_artifacts(
    output_dir: str | Path,
    *,
    expected_input_hashes: Mapping[str, str] | None = None,
    expected_source_sda_result_cid: str | None = None,
) -> dict[str, Any]:
    output = Path(output_dir)
    metadata_path = output / METADATA_FILENAME
    if not metadata_path.is_file():
        raise FileNotFoundError("Node-wise SDA metadata is unavailable. Complete the governed SDA request first.")
    metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    if metadata.get("extension_id") != NODE_SDA_EXTENSION_ID:
        raise RuntimeError("Node-wise SDA metadata has an unexpected extension identity")
    if expected_input_hashes is not None and metadata.get("input_hashes") != {
        str(key): str(value) for key, value in expected_input_hashes.items()
    }:
        raise RuntimeError("Node-wise SDA artifacts are stale for the active input workbooks")
    if expected_source_sda_result_cid is not None and str(metadata.get("source_sda_result_cid", "")) != str(expected_source_sda_result_cid):
        raise RuntimeError("Node-wise SDA artifacts are bound to a different SDA result")

    for key, record in metadata.get("artifacts", {}).items():
        filename = str(record.get("filename", ""))
        if not filename or Path(filename).name != filename:
            raise RuntimeError(f"Unsafe node-wise SDA artifact filename for {key}")
        path = output / filename
        if not path.is_file():
            raise FileNotFoundError(f"Node-wise SDA artifact is missing: {filename}")
        if _sha256_file(path) != str(record.get("sha256", "")):
            raise RuntimeError(f"Node-wise SDA artifact failed SHA-256 verification: {filename}")
        if key in {"all_nodes", "hotspot_nodes"}:
            frame = pd.read_csv(path)
            if len(frame) != int(record.get("row_count", -1)):
                raise RuntimeError(f"Node-wise SDA artifact row count is invalid: {filename}")
    return metadata


__all__ = (
    "NODE_SDA_EXTENSION_ID",
    "NODE_SDA_ALGORITHM_ID",
    "FACTOR_NAMES",
    "NodeSDAResult",
    "node_sda_decompose",
    "compute_node_wise_sda",
    "write_node_sda_artifacts",
    "bind_node_sda_metadata",
    "verify_node_sda_artifacts",
    "ALL_NODES_FILENAME",
    "HOTSPOTS_FILENAME",
    "WORKBOOK_FILENAME",
    "METADATA_FILENAME",
)
