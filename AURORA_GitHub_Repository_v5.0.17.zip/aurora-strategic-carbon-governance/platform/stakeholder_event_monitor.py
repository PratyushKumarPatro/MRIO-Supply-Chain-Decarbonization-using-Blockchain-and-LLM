"""Role-aware stakeholder notification monitor for the Strategic Carbon Intelligence & Governance Platform.

The monitor does not change smart-contract execution. It observes the existing
Solidity event logs from the four independently deployed contracts, resolves the
three principal stakeholder identities through the shared Registration contract
and ``deployment.json``, and writes a local, rebuildable notification index.

Analytical and governance lifecycle events are visible to the Regulatory
Authority, MRIO Data Provider, and Focal Company. Query Management events remain
requester-only by default because the query text is emitted on-chain and may be
privacy-sensitive. The blockchain event log remains authoritative; the JSONL
notification file is only a convenience index for the local Streamlit client.
"""
from __future__ import annotations

import argparse
import json
import os
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

from web3 import Web3
from web3._utils.events import get_event_data

NOTIFICATION_FILENAME = "stakeholder_notifications.jsonl"
HEARTBEAT_FILENAME = "stakeholder_event_monitor_heartbeat.json"
SEEN_FILENAME = "stakeholder_notification_seen.json"

ROLE_NAMES = {
    0: "None",
    1: "RegulatoryAuthority",
    2: "MRIODataProvider",
    3: "FocalCompany",
    4: "RegistrationOracle",
    5: "UpstreamAnalyticsOracle",
    6: "GovernanceOracle",
    7: "QueryOracle",
}

PRINCIPAL_ROLE_ACCOUNTS = {
    "RegulatoryAuthority": "regulator",
    "MRIODataProvider": "mrio_provider",
    "FocalCompany": "focal_company",
}

PRINCIPAL_ROLE_CODES = {
    "RegulatoryAuthority": 1,
    "MRIODataProvider": 2,
    "FocalCompany": 3,
}

REQUEST_EVENTS = {
    "RegistrationRequested",
    "MRIODataUpdateRequested",
    "FocalCompanyDemandDataUpdateRequested",
    "MRIOCarbonAccountingRequested",
    "StructuralPathAnalysisRequested",
    "StructuralDecompositionAnalysisRequested",
    "NetworkAnalysisRequested",
    "InterventionProposalRequested",
    "RegionalSourcingOpportunityAnalysisRequested",
    "QueryRequested",
}

COMPLETION_EVENTS = {
    "RegistrationVerified",
    "DataUpdateValidated",
    "MRIOCarbonAccountingComputed",
    "StructuralPathAnalysisCompleted",
    "StructuralDecompositionAnalysisPerformed",
    "NetworkAnalysisCompleted",
    "InterventionProposalFulfilled",
    "RegionalSourcingOpportunityAnalysisCompleted",
    "HotspotRegistered",
    "InterventionProposed",
    "InterventionDecided",
    "QueryFulfilled",
}

FAILURE_EVENTS = {
    "ComputeFailed",
    "NetworkAnalysisFailed",
    "InterventionProposalFailed",
    "RegionalSourcingOpportunityAnalysisFailed",
    "QueryFailed",
}

EVENT_TITLES = {
    "OracleRoleAssigned": "Oracle role assigned",
    "RegistrationRequested": "Stakeholder registration requested",
    "RegistrationVerified": "Stakeholder registration verified",
    "EntityRegistered": "Entity registered",
    "EntityRevoked": "Stakeholder role revoked",
    "MRIODataUpdateRequested": "MRIO data validation requested",
    "FocalCompanyDemandDataUpdateRequested": "Focal-company demand validation requested",
    "DataUpdateValidated": "Source-data validation completed",
    "FocalDemandInvalidated": "Focal-company demand data invalidated",
    "MRIOCarbonAccountingRequested": "MRIO carbon accounting requested",
    "MRIOCarbonAccountingComputed": "MRIO carbon accounting completed",
    "StructuralPathAnalysisRequested": "Structural Path Analysis requested",
    "StructuralPathAnalysisCompleted": "Structural Path Analysis completed",
    "StructuralDecompositionAnalysisRequested": "Structural Decomposition Analysis requested",
    "StructuralDecompositionAnalysisPerformed": "Structural Decomposition Analysis completed",
    "ComputeFailed": "Upstream computation failed",
    "NetworkAnalysisRequested": "Network/DLI analysis requested",
    "NetworkAnalysisCompleted": "Network/DLI analysis completed",
    "NetworkAnalysisFailed": "Network/DLI analysis failed",
    "InterventionProposalRequested": "Intervention governance requested",
    "InterventionProposalFulfilled": "Intervention governance record created",
    "InterventionProposalFailed": "Intervention governance request failed",
    "RegionalSourcingOpportunityAnalysisRequested": "AURORA requested",
    "RegionalSourcingOpportunityAnalysisCompleted": "AURORA completed",
    "RegionalSourcingOpportunityAnalysisFailed": "AURORA failed",
    "HotspotRegistered": "Hotspot registered",
    "InterventionProposed": "Intervention proposed",
    "InterventionDecided": "Intervention decision recorded",
    "QueryRequested": "Strategic-assistant query submitted",
    "QueryFulfilled": "Strategic-assistant query completed",
    "QueryFailed": "Strategic-assistant query failed",
}


def _jsonable(value: Any) -> Any:
    if value is None or isinstance(value, (str, int, float, bool)):
        return value
    if isinstance(value, (bytes, bytearray)):
        return "0x" + bytes(value).hex()
    if hasattr(value, "hex"):
        try:
            text = value.hex()
            return text if str(text).startswith("0x") else "0x" + str(text)
        except Exception:
            pass
    if isinstance(value, dict):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, (list, tuple, set)):
        return [_jsonable(item) for item in value]
    try:
        return {str(key): _jsonable(item) for key, item in dict(value).items()}
    except Exception:
        return str(value)


def _hex(value: Any) -> str:
    material = _jsonable(value)
    return str(material or "")


def _read_json(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def _atomic_write_json(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.tmp")
    temporary.write_text(json.dumps(value, indent=2, default=str), encoding="utf-8")
    temporary.replace(path)


def _event_topic(event_abi: dict[str, Any]) -> str:
    signature = (
        f"{event_abi.get('name', '')}"
        f"({','.join(str(item.get('type', '')) for item in event_abi.get('inputs', []))})"
    )
    return Web3.keccak(text=signature).hex().lower()


def _event_abis(abi: Iterable[dict[str, Any]]) -> dict[str, dict[str, Any]]:
    result: dict[str, dict[str, Any]] = {}
    for item in abi:
        if not isinstance(item, dict) or item.get("type") != "event" or item.get("anonymous"):
            continue
        result[_event_topic(item)] = item
    return result


def _notification_paths(deployment_path: str | Path) -> tuple[Path, Path, Path]:
    runtime = Path(deployment_path).resolve().parent / "runtime"
    runtime.mkdir(parents=True, exist_ok=True)
    return (
        runtime / NOTIFICATION_FILENAME,
        runtime / HEARTBEAT_FILENAME,
        runtime / SEEN_FILENAME,
    )


def load_notifications(
    deployment_path: str | Path,
    *,
    limit: int | None = None,
) -> list[dict[str, Any]]:
    notification_path, _, _ = _notification_paths(deployment_path)
    if not notification_path.is_file():
        return []
    records: list[dict[str, Any]] = []
    for line in notification_path.read_text(encoding="utf-8", errors="replace").splitlines():
        try:
            item = json.loads(line)
        except json.JSONDecodeError:
            continue
        if isinstance(item, dict):
            records.append(item)
    records.sort(key=notification_sort_key)
    if limit is not None and limit >= 0:
        return records[-limit:]
    return records


def notification_sort_key(item: dict[str, Any]) -> tuple[int, int, int]:
    return (
        int(item.get("block_number", 0) or 0),
        int(item.get("transaction_index", 0) or 0),
        int(item.get("log_index", 0) or 0),
    )


def load_seen_state(deployment_path: str | Path) -> dict[str, Any]:
    _, _, seen_path = _notification_paths(deployment_path)
    return _read_json(seen_path)


def mark_notifications_seen(
    deployment_path: str | Path,
    role_name: str,
    records: Iterable[dict[str, Any]],
) -> dict[str, Any]:
    _, _, seen_path = _notification_paths(deployment_path)
    state = _read_json(seen_path)
    keys = [notification_sort_key(item) for item in records]
    if keys:
        state[str(role_name)] = list(max(keys))
        _atomic_write_json(seen_path, state)
    return state


def is_unread(item: dict[str, Any], role_name: str, seen_state: dict[str, Any]) -> bool:
    raw = seen_state.get(role_name, [0, 0, -1])
    try:
        seen_key = tuple(int(value) for value in raw[:3])
    except Exception:
        seen_key = (0, 0, -1)
    return notification_sort_key(item) > seen_key


def _principal_recipients(
    w3: Web3 | None,
    deployment: dict[str, Any],
) -> tuple[list[str], list[str]]:
    """Return configured principal accounts, verified against Registration when possible.

    The guided deployment assigns one known address to each principal role. Once
    Registration is deployed, roleOf is consulted so a revoked or not-yet-approved
    account is not treated as an active recipient. If the registry is temporarily
    unavailable, the configured deployment identities are retained as a resilient
    presentation fallback; the blockchain event itself remains authoritative.
    """

    accounts = deployment.get("accounts", {}) if isinstance(deployment.get("accounts"), dict) else {}
    registry = None
    registration_spec = (deployment.get("contracts") or {}).get("Registration")
    if w3 is not None and isinstance(registration_spec, dict) and registration_spec.get("address"):
        try:
            registry = w3.eth.contract(
                address=registration_spec["address"],
                abi=registration_spec.get("abi", []),
            )
        except Exception:
            registry = None

    roles: list[str] = []
    addresses: list[str] = []
    for role_name, account_key in PRINCIPAL_ROLE_ACCOUNTS.items():
        address = str(accounts.get(account_key, "") or "")
        if not address:
            continue
        active = True
        if registry is not None:
            try:
                active = int(registry.functions.roleOf(address).call()) == PRINCIPAL_ROLE_CODES[role_name]
            except Exception:
                active = True
        if active:
            roles.append(role_name)
            addresses.append(address)
    return roles, addresses


def _account_role(deployment: dict[str, Any], address: str) -> str:
    accounts = deployment.get("accounts", {}) if isinstance(deployment.get("accounts"), dict) else {}
    lowered = str(address or "").lower()
    for role_name, account_key in PRINCIPAL_ROLE_ACCOUNTS.items():
        if str(accounts.get(account_key, "") or "").lower() == lowered:
            return role_name
    for key, role_name in (
        ("registration_oracle", "RegistrationOracle"),
        ("upstream_oracle", "UpstreamAnalyticsOracle"),
        ("governance_oracle", "GovernanceOracle"),
        ("query_oracle", "QueryOracle"),
    ):
        if str(accounts.get(key, "") or "").lower() == lowered:
            return role_name
    return "Unknown"


def _requester_for_query(
    w3: Web3,
    deployment: dict[str, Any],
    request_id: int,
) -> str:
    spec = (deployment.get("contracts") or {}).get("QueryManagement")
    if not isinstance(spec, dict) or not spec.get("address"):
        return ""
    try:
        contract = w3.eth.contract(address=spec["address"], abi=spec["abi"])
        record = contract.functions.getQuery(int(request_id)).call()
        return str(record[0])
    except Exception:
        return ""


def _recipient_policy(
    w3: Web3,
    deployment: dict[str, Any],
    contract_name: str,
    event_name: str,
    args: dict[str, Any],
) -> tuple[list[str], list[str], str]:
    all_roles, all_addresses = _principal_recipients(w3, deployment)

    if contract_name == "QueryManagement":
        requester = str(args.get("requester", "") or "")
        if not requester and args.get("requestId") is not None:
            requester = _requester_for_query(w3, deployment, int(args["requestId"]))
        if requester:
            return [_account_role(deployment, requester)], [requester], "requester-only"
        return [], [], "requester-only"

    if event_name in {"RegistrationRequested", "RegistrationVerified"}:
        requester = str(args.get("requester", "") or "")
        regulator = str((deployment.get("accounts") or {}).get("regulator", "") or "")
        roles = ["RegulatoryAuthority"]
        addresses = [regulator] if regulator else []
        requester_role = _account_role(deployment, requester)
        if requester and requester.lower() not in {value.lower() for value in addresses}:
            roles.append(requester_role)
            addresses.append(requester)
        return roles, addresses, "registration-parties"

    # Every analytical and governance event is intentionally visible to all
    # three principal stakeholders. This includes SPA request/completion events.
    return all_roles, all_addresses, "all-principal-stakeholders"


def _actor_address(args: dict[str, Any]) -> str:
    for key in (
        "requester",
        "decidedBy",
        "assignedBy",
        "registeredBy",
        "revokedBy",
        "verifiedBy",
        "oracle",
    ):
        value = str(args.get(key, "") or "")
        if value:
            return value
    return ""


def _status_for_event(event_name: str, args: dict[str, Any]) -> str:
    if event_name in FAILURE_EVENTS:
        return "Failed"
    if event_name == "DataUpdateValidated":
        return "Completed" if bool(args.get("accepted")) else "Rejected"
    if event_name == "RegistrationVerified":
        return "Completed" if bool(args.get("approved")) else "Rejected"
    if event_name in REQUEST_EVENTS:
        return "Requested"
    if event_name in COMPLETION_EVENTS:
        return "Completed"
    return "Recorded"


def _request_id(args: dict[str, Any]) -> int | None:
    value = args.get("requestId")
    try:
        return int(value) if value is not None else None
    except Exception:
        return None


def _content_reference(args: dict[str, Any]) -> str:
    for key in (
        "resultCID",
        "resultHash",
        "validationHash",
        "verificationCID",
        "errorCID",
        "errorHash",
        "evidenceCID",
        "actionCID",
        "optionCID",
        "dataHash",
    ):
        value = str(args.get(key, "") or "").strip()
        if value:
            return value
    return ""


def _summary(event_name: str, args: dict[str, Any]) -> str:
    parts: list[str] = []
    if args.get("year") is not None:
        parts.append(f"year {int(args['year'])}")
    if args.get("baseYear") is not None:
        text = f"{int(args['baseYear'])}"
        if args.get("comparisonYear") is not None:
            text += f"-{int(args['comparisonYear'])}"
        parts.append(text)
    if args.get("nodeCode"):
        parts.append(f"node {args['nodeCode']}")
    if args.get("requestId") is not None:
        parts.append(f"request #{int(args['requestId'])}")
    if event_name == "DataUpdateValidated":
        parts.append("accepted" if bool(args.get("accepted")) else "rejected")
    if event_name == "RegistrationVerified":
        parts.append("approved" if bool(args.get("approved")) else "rejected")
    if event_name == "InterventionDecided" and args.get("status") is not None:
        labels = {0: "proposed", 1: "approved", 2: "rejected"}
        parts.append(labels.get(int(args["status"]), f"status {args['status']}"))
    return "; ".join(parts) if parts else "On-chain lifecycle event recorded."


def _decode_contract_logs(
    w3: Web3,
    deployment: dict[str, Any],
    contract_name: str,
    spec: dict[str, Any],
    from_block: int,
    to_block: int,
) -> list[dict[str, Any]]:
    address = str(spec.get("address", "") or "")
    abi = spec.get("abi", [])
    if not address or not isinstance(abi, list):
        return []
    topic_map = _event_abis(abi)
    logs = w3.eth.get_logs(
        {
            "fromBlock": int(from_block),
            "toBlock": int(to_block),
            "address": address,
        }
    )
    results: list[dict[str, Any]] = []
    for raw in logs:
        topics = list(raw.get("topics", []) or [])
        if not topics:
            continue
        event_abi = topic_map.get(_hex(topics[0]).lower())
        if event_abi is None:
            continue
        try:
            decoded = get_event_data(w3.codec, event_abi, raw)
            args = _jsonable(decoded.get("args", {}))
        except Exception:
            continue
        results.append(
            {
                "contract": contract_name,
                "contract_address": address,
                "event": str(event_abi.get("name", "Unknown")),
                "args": args if isinstance(args, dict) else {},
                "block_number": int(raw.get("blockNumber", 0) or 0),
                "transaction_index": int(raw.get("transactionIndex", 0) or 0),
                "log_index": int(raw.get("logIndex", 0) or 0),
                "transaction_hash": _hex(raw.get("transactionHash")),
            }
        )
    return results


class StakeholderEventMonitor:
    def __init__(
        self,
        deployment_path: str | Path,
        *,
        rpc_url: str | None = None,
        poll_interval: float = 1.0,
    ) -> None:
        self.deployment_path = Path(deployment_path).resolve()
        self.poll_interval = max(0.25, float(poll_interval))
        self.rpc_url_override = rpc_url
        self.notification_path, self.heartbeat_path, _ = _notification_paths(self.deployment_path)
        self.seen_ids = {
            str(item.get("notification_id", ""))
            for item in load_notifications(self.deployment_path)
            if item.get("notification_id")
        }
        self.block_timestamp_cache: dict[int, tuple[int, str]] = {}

    def _deployment(self) -> dict[str, Any]:
        deployment = _read_json(self.deployment_path)
        if not deployment:
            raise RuntimeError(f"Cannot read deployment state: {self.deployment_path}")
        return deployment

    def _connect(self, deployment: dict[str, Any]) -> Web3:
        rpc_url = self.rpc_url_override or str(
            deployment.get("rpc_url", "http://127.0.0.1:8545")
        )
        w3 = Web3(Web3.HTTPProvider(rpc_url, request_kwargs={"timeout": 20}))
        if not w3.is_connected():
            raise RuntimeError(f"Ganache is not reachable at {rpc_url}")
        expected_chain = deployment.get("chain_id")
        if expected_chain is not None and int(expected_chain) != int(w3.eth.chain_id):
            raise RuntimeError(
                f"Deployment chain {expected_chain} does not match connected chain {w3.eth.chain_id}"
            )
        return w3

    def _block_time(self, w3: Web3, block_number: int) -> tuple[int, str]:
        if block_number not in self.block_timestamp_cache:
            block = w3.eth.get_block(block_number, full_transactions=False)
            timestamp = int(block.get("timestamp", 0) or 0)
            iso = (
                datetime.fromtimestamp(timestamp, tz=timezone.utc).isoformat()
                if timestamp
                else ""
            )
            self.block_timestamp_cache[block_number] = (timestamp, iso)
        return self.block_timestamp_cache[block_number]

    def _record(
        self,
        w3: Web3,
        deployment: dict[str, Any],
        decoded: dict[str, Any],
    ) -> dict[str, Any]:
        event_name = str(decoded["event"])
        args = decoded.get("args", {}) if isinstance(decoded.get("args"), dict) else {}
        roles, addresses, visibility = _recipient_policy(
            w3,
            deployment,
            str(decoded["contract"]),
            event_name,
            args,
        )
        actor = _actor_address(args)
        timestamp, timestamp_utc = self._block_time(w3, int(decoded["block_number"]))
        notification_id = (
            f"{int(w3.eth.chain_id)}:{decoded['transaction_hash']}:{int(decoded['log_index'])}"
        )
        return {
            "notification_schema_version": "1.0",
            "notification_id": notification_id,
            "architecture_version": str(deployment.get("architecture_version", "")),
            "chain_id": int(w3.eth.chain_id),
            "contract": str(decoded["contract"]),
            "contract_address": str(decoded["contract_address"]),
            "event": event_name,
            "title": EVENT_TITLES.get(event_name, event_name),
            "summary": _summary(event_name, args),
            "status": _status_for_event(event_name, args),
            "visibility": visibility,
            "recipient_roles": roles,
            "recipient_addresses": addresses,
            "actor_address": actor,
            "actor_role": _account_role(deployment, actor),
            "request_id": _request_id(args),
            "content_reference": _content_reference(args),
            "args": args,
            "block_number": int(decoded["block_number"]),
            "transaction_index": int(decoded["transaction_index"]),
            "log_index": int(decoded["log_index"]),
            "transaction_hash": str(decoded["transaction_hash"]),
            "block_timestamp": timestamp,
            "block_timestamp_utc": timestamp_utc,
            "indexed_at_utc": datetime.now(timezone.utc).isoformat(),
        }

    def _append(self, records: Iterable[dict[str, Any]]) -> int:
        material = [item for item in records if item.get("notification_id") not in self.seen_ids]
        if not material:
            return 0
        material.sort(key=notification_sort_key)
        self.notification_path.parent.mkdir(parents=True, exist_ok=True)
        with self.notification_path.open("a", encoding="utf-8") as handle:
            for item in material:
                handle.write(json.dumps(item, sort_keys=True, default=str) + "\n")
                self.seen_ids.add(str(item["notification_id"]))
        return len(material)

    def _heartbeat(
        self,
        *,
        status: str,
        deployment: dict[str, Any] | None = None,
        latest_block: int | None = None,
        added: int = 0,
        error: str = "",
    ) -> None:
        payload = {
            "service": "stakeholder-event-monitor",
            "version": "5.0.17",
            "status": status,
            "updated_at_utc": datetime.now(timezone.utc).isoformat(),
            "deployment": str(self.deployment_path),
            "architecture_version": str((deployment or {}).get("architecture_version", "")),
            "latest_block": latest_block,
            "indexed_notifications": len(self.seen_ids),
            "added_last_cycle": int(added),
            "error": error,
        }
        _atomic_write_json(self.heartbeat_path, payload)

    def sync_once(self) -> int:
        deployment = self._deployment()
        w3 = self._connect(deployment)
        latest_block = int(w3.eth.block_number)
        from_block = max(0, int(deployment.get("bootstrap_block", 0) or 0))
        decoded_logs: list[dict[str, Any]] = []
        for contract_name, spec in (deployment.get("contracts") or {}).items():
            if not isinstance(spec, dict):
                continue
            decoded_logs.extend(
                _decode_contract_logs(
                    w3,
                    deployment,
                    str(contract_name),
                    spec,
                    from_block,
                    latest_block,
                )
            )
        records = [self._record(w3, deployment, item) for item in decoded_logs]
        added = self._append(records)
        self._heartbeat(
            status="running",
            deployment=deployment,
            latest_block=latest_block,
            added=added,
        )
        return added

    def run(self) -> None:
        while True:
            try:
                self.sync_once()
            except KeyboardInterrupt:
                self._heartbeat(status="stopped")
                return
            except Exception as exc:
                try:
                    self._heartbeat(status="error", error=str(exc))
                except Exception:
                    pass
            time.sleep(self.poll_interval)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--deployment", default="deployment.json")
    parser.add_argument("--rpc-url", default=None)
    parser.add_argument("--poll-interval", type=float, default=1.0)
    parser.add_argument("--once", action="store_true")
    args = parser.parse_args()

    monitor = StakeholderEventMonitor(
        args.deployment,
        rpc_url=args.rpc_url,
        poll_interval=args.poll_interval,
    )
    if args.once:
        added = monitor.sync_once()
        print(f"Indexed {added} new stakeholder notification(s).")
    else:
        monitor.run()


if __name__ == "__main__":
    main()
